from pathlib import Path
import gzip,hashlib,io,json,tarfile

root=Path(__file__).resolve().parents[1]
work=root/'build/pointer-shape-worktree'
base=root/'build/ci-pointer-reference-ed5beca'
directory=base/'reference'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'pointer-run.json').read_text())
assert run['databaseId']==43692238900 and run['conclusion']=='success'
assert run['headSha']=='ed5beca6703572d287f2dfd9e22dd8a0a87df949'
raw=(directory/'observations.json').read_bytes()
data=json.loads(raw)
summary=json.loads((directory/'rea-summary.json').read_text())
assert data['status']=='complete' and data['family']=='kitty-pointer'
assert data['upstream_commit']=='8e5487e9d4a1dd79c3a769e0ba82326b8ad7c37f'
assert data['case_count']==117 and data['state_count']==555
assert [c['name'] for c in data['cases']]==data['expected_cases']
assert sum(len(c['steps']) for c in data['cases'])==555
assert len(data['controls'])==3 and all(c['passed'] for c in data['controls'])
assert summary['observations_sha256']==sha(raw)
assert summary['exit']['code']==0 and summary['cleanup']['owned_process_group']=='verified'
assert summary['cleanup']['temporary_root']=='removed'
files={p.relative_to(base).as_posix():p.read_bytes() for p in base.rglob('*') if p.is_file()}
files['controller.py']=Path(__file__).read_bytes()
outdir=work/'research/pointer-shape-evidence';outdir.mkdir(exist_ok=True)
archive=outdir/'kitty-reference-ed5beca.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,payload in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(payload);tar.addfile(info,io.BytesIO(payload))
        records.append(dict(path=name,raw_bytes=len(payload),raw_sha256=sha(payload)))
with tarfile.open(archive) as tar:
    for record in records:assert sha(tar.extractfile(record['path']).read())==record['raw_sha256']
manifest=dict(run=run['databaseId'],url=run['url'],fixture_source=run['headSha'],
    upstream_source=data['upstream_commit'],source_sha256=data['source_sha256'],
    compiled_sha256=data['compiled_sha256'],observations_sha256=sha(raw),
    controls=3,cases=117,states=555,rea=summary,
    scope='Independent upstream parser and stack observations only. Nemoterm implementation, Windows cursor rendering and native acceptance remain incomplete.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
        archive_sha256=sha(archive.read_bytes()),records=records))
(work/'research/pointer-shape-reference-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(records=len(records),archive_bytes=archive.stat().st_size,cases=117,states=555)))
