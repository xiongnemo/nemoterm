"""Retain completed hosted reference results as data; never execute products."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

for run_id in sys.argv[1:]:
    base = Path(__file__).resolve().parent/'retained'/run_id
    base.mkdir(parents=True, exist_ok=True)
    for name, endpoint in [('run',f'runs/{run_id}'),
                           ('jobs',f'runs/{run_id}/jobs?per_page=100'),
                           ('artifacts',f'runs/{run_id}/artifacts?per_page=100')]:
        data = subprocess.check_output(['gh','api','repos/xiongnemo/nemoterm/actions/'+endpoint])
        (base/(name+'.json')).write_bytes(data)
    run = json.loads((base/'run.json').read_bytes())
    assert run['status'] == 'completed', 'Refusing unfinished reference run'
    artifacts = json.loads((base/'artifacts.json').read_bytes())['artifacts']
    for artifact in artifacts:
        if not artifact['name'].startswith('regis-reference-'):
            continue
        ident = artifact['id']
        target = base/f'{ident}.zip'
        if not target.exists():
            with target.open('wb') as out:
                subprocess.run(['gh','api',f'repos/xiongnemo/nemoterm/actions/artifacts/{ident}/zip'],
                               stdout=out,check=True)
        receipt = dict(id=ident,bytes=target.stat().st_size,
                       sha256=hashlib.sha256(target.read_bytes()).hexdigest())
        (base/'download-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
        with zipfile.ZipFile(target) as bundle:
            assert bundle.testzip() is None
            data = json.loads(bundle.read('observations.json'))
            assert hashlib.sha256(bundle.read('xterm')).hexdigest() == data['executable_sha256']
            observations = {}
            for name, variants in data['cases'].items():
                row = variants['whole']
                observations[name] = dict(replies=[s['reply_hex'] for s in row['steps']],
                    images=[s['frame']['rgb_sha256'] for s in row['steps']],
                    colours=[s['frame']['colours'] for s in row['steps']],
                    non_black_pixels=[s['frame']['non_black_pixels'] for s in row['steps']])
                if any(word in name for word in ('palette','ownership','scroll','erase')):
                    print(run_id,name,observations[name]['colours'],flush=True)
            rows = [r for variants in data['cases'].values() for r in variants.values()]
            summary = dict(scope='Read-only analysis of upstream evidence; no local product execution.',
                executable_sha256=data['executable_sha256'],fixture_commit=data['fixture_commit'],
                cases=len(data['cases']),processes=len(rows),steps=sum(len(r['steps']) for r in rows),
                completed=data['completed'],all_natural=all(r['exit_code']==0 and not r['forced_cleanup'] for r in rows),
                transport_mismatches=data['transport_mismatches'],control_failures=data['control_failures'],
                observations=observations)
            (base/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
            print(run_id,{k:v for k,v in summary.items() if k!='observations'})
        print(receipt)
