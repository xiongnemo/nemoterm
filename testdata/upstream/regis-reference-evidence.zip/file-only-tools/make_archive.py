"""Package original hosted observations as data without executing a product."""
from pathlib import Path
import hashlib
import json
import zipfile

base = Path(__file__).resolve().parent
entries = {}
for run in sorted((base/'retained').iterdir()):
    for source in sorted(run.iterdir()):
        if source.suffix not in ('.json', '.zip'):
            continue
        entries[f'{run.name}/{source.name}'] = source.read_bytes()
for name in ('retain.py', 'make_archive.py'):
    entries['file-only-tools/'+name] = (base/name).read_bytes()
manifest = dict(scope='Complete original hosted ReGIS reference artifacts and final metadata. No local product execution.',
                files={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
                       for name,data in entries.items()})
entries['MANIFEST.json'] = (json.dumps(manifest,indent=2)+'\n').encode()
target = base.parents[1]/'research/regis-reference-evidence.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
    for name,data in sorted(entries.items()):
        info = zipfile.ZipInfo(name,(2026,11,18,0,0,0))
        info.compress_type = zipfile.ZIP_DEFLATED
        bundle.writestr(info,data)
print(dict(entries=len(entries),bytes=target.stat().st_size,
           sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
