"""Retain the original cloud XTerm bell capture without running a desktop test."""
from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile

root = Path(__file__).resolve().parents[1]
work = root/'build/bell-modes-worktree'
base = root/'build/ci-bell-reference-fd5d160'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
run = json.loads((base/'bell-run.json').read_bytes())
source = run['headSha']
assert source == 'fd5d1605ada039a1c64b66fab1bdd040b4d10a1f'
assert run['databaseId'] == 43719391640 and run['conclusion'] == 'success'
assert run['status'] == 'completed'
artifacts = json.loads((base/'bell-artifacts.json').read_bytes())['artifacts']
artifact, = [a for a in artifacts if a['name'] == 'protocol-reference-bell-modes-'+source]
assert artifact['id'] == 14163772996
assert artifact['id'] == json.loads((base/'reference-download.json').read_bytes())['artifact_id']
b = base/'reference'
assert (b/'upstream-commit.txt').read_text().strip() == '5c75ead9a75d4b2e666ca06fa94503b5766ed93f'
assert (b/'fixture-commit.txt').read_text().strip() == source
raw = (b/'bell-modes-xterm.json').read_bytes()
assert sha(raw) == 'c5a87d9f9ee75d637293e3a6767d86102be622271720e8ee4b704e5727c9b6b4'
data = json.loads(raw)
assert data['completed'] and len(data['cases']) == 112
assert sum(len(c['steps']) for c in data['cases'].values()) == 192
assert len(data['literal_controls']) == 3
assert data['executable_sha256'] == (b/'executable-sha256.txt').read_text().split()[0]
entries = {}
for name in ['tests/xterm_bell_modes_oracle.py', 'tests/xterm_locator_oracle.py',
             '.github/workflows/protocol-reference.yml']:
    content = subprocess.check_output(['git','show',source+':'+name],cwd=work)
    if name == 'tests/xterm_bell_modes_oracle.py': assert sha(content) == data['fixture_sha256']
    entries['source/'+name] = content
for line in (b/'bell-source-sha256.txt').read_text().splitlines():
    digest, name = line.split(None,1)
    assert sha((b/'bell-source'/Path(name).name).read_bytes()) == digest
for name, case in data['cases'].items():
    assert case['completed'] and case['exit_code'] == 0 and not case['stderr'], name
    assert case['cell_pixels'] == [6,13]
    for step in case['steps']:
        wire = bytes.fromhex(step['wire_with_barrier_hex'])
        assert wire.endswith(b'\x1b[0n')
        assert wire[:-4].hex() == step['reply_hex']
        for key in ('window_before','window_after'):
            state = step[key]
            assert bool(state['hint_flags'] & 256) == state['urgency']
            assert state['above_other'] == (state['root_stack'].index(case['shell_window']) >
                                           state['root_stack'].index(case['other_window']))
            assert state['term_focused'] == (state['focus'] in (case['shell_window'],case['viewport_window']))
off = data['cases']['00-physical-off']['steps'][0]['window_after']
on = data['cases']['00-physical-on']['steps'][0]['window_after']
focus = data['cases']['00-physical-on']['steps'][1]['window_after']
assert not off['urgency'] and not off['above_other'] and not off['term_focused']
assert on['urgency'] and on['above_other'] and not on['term_focused']
assert not focus['urgency'] and focus['term_focused']
for p in base.rglob('*'):
    if p.is_file(): entries[p.relative_to(base).as_posix()] = p.read_bytes()
entries['source/retain-bell-reference.py'] = Path(__file__).read_bytes()
archive = work/'research/bell-modes-reference.tar.gz'
records = []
with archive.open('xb') as out, gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz, \
     tarfile.open(fileobj=gz,mode='w|') as tar:
    for name, content in sorted(entries.items()):
        info = tarfile.TarInfo(name); info.size = len(content)
        tar.addfile(info,io.BytesIO(content))
        records.append(dict(path=name,raw_bytes=len(content),raw_sha256=sha(content)))
with tarfile.open(archive,'r|gz') as tar:
    for member, record in zip(tar,records,strict=True):
        assert member.name == record['path'] and sha(tar.extractfile(member).read()) == record['raw_sha256']
manifest = dict(source=source,run=run['databaseId'],artifact_id=artifact['id'],
    cases=112,steps=192,literal_controls=3,natural_exits=112,raw_sha256=sha(raw),
    scope='Independent XTerm observations, including raw urgency/focus/stacking; does not certify Windows behavior.',
    bundle=dict(path=archive.relative_to(work).as_posix(),bytes=archive.stat().st_size,
                sha256=sha(archive.read_bytes()),records=records))
(work/'research/bell-modes-reference-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Retained',len(records),'records,',archive.stat().st_size,'bytes; 112 cases / 192 steps')
