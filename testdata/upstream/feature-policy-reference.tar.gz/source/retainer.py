"""Retain the unchanged upstream OSC 60/61/62 observations before implementation."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/feature-policy-worktree'
base=root/'build/ci-feature-policy-reference-1a77a76';source='1a77a76efff0f95408085f700bce983be69ee6ae'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'feature-policy-run.json').read_bytes())
assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(43727943696,source,'completed','success')
artifacts=json.loads((base/'feature-policy-artifacts.json').read_bytes())['artifacts']
receipt=json.loads((base/'reference-download.json').read_bytes())
artifact=next(a for a in artifacts if a['id']==receipt['artifact_id'])
assert artifact['name']=='protocol-reference-feature-policy-'+source and receipt['source']==source
reference=base/'reference';raw=(reference/'feature-policy-xterm.json').read_bytes();data=json.loads(raw)
assert sha(raw)=='84990aadc68e758f926f703f279ceb52d039ed94f96d307465e46b6ac3b4e865'
assert data['completed'] and data['version']=='XTerm(412)' and len(data['profiles'])==20
assert (reference/'upstream-commit.txt').read_text().strip()=='5c75ead9a75d4b2e666ca06fa94503b5766ed93f'
assert (reference/'fixture-commit.txt').read_text().strip()==source
assert (reference/'executable-sha256.txt').read_text().split()[0]==data['executable_sha256']
streams=0;baseline=data['profiles']['default']['cases']
for name,profile in data['profiles'].items():
    assert profile['completed'] and profile['exit_code']==0 and not profile['forced_cleanup'] and not profile['stderr']
    assert len(profile['cases'])==105
    for key,case in profile['cases'].items():
        assert case['sequence_hex']==baseline[key]['sequence_hex']
        assert bytes.fromhex(case['input_with_barrier_hex'])==bytes.fromhex(case['sequence_hex'])+b'\x1b F\x1b[5n'
        assert bytes.fromhex(case['wire_with_barrier_hex'])==bytes.fromhex(case['reply_hex'])+b'\x1b[0n'
        streams+=1
    assert json.loads((reference/'feature-policy-xterm'/name/'observed.json').read_bytes())==profile
assert streams==2100 and len(data['literal_controls'])==3
for line in (reference/'feature-policy-source-sha256.txt').read_text().splitlines():
    checksum,path=line.split(maxsplit=1)
    assert sha((reference/'feature-policy-source'/Path(path).name).read_bytes())==checksum
entries={'source/retainer.py':Path(__file__).read_bytes()}
for name in ('tests/xterm_feature_policy_oracle.py','tests/xterm_locator_oracle.py','.github/workflows/protocol-reference.yml'):
    entries['source/'+name]=subprocess.check_output(['git','show',source+':'+name],cwd=work)
assert sha(entries['source/tests/xterm_feature_policy_oracle.py'])==data['fixture_sha256']
for p in base.rglob('*'):
    if p.is_file():entries[p.relative_to(base).as_posix()]=p.read_bytes()
archive=work/'research/feature-policy-reference.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,blob in sorted(entries.items()):
        info=tarfile.TarInfo(name);info.size=len(blob);tar.addfile(info,io.BytesIO(blob))
        records.append(dict(path=name,raw_bytes=len(blob),raw_sha256=sha(blob)))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path'] and sha(tar.extractfile(member).read())==record['raw_sha256']
manifest=dict(fixture_source=source,run=43727943696,conclusion='success',artifact_id=artifact['id'],
    upstream_commit='5c75ead9a75d4b2e666ca06fa94503b5766ed93f',raw_reference_sha256=sha(raw),
    profiles=20,cases_per_profile=105,exact_streams=streams,literal_controls=data['literal_controls'],natural_cleanup=True,
    scope='Independent unmodified XTerm resource-policy capture only. No Nemoterm implementation or product acceptance is inferred.',
    bundle=dict(path=archive.relative_to(work).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),records=records))
(work/'research/feature-policy-reference-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Retained',len(records),'records,',archive.stat().st_size,'bytes;',streams,'raw reply streams')
