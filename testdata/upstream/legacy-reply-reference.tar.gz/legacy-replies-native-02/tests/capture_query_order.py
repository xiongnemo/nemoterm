"""Diagnose reply ordering separately; preserve the original full-capture failure."""
from protocol_oracle_window import run
from legacy_reply_cases import RESET,FINISH,CSI
import os
os.environ['NEMOTERM_TEST_INPUT_CP']='28591'
run('legacy-query-order',[
    ('normal-cpr',RESET+CSI+'6n'+FINISH,None),
    ('embedded-enq-cpr',RESET+CSI+'6\x05n'+FINISH,None)],
    profile=dict(NemoRenderer=0,NemoTabs=0,WarnOnClose=0,Answerback=''),
    font='SarasaTermSC Nerd Font Light',source_reference='Capture only; compare ordered replies independently')
