#!/bin/sh
set -eu
output=/mnt/c/Users/nemo/Documents/Projects/nemoterm/build/legacy-replies-01
source_dir=$(mktemp -d /tmp/nemoterm-legacy-reference-XXXXXX)
printf '%s\n' "$source_dir" > "$output/source-directory.txt"
git -C "$source_dir" init > "$output/git.log" 2>&1
git -C "$source_dir" fetch --depth 1 https://github.com/ThomasDickey/xterm-snapshots.git 5c75ead9a75d4b2e666ca06fa94503b5766ed93f >> "$output/git.log" 2>&1
git -C "$source_dir" checkout --detach FETCH_HEAD >> "$output/git.log" 2>&1
git -C "$source_dir" rev-parse HEAD > "$output/upstream-commit.txt"
cd "$source_dir"
./configure > "$output/configure.log" 2>&1
make -j4 > "$output/make.log" 2>&1
git diff --exit-code > "$output/source-diff.txt"
./xterm -version > "$output/version.txt"
sha256sum xterm > "$output/executable-sha256.txt"
gcc --version > "$output/compiler.txt"
mkdir "$output/upstream"
for file in charproc.c VTPrsTbl.c ptyx.h ctlseqs.ms xtermcfg.h; do
    cp "$file" "$output/upstream/$file"
done
cp xterm "$output/xterm-reference"
printf 'Built pinned reference in %s\n' "$source_dir"
