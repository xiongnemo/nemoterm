"""Capture unmodified pinned XTerm replies on a private display."""
from pathlib import Path
import json,sys
from legacy_reply_cases import cases
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'gdi-dense-memory-worktree/tests'))
from xterm_state_oracle import run_cases

folder=Path(__file__).resolve().parent
source=Path((folder/'source-directory.txt').read_text().strip())
assert (folder/'upstream-commit.txt').read_text().strip()=='5c75ead9a75d4b2e666ca06fa94503b5766ed93f'
for name,value in [('empty',''),('configured','NEMOREF')]:
    output=folder/('xterm-'+name+'.json');assert not output.exists()
    run_cases(str(source/'xterm'),str(output),cases(),['-ti','vt525','-xrm','*answerbackString: '+value],raw_replies=True)
    data=json.loads(output.read_text());assert len(data['cases'])==len(cases())
    print('Captured',name,len(data['cases']),flush=True)
