"""Retain XTerm's documented VT100-only parameter replies independently."""
from pathlib import Path
import sys
from legacy_reply_cases import cases
folder=Path(__file__).resolve().parent
sys.path.insert(0,str(folder.parent/'gdi-dense-memory-worktree/tests'))
from xterm_state_oracle import run_cases
source=Path((folder/'source-directory.txt').read_text().strip())
output=folder/'xterm-vt100.json';assert not output.exists()
selected={name:sequence for name,sequence in cases().items() if name.startswith('parameters-')}
run_cases(str(source/'xterm'),str(output),selected,['-ti','vt100'],raw_replies=True)
