"""Compare raw observations without altering either reference or native reports."""
from pathlib import Path
import json,sys

folder=Path(__file__).resolve().parent
native=folder.parent/(sys.argv[1] if len(sys.argv)>1 else 'legacy-replies-native-01')
summary=dict(reference='5c75ead9a75d4b2e666ca06fa94503b5766ed93f',profiles={})
for profile in ('empty','configured'):
    reference=json.loads((folder/('xterm-'+profile+'.json')).read_text())
    report=native/'research'/('legacy-replies-'+profile+'-observed.json')
    if not report.exists():summary['profiles'][profile]=dict(missing=True);continue
    actual=json.loads(report.read_text())
    compared=[];differences=[];identity=[]
    for name,wire_hex in actual['cases'].items():
        wire=bytes.fromhex(wire_hex);assert wire.endswith(b'\x1b[0n')
        observed=wire[:-4]
        expected=bytes.fromhex(reference['cases'][name]['reply_hex'])
        cp=actual['case_metadata'][name]['input_cp'];assert cp in (28591,65001)
        projected=b''.join(chr(b).encode('utf-8') if cp==65001 and 0x80<=b<=0x9f else bytes([b]) for b in expected)
        if name.startswith(('identify-','primary-')) and name!='identify-vt52':
            counterpart=name.replace('identify-','primary-',1) if name.startswith('identify-') else name.replace('primary-','identify-',1)
            if counterpart in actual['cases']:
                native_same=wire_hex==actual['cases'][counterpart]
                reference_same=expected==bytes.fromhex(reference['cases'][counterpart]['reply_hex'])
                identity.append(dict(name=name,native_decid_matches_da=native_same,reference_decid_matches_da=reference_same,
                                     native_hex=observed.hex(),reference_hex=expected.hex()))
            continue
        record=dict(name=name,matched=observed==projected,expected_hex=projected.hex(),reference_hex=expected.hex(),
                    actual_hex=observed.hex(),console_input_cp=cp)
        compared.append(record)
        if not record['matched']:differences.append(record)
    summary['profiles'][profile]=dict(capture_completed=actual['completed'],captured=len(actual['cases']),
        requested=len(reference['cases']),compared=len(compared),matched=sum(c['matched'] for c in compared),
        differences=differences,identity_checks=identity,all_comparisons=compared,
        cleanup=actual.get('cleanup'),last_snapshot=actual.get('last_snapshot'))
target=native/'comparison.json';assert not target.exists()
target.write_text(json.dumps(summary,indent=2)+'\n')
for profile,result in summary['profiles'].items():
    print(profile,{k:v for k,v in result.items() if k not in ('all_comparisons','identity_checks','cleanup','last_snapshot')})
