"""Diagnose reply ordering separately; preserve the original full-capture failure."""
from protocol_oracle_window import run
from legacy_reply_cases import RESET,FINISH,CSI
import os
os.environ['NEMOTERM_TEST_INPUT_CP']='28591'
os.environ['NEMOTERM_PROTOCOL_WIRE_TRACE']='1'
run('legacy-query-order',[
    ('warmup',CSI+'5n',b'\x1b[0n'),
    ('bare-cpr',CSI+'6n',None),
    ('normal-cpr',RESET+CSI+'6n'+FINISH,None),
    ('embedded-enq-cpr',RESET+CSI+'6\x05n'+FINISH,None)],
    profile=dict(NemoRenderer=0,NemoTabs=0,WarnOnClose=0,Answerback=''),
    font='SarasaTermSC Nerd Font Light',source_reference='Capture only; compare ordered replies independently')
