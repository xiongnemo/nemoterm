"""Capture replies only; comparison with the independent reference is separate."""
from pathlib import Path
import hashlib,json,os
from legacy_reply_cases import cases
from protocol_oracle_window import run
from native_test_utils import root

image=Path(os.environ['NEMOTERM_TEST_EXE'])
assert hashlib.sha256(image.read_bytes()).hexdigest()=='a6c4c3b2d31db884ca22636e4d05bfd055df0fa8d50d64a2e9cba7cf8485b292'
os.environ['NEMOTERM_TEST_INPUT_CP']='28591'
for name,value in [('empty',''),('configured','NEMOREF')]:
    label='legacy-replies-'+name
    selected={key:sequence for key,sequence in cases().items() if key!='answerback-within-csi'}
    if name=='empty':selected={key:sequence for key,sequence in selected.items() if key in ('answerback-within-osc','answerback-vt52','identify-vt52')}
    run(label,[(key,sequence,None) for key,sequence in selected.items()],
        barrier=('\x1b[5n',b'\x1b[0n'),profile=dict(NemoRenderer=0,NemoTabs=0,WarnOnClose=0,Answerback=value),
        font='SarasaTermSC Nerd Font Light',source_reference='Capture only; exact reference comparison pending')
    path=root/'research'/(label+'-observed.json')
    data=json.loads(path.read_text());data.update(comparison_pending=True,physical_input=False,clipboard_access=False,
        omitted_cases=[key for key in cases() if key not in selected],
        omission_reason='Original empty-profile pass observations are preserved in native-01; embedded ENQ/CPR ordering remains unresolved and is isolated separately.')
    path.write_text(json.dumps(data,indent=2)+'\n')
