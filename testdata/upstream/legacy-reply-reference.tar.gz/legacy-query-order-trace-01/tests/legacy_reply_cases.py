"""Shared original wire requests, without product-derived expected replies."""
ESC='\x1b';CSI=ESC+'['
RESET=CSI+'65;1"p'+ESC+'c'+ESC+' F'
FINISH=ESC+'<'+CSI+'65;1"p'+ESC+' F'

def cases():
    values={}
    for framing in ('F','G'):
        for prefix in ('','?','>','='):
            for argument in ('','0','00','1','2','3','0;1','1;0',';1','0:0','0:1','1:0',':1','0;1:2',
                             '65535','65536','999999999999999999999999'):
                name='parameters-'+framing+'-'+(prefix or 'plain')+'-'+(argument or 'default')
                values[name]=RESET+ESC+' '+framing+CSI+prefix+argument+'x'+FINISH
    operations=[('initial',''),('soft-reset',CSI+'!p'),('hard-reset',ESC+'c'),
                ('alternate',CSI+'?1049h'),('saved-cursor',ESC+'7'+CSI+'2;3H'+ESC+'8'),
                ('utf8-on',ESC+'%G'),('utf8-off',ESC+'%@'),('level-61',CSI+'61;1"p')]
    for framing in ('F','G'):
        for label,operation in operations:
            values['answerback-'+framing+'-'+label]=RESET+ESC+' '+framing+operation+'\x05'+FINISH
            values['identify-'+framing+'-'+label]=RESET+ESC+' '+framing+operation+ESC+'Z'+FINISH
            values['primary-'+framing+'-'+label]=RESET+ESC+' '+framing+operation+CSI+'c'+FINISH
    # A C0 enquiry inside an incomplete CSI must not lose the following cursor
    # request; an OSC payload must not be mistaken for an external enquiry.
    values['answerback-within-csi']=RESET+CSI+'6\x05n'+FINISH
    values['answerback-within-osc']=RESET+ESC+']0;NEMO\x05REF'+ESC+'\\'+FINISH
    values['answerback-vt52']=RESET+CSI+'?2l\x05'+FINISH
    values['identify-vt52']=RESET+CSI+'?2l'+ESC+'Z'+FINISH
    return values
