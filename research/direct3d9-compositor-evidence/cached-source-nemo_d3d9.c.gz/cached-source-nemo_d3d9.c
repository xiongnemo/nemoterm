/* SPDX-License-Identifier: MIT
 * Direct3D 9Ex blit compositor for the existing GDI rasterizer and Sixel.
 * UI-thread only. No vertex buffers, shaders, managed pool or software device.
 * A retained non-lockable render target supplies repaint and synchronized
 * output. Readback uses fixed 512x128 GPU/system-memory tiles, never a second
 * CPU frame. Cache resources belong to the device and survive window resizing.
 * See Microsoft IDirect3DDevice9 UpdateSurface, StretchRect and
 * GetRenderTargetData contracts. Failed hardware calls use frontend fallback.
 */
#define COBJMACROS
#include "putty.h"
#include <d3d9.h>
#include "nemo_d3d9.h"

#define CACHE_COUNT 256
#define CACHE_BYTES (4U*1024U*1024U)
#define FRAME_BYTES (128U*1024U*1024U)
#define READ_WIDTH 512
#define READ_HEIGHT 128
#define FORMAT D3DFMT_X8R8G8B8
#define RELEASE(p) do { if (p) { IUnknown_Release((IUnknown *)(p)); (p)=NULL; } } while (0)

typedef struct Run {
    IDirect3DSurface9 *surface;
    strbuf *key;
    uint64_t hash, used;
    unsigned bytes;
    int width, height;
} Run;
struct NemoD3D9 {
    HWND parent, surface;
    HMODULE module;
    IDirect3D9Ex *factory;
    IDirect3DDevice9Ex *device;
    IDirect3DSwapChain9 *chain;
    IDirect3DSurface9 *frame, *backbuffer, *upload, *read_target, *read_system;
    HDC scratch, read_dc;
    HBITMAP bitmap, read_bitmap;
    HGDIOBJ oldbitmap, read_old;
    uint32_t *pixels, *read_pixels;
    int width, height, strip_width, strip_height, upload_width, upload_height;
    unsigned limit_width, limit_height, cache_bytes;
    uint64_t tick;
    bool failed;
    Run cache[CACHE_COUNT];
};
static bool check(NemoD3D9 *g, HRESULT hr)
{
    if (FAILED(hr)) g->failed=true;
    return !g->failed;
}
static D3DCOLOR color(COLORREF c)
{
    return D3DCOLOR_XRGB(GetRValue(c),GetGValue(c),GetBValue(c));
}
static LRESULT CALLBACK surface_proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
    if (msg==WM_NCHITTEST) return HTTRANSPARENT;
    if (msg==WM_MOUSEACTIVATE) return MA_NOACTIVATE;
    if (msg==WM_ERASEBKGND) return 1;
    if (msg==WM_PAINT) {
        ValidateRect(hwnd,NULL);InvalidateRect(GetParent(hwnd),NULL,false);return 0;
    }
    return DefWindowProcW(hwnd,msg,wp,lp);
}
static void evict(NemoD3D9 *g, Run *r)
{
    RELEASE(r->surface);
    if (r->key) strbuf_free(r->key);
    g->cache_bytes-=r->bytes;memset(r,0,sizeof(*r));
}
void nemo_d3d9_clear_cache(NemoD3D9 *g)
{
    if (g) for (unsigned i=0;i<CACHE_COUNT;i++) {
        Run *r=&g->cache[i];
        if (r->key) strbuf_free(r->key);
        r->key=NULL;r->hash=r->used=0;
    }
}
static void free_frame(NemoD3D9 *g)
{
    RELEASE(g->frame);RELEASE(g->backbuffer);RELEASE(g->chain);
}
void nemo_d3d9_free(NemoD3D9 *g)
{
    if (!g) return;
    for (unsigned i=0;i<CACHE_COUNT;i++) evict(g,&g->cache[i]);
    free_frame(g);
    RELEASE(g->upload);RELEASE(g->read_target);RELEASE(g->read_system);
    RELEASE(g->device);RELEASE(g->factory);
    if (g->bitmap) {SelectObject(g->scratch,g->oldbitmap);DeleteObject(g->bitmap);}
    if (g->read_bitmap) {SelectObject(g->read_dc,g->read_old);DeleteObject(g->read_bitmap);}
    if (g->scratch) DeleteDC(g->scratch);
    if (g->read_dc) DeleteDC(g->read_dc);
    if (g->surface) DestroyWindow(g->surface);
    if (g->module) FreeLibrary(g->module);
    sfree(g);
}
static D3DPRESENT_PARAMETERS presentation(HWND hwnd, int w, int h)
{
    D3DPRESENT_PARAMETERS p={0};
    p.BackBufferWidth=w;p.BackBufferHeight=h;p.BackBufferFormat=FORMAT;
    p.BackBufferCount=1;p.SwapEffect=D3DSWAPEFFECT_DISCARD;p.Windowed=TRUE;
    p.hDeviceWindow=hwnd;p.PresentationInterval=D3DPRESENT_INTERVAL_IMMEDIATE;
    return p;
}
NemoD3D9 *nemo_d3d9_create(HWND parent)
{
    NemoD3D9 *g=snew(NemoD3D9);memset(g,0,sizeof(*g));g->parent=parent;
    g->module=load_system32_dll("d3d9.dll");
    if (!g->module) goto fail;
    typedef HRESULT (WINAPI *Create)(UINT,IDirect3D9Ex **);
    Create create;*(FARPROC *)&create=GetProcAddress(g->module,"Direct3DCreate9Ex");
    if (!create || !check(g,create(D3D_SDK_VERSION,&g->factory))) goto fail;
    WNDCLASSW wc={0};wc.lpfnWndProc=surface_proc;
    wc.hInstance=GetModuleHandle(NULL);wc.lpszClassName=L"NemotermDirect3D9";
    if (!RegisterClassW(&wc) && GetLastError()!=ERROR_CLASS_ALREADY_EXISTS) goto fail;
    g->surface=CreateWindowExW(0,wc.lpszClassName,L"",WS_CHILD|WS_CLIPSIBLINGS,
                             0,0,1,1,parent,NULL,wc.hInstance,NULL);
    g->scratch=CreateCompatibleDC(NULL);
    if (!g->surface || !g->scratch) goto fail;
    HWND owner=GetAncestor(parent,GA_ROOT);
    D3DPRESENT_PARAMETERS p=presentation(owner,1,1);
    if (!check(g,IDirect3D9Ex_CreateDeviceEx(g->factory,D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,owner,
            D3DCREATE_HARDWARE_VERTEXPROCESSING|D3DCREATE_FPU_PRESERVE,&p,NULL,&g->device))) goto fail;
    D3DCAPS9 caps;
    if (!check(g,IDirect3DDevice9Ex_GetDeviceCaps(g->device,&caps))) goto fail;
    g->limit_width=caps.MaxTextureWidth;g->limit_height=caps.MaxTextureHeight;
    if (g->limit_width<READ_WIDTH || g->limit_height<READ_HEIGHT) goto fail;
    return g;
  fail:
    nemo_d3d9_free(g);return NULL;
}
const char *nemo_d3d9_device(NemoD3D9 *g) { return "Direct3D 9Ex hardware blit compositor"; }
HDC nemo_d3d9_dc(NemoD3D9 *g) { return g->scratch; }
int nemo_d3d9_frame(NemoD3D9 *g, COLORREF background)
{
    RECT r;
    if (g->failed || !GetClientRect(g->parent,&r) || r.right<=0 || r.bottom<=0) return 0;
    if ((unsigned)r.right>g->limit_width || (unsigned)r.bottom>g->limit_height ||
        (uint64_t)r.right*r.bottom*4>FRAME_BYTES) {g->failed=true;return 0;}
    bool changed=r.right!=g->width || r.bottom!=g->height;
    if (changed) {
        free_frame(g);
        /* Additional swap chains resize without resetting the device or its
         * reusable resources. The default chain is a never-presented 1x1. */
        D3DPRESENT_PARAMETERS p=presentation(g->surface,r.right,r.bottom);
        if (!check(g,IDirect3DDevice9Ex_CreateAdditionalSwapChain(g->device,&p,&g->chain)) ||
            !check(g,IDirect3DSwapChain9_GetBackBuffer(g->chain,0,D3DBACKBUFFER_TYPE_MONO,&g->backbuffer)) ||
            !check(g,IDirect3DDevice9Ex_CreateRenderTarget(g->device,r.right,r.bottom,FORMAT,
                D3DMULTISAMPLE_NONE,0,FALSE,&g->frame,NULL))) return 0;
        g->width=r.right;g->height=r.bottom;
        SetWindowPos(g->surface,NULL,0,0,g->width,g->height,SWP_NOACTIVATE|SWP_NOZORDER);
        if (!check(g,IDirect3DDevice9Ex_ColorFill(g->device,g->frame,NULL,color(background)))) return 0;
    }
    return changed?2:1;
}
bool nemo_d3d9_present(NemoD3D9 *g)
{
    if (g->failed || !g->frame || !g->chain) return false;
    if (!check(g,IDirect3DDevice9Ex_StretchRect(g->device,g->frame,NULL,g->backbuffer,NULL,D3DTEXF_NONE))) return false;
    if (!IsWindowVisible(g->surface)) ShowWindow(g->surface,SW_SHOWNOACTIVATE);
    return check(g,IDirect3DSwapChain9_Present(g->chain,NULL,NULL,NULL,NULL,0));
}
static bool dimensions(NemoD3D9 *g, int w, int h)
{
    if (w<=0 || h<=0 || (unsigned)w>g->limit_width || (unsigned)h>g->limit_height ||
        (uint64_t)w*h*4>CACHE_BYTES) g->failed=true;
    return !g->failed;
}
static HBITMAP dib(HDC dc, int w, int h, uint32_t **pixels)
{
    BITMAPINFO bi={0};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth=w;bi.bmiHeader.biHeight=-h;
    bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;bi.bmiHeader.biCompression=BI_RGB;
    return CreateDIBSection(dc,&bi,DIB_RGB_COLORS,(void **)pixels,NULL,0);
}
static bool strip(NemoD3D9 *g, int w, int h)
{
    if (!dimensions(g,w,h)) return false;
    if (w<=g->strip_width && h<=g->strip_height) return true;
    w=max(w,g->strip_width);h=max(h,g->strip_height);
    if (!dimensions(g,w,h)) return false;
    GdiFlush();
    if (g->bitmap) {SelectObject(g->scratch,g->oldbitmap);DeleteObject(g->bitmap);g->bitmap=NULL;}
    g->bitmap=dib(g->scratch,w,h,&g->pixels);
    if (!g->bitmap) {g->failed=true;return false;}
    g->oldbitmap=SelectObject(g->scratch,g->bitmap);g->strip_width=w;g->strip_height=h;
    return true;
}
static uint64_t keyhash(ptrlen key)
{
    uint64_t hash=UINT64_C(14695981039346656037);const unsigned char *p=key.ptr;
    for (size_t i=0;i<key.len;i++) hash=(hash^p[i])*UINT64_C(1099511628211);
    return hash;
}
/* Clip the destination, preserving the same-size source coordinates. */
static bool clip(NemoD3D9 *g, RECT box, RECT *src, RECT *dst)
{
    *dst=box;dst->left=max(0,dst->left);dst->top=max(0,dst->top);
    dst->right=min(g->width,dst->right);dst->bottom=min(g->height,dst->bottom);
    src->left=dst->left-box.left;src->top=dst->top-box.top;
    src->right=dst->right-box.left;src->bottom=dst->bottom-box.top;
    return dst->right>dst->left && dst->bottom>dst->top;
}
static bool draw(NemoD3D9 *g, IDirect3DSurface9 *surface, RECT box)
{
    RECT src,dst;
    return !clip(g,box,&src,&dst) || check(g,IDirect3DDevice9Ex_StretchRect(
        g->device,surface,&src,g->frame,&dst,D3DTEXF_NONE));
}
bool nemo_d3d9_cached(NemoD3D9 *g, RECT box, ptrlen key)
{
    if (g->failed) return false;
    uint64_t hash=keyhash(key);
    for (unsigned i=0;i<CACHE_COUNT;i++) {
        Run *r=&g->cache[i];
        if (r->key && r->hash==hash && r->width==box.right-box.left &&
            r->height==box.bottom-box.top && ptrlen_eq_ptrlen(ptrlen_from_strbuf(r->key),key)) {
            r->used=++g->tick;return draw(g,r->surface,box);
        }
    }
    return false;
}
static bool readback_resources(NemoD3D9 *g)
{
    if (g->read_target) return !g->failed;
    if (!check(g,IDirect3DDevice9Ex_CreateRenderTarget(g->device,READ_WIDTH,READ_HEIGHT,FORMAT,
            D3DMULTISAMPLE_NONE,0,FALSE,&g->read_target,NULL)) ||
        !check(g,IDirect3DDevice9Ex_CreateOffscreenPlainSurface(g->device,READ_WIDTH,READ_HEIGHT,
            FORMAT,D3DPOOL_SYSTEMMEM,&g->read_system,NULL))) return false;
    g->read_dc=CreateCompatibleDC(NULL);
    if (!g->read_dc) {g->failed=true;return false;}
    g->read_bitmap=dib(g->read_dc,READ_WIDTH,READ_HEIGHT,&g->read_pixels);
    if (!g->read_bitmap) {g->failed=true;return false;}
    g->read_old=SelectObject(g->read_dc,g->read_bitmap);return true;
}
static bool read_pixels(NemoD3D9 *g, HDC dest, int dx, int dy, int x, int y, int w, int h)
{
    if (g->failed || !g->frame || !readback_resources(g)) return false;
    RECT box={x,y,x+w,y+h},offset,clipped;
    if (!clip(g,box,&offset,&clipped)) return true;
    dx+=offset.left;dy+=offset.top;x=clipped.left;y=clipped.top;
    w=clipped.right-x;h=clipped.bottom-y;
    for (int row=0;row<h;row+=READ_HEIGHT) for (int col=0;col<w;col+=READ_WIDTH) {
        int cw=min(READ_WIDTH,w-col),ch=min(READ_HEIGHT,h-row);
        RECT src={x+col,y+row,x+col+cw,y+row+ch},dst={0,0,cw,ch};
        if (!check(g,IDirect3DDevice9Ex_StretchRect(g->device,g->frame,&src,g->read_target,&dst,D3DTEXF_NONE)) ||
            !check(g,IDirect3DDevice9Ex_GetRenderTargetData(g->device,g->read_target,g->read_system))) return false;
        D3DLOCKED_RECT locked;
        if (!check(g,IDirect3DSurface9_LockRect(g->read_system,&locked,NULL,D3DLOCK_READONLY))) return false;
        GdiFlush();
        bool valid=locked.Pitch>=cw*4;
        if (valid) for (int line=0;line<ch;line++)
            memcpy(g->read_pixels+line*READ_WIDTH,(char *)locked.pBits+(size_t)line*locked.Pitch,cw*4);
        check(g,IDirect3DSurface9_UnlockRect(g->read_system));
        if (!valid || !BitBlt(dest,dx+col,dy+row,cw,ch,g->read_dc,0,0,SRCCOPY)) g->failed=true;
        if (g->failed) return false;
    }
    GdiFlush();return true;
}
bool nemo_d3d9_begin_run(NemoD3D9 *g, RECT box, bool overlay)
{
    int w=box.right-box.left,h=box.bottom-box.top;
    if (!strip(g,w,h)) return false;
    GdiFlush();memset(g->pixels,0,(size_t)g->strip_width*h*4);
    SelectClipRgn(g->scratch,NULL);SetViewportOrgEx(g->scratch,-box.left,-box.top,NULL);
    IntersectClipRect(g->scratch,box.left,box.top,box.right,box.bottom);
    return !overlay || read_pixels(g,g->scratch,box.left,box.top,box.left,box.top,w,h);
}
static bool upload_pixels(NemoD3D9 *g, int w, int h, const void *pixels, unsigned pitch)
{
    if (!dimensions(g,w,h)) return false;
    if (w>g->upload_width || h>g->upload_height) {
        int nw=max(w,g->upload_width),nh=max(h,g->upload_height);
        if (!dimensions(g,nw,nh)) return false;
        RELEASE(g->upload);
        if (!check(g,IDirect3DDevice9Ex_CreateOffscreenPlainSurface(g->device,nw,nh,FORMAT,
            D3DPOOL_SYSTEMMEM,&g->upload,NULL))) return false;
        g->upload_width=nw;g->upload_height=nh;
    }
    D3DLOCKED_RECT locked;RECT used={0,0,w,h};
    if (!check(g,IDirect3DSurface9_LockRect(g->upload,&locked,&used,0))) return false;
    bool valid=locked.Pitch>=w*4 && pitch>=(unsigned)w*4;
    if (valid) for (int line=0;line<h;line++)
        memcpy((char *)locked.pBits+(size_t)line*locked.Pitch,(const char *)pixels+(size_t)line*pitch,w*4);
    check(g,IDirect3DSurface9_UnlockRect(g->upload));
    if (!valid) g->failed=true;
    return !g->failed;
}
static void upload(NemoD3D9 *g, RECT box, const void *pixels, unsigned pitch)
{
    if (!upload_pixels(g,box.right-box.left,box.bottom-box.top,pixels,pitch)) return;
    RECT src,dst;
    if (clip(g,box,&src,&dst)) {
        POINT point={dst.left,dst.top};
        check(g,IDirect3DDevice9Ex_UpdateSurface(g->device,g->upload,&src,g->frame,&point));
    }
}
void nemo_d3d9_end_run(NemoD3D9 *g, RECT box, ptrlen key)
{
    GdiFlush();if (g->failed) return;
    int w=box.right-box.left,h=box.bottom-box.top;
    if (!dimensions(g,w,h)) return;
    unsigned bytes=(unsigned)w*h*4;
    if (!key.len || key.len>16384) {upload(g,box,g->pixels,g->strip_width*4);return;}
    Run *r=NULL;
    for (unsigned i=0;i<CACHE_COUNT;i++) if (!r || g->cache[i].used<r->used) r=&g->cache[i];
    if (r->surface) {
        Run *same=NULL;
        for (unsigned i=0;i<CACHE_COUNT;i++)
            if (g->cache[i].surface && g->cache[i].width==w && g->cache[i].height==h &&
                (!same || g->cache[i].used<same->used)) same=&g->cache[i];
        if (same) r=same;
    }
    if (!r->surface || r->width!=w || r->height!=h) {
        evict(g,r);
        while (g->cache_bytes+bytes>CACHE_BYTES) {
            Run *old=NULL;
            for (unsigned i=0;i<CACHE_COUNT;i++)
                if (g->cache[i].surface && (!old || g->cache[i].used<old->used)) old=&g->cache[i];
            if (!old) break;
            evict(g,old);
        }
        if (!check(g,IDirect3DDevice9Ex_CreateRenderTarget(g->device,w,h,FORMAT,
            D3DMULTISAMPLE_NONE,0,FALSE,&r->surface,NULL))) return;
        r->width=w;r->height=h;r->bytes=bytes;g->cache_bytes+=bytes;
    }
    if (r->key) strbuf_free(r->key);
    r->key=NULL;
    if (!upload_pixels(g,w,h,g->pixels,g->strip_width*4)) return;
    RECT src={0,0,w,h};POINT point={0,0};
    if (!check(g,IDirect3DDevice9Ex_UpdateSurface(g->device,g->upload,&src,r->surface,&point))) return;
    r->used=++g->tick;r->hash=keyhash(key);r->key=strbuf_new();put_datapl(r->key,key);
    draw(g,r->surface,box);
}
void nemo_d3d9_row(NemoD3D9 *g, int x, int y, int width, const uint32_t *pixels)
{
    RECT box={x,y,x+width,y+1};upload(g,box,pixels,width*4);
}
void nemo_d3d9_fill_rect(NemoD3D9 *g, RECT rect, COLORREF colour)
{
    if (g->failed || !g->frame) return;
    RECT src,dst;
    if (clip(g,rect,&src,&dst)) check(g,IDirect3DDevice9Ex_ColorFill(g->device,g->frame,&dst,color(colour)));
}
void nemo_d3d9_borders(NemoD3D9 *g, RECT text, COLORREF background)
{
    RECT r={0,0,g->width,text.top};nemo_d3d9_fill_rect(g,r,background);
    r.top=text.bottom;r.bottom=g->height;nemo_d3d9_fill_rect(g,r,background);
    r.top=text.top;r.bottom=text.bottom;r.right=text.left;nemo_d3d9_fill_rect(g,r,background);
    r.left=text.right;r.right=g->width;nemo_d3d9_fill_rect(g,r,background);
}
bool nemo_d3d9_print(NemoD3D9 *g, HDC dc)
{
    return g->width>0 && g->height>0 && read_pixels(g,dc,0,0,0,0,g->width,g->height);
}
bool nemo_d3d9_attach(NemoD3D9 *g, HWND parent)
{
    ShowWindow(g->surface,SW_HIDE);SetLastError(0);
    if (!SetParent(g->surface,parent) && GetLastError()) return false;
    g->parent=parent;nemo_d3d9_clear_cache(g);return true;
}
void nemo_d3d9_show(NemoD3D9 *g, bool visible)
{
    ShowWindow(g->surface,visible ? SW_SHOWNOACTIVATE : SW_HIDE);
}
bool nemo_d3d9_print_band(NemoD3D9 *g, HDC dc, int top, int height)
{
    top=max(0,top);height=min(height,g->height-top);
    return g->width>0 && height>0 && read_pixels(g,dc,0,top,0,top,g->width,height);
}
