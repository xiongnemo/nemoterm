/* Optional Direct3D 9Ex hardware compositor, created only for GPU mode. */
#ifndef NEMO_D3D9_H
#define NEMO_D3D9_H
typedef struct NemoD3D9 NemoD3D9;
NemoD3D9 *nemo_d3d9_create(HWND);
void nemo_d3d9_free(NemoD3D9 *);
void nemo_d3d9_clear_cache(NemoD3D9 *);
const char *nemo_d3d9_device(NemoD3D9 *);
int nemo_d3d9_frame(NemoD3D9 *, COLORREF);
HDC nemo_d3d9_dc(NemoD3D9 *);
bool nemo_d3d9_present(NemoD3D9 *);
bool nemo_d3d9_print(NemoD3D9 *, HDC);
bool nemo_d3d9_attach(NemoD3D9 *, HWND);
void nemo_d3d9_show(NemoD3D9 *, bool);
bool nemo_d3d9_print_band(NemoD3D9 *, HDC, int, int);
bool nemo_d3d9_cached(NemoD3D9 *, RECT, ptrlen);
bool nemo_d3d9_begin_run(NemoD3D9 *, RECT, bool);
void nemo_d3d9_end_run(NemoD3D9 *, RECT, ptrlen);
void nemo_d3d9_row(NemoD3D9 *, int, int, int, const uint32_t *);
void nemo_d3d9_borders(NemoD3D9 *, RECT, COLORREF);
void nemo_d3d9_fill_rect(NemoD3D9 *, RECT, COLORREF);
#endif
