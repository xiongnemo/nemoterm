import hashlib, json, os, subprocess, sys, time
from pathlib import Path

root = Path(sys.argv[1]).resolve()
name = sys.argv[2]
sys.path.insert(0, str(root/'tests'))
from owned_job import OwnedJob

exe = root/'dist/nemoterm.exe'
evidence = dict(executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),
                name=name, completed=False, exit_code=None)
env = dict(os.environ, NEMOTERM_TEST_EXE=str(exe),
           NEMOTERM_REQUIRE_OPENGL='1', NEMOTERM_REQUIRE_DIRECTX='1')
start = time.monotonic()
with OwnedJob() as job:
    try:
        with (root/f'{name}.log').open('w', encoding='utf-8') as log:
            child = job.spawn([sys.executable, str(root/'tests'/f'{name}_window_smoke.py'),
                               *sys.argv[3:]], env=env, stdout=log, stderr=subprocess.STDOUT,
                              creationflags=subprocess.CREATE_NO_WINDOW)
            evidence['controller_pid'] = child.pid
            evidence['exit_code'] = child.wait(timeout=180)
    finally:
        evidence['cleanup'] = job.finish(grace=3)
        evidence['seconds'] = round(time.monotonic()-start, 3)
        evidence['completed'] = evidence['exit_code'] == 0 and not evidence['cleanup']['terminated_remaining']
        (root/'research'/f'{name}-controller.json').write_text(json.dumps(evidence, indent=2))
print(json.dumps(evidence), flush=True)
if not evidence['completed']:
    print((root/f'{name}.log').read_text(encoding='utf-8')[-7000:])
    raise SystemExit(1)
