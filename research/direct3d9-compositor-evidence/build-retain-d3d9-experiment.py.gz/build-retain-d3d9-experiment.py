import datetime, gzip, hashlib, json, subprocess
from pathlib import Path

work = Path(__file__).resolve().parents[1]
root = work.parents[1]
out = root / 'research/direct3d9-compositor-evidence'
out.mkdir(exist_ok=False)
files = []

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def retain(name, raw):
    dest = out / (name + '.gz')
    assert not dest.exists(), dest
    encoded = gzip.compress(raw, mtime=0)
    dest.write_bytes(encoded)
    assert gzip.decompress(dest.read_bytes()) == raw
    files.append(dict(path=dest.relative_to(root).as_posix(), sha256=sha(encoded),
                      bytes=len(encoded), raw_sha256=sha(raw), raw_bytes=len(raw),
                      encoding='gzip'))

def identity(exe):
    raw = exe.read_bytes()
    return dict(sha256=sha(raw), bytes=len(raw))

arms = {}
for arm, folder in [('cached', 'd3d9-check-1'), ('uncached', 'd3d9-check-nocache')]:
    folder = work / 'build' / folder
    observed = json.loads((folder/'research/workload-tabs-directx-left-observed.json').read_text())
    memory = json.loads((folder/'research/workload-tabs-directx-left-memory.json').read_text())
    controller = json.loads((folder/'research/tabs-controller.json').read_text())
    assert len(observed['checks']) == 9 and not observed['memory_limit_passed']
    assert not memory['injected'] and not memory['errors']
    assert observed['actual_grid'] == [160, 48] and observed['actual_renderer'] == 3
    assert controller['exit_code'] == 1 and not controller['cleanup']['terminated_remaining']
    assert not controller['cleanup']['after']['active']
    exe = identity(folder/'dist/nemoterm.exe')
    assert exe['sha256'] == observed['executable_sha256'] == controller['executable_sha256']
    arms[arm] = dict(executable=exe, frontend_peaks=memory['peaks']['frontend'],
                     actual_grid=observed['actual_grid'], font=observed['font'],
                     functional_checks=observed['checks'], memory_limit_passed=False,
                     sample_count=memory['sample_count'], sampling_seconds=memory['seconds'],
                     controller_seconds=controller['seconds'], controller=controller,
                     memory_instrumented=False, pixel_checks_after_memory_instrumented=True)
    for p in sorted((folder/'research').iterdir()):
        retain(arm+'-'+p.name, p.read_bytes())
    for p in sorted((folder/'source').iterdir()):
        retain(arm+'-source-'+p.name, p.read_bytes())
    for name in ['tabs.log', 'workload-controller.log', 'renderer.log']:
        p = folder/name
        if p.exists(): retain(arm+'-'+name, p.read_bytes())

parity_path = work/'build/d3d9-check-1/research/renderer-observed.json'
parity = json.loads(parity_path.read_text())
assert parity['completed'] and parity['parity_failures'] == []
arms['cached']['renderer_parity'] = dict(completed=True, failures=[], modes=parity['modes'])

# The full new sources are above; this patch retains the tracked dispatch/build
# and native child-class changes relative to the recorded main commit.
tracked = ['tests/tabs_window_smoke.py', 'vendor/putty-0.85/windows/CMakeLists.txt',
           'vendor/putty-0.85/windows/nemo_gpu.c']
retain('tracked-integration.patch', subprocess.check_output(
    ['git', 'diff', '--binary', 'HEAD', '--', *tracked], cwd=work))
for name in ['tests/tabs_window_smoke.py', 'build/run-owned-check.py',
             'build/d3d9-frontend-build.log', 'build/d3d9-host-build.log',
             'build/d3d9-nocache-frontend-build.log', 'build/d3d9-nocache-host-build.log',
             'build/retain-d3d9-experiment.py']:
    retain(name.replace('/', '-'), (work/name).read_bytes())

base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=work, text=True).strip()
assert base == '9cf51ace2aa17f7b2358967e0a5c7615b5e4e642'
accepted = identity(root/'dist/nemoterm.exe')
assert accepted['sha256'] == 'a108894f50f7d797f7d2c01558a71f268a1c812fe365270e5a6a7fb7868ca4ed'
manifest = dict(
    recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    base_commit=base,
    decision='Reject both Direct3D 9Ex variants; retain existing Direct2D renderer.',
    memory_requirement_bytes=25000000, memory_requirement_inclusive=True,
    renderer_changes_retained=False, accepted_distribution_replaced=False,
    full_goal_complete=False, accepted_local_distribution=accepted,
    environment=dict(os='Windows 10 IoT Enterprise LTSC', build='19044',
                     adapter='NVIDIA GeForce RTX 3060 Laptop GPU', driver='32.0.15.8132',
                     other_adapter='MuMu Virtual Display Adapter', other_driver='20.36.41.498'),
    arms=arms,
    limitations=[
        'Local incremental experimental images, not CI release artifacts.',
        'Cached arm has the existing three-renderer pixel suite; uncached arm only the full tabs/workload fixture.',
        'Memory sampling completes before pixel-probe attachment; later functional screenshots are instrumented.',
        'Nine tab checks and pixel parity are not full device-loss, settings, compiler or platform acceptance.',
        'One observed run per arm is not a statistically controlled performance comparison.',
        'Removing per-run resource reuse did not lower this workload private WS; this is not allocation ownership proof.',
        'Prior Direct2D 29,569,024-byte peak is a different CI image/run; no exact causal delta is claimed.'
    ], files=files)
dest = root/'research/direct3d9-compositor-validation.json'
dest.write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
for entry in manifest['files']:
    raw = (root/entry['path']).read_bytes()
    assert sha(raw) == entry['sha256'] and len(raw) == entry['bytes']
    decoded = gzip.decompress(raw)
    assert sha(decoded) == entry['raw_sha256'] and len(decoded) == entry['raw_bytes']
print(json.dumps(dict(files=len(files), compressed_bytes=sum(f['bytes'] for f in files),
                      manifest=str(dest)), indent=2))
