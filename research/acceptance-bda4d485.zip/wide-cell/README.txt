Ten same-image agent sessions. Executed on GitHub runners; see source and wide-selected PNGs in artifact 14614082389 and receipts in 14613828801. Crops use nearest neighbour scaling.
