import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
dest=root/'build/io-failure-observer';assert not dest.exists()
for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
shutil.copytree(root/'tests',dest/'tests')
shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
shutil.copy2(root/'build/io-fix-single/nemoterm.exe',dest/'dist')
p=dest/'tests/tabs_window_smoke.py';original=p.read_text(encoding='utf-8');source=original
def replace(a,b):
    global source
    assert source.count(a)==1,a
    source=source.replace(a,b)
replace("3:'NemotermDirect2D'","3:'NemotermDirect3D11'")
replace("profile,'--tabs','--tab-side'", "profile,'--automation','--tabs','--tab-side'")
needle="                assert sample['handles']<=baseline['handles']+6,(baseline,sample)"
replace(needle,"""                if sample['handles']>baseline['handles']+6:
                    # Preserve the failing pre-request count and keep the original
                    # assertion below. Requests may change UI scheduling; these
                    # subsequent observations are diagnostic, never acceptance.
                    evidence['memory_acceptance']=False
                    observation=dict(cycle=i,pre_query_resources=sample,snapshots=[])
                    evidence['io_failure_diagnostic']=observation
                    sys.path.insert(0,str(root/'tools'))
                    import nemoterm_debug as api
                    started=time.monotonic()
                    instance=next(iter(api.discover(process.pid)))
                    observation['snapshots'].append(dict(seconds=time.monotonic()-started,
                        io=instance['io_handles'],post_query_resources=resources()))
                    for delay in (.05,.2,1.0):
                        time.sleep(max(0,started+delay-time.monotonic()))
                        state=api.request(instance['endpoint'])
                        observation['snapshots'].append(dict(seconds=time.monotonic()-started,
                            io=state['io_handles'],post_query_resources=resources()))
"""+needle)
compile(source,str(p),'exec');p.write_text(source,encoding='utf-8')
(dest/'research/diagnostic-fixture.json').write_text(json.dumps(dict(
    original_sha256=hashlib.sha256(original.encode()).hexdigest(),
    modified_sha256=hashlib.sha256(source.encode()).hexdigest(),
    purpose='Read I/O statistics only after a resource failure; retain the pre-query sample and original failing assertion',
    memory_acceptance=False),indent=2)+'\n',encoding='utf-8')
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
with (dest/'controller.log').open('w',encoding='utf-8') as log:
    code=subprocess.run([sys.executable,str(controller),str(dest),'tabs','--renderer','directx',
        '--side','left','--cols','160','--rows','48','--workload-memory'],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
print((dest/'controller.log').read_text(encoding='utf-8')[-3000:],flush=True)
raise SystemExit(code)
