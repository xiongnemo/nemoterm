import collections,datetime,gzip,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
out=root/'research/d3d11-threading-evidence';out.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
files=[]
def retain(p,name):
    raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);dest=out/(name+'.gz')
    assert not dest.exists(),dest
    dest.write_bytes(packed)
    files.append(dict(path=dest.relative_to(root).as_posix(),bytes=len(packed),sha256=sha(packed),
        raw_bytes=len(raw),raw_sha256=sha(raw),encoding='gzip'))
binary=root/'build/no-worker-single/nemoterm.exe';digest=sha(binary.read_bytes())
assert digest=='f4b7cc47a4278b578b775bb2fdb1d0012b75306bd1bd8580deace9dc12599940'
control='bb73edd96408c84a8e00d6e321ff4f99fc54d894b91fcf5444a72b907760cd3c'
cases={}
for label in ('no-worker-pixels','no-worker-workload','no-worker-resource-diagnostic',
              'threading-control-diagnostic','threading-candidate-diagnostic'):
    base=root/'build'/label;fixture='renderer' if label.endswith('pixels') else 'tabs'
    ctl=read(base/'research'/f'{fixture}-controller.json')
    identity=control if label=='threading-control-diagnostic' else digest
    assert ctl['executable_sha256']==identity and not ctl['cleanup']['after']['active']
    v=read(base/'research'/('renderer-observed.json' if fixture=='renderer' else 'workload-tabs-directx-left-observed.json'))
    assert v['executable_sha256']==identity
    item=dict(executable_sha256=identity,controller=ctl)
    if fixture=='renderer':
        assert ctl['completed'] and [m['active'] for m in v['modes']]==['GDI','OpenGL','DirectX']
        item.update(modes=[dict(active=m['active'],checks=len(m['checks']),
            memory_instrumented=m['memory_instrumented']) for m in v['modes']],memory_acceptance=False)
    else:
        memory=read(base/'research/workload-tabs-directx-left-memory.json')
        assert not v['completed'] and not memory['injected'] and not memory['errors']
        assert v['actual_grid']==[160,48] and v['font']=='SarasaTermSC Nerd Font Light'
        threads=collections.defaultdict(list)
        for sample in memory['samples']:
            for process in sample['processes']:
                if process['role']=='frontend' and 'threads' in process:threads[sample['phase']].append(process['threads'])
        item.update(diagnostic_completed=v.get('diagnostic_completed',False),memory_acceptance=False,
            checks=v['checks'],peaks=memory['peaks'],samples=memory['sample_count'],seconds=memory['seconds'],
            font=v['font'],actual_grid=v['actual_grid'],error=v['error'],baseline=v['two_tabs'],
            cycles=v['cycles'],violations=v.get('resource_violations'),inner_cleanup=v['owned_job_cleanup'],
            threads_by_phase={k:dict(min=min(x),max=max(x)) for k,x in threads.items()})
        if 'diagnostic' in label:
            assert v['diagnostic_completed'] and len(v['checks'])==8
            assert not v['owned_job_cleanup']['terminated_remaining']
    cases[label]=item
    for p in sorted((base/'research').glob('*')):
        if p.is_file():retain(p,label+'-'+p.name)
    for relative in (fixture+'.log','controller.log','tests/tabs_window_smoke.py',
        'tests/renderer_window_smoke.py','tests/console_process_utils.py','tests/tab_workload_memory.py',
        'tests/owned_job.py','tests/memory_limits.py'):
        p=base/relative
        if p.exists():retain(p,label+'-'+relative.replace('/','_'))
for name in ('no-worker-frontend.log','run-no-worker-checks.py','run-no-worker-diagnostic.py',
    'prepare-threading-pair.py','run-threading-control.py','run-threading-candidate.py',
    'threading-control-invocation.log','threading-candidate-invocation.log','retain-threading.py','link-image.py'):
    retain(root/'build'/name,name)
for p in (root/'build/no-worker-single').iterdir():
    if p.suffix in ('.json','.log','.rsp'):retain(p,'link-'+p.name)
source='vendor/putty-0.85/windows/nemo_d3d11.c'
retain(root/source,'candidate-nemo_d3d11.c')
patch=subprocess.check_output(['git','diff','47f801b','--',source],cwd=root)
patchpath=root/'build/threading-candidate.patch';patchpath.write_bytes(patch);retain(patchpath,patchpath.name)
result=dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    experimental_base_commit=subprocess.check_output(['git','rev-parse','47f801b'],cwd=root,text=True).strip(),
    candidate=dict(bytes=binary.stat().st_size,sha256=digest,source_sha256=sha((root/source).read_bytes().replace(b'\r\n',b'\n'))),
    control_sha256=control,source_reference='https://learn.microsoft.com/en-us/windows/win32/api/d3d11/ne-d3d11-d3d11_create_device_flag',
    reused_host_source_checkpoint='37ef26dae839319f7bf703bb648038c343c357f1',
    distribution='Experimental local single image; not CI artifact or accepted product',
    decision='Keep as experiment: memory observations improved, resource gate still fails',
    accepted_distribution_replaced=False,full_goal_complete=False,cases=cases,files=files)
for f in files:
    data=(root/f['path']).read_bytes()
    assert sha(data)==f['sha256'] and sha(gzip.decompress(data))==f['raw_sha256']
(root/'research/d3d11-threading-validation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(files=len(files),cases={k:dict(peaks=v.get('peaks',{}).get('frontend'),
    settled_threads=v.get('threads_by_phase',{}).get('settled')) for k,v in cases.items()})))
