import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
dest=root/'build/threading-control-diagnostic';assert not dest.exists()
for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
shutil.copytree(root/'tests',dest/'tests');shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
shutil.copy2(root/'build/sequential-single/nemoterm.exe',dest/'dist')
p=dest/'tests/tabs_window_smoke.py';original=p.read_text(encoding='utf-8');source=original
def replace(a,b):
    global source
    assert source.count(a)==1,a
    source=source.replace(a,b)
replace("3:'NemotermDirect2D'","3:'NemotermDirect3D11'")
pair=(root.parent/'cursor-worktree/build/ci-relative-43517911793/resource-pair-01/directx/tests/tabs_window_smoke.py').read_text(encoding='utf-8')
helper=pair[pair.index('def baseline_window_snapshot'):pair.index('def diagnostic_counts')]
replace('evidence=dict(executable_sha256=',helper+'evidence=dict(executable_sha256=')
replace('            for i in range(12):',"""            evidence.update(memory_acceptance=False,resource_assertions_deferred=True,
                            resource_violations=[],resource_windows=[baseline_window_snapshot(process.pid)])
            for i in range(12):""")
assertions="""                assert sample['handles']<=baseline['handles']+6,(baseline,sample)
                assert sample['gdi']<=baseline['gdi']+3,(baseline,sample)
                assert sample['user']<=baseline['user']+2,(baseline,sample)"""
replace(assertions,"""                if sample['handles']>baseline['handles']+6 or sample['gdi']>baseline['gdi']+3 or sample['user']>baseline['user']+2:
                    evidence['resource_violations'].append(dict(cycle=i,baseline=baseline,sample=sample))
                evidence['resource_windows'].append(baseline_window_snapshot(process.pid))
                (root/'research/resource-progress.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
                print('Resource diagnostic cycle',i,sample,flush=True)""")
replace("            evidence['checks'].append('12 create/close cycles retain one shared renderer without handle growth')",
"""            if not evidence['resource_violations']:
                evidence['checks'].append('12 create/close cycles retain one shared renderer without handle growth')
            evidence['resource_phase_finished']=True""")
replace("            if args.workload_memory and evidence['memory_limit_required']:\n                assert evidence['memory_limit_passed'],evidence['peak_private_ws']",
"""            evidence['diagnostic_completed']=True
            if evidence['resource_violations']:
                first_failure=evidence['resource_violations'][0]
                baseline,sample=first_failure['baseline'],first_failure['sample']
"""+assertions+"""
            if args.workload_memory and evidence['memory_limit_required']:
                assert evidence['memory_limit_passed'],evidence['peak_private_ws']
            raise SystemExit(2)""")
compile(source,str(p),'exec');p.write_text(source,encoding='utf-8')
(dest/'research/diagnostic-fixture.json').write_text(json.dumps(dict(original_sha256=hashlib.sha256(original.encode()).hexdigest(),modified_sha256=hashlib.sha256(source.encode()).hexdigest(),
    purpose='Retain all resource violations, inspect owned window sets and defer original assertions until after full workload and natural cleanup; never acceptance'),indent=2)+'\n',encoding='utf-8')

# Preserve only owned-process thread counts already returned by Toolhelp.
collector=dest/'tests/console_process_utils.py'
collector_source=collector.read_text(encoding='utf-8')
for old,new in [
    ('    rows = {}','    rows = {}; thread_counts = {}'),
    ('            rows[item.pid] = (item.parent, item.name)',
     '            rows[item.pid] = (item.parent, item.name)\n            thread_counts[item.pid] = item.threads'),
    ('                                   memory=memory))',
     '                                   memory=memory, threads=thread_counts[pid]))')]:
    assert collector_source.count(old)==1,old
    collector_source=collector_source.replace(old,new)
compile(collector_source,str(collector),'exec')
collector.write_text(collector_source,encoding='utf-8')

controller=root.parent/'rtl-worktree/build/run-owned-check.py'
with (dest/'controller.log').open('w',encoding='utf-8') as log:
    code=subprocess.run([sys.executable,str(controller),str(dest),'tabs','--renderer','directx','--side','left','--cols','160','--rows','48','--workload-memory'],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
print((dest/'controller.log').read_text(encoding='utf-8')[-3000:],flush=True)
raise SystemExit(code)
