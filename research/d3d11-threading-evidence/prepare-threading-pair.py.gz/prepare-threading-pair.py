from pathlib import Path
root=Path(__file__).resolve().parents[1]
extra='''
# Preserve only owned-process thread counts already returned by Toolhelp.
collector=dest/'tests/console_process_utils.py'
collector_source=collector.read_text(encoding='utf-8')
for old,new in [
    ('    rows = {}','    rows = {}; thread_counts = {}'),
    ('            rows[item.pid] = (item.parent, item.name)',
     '            rows[item.pid] = (item.parent, item.name)\\n            thread_counts[item.pid] = item.threads'),
    ('                                   memory=memory))',
     '                                   memory=memory, threads=thread_counts[pid]))')]:
    assert collector_source.count(old)==1,old
    collector_source=collector_source.replace(old,new)
compile(collector_source,str(collector),'exec')
collector.write_text(collector_source,encoding='utf-8')
'''
for label,original,target in [('control','sequential','threading-control-diagnostic'),
                              ('candidate','no-worker','threading-candidate-diagnostic')]:
    source=(root/'build'/f'run-{original}-diagnostic.py').read_text(encoding='utf-8')
    source=source.replace(f"build/{original}-resource-diagnostic",f'build/{target}')
    needle="controller=root.parent/'rtl-worktree/build/run-owned-check.py'"
    assert source.count(needle)==1
    source=source.replace(needle,extra+'\n'+needle)
    path=root/'build'/f'run-threading-{label}.py'
    assert not path.exists(),path
    compile(source,str(path),'exec');path.write_text(source,encoding='utf-8')
