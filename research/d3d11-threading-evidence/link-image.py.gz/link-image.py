import hashlib,json,re,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
old=root.parent/'rtl-worktree'
host=old/'build/openconsole-single'
dest=root/'build'/sys.argv[1]
assert not dest.exists(),dest
dest.mkdir()
log=host/'obj/x64/Release/Host.EXE/Host.EXE.tlog/link.command.1.tlog'
lines=log.read_text(encoding='utf-16').splitlines()
assert sum(x.startswith('^') for x in lines)==1
args='\n'.join(x for x in lines if x and not x.startswith('^'))
args=re.sub(re.escape(str(old/'build/frontend-single')),lambda _:str(root/'build/frontend-single'),args,flags=re.I)
for flag,suffix in [('OUT','exe'),('PDB','pdb'),('IMPLIB','lib')]:
    args,n=re.subn(r'/'+flag+r':"[^"]+"',lambda _:f'/{flag}:"{dest / ("nemoterm."+suffix)}"',args,flags=re.I)
    assert n==1,(flag,n)
args=args.replace('/LTCG:incremental','/LTCG')
rsp=dest/'link.rsp';rsp.write_text(args,encoding='utf-8')
inputs=[]
for value in re.findall(r'"([^"\n]+\.(?:lib|obj|res))"',args,re.I):
    p=Path(value)
    if p.exists() and p.is_file():inputs.append(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size))
(dest/'link-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n',encoding='utf-8')
with (dest/'link.log').open('w',encoding='utf-8') as out:
    code=subprocess.run(['link.exe','@'+str(rsp)],cwd=host/'src/host/exe',stdout=out,stderr=subprocess.STDOUT).returncode
print((dest/'link.log').read_text(encoding='utf-8')[-4000:])
if code:raise SystemExit(code)
p=dest/'nemoterm.exe';result=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(dest/'image.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(result)
