import datetime,gzip,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
path=root/'research/d3d11-threading-validation.json';manifest=read(path)
out=root/'research/d3d11-threading-evidence';files=[]
def retain(p,name):
    raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);dest=out/(name+'.gz')
    assert not dest.exists(),dest;dest.write_bytes(packed)
    files.append(dict(path=dest.relative_to(root).as_posix(),bytes=len(packed),sha256=sha(packed),
        raw_bytes=len(raw),raw_sha256=sha(raw),encoding='gzip'))
image=root/'build/io-fix-single/nemoterm.exe';digest=sha(image.read_bytes())
assert digest=='00f9a30d6a4660efc020cfebef5bddc51146a460ebd0308a15b6ee50cc26fe49'
followup=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    image=dict(bytes=image.stat().st_size,sha256=digest),memory_acceptance=False,cases={})
for label,fixture in [('io-fix-pixels','renderer'),('io-fix-workload','tabs'),('io-failure-observer','tabs')]:
    base=root/'build'/label;ctl=read(base/'research'/f'{fixture}-controller.json')
    assert ctl['executable_sha256']==digest and not ctl['cleanup']['after']['active']
    v=read(base/'research'/('renderer-observed.json' if fixture=='renderer' else 'workload-tabs-directx-left-observed.json'))
    assert v['executable_sha256']==digest
    item=dict(controller=ctl,memory_acceptance=False)
    if fixture=='renderer':
        assert ctl['completed'] and [m['active'] for m in v['modes']]==['GDI','OpenGL','DirectX']
        item['modes']=[dict(active=m['active'],checks=len(m['checks'])) for m in v['modes']]
    else:
        assert not ctl['completed'] and not v['completed'] and v['owned_job_cleanup']['terminated_remaining']
        assert v['actual_grid']==[160,48] and v['font']=='SarasaTermSC Nerd Font Light'
        item.update(baseline=v['two_tabs'],last_cycle=v['cycles'][-1],cycles=len(v['cycles']),
            io_diagnostic=v.get('io_failure_diagnostic'),error=v['error'],inner_cleanup=v['owned_job_cleanup'])
    followup['cases'][label]=item
    for p in sorted((base/'research').iterdir()):
        if p.is_file():retain(p,label+'-'+p.name)
    for relative in (fixture+'.log','controller.log','tests/tabs_window_smoke.py','tests/renderer_window_smoke.py'):
        retain(base/relative,label+'-'+relative.replace('/','_'))
for name in ('io-fix-frontend.log','io-fix-handle-test.log','run-io-fix-checks.py',
    'run-io-failure-observer.py','retain-io-followup.py'):
    retain(root/'build'/name,name)
for p in (root/'build/io-fix-single').iterdir():
    if p.suffix in ('.json','.log','.rsp'):retain(p,'io-fix-link-'+p.name)
manifest['io_lifetime_followup']=followup;manifest['files']+=files
for f in manifest['files']:
    b=(root/f['path']).read_bytes()
    assert len(b)==f['bytes'] and sha(b)==f['sha256'] and sha(gzip.decompress(b))==f['raw_sha256']
path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(new_records=len(files),total=len(manifest['files']),followup=followup),indent=2))
