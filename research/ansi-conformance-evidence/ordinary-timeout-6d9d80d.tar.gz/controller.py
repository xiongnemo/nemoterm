"""Preserve the original full-CI SUB assertion failures and all completed jobs."""
from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile
root=Path(__file__).resolve().parents[1]
work=root/'build/cancellation-worktree'
base=root/'build/ci-ansi-ordinary-6d9d80d'
source='6d9d80d9421ec8bfe9476018d53c0355f3356b09'
run=json.loads((base/'ordinary-run.json').read_text(encoding='utf-8'))
assert (run['headSha'],run['databaseId'],run['status'],run['conclusion']) == (source,43706562015,'completed','cancelled')
assert sorted(j['conclusion'] for j in run['jobs']) == ['cancelled','success','success','success']
annotations=json.loads((base/'windows-job-annotations.json').read_text(encoding='utf-8'))
assert any(a['message']=='The job has exceeded the maximum execution time of 40m0s' for a in annotations)
entries={'controller.py':Path(__file__)}
for p in base.rglob('*'):
    if p.is_file():entries[p.relative_to(base).as_posix()]=p
for name in ('.github/workflows/ci.yml','scripts/generate-ansi-reference.py','tests/tab_workload_memory.py','tests/memory_limits.py'):
    entries['source/'+name]=subprocess.check_output(['git','show',f'{source}:{name}'],cwd=work)
workloads=[]
for p in sorted((base/'core-evidence').rglob('*workload-tabs-*-observed.json')):
    d=json.loads(p.read_text(encoding='utf-8'))
    assert d['completed'] and d['memory_limit_passed'] and not d['memory_instrumented']
    assert not d['owned_job_cleanup']['terminated_remaining']
    workloads.append(dict(path=p.relative_to(base).as_posix(),renderer=d['renderer'],grid=d['actual_grid'],
                          executable_sha256=d['executable_sha256'],peaks=d['process_tree_memory']['peaks']['frontend'],
                          limit=d['memory_limit_bytes']))
assert len(workloads)==11
def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
archive=work/'research/ansi-conformance-evidence/ordinary-timeout-6d9d80d.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,value in sorted(entries.items()):
        info=tarfile.TarInfo(name)
        if isinstance(value,bytes):
            info.size=len(value);checksum=hashlib.sha256(value).hexdigest();tar.addfile(info,io.BytesIO(value))
        else:
            info.size=value.stat().st_size;checksum=digest(value)
            with value.open('rb') as f:tar.addfile(info,f)
        records.append(dict(path=name,raw_bytes=info.size,raw_sha256=checksum))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path']
        assert hashlib.file_digest(tar.extractfile(member),'sha256').hexdigest()==record['raw_sha256']
manifest=dict(source=source,run=43706562015,conclusion='cancelled',
    reason='GitHub annotation confirms the Windows job exceeded its outer 40-minute execution limit during the final dense DirectX workload.',
    completed_workloads=workloads,
    limits='Eleven completed uninjected memory workloads, including dense GDI; no completed dense DX result or successful full-product artifact. The GDI memory target and accepted current DX footprint are unchanged.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
                archive_sha256=digest(archive),records=records))
(work/'research/ansi-conformance-ordinary-timeout-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size)))
