from pathlib import Path
import gzip,hashlib,json,tarfile
root=Path(__file__).resolve().parents[1]
work=root/'build/kitty-relative-worktree'
directory=root/'build/kitty-relative-implementation-03'
manifest_path=work/'research/kitty-relative-validation.json'
manifest=json.loads(manifest_path.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
label='implementation-03'
assert all(x['label']!=label for x in manifest['implementations'])
exits={r['test']:r['exit'] for r in json.loads((directory/'results.json').read_text(encoding='utf-8-sig'))}
assert exits==dict(test_sixel_terminal=1,test_kitty_cache=0,test_kitty_placements=0,test_kitty_layout=0)
log=(directory/'test_sixel_terminal.log').read_text(encoding='utf-8-sig')
failures=[s.removeprefix('Kitty relative failed state: ') for s in log.splitlines()
          if s.startswith('Kitty relative failed state: ')]
assert failures==['virtual-parent/'+s for s in ['virtual-root','relative-child','placeholder','earlier-placeholder','erase-placeholders']]
assert 'Kitty relative replay: 238 states; 5 failed states' in log
assert '1982 checks passed' in (directory/'test-cache-strict.log').read_text(encoding='utf-8-sig')
relative=f'research/kitty-relative-evidence/{label}.tar.gz'
archive=work/relative
files={p.name:p for p in directory.iterdir() if p.is_file() and p.suffix!='.exe'}
files['controller.py']=Path(__file__)
rows=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w|') as tar:
    for name,p in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=p.stat().st_size
        with p.open('rb') as f:tar.addfile(info,f)
        rows.append(dict(path=name,raw_bytes=info.size,raw_sha256=sha(p)))
manifest['bundles'].append(dict(path=relative,archive_bytes=archive.stat().st_size,
    archive_sha256=sha(archive),records=rows))
manifest['implementations'].append(dict(label=label,base_commit=(directory/'base-commit.txt').read_text(encoding='utf-8-sig').strip(),
    exit_codes=exits,failures=failures,strict_cache_exit=0,
    scope='Read-only queries also preserve deferred orphan data; local tests only',source_patch_sha256=sha(directory/'source.patch')))
for bundle in manifest['bundles']:
    assert sha(work/bundle['path'])==bundle['archive_sha256']
    with tarfile.open(work/bundle['path'],'r:gz') as tar:
        for row in bundle['records']:
            assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest()==row['raw_sha256']
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(label=label,records=len(rows),archive_bytes=archive.stat().st_size,all_bundles_verified=len(manifest['bundles']))))
