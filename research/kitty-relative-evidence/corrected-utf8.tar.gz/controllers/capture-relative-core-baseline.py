from pathlib import Path
import datetime,hashlib,json,re,shutil,subprocess

root=Path(__file__).resolve().parents[1]
work=root/'build/kitty-relative-worktree'
out=root/'build/kitty-relative-core-baseline'
assert not out.exists()
subprocess.run(['git','diff','--quiet','03c1f05158eca8d0b8b78327d28651149b115416','--',
    'vendor/putty-0.85/terminal','vendor/putty-0.85/windows','native'],cwd=work,check=True)
out.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
exe=work/'build/test_sixel_terminal.exe'
with (out/'baseline.log').open('wb') as log:
    result=subprocess.run([str(exe)],cwd=work,stdout=log,stderr=subprocess.STDOUT,timeout=60)
log=(out/'baseline.log').read_text(errors='replace')
failed=re.findall(r'^Kitty relative failed state: (.+)$',log,re.M)
summary=re.search(r'Kitty relative replay: (\d+) states; (\d+) failed states',log)
assert summary and int(summary[1])==238 and int(summary[2])==len(failed)
assert result.returncode==1 and failed, 'This controller captures a failing pre-implementation baseline'
paths=['tests/kitty_relative_oracle.py','scripts/generate-kitty-relative-reference.py',
    'vendor/putty-0.85/test/test_kitty_relative.inc','vendor/putty-0.85/test/kitty_relative_reference.h',
    'vendor/putty-0.85/test/test_kitty_terminal.inc','build/CMakeCache.txt']
files=[]
for name in paths:
    p=work/name;target=out/'snapshot'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
    files.append(dict(path=name,sha256=sha(p)))
shutil.copy2(__file__,out/'controller.py')
compiler=root/'../unused'
commands=subprocess.check_output([str(root/'tools/python/bin/ninja.exe'),'-C',str(work/'build'),'-t','commands','test_sixel_terminal'],text=True)
(out/'build-commands.txt').write_text(commands)
(out/'compiler-version.txt').write_text(subprocess.check_output(
    ['C:/Users/nemo/scoop/apps/mingw-msvcrt/current/bin/gcc.exe','--version'],text=True))
record=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    production_source='03c1f05158eca8d0b8b78327d28651149b115416',
    fixture_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
    fixture_scope='New uncommitted replay files retained byte-for-byte; production sources unchanged',
    core_executable_sha256=sha(exe),core_executable_bytes=exe.stat().st_size,
    core_exit_code=result.returncode,states=238,failed_states=len(failed),
    failed_cases=len({name.split('/')[0] for name in failed}),failures=failed,files=files,
    log_sha256=sha(out/'baseline.log'),scope='Headless real-core baseline failure, not product acceptance')
(out/'baseline.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ('core_exit_code','states','failed_states','failed_cases','core_executable_sha256')}))
