from pathlib import Path

source=Path(__file__).with_name('capture-relative-core-baseline.py').read_text()
assert source.count("out=root/'build/kitty-relative-core-baseline'")==1
source=source.replace("out=root/'build/kitty-relative-core-baseline'",
                      "out=root/'build/kitty-relative-core-utf8-baseline'")
exec(compile(source,str(Path(__file__)),'exec'))
