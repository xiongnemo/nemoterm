from pathlib import Path
import gzip,hashlib,json,subprocess,tarfile

root=Path(__file__).resolve().parents[1]
work=root/'build/kitty-relative-worktree'
manifest_path=work/'research/kitty-relative-validation.json'
manifest=json.loads(manifest_path.read_text())
assert 'implementations' not in manifest
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
assert base=='33cd9b5b42b02cbb71e580c73c033c6ef97d431a'
strict=root/'build/kitty-relative-strict-components'
(strict/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=work))
(strict/'base-commit.txt').write_text(base+'\n')
expected=['virtual-root','relative-child','placeholder','earlier-placeholder','erase-placeholders']
records=[]
for label,folder in [
    ('implementation-01','kitty-relative-implementation-01'),
    ('implementation-02','kitty-relative-implementation-02'),
    ('strict-components','kitty-relative-strict-components')]:
    directory=root/'build'/folder
    if label.startswith('implementation'):
        log=(directory/'test_sixel_terminal.log').read_text(encoding='utf-8-sig')
        failures=[s.removeprefix('Kitty relative failed state: ') for s in log.splitlines()
                  if s.startswith('Kitty relative failed state: ')]
        assert failures==['virtual-parent/'+s for s in expected]
        assert 'Kitty relative replay: 238 states; 5 failed states' in log
        assert all('(Kitty relative replay: ' in s for s in log.splitlines() if s.startswith('/putty/'))
        exits=dict(test_sixel_terminal=1,test_kitty_cache=0,test_kitty_placements=0,
                   test_kitty_layout=1 if label.endswith('01') else 0)
    else:
        failures=[]
        exits=dict(cache=0,layout=0,placements=0)
        for name,count in [('cache',1975),('layout',150),('placements',2841)]:
            assert f'{count} checks passed' in (directory/f'test-{name}.log').read_text(encoding='utf-8-sig')
    relative=f'research/kitty-relative-evidence/{label}.tar.gz'
    archive=work/relative
    files={p.name:p for p in directory.iterdir() if p.is_file() and p.suffix!='.exe'}
    files['controller.py']=Path(__file__)
    rows=[]
    with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w|') as tar:
        for name,p in sorted(files.items()):
            info=tarfile.TarInfo(name);info.size=p.stat().st_size
            with p.open('rb') as f:tar.addfile(info,f)
            rows.append(dict(path=name,raw_bytes=info.size,raw_sha256=sha(p)))
    with tarfile.open(archive,'r:gz') as tar:
        for row in rows:
            assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest()==row['raw_sha256']
    manifest['bundles'].append(dict(path=relative,archive_bytes=archive.stat().st_size,
        archive_sha256=sha(archive),records=rows))
    records.append(dict(label=label,base_commit=base,exit_codes=exits,failures=failures,
        scope='Local component and real-core tests; no native rendering or product acceptance',
        source_patch_sha256=sha(directory/'source.patch')))
    print(json.dumps(dict(label=label,records=len(rows),archive_bytes=archive.stat().st_size)))
manifest['implementations']=records
manifest['scope']='Ordinary relative placements implemented; 233/238 states match; five Unicode-placeholder states fail; product acceptance pending'
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
assert sha(root/'dist/nemoterm.exe')=='1655120a9a64bfd29b64f6ad0a5cc912484ba1d242ec560938591c03328e2cf1'
