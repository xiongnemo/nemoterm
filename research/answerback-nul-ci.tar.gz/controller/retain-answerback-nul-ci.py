from pathlib import Path
import hashlib,json,tarfile
root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
base=root/'build/ci-answerback-nul-253855b'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source='253855b481b2ccd6a13dae5490c42f19c8b9dd64'
run=load(base/'ansi-components-run.json')
assert run['databaseId']==43757506328 and run['headSha']==source and run['conclusion']=='success'
jobs={j['name']:j['conclusion'] for j in run['jobs']}
assert jobs['linux (gcc)']==jobs['linux (clang)']==jobs['msvc']=='success'
for compiler in ('gcc','clang','msvc'):
    assert (base/'ansi-components'/compiler/'test_queries.log').read_text().strip()=='Query suite passed'
files=[]
def add(p,n):files.append(dict(path=n,source=p,bytes=p.stat().st_size,sha256=sha(p)))
for p in (base/'ansi-components').rglob('*'):
    if p.is_file():add(p,p.relative_to(base).as_posix())
for name in ('ansi-components-run.json','ansi-components-run.log','ansi-components-artifacts.json'):
    add(base/name,name)
for compiler in ('gcc','clang','msvc'):
    add(base/'ansi-components'/(compiler+'-download.json'),'ansi-components/'+compiler+'-download.json')
add(Path(__file__),'controller/retain-answerback-nul-ci.py')
archive=work/'research/answerback-nul-ci.tar.gz';assert not archive.exists()
with tarfile.open(archive,'x:gz') as tar:
    for f in files:tar.add(f['source'],arcname=f['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for f in files:assert hashlib.sha256(tar.extractfile(f['path']).read()).hexdigest()==f['sha256']
record=dict(source_commit=source,run_id=run['databaseId'],conclusion=run['conclusion'],
    scope='GCC and Clang sanitizer plus MSVC component regression for the NUL conversion fix; full native and single-image acceptance are separate.',
    artifacts={c:load(base/'ansi-components'/(c+'-download.json'))['artifact_id'] for c in ('gcc','clang','msvc')},
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),
    files=[{k:v for k,v in f.items() if k!='source'} for f in files])
(work/'research/answerback-nul-ci-validation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='files'},indent=2))
