from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];base=root/'build/iterm-ci-preview';base.mkdir()
exe=root/'build/ci-iterm-3187ec5/product/nemoterm.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='8e52b517787fb508937611b15eb48855ab0e73521978f579d853cf48d9748585'
fixture=(root/'tests/tabs_window_smoke.py').read_text()
needle='                if hover_session:hover_session.detach()'
assert fixture.count(needle)==1
fixture=fixture.replace(needle,"                if hover_session:\n                    evidence['hover_messages']=hover_script.exports_sync.events()\n                    hover_session.detach()")
trace='''
const events=[];
const getProc=new NativeFunction(Process.getModuleByName('user32.dll').getExportByName('GetWindowLongPtrW'),'pointer',['pointer','int']);
Interceptor.attach(getProc(ownedHost,-4),{
    onEnter(args) {
        if (!args[0].equals(ownedHost)) return;
        const msg=args[1].toUInt32();
        if ([0x200,0x2a3,0x113,0x5,0x6].includes(msg)) {
            events.push({msg,wp:args[2].toUInt32(),lp:args[3].toInt32(),ms:Date.now()});
            if(events.length>256)events.shift();
        }
    }
});
rpc.exports.events=()=>events;
'''
results=[]
for inline in [False,True]:
    name='directx'+('-images' if inline else '')
    dest=base/name
    for directory in ('dist','research','build','tools'):(dest/directory).mkdir(parents=True)
    shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
    (dest/'tests/tabs_window_smoke.py').write_text(fixture,encoding='utf-8')
    probe=dest/'tests/tabs_hover_probe.js';probe.write_text(probe.read_text()+trace)
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(exe,dest/'dist/nemoterm.exe')
    args=['--renderer','directx','--side','left','--cols','160','--rows','48','--workload-memory']+(['--inline-images'] if inline else [])
    with (dest/'controller.log').open('w') as log:
        run=subprocess.run([sys.executable,str(root.parent/'rtl-worktree/build/run-owned-check.py'),str(dest),'tabs',*args],stdout=log,stderr=subprocess.STDOUT)
    prefix='inline-workload-tabs' if inline else 'workload-tabs'
    observed=dest/f'research/{prefix}-directx-left-observed.json'
    d=json.loads(observed.read_text()) if observed.exists() else {}
    record=dict(name=name,exit_code=run.returncode,completed=d.get('completed'),peak_private_ws=d.get('peak_private_ws'),memory_limit_passed=d.get('memory_limit_passed'),error=d.get('error'),hover_messages=d.get('hover_messages'))
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps({k:v for k,v in record.items() if k!='hover_messages'}),flush=True)
    if run.returncode:
        print((dest/'controller.log').read_text()[-2800:]);raise SystemExit(run.returncode)
