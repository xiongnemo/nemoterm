from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];project=root.parents[1]
base=root/'build/rtl-capture-comparison';base.mkdir()
old=subprocess.check_output(['git','show','d82d9ae:tests/rtl_window_smoke.py'],cwd=root).decode()
old=old.replace('from gpu_capture import OwnedGPUCapture','from gpu_capture import OwnedGPUCapture\nfrom thread_snapshot import OwnedThreadSnapshot')
needle='                    u.PostMessageW(hwnd,0x10,0,0);assert process.wait(timeout=10)==0'
assert old.count(needle)==1
old=old.replace(needle,'''                    close_started=time.monotonic()
                    assert u.PostMessageW(hwnd,0x10,0,0)
                    try:
                        assert process.wait(timeout=10)==0
                        record['close_seconds']=time.monotonic()-close_started
                    except subprocess.TimeoutExpired:
                        record['close_seconds']=time.monotonic()-close_started
                        try:
                            record['timeout_threads']=OwnedThreadSnapshot(process,job).snapshot('rtl-close-timeout')
                        except Exception as error:
                            record['snapshot_error']=repr(error)
                        raise''')
(base/'original-fixture.py').write_text(old,encoding='utf-8')
images=[('failed-ci',root/'build/ci-tabs-d82d9ae/unverified-product/nemoterm.exe','40924e0b16b3cbf6c2b90fa5b29af2ce69076469bd74b0b1fda2decfb569f573'),('main-ci',project/'build/ci-main-8264b27/product/nemoterm.exe','11041b9d7b1ee3107827dd53336de6d46cd5f8db8f606915e936a0efdf070e8b')]
cases=[('before-'+str(i),'old',images[0],'Courier') for i in range(2)]
cases += [('after-'+image[0]+'-'+fontname,'new',image,font) for image in images for fontname,font in [('courier','Courier'),('sarasa','SarasaTermSC Nerd Font Light')]]
results=[]
for name,fixture,(label,exe,digest),font in cases:
    assert hashlib.sha256(exe.read_bytes()).hexdigest()==digest
    dest=base/name
    for directory in ('dist','research','build','tools'):(dest/directory).mkdir(parents=True)
    shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
    if fixture=='old':(dest/'tests/rtl_window_smoke.py').write_text(old,encoding='utf-8')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(exe,dest/'dist/nemoterm.exe')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        result=subprocess.run([sys.executable,str(project/'build/rtl-worktree/build/run-owned-check.py'),str(dest),'rtl','--font',font],env=dict(os.environ,CI='true'),stdout=log,stderr=subprocess.STDOUT)
    observed=dest/'research/rtl-window-observed.json'
    d=json.loads(observed.read_text()) if observed.exists() else {}
    record=dict(name=name,fixture=fixture,image=label,font=font,exit_code=result.returncode,completed=d.get('completed'),modes=[dict(requested=m['requested'],active=m.get('active'),checks=len(m['checks']),close_seconds=m.get('close_seconds'),cleanup=m.get('cleanup')) for m in d.get('modes',[])],error=d.get('error'))
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps(record),flush=True)
    if result.returncode:
        print((dest/'controller.log').read_text()[-3000:]);raise SystemExit(result.returncode)
