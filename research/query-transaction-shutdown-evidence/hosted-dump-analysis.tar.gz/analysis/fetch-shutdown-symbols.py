"""Obtain matching Microsoft analysis files; never load these DLLs for execution."""
from pathlib import Path
import concurrent.futures,hashlib,json,struct,urllib.request,uuid
root=Path(__file__).resolve().parents[1]
base=root/'build/query-transaction-shutdown-88743d3'
directory=base/'symbols';directory.mkdir(exist_ok=True)
record=json.loads((base/'dump-structure.json').read_text())

def pe_identity(data):
 pe=struct.unpack_from('<I',data,60)[0];assert data[pe:pe+4]==b'PE\0\0'
 sections=struct.unpack_from('<H',data,pe+6)[0]
 timestamp=struct.unpack_from('<I',data,pe+8)[0]
 opt=pe+24;optsize=struct.unpack_from('<H',data,pe+20)[0]
 assert struct.unpack_from('<H',data,opt)[0]==0x20b
 size=struct.unpack_from('<I',data,opt+56)[0]
 def offset(rva):
  for i in range(sections):
   at=opt+optsize+40*i
   vs,va,rs,rp=struct.unpack_from('<IIII',data,at+8)
   if va<=rva<va+max(vs,rs):return rp+rva-va
  raise ValueError('RVA outside sections')
 debug,debugsize=struct.unpack_from('<II',data,opt+112+6*8)
 result=dict(timestamp=timestamp,size=size,sha256=hashlib.sha256(data).hexdigest())
 if debug:
  pos=offset(debug)
  for i in range(debugsize//28):
   kind,length,_,pointer=struct.unpack_from('<IIII',data,pos+28*i+12)
   cv=data[pointer:pointer+length]
   if kind==2 and cv[:4]==b'RSDS':
    result.update(pdb_guid=str(uuid.UUID(bytes_le=cv[4:20])),pdb_age=struct.unpack_from('<I',cv,20)[0])
 return result

def acquire(mod):
 row=dict(module=mod['name'],files=[])
 for name,key in ((mod['name'],mod['image_symbol_key']),(mod['pdb_name'],mod['pdb_key'])):
  assert '/' not in name and '\\' not in name
  url=f'https://msdl.microsoft.com/download/symbols/{name}/{key}/{name}'
  path=directory/name
  item=dict(url=url,name=name);row['files'].append(item)
  try:
   if not path.exists():
    with urllib.request.urlopen(url,timeout=50) as response:raw=response.read(64*1024*1024+1)
    assert len(raw)<=64*1024*1024
    path.write_bytes(raw)
   raw=path.read_bytes();item.update(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
   if name.lower().endswith('.dll'):
    identity=pe_identity(raw)
    for key in ('timestamp','size','pdb_guid','pdb_age'):assert identity[key]==mod[key],(name,key,identity,mod)
    item['verified_pe_identity']=identity
  except Exception as error:item['error']=repr(error)
 return row

if __name__=='__main__':
 selected=[m for m in record['modules'] if m['name'].lower() in ('ntdll.dll','kernelbase.dll','kernel32.dll','dxgi.dll','ucrtbase.dll','d3d11.dll')]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(acquire,selected))
 (base/'symbol-downloads.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(results,indent=2))
