"""Copy the installed Frida DLL from one newly owned waiting control, then exit."""
from pathlib import Path
import ctypes as c,hashlib,importlib.util,json,shutil,subprocess,sys,uuid
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-features-worktree'
sys.path.insert(0,str(work/'tests'))
import frida
from native_exception_observer import k
from owned_job import OwnedJob
from thread_snapshot import modules
from frida_test_utils import detach_session
spec=importlib.util.spec_from_file_location('identity',root/'build/fetch-shutdown-symbols.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
base=root/'build/query-transaction-shutdown-88743d3'
target=base/'symbols/frida-agent.dll';assert not target.exists()
expected=next(m for m in module.record['modules'] if m['name']=='frida-agent.dll')
token='Local\\NemoFridaAnalysis-'+str(uuid.uuid4());go=k.CreateEventW(None,True,False,token)
if not go:raise c.WinError(c.get_last_error())
result=dict(frida_version=frida.__version__);session=None
try:
 with OwnedJob() as job:
  process=job.spawn([str(work/'build/failure-dump-local/control.exe'),token,'normal'],creationflags=subprocess.CREATE_NO_WINDOW)
  try:
   session=frida.attach(process.pid)
   image=next(m for m in modules(process._handle) if m['name']=='frida-agent.dll')
   raw=Path(image['path']).read_bytes();identity=module.pe_identity(raw)
   for key in ('timestamp','size','pdb_guid','pdb_age'):assert identity[key]==expected[key],(key,identity,expected)
   target.write_bytes(raw);result.update(identity=identity,source_path=image['path'],bytes=len(raw))
  finally:
   if session:detach_session(session)
   k.SetEvent(go)
   result['target_exit']=process.wait(timeout=10)
   result['cleanup']=job.finish(grace=2)
  assert result['target_exit']==23 and not result['cleanup']['terminated_remaining']
finally:
 k.CloseHandle(go)
 (base/'frida-analysis-image.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
