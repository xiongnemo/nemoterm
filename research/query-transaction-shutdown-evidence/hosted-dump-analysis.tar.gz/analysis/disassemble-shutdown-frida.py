"""Resolve function ranges from the matching PE unwind table, then disassemble."""
from pathlib import Path
import json,struct,subprocess
root=Path(__file__).resolve().parents[1];base=root/'build/query-transaction-shutdown-88743d3'
p=base/'symbols/frida-agent.dll';data=p.read_bytes()
pe=struct.unpack_from('<I',data,60)[0];opt=pe+24
sections=struct.unpack_from('<H',data,pe+6)[0];optsize=struct.unpack_from('<H',data,pe+20)[0]
imagebase=struct.unpack_from('<Q',data,opt+24)[0]
def offset(rva):
 for i in range(sections):
  at=opt+optsize+40*i;vs,va,rs,rp=struct.unpack_from('<IIII',data,at+8)
  if va<=rva<va+max(vs,rs):return rp+rva-va
 raise ValueError('RVA outside file')
table,size=struct.unpack_from('<II',data,opt+112+3*8);start=offset(table)
functions=[struct.unpack_from('<III',data,at) for at in range(start,start+size,12)]
rows=[]
for address in (0x138815,0x137e28,0x13b66a,0x13972d,0x131391):
 lo,hi,unwind=next(f for f in functions if f[0]<=address<f[1]);rows.append(dict(rva=hex(address),begin=hex(lo),end=hex(hi),unwind=hex(unwind)))
 command=['C:/Users/nemo/scoop/apps/llvm/current/bin/llvm-objdump.exe','-d','--no-show-raw-insn',f'--start-address={imagebase+lo}',f'--stop-address={imagebase+hi}',str(p)]
 raw=subprocess.check_output(command)
 (base/f'frida-disassembly-{lo:x}.txt').write_bytes(raw)
print(json.dumps(rows,indent=2));(base/'frida-unwind-ranges.json').write_text(json.dumps(rows,indent=2)+'\n')
