"""Parse retained dump identities/context; stack words are candidates, not unwind."""
from pathlib import Path
import hashlib,json,struct,uuid
root=Path(__file__).resolve().parents[1]
base=root/'build/ci-query-shutdown-a8fffe4/diagnostic'
paths=list(base.glob('shutdown-failure-*/failure.dmp'));assert len(paths)==1
p=paths[0];data=p.read_bytes();assert data[:4]==b'MDMP'
count,offset=struct.unpack_from('<II',data,8)
streams={t:(size,rva) for t,size,rva in (struct.unpack_from('<III',data,offset+12*i) for i in range(count))}
for size,rva in streams.values():assert rva+size<=len(data)
size,rva=streams[4];module_count=struct.unpack_from('<I',data,rva)[0];modules=[]
for i in range(module_count):
 pos=rva+4+108*i
 base,size,checksum,timestamp,name_rva=struct.unpack_from('<QIIII',data,pos)
 length=struct.unpack_from('<I',data,name_rva)[0]
 name=data[name_rva+4:name_rva+4+length].decode('utf-16le')
 cvsize,cvrva=struct.unpack_from('<II',data,pos+76);cv=data[cvrva:cvrva+cvsize]
 row=dict(name=name.split('\\')[-1],path=name,base=base,size=size,timestamp=timestamp,checksum=checksum,
          image_symbol_key=f'{timestamp:08X}{size:x}')
 if cv[:4]==b'RSDS':
  guid=uuid.UUID(bytes_le=cv[4:20]);age=struct.unpack_from('<I',cv,20)[0]
  row.update(pdb_guid=str(guid),pdb_age=age,pdb_name=cv[24:].split(b'\0')[0].decode('utf-8'),pdb_key=guid.hex.upper()+str(age))
 modules.append(row)
def resolve(address):
 for mod in modules:
  if mod['base']<=address<mod['base']+mod['size']:
   return mod['name']+'+'+hex(address-mod['base'])
 return None
size,rva=streams[3];thread_count=struct.unpack_from('<I',data,rva)[0];threads=[]
for i in range(thread_count):
 pos=rva+4+48*i;tid=struct.unpack_from('<I',data,pos)[0]
 stack,stack_size,stack_rva,context_size,context_rva=struct.unpack_from('<QIIII',data,pos+24)
 rip=struct.unpack_from('<Q',data,context_rva+248)[0];rsp=struct.unpack_from('<Q',data,context_rva+152)[0]
 candidates=[]
 for at in range(max(0,rsp-stack),stack_size-7,8):
  pointer=struct.unpack_from('<Q',data,stack_rva+at)[0]
  if name:=resolve(pointer):candidates.append(dict(address=hex(stack+at),pointer=hex(pointer),module_rva=name))
 threads.append(dict(tid=tid,rip=hex(rip),rsp=hex(rsp),instruction=resolve(rip),stack_bytes=stack_size,
                     raw_stack_pointer_candidates=candidates))
record=dict(dump_path=str(p),dump_sha256=hashlib.sha256(data).hexdigest(),modules=modules,threads=threads,
 caveat='Register instruction is captured; raw stack-pointer candidates are not an unwound call chain')
out=root/'build/query-transaction-shutdown-88743d3/dump-structure.json';out.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(modules=[m for m in modules if m['name'].lower() in ('ntdll.dll','kernelbase.dll','kernel32.dll','frida-agent.dll')],threads=threads),indent=2))
