"""One unchanged local shutdown replay of the exact failed image, not acceptance."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-features-worktree'
source='88743d31c21090bf78be63fc2719a51993507310'
base=root/'build/ci-kitty-query-transactions-88743d3'
stage=root/'build/query-transaction-shutdown-88743d3/baseline'
stage.mkdir(parents=True,exist_ok=False)
for folder in ('dist','tests','research','logs'):(stage/folder).mkdir()
names=subprocess.check_output(['git','ls-tree','-r','--name-only',source,'--','tests'],cwd=work,text=True).splitlines()
for name in names:
 p=stage/name;p.parent.mkdir(exist_ok=True,parents=True)
 p.write_bytes(subprocess.check_output(['git','show',source+':'+name],cwd=work))
exe=base/'unverified-product/nemoterm.exe'
digest=hashlib.sha256(exe.read_bytes()).hexdigest()
assert digest=='214abd0b87b45397d5952cb4151ac0778cc4b436c5ba34fa1a4e4bf0ad160c47'
shutil.copy2(exe,stage/'dist/nemoterm.exe')
identity=dict(source_commit=source,source_run=43660381407,artifact_id=14139608856,
 executable_sha256=digest,executable_bytes=exe.stat().st_size,
 scope='One unchanged exact-failed-image local shutdown replay; no product acceptance')
(stage/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
shutil.copy2(Path(__file__),stage/'controller.py')
env=dict(os.environ,NEMOTERM_TEST_EXE=str(stage/'dist/nemoterm.exe'),NEMOTERM_REQUIRE_OPENGL='1',NEMOTERM_REQUIRE_DIRECTX='1',NEMOTERM_SHUTDOWN_DEADLINE_SECONDS='120')
start=time.monotonic()
with (stage/'logs/shutdown.log').open('w') as log:
 result=subprocess.run([sys.executable,'tests/shutdown_window_smoke.py'],cwd=stage,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
row=dict(exit_code=result.returncode,seconds=time.monotonic()-start)
(stage/'result.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
sys.exit(result.returncode)
