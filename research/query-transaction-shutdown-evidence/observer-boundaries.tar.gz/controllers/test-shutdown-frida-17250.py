"""Check loader-hook activation separately from lifetime-order assertions."""
from pathlib import Path
import ctypes as c,json,os,shutil,subprocess,sys,tempfile
from ctypes import wintypes as w
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-features-worktree'
base=root/'build/query-transaction-shutdown-88743d3/frida-17.25.0-local'
base.mkdir(parents=True,exist_ok=False)
shutil.copytree(root/'build/query-transaction-shutdown-88743d3/address-probe-local-v2/tests',base/'tests',ignore=shutil.ignore_patterns('__pycache__'))
(base/'research').mkdir();(base/'logs').mkdir();(base/'dist').mkdir()
shutil.copy2(root/'build/ci-kitty-query-transactions-88743d3/unverified-product/nemoterm.exe',base/'dist/nemoterm.exe')
sys.path.insert(0,str(base/'tests'))
import frida
from owned_job import OwnedJob
from thread_snapshot import modules
from native_test_utils import wait_for,read_snapshot
from frida_test_utils import detach_session
from shutdown_probe_targets import resolve_shutdown_probe_targets,k
k.ReadProcessMemory.argtypes=[w.HANDLE,c.c_void_p,c.c_void_p,c.c_size_t,c.POINTER(c.c_size_t)]
k.ReadProcessMemory.restype=w.BOOL
legacy=subprocess.check_output(['git','show','88743d3:tests/shutdown_probe.js'],cwd=work,text=True)
candidate=(base/'tests/shutdown_probe.js').read_text()
for name in ('shutdown_probe.js','shutdown_probe_controls.py','shutdown_window_smoke.py'):
 shutil.copy2(work/'tests'/name,base/'tests'/name)
fixture=work/'build/shutdown-address-probe/fixture.exe'
records=[]
(base/'frida-version.json').write_text(json.dumps(dict(frida=frida.__version__,python=sys.version),indent=2)+'\n')
for mode in ('empty-script','legacy-module-lookups','external-addresses'):
 row=dict(mode=mode,snapshots=[]);records.append(row);session=None
 with tempfile.TemporaryDirectory(prefix='nemo-loader-boundary-') as temp,OwnedJob() as job:
  ready=Path(temp)/'ready.json'
  process=job.spawn([str(fixture),'ordered',str(ready)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
  try:
   hwnd=wait_for(lambda:read_snapshot(ready))['hwnd']
   row['targets']=resolve_shutdown_probe_targets(process,job)
   ntdll=c.WinDLL('ntdll');remote=next(m for m in modules(process._handle) if m['name'].lower()=='ntdll.dll')
   addresses={name:remote['base']+k.GetProcAddress(ntdll._handle,name.encode())-ntdll._handle for name in ('LdrLoadDll','LdrUnloadDll')}
   def capture(phase):
    entry=dict(phase=phase,bytes={})
    for name,address in addresses.items():
     data=c.create_string_buffer(32);count=c.c_size_t()
     assert k.ReadProcessMemory(process._handle,address,data,len(data),c.byref(count)) and count.value==len(data)
     entry['bytes'][name]=data.raw.hex()
    row['snapshots'].append(entry)
   capture('before-attach')
   session=frida.attach(process.pid);capture('after-attach')
   script=session.create_script('rpc.exports={ping(){return 1;}};' if mode=='empty-script' else legacy if mode=='legacy-module-lookups' else candidate)
   script.load()
   if mode=='empty-script':assert script.exports_sync.ping()==1
   elif mode=='legacy-module-lookups':script.exports_sync.watch(hex(hwnd))
   else:script.exports_sync.watch(hex(hwnd),row['targets']['addresses'])
   capture('after-script')
   row['loader_entries_changed']={name:row['snapshots'][0]['bytes'][name]!=row['snapshots'][-1]['bytes'][name] for name in addresses}
   detach_session(session);session=None
   process.stdin.write(b'G');process.stdin.flush();process.stdin.close()
   row['exit_code']=process.wait(timeout=10)
   row['cleanup']=job.finish(grace=2)
   assert row['exit_code']==0 and not row['cleanup']['terminated_remaining']
  finally:
   if session:detach_session(session)
   (base/'loader-boundary.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps({k:row[k] for k in ('mode','loader_entries_changed','exit_code')}),flush=True)
env=dict(os.environ,NEMOTERM_TEST_EXE=str(base/'dist/nemoterm.exe'),NEMOTERM_REQUIRE_OPENGL='1',NEMOTERM_REQUIRE_DIRECTX='1',NEMOTERM_SHUTDOWN_DEADLINE_SECONDS='120')
for name,command in [('controls',['tests/shutdown_probe_controls.py','--executable',str(fixture)]),('shutdown',['tests/shutdown_window_smoke.py','--failure-dump',str(work/'build/failure-dump-local/helper.exe')])]:
 with (base/'logs'/f'{name}.log').open('w') as log:
  result=subprocess.run([sys.executable,*command],cwd=base,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
 print(json.dumps(dict(group=name,exit_code=result.returncode)),flush=True)
 if result.returncode:sys.exit(result.returncode)
shutil.copy2(Path(__file__),base/'controller.py')
