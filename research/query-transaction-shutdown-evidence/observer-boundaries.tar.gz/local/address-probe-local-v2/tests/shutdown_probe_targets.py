"""Resolve same-host system exports without activating Frida's module registry."""
import ctypes as c
from ctypes import wintypes as w
import os
from handle_snapshot import OwnedHandleSnapshot
from thread_snapshot import modules, k

k.GetProcAddress.argtypes = [w.HMODULE, c.c_char_p]
k.GetProcAddress.restype = c.c_void_p
k.GetModuleHandleExW.argtypes = [w.DWORD, c.c_void_p, c.POINTER(w.HMODULE)]
k.GetModuleHandleExW.restype = w.BOOL
k.GetModuleFileNameW.argtypes = [w.HMODULE, w.LPWSTR, w.DWORD]
k.GetModuleFileNameW.restype = w.DWORD


def resolve_shutdown_probe_targets(process, job):
    owner = OwnedHandleSnapshot(process, job)
    owner._validate_owner()
    remote = modules(process._handle)
    addresses, identities = {}, []
    for library, name in (('user32.dll', 'IsWindow'), ('user32.dll', 'GetWindowLongPtrW'),
                          ('user32.dll', 'GetWindowThreadProcessId'),
                          ('ntdll.dll', 'RtlFreeHeap'), ('ole32.dll', 'CoUninitialize')):
        # Resolve forwarders in the controller, then use the actual owning
        # image's RVA in the fixture. Absolute local/remote bases may differ.
        local = c.WinDLL(library)
        address = k.GetProcAddress(local._handle, name.encode('ascii'))
        module = w.HMODULE()
        if not address or not k.GetModuleHandleExW(6, address, c.byref(module)):
            raise c.WinError(c.get_last_error())
        path = c.create_unicode_buffer(32768)
        length = k.GetModuleFileNameW(module, path, len(path))
        if not length or length >= len(path):
            raise RuntimeError('System export owner path unavailable')
        matches = [m for m in remote if os.path.normcase(m['path']) == os.path.normcase(path.value)]
        if len(matches) != 1:
            raise RuntimeError(('Export owner differs between controller and fixture', name, path.value))
        target = matches[0]
        rva = address-module.value
        if not 0 <= rva < target['size']:
            raise RuntimeError(('Export outside matched fixture module', name))
        addresses[name] = hex(target['base']+rva)
        identities.append(dict(export=name, module=target['path'], rva=rva,
                               local_base=module.value, remote_base=target['base'],
                               remote_size=target['size']))
    owner._validate_owner()
    return dict(addresses=addresses, modules=identities,
                scope='Verified private-job member; same-host system module paths and bounded RVAs')
