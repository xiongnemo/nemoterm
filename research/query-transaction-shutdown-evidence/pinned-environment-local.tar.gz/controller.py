from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
import frida
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-features-worktree'
base=root/'build/query-transaction-shutdown-88743d3/pinned-environment-local'
assert frida.__version__=='17.23.3'
base.mkdir(parents=True,exist_ok=False)
shutil.copytree(work/'tests',base/'tests',ignore=shutil.ignore_patterns('__pycache__'))
for name in ('research','logs','dist'):(base/name).mkdir()
shutil.copy2(root/'build/ci-kitty-query-transactions-88743d3/unverified-product/nemoterm.exe',base/'dist/nemoterm.exe')
env=dict(os.environ,NEMOTERM_TEST_EXE=str(base/'dist/nemoterm.exe'),NEMOTERM_REQUIRE_DIRECTX='1',NEMOTERM_SHUTDOWN_DEADLINE_SECONDS='120')
record=dict(frida=frida.__version__,interpreter=sys.executable,groups=[],completed=False)
try:
 for name,command in [('controls',['tests/shutdown_probe_controls.py','--executable',str(work/'build/shutdown-address-probe/fixture.exe')]),
    ('shutdown',['tests/shutdown_window_smoke.py','--failure-dump',str(work/'build/failure-dump-local/helper.exe')])]:
  with (base/'logs'/f'{name}.log').open('w') as log:
   result=subprocess.run([sys.executable,*command],cwd=base,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
  record['groups'].append(dict(group=name,exit_code=result.returncode));print(record['groups'][-1],flush=True)
  assert result.returncode==0
 result=json.loads((base/'research/shutdown-window-observed.json').read_text())
 assert result['completed'] and result['frida_version']=='17.23.3' and len(result['cases'])==12
 assert all(c['active_renderer']=={'gdi':1,'opengl':2,'directx':3}[c['renderer']] and c['exit_code']==0 and not c['cleanup']['terminated_remaining'] for c in result['cases'])
 record['completed']=True
finally:
 record['source_sha256']={n:hashlib.sha256((work/n).read_bytes()).hexdigest() for n in ('scripts/prepare-shutdown-observer.ps1','scripts/test-shutdown-observer.ps1','scripts/test-single-exe.ps1','tests/shutdown_window_smoke.py','tests/shutdown_probe_controls.py','tests/shutdown_probe.js','tests/requirements-shutdown.txt')}
 (base/'controller-result.json').write_text(json.dumps(record,indent=2)+'\n')
 shutil.copy2(__file__,base/'controller.py')
