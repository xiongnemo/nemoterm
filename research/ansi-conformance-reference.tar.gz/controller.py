"""Preserve input-authoring revisions and their independent XTerm observations."""
from pathlib import Path
import ast,gzip,hashlib,io,json,re,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/pointer-shape-worktree'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
upstream='5c75ead9a75d4b2e666ca06fa94503b5766ed93f'
specs=[('dd3dee2',43701547126,222),('677d00b',43701656227,222),('3b49cd4',43701953352,243)]
files={'controller.py':Path(__file__).read_bytes()};runs=[]
for short,run_id,count in specs:
    source=subprocess.check_output(['git','rev-parse',short],cwd=work,text=True).strip()
    base=root/'build'/('ci-ansi-reference-'+short);ref=base/'reference'
    run=json.loads((base/'ansi-run.json').read_text())
    assert (run['headSha'],run['databaseId'],run['conclusion'])==(source,run_id,'success')
    assert (ref/'fixture-commit.txt').read_text().strip()==source
    assert (ref/'upstream-commit.txt').read_text().strip()==upstream
    data=json.loads((ref/'ansi-conformance-xterm.json').read_text())
    assert data['completed'] and data['version']=='XTerm(412)' and len(data['cases'])==count
    assert (ref/'executable-sha256.txt').read_text().split()[0]==data['executable_sha256']
    blobs={}
    for name in ['tests/xterm_ansi_conformance_oracle.py','tests/xterm_state_oracle.py','.github/workflows/protocol-reference.yml']:
        raw=subprocess.check_output(['git','show',f'{source}:{name}'],cwd=work)
        blobs[name]=raw;files[short+'/source/'+name]=raw
    module=ast.parse(blobs['tests/xterm_ansi_conformance_oracle.py'])
    module.body=[n for n in module.body if isinstance(n,(ast.Assign,ast.FunctionDef))]
    namespace={};exec(compile(module,'pure-ansi-inputs','exec'),namespace)
    inputs=namespace['cases']();assert list(inputs)==list(data['cases'])
    cells=0
    for i,(name,case) in enumerate(inputs.items()):
        record=data['cases'][name]
        original=json.loads((ref/f'ansi-conformance-xterm/{i:03}.json').read_text())['cases'][name]
        assert original['reply_hex']==record['reply_hex'] and original['sequence_hex']==record['sequence_hex']==case['sequence'].hex()
        observed=re.findall(rb'\x1bP([0-9]+)!~([0-9A-Fa-f]{4})\x1b\\',bytes.fromhex(record['reply_hex']))
        assert [int(n) for n,v in observed]==list(range(1,case['cell_count']+1))
        assert [int(v,16) for n,v in observed]==record['unicode_cells']
        if 'control' in case:assert record['unicode_cells']==case['control']
        cells+=case['cell_count']
    for f in base.rglob('*'):
        if f.is_file():files[short+'/'+f.relative_to(base).as_posix()]=f.read_bytes()
    runs.append(dict(source=source,run=run_id,upstream=upstream,cases=count,unicode_cells=cells,literal_controls=3,
        executable_sha256=data['executable_sha256'],observations_sha256=sha((ref/'ansi-conformance-xterm.json').read_bytes()),
        scope=('Initial probe starts with q; SS2/SS3 first-character behavior is not distinguished.' if short=='dd3dee2' else
               'Corrected first-character probe; reset defaults and preserved current/pending invocations not yet covered.' if short=='677d00b' else
               'Current 243-stream reference with reset defaults, preserved invocations and VT52 return; no Nemoterm implementation acceptance.')))
source_path=root/'build/ansi-conformance-reference-source/charproc.c'
files['upstream/charproc.c']=source_path.read_bytes()
files['upstream/source.json']=(json.dumps(dict(url=f'https://raw.githubusercontent.com/ThomasDickey/xterm-snapshots/{upstream}/charproc.c',
    sha256=sha(source_path.read_bytes()),scope='Read-only source audit; not an extra runtime observation.'),indent=2)+'\n').encode()
archive=work/'research/ansi-conformance-reference.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for r in records:assert sha(tar.extractfile(r['path']).read())==r['raw_sha256']
manifest=dict(runs=runs,current_source=runs[-1]['source'],
    scope='Independent XTerm input, raw replies and Unicode checksum observations only. No local GUI execution or production implementation change.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,archive_sha256=sha(archive.read_bytes()),records=records))
(work/'research/ansi-conformance-reference-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(runs=len(runs),records=len(records),bytes=archive.stat().st_size,current_cases=count,current_cells=cells)))
