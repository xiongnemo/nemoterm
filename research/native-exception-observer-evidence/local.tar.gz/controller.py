from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path(__file__).resolve().parent.parent
work=root/'build/kitty-placement-worktree'
sha=lambda b:hashlib.sha256(b).hexdigest()
raw={}
controls=json.loads((work/'build/exception-observer/controls-2/results.json').read_text())
assert len(controls)==4 and all(r['passed'] and not r['cleanup']['terminated_remaining'] for r in controls)
for p in (work/'build/exception-observer').rglob('*'):
 if p.is_file():raw['local/'+p.relative_to(work/'build/exception-observer').as_posix()]=p.read_bytes()
tabs=[]
for renderer,actual in [('gdi',1),('opengl',2)]:
 p=work/f'research/exception-tabs-{renderer}-right-observed.json'
 d=json.loads(p.read_text())
 assert d['completed'] and d['exception_diagnostic'] and d['memory_acceptance']==False
 assert len(d['checks'])==9 and d['actual_renderer']==actual
 assert not d['owned_job_cleanup']['terminated_remaining']
 assert d['executable_sha256']=='04339e0b69d0ca57492068380163b28a07fb856921c2d48246b3b9f8bea0bb78'
 assert d['exception_observer']['exit_code']==0 and not d['exception_observer']['dumps']
 events=[json.loads(line) for line in Path(d['exception_observer']['events_file']).read_text().splitlines()]
 assert not any(e['event']=='observer_error' for e in events)
 assert any(e['event']=='process_exit' and e['code']==0 for e in events)
 assert not any(e['event']=='exception' and not e['first_chance'] for e in events)
 tabs.append(dict(renderer=renderer,actual_renderer=actual,checks=len(d['checks']),cleanup=d['owned_job_cleanup'],observer=d['exception_observer']))
for p in (work/'research').glob('exception-tabs-*'):
 for q in ([p] if p.is_file() else p.rglob('*')):
  if q.is_file():raw['local/research/'+q.relative_to(work/'research').as_posix()]=q.read_bytes()
for name in ('tests/native_exception_observer.c','tests/native_exception_control.c','tests/native_exception_observer.py','tests/native_exception_controls.py','tests/tabs_window_smoke.py','scripts/test-exception-observer.ps1','.github/workflows/tabs-close-replay.yml'):
 raw['fixture/'+name]=(work/name).read_bytes()
raw['controller.py']=Path(__file__).read_bytes()
buf=io.BytesIO();records=[]
with tarfile.open(fileobj=buf,mode='w') as tar:
 for name,data in sorted(raw.items()):
  info=tarfile.TarInfo(name);info.size=len(data);tar.addfile(info,io.BytesIO(data))
  records.append(dict(path=name,raw_bytes=len(data),raw_sha256=sha(data)))
compressed=gzip.compress(buf.getvalue(),mtime=0)
path='research/native-exception-observer-evidence/local.tar.gz'
(work/path).parent.mkdir(exist_ok=True)
(work/path).write_bytes(compressed)
with tarfile.open(fileobj=io.BytesIO(compressed),mode='r:gz') as tar:
 for row in records:assert sha(tar.extractfile(row['path']).read())==row['raw_sha256']
manifest=dict(scope='External debugger controls and exact failed-image diagnostics; not product or memory acceptance',
 controls=controls,tabs=tabs,source_snapshot_note='Snapshot is after a readiness error-check clarification. The first control run and GDI replay preceded that Python-only clarification; helper binary and native behavior are unchanged. Controls-2 and OpenGL replay used the retained wrapper.',
 bundles=[dict(path=path,archive_sha256=sha(compressed),archive_bytes=len(compressed),records=records)])
(work/'research/native-exception-observer-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(records=len(records),archive_bytes=len(compressed),controls=4,tabs=2)))
