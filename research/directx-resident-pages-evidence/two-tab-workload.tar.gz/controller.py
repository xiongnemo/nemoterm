"""Run the existing dense two-tab workload with explicit metadata-only snapshots."""
from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-features-worktree'
base=root/'build/query-resident-workload';base.mkdir(exist_ok=False)
source=(root/'build/query-working-set-attribution.py').read_text()
function=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='snapshot')
module='''import ctypes as c,mmap,time
from ctypes import wintypes as w
from native_test_utils import k,ps
from handle_snapshot import OwnedHandleSnapshot
from thread_snapshot import modules
from working_set_regions import Region
ps.GetMappedFileNameW.restype=w.DWORD
'''+ast.get_source_segment(source,function)+'\n'
results=[]
for renderer,side in [('gdi','top'),('directx','left')]:
 stage=base/renderer;stage.mkdir()
 shutil.copytree(work/'tests',stage/'tests',ignore=shutil.ignore_patterns('__pycache__'))
 shutil.copytree(work/'tools',stage/'tools',ignore=shutil.ignore_patterns('__pycache__','node_modules','.git'))
 (stage/'research').mkdir();(stage/'logs').mkdir();(stage/'tests/resident_pages.py').write_text(module)
 path=stage/'tests/tabs_window_smoke.py';original=path.read_text();text=original
 text=text.replace("base_scene=scene", "prefix='resident-pages-'+prefix\nbase_scene=scene",1)
 needle="                value=dict(handles=count.value"
 insert="""                if memory_sampler and memory_sampler.phase in ('history-0','history-1','frame-0','frame-23','settled'):
                    phase=memory_sampler.phase
                    maps=evidence.setdefault('resident_page_maps',{})
                    if phase not in maps:
                        from resident_pages import snapshot
                        maps[phase]=snapshot(process,job,phase)
"""
 assert text.count(needle)==1;text=text.replace(needle,insert+needle)
 needle="                memory_path=root/'research'/f'{prefix}-{args.renderer}-{args.side}-memory.json'"
 assert text.count(needle)==1
 text=text.replace(needle,"                memory['diagnostic_only']=True\n                memory['external_resident_page_metadata']=True\n"+needle)
 needle="                evidence['memory_limit_passed']=None if diagnostic else private_ws_passes(actual,evidence['peak_private_ws'])"
 replacement="""                evidence['memory_limit_passed']=None
                evidence['memory_acceptance']=False
                evidence['external_resident_page_metadata']=True
                evidence['diagnostic_completed']=False
                u.PostMessageW(host,0x10,0,0);process.wait(timeout=15)
                assert process.returncode==0,process.returncode
                evidence['owned_job_cleanup']=job.finish(grace=5)
                assert not evidence['owned_job_cleanup']['terminated_remaining']
                evidence['diagnostic_completed']=True
                print('Resident-page diagnostic complete; no memory acceptance and no injected capture',flush=True)
                raise SystemExit(2)"""
 assert text.count(needle)==1;text=text.replace(needle,replacement)
 path.write_text(text)
 (stage/'fixture-change.json').write_text(json.dumps(dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
  original_sha256=hashlib.sha256(original.encode()).hexdigest(),modified_sha256=hashlib.sha256(text.encode()).hexdigest(),
  scope='Added five metadata snapshots and explicit diagnostic exit before any injected capture; workload and functional checks before that point unchanged'),indent=2)+'\n')
 exe=root/'dist/nemoterm.exe';assert hashlib.sha256(exe.read_bytes()).hexdigest()=='dfae1cdea10e091d209aa56ce291b63e3ae5ada2f02035254c3c3398cda6c5ab'
 env=dict(os.environ,NEMOTERM_TEST_EXE=str(exe),NEMOTERM_REQUIRE_DIRECTX='1',NEMOTERM_TEST_TRACEBACK_SECONDS='60')
 env.pop('CI',None)
 command=[sys.executable,'tests/tabs_window_smoke.py','--renderer',renderer,'--side',side,'--workload-memory',
  '--cols','160','--rows','48','--font','SarasaTermSC Nerd Font Light']
 with (stage/'logs/run.log').open('w') as log:
  result=subprocess.run(command,cwd=stage,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 observed=json.loads((stage/f'research/resident-pages-workload-tabs-{renderer}-{side}-observed.json').read_text())
 assert result.returncode==2 and observed['diagnostic_completed'] and not observed['memory_acceptance']
 assert observed['memory_limit_passed'] is None and not observed['memory_instrumented']
 assert observed['actual_grid']==[160,48] and observed['actual_renderer']=={'gdi':1,'directx':3}[renderer]
 assert not observed['owned_job_cleanup']['terminated_remaining'] and len(observed['resident_page_maps'])==5
 assert all(not s['unavailable'] for s in observed['resident_page_maps'].values())
 row=dict(renderer=renderer,diagnostic_completed=True,exit_code=result.returncode,
  sampled_peaks=observed['process_tree_memory']['peaks']['frontend'],
  maps={k:v['totals'] for k,v in observed['resident_page_maps'].items()})
 results.append(row);(base/'summary.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
shutil.copy2(__file__,base/'controller.py')
