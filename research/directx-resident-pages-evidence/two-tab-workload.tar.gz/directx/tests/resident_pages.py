import ctypes as c,mmap,time
from ctypes import wintypes as w
from native_test_utils import k,ps
from handle_snapshot import OwnedHandleSnapshot
from thread_snapshot import modules
from working_set_regions import Region
ps.GetMappedFileNameW.restype=w.DWORD
def snapshot(process,job,label):
 owner=OwnedHandleSnapshot(process,job);owner._validate_owner()
 started=time.monotonic();capacity=65536
 for _ in range(8):
  pages=(c.c_size_t*(capacity+1))()
  if ps.QueryWorkingSet(process._handle,pages,c.sizeof(pages)):break
  error=k.GetLastError()
  if error!=24:raise c.WinError(error)
  capacity=max(capacity*2,int(pages[0])+4096)
  if capacity>4194304:raise RuntimeError('Working-set metadata limit exceeded')
 else:raise RuntimeError('Working-set query did not converge')
 count=int(pages[0]);assert 0<count<=capacity
 flags=sorted(map(int,pages[1:count+1]),key=lambda x:x>>12)
 catalog=modules(process._handle);module_by_base={m['base']:m for m in catalog}
 allocations={};region=Region();unavailable=[]
 for value in flags:
  address=value & ~4095
  if not region.base or not region.base<=address<region.base+region.size:
   if k.VirtualQueryEx(process._handle,address,c.byref(region),c.sizeof(region))!=c.sizeof(region):
    unavailable.append(dict(address=hex(address),error=k.GetLastError()));continue
  allocation=region.allocation or region.base
  if allocation not in allocations:
   path=c.create_unicode_buffer(32768)
   length=ps.GetMappedFileNameW(process._handle,allocation,path,len(path)) if region.kind in (0x1000000,0x40000) else 0
   assert length<len(path)
   allocations[allocation]=dict(base=hex(allocation),kind={0x20000:'private',0x40000:'mapped',0x1000000:'image'}.get(region.kind,hex(region.kind)),
    mapped_path=path.value if length else None,module=module_by_base.get(allocation),private_ws=0,shareable_ws=0,
    shareable_one_process=0,total_ws=0,observed_states=[])
  row=allocations[allocation];row['total_ws']+=4096
  shareable=bool(value&256);row['shareable_ws' if shareable else 'private_ws']+=4096
  if shareable and ((value>>5)&7)==1:row['shareable_one_process']+=4096
  if region.state not in row['observed_states']:row['observed_states'].append(region.state)
 owner._validate_owner()
 rows=sorted(allocations.values(),key=lambda r:r['total_ws'],reverse=True)
 totals={key:sum(r[key] for r in rows) for key in ('private_ws','shareable_ws','shareable_one_process','total_ws')}
 assert totals['private_ws']+totals['shareable_ws']==totals['total_ws']==(count-len(unavailable))*4096
 return dict(label=label,seconds=time.monotonic()-started,pages=count,totals=totals,allocations=rows,
  page_flags=flags,unavailable=unavailable,modules=catalog,
  scope='One QueryWorkingSet list followed by VirtualQueryEx/module metadata; sequential, not atomic. Shared bit means sharable, not exclusive ownership. No page contents, target calls, injection, suspension or trimming.')
