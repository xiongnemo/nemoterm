"""Read metadata, never page contents, from two newly spawned owned frontends."""
from pathlib import Path
import ctypes as c,hashlib,json,mmap,os,platform,subprocess,sys,time,uuid,winreg
from ctypes import wintypes as w
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-features-worktree'
base=root/'build/query-working-set-attribution';base.mkdir(exist_ok=False)
sys.path.insert(0,str(work/'tests'))
from native_test_utils import find_window,wait_for,read_snapshot,write_snapshot,u,k,ps
from owned_job import OwnedJob
from handle_snapshot import OwnedHandleSnapshot
from thread_snapshot import modules
from working_set_regions import Region
u.GetPropW.argtypes=[w.HWND,w.LPCWSTR];u.GetPropW.restype=w.HANDLE
ps.GetMappedFileNameW.restype=w.DWORD
assert c.sizeof(c.c_void_p)==8 and mmap.PAGESIZE==4096

def snapshot(process,job,label):
 owner=OwnedHandleSnapshot(process,job);owner._validate_owner()
 started=time.monotonic();capacity=65536
 for _ in range(8):
  pages=(c.c_size_t*(capacity+1))()
  if ps.QueryWorkingSet(process._handle,pages,c.sizeof(pages)):break
  error=k.GetLastError()
  if error!=24:raise c.WinError(error)
  capacity=max(capacity*2,int(pages[0])+4096)
  if capacity>4194304:raise RuntimeError('Working-set metadata limit exceeded')
 else:raise RuntimeError('Working-set query did not converge')
 count=int(pages[0]);assert 0<count<=capacity
 flags=sorted(map(int,pages[1:count+1]),key=lambda x:x>>12)
 catalog=modules(process._handle);module_by_base={m['base']:m for m in catalog}
 allocations={};region=Region();unavailable=[]
 for value in flags:
  address=value & ~4095
  if not region.base or not region.base<=address<region.base+region.size:
   if k.VirtualQueryEx(process._handle,address,c.byref(region),c.sizeof(region))!=c.sizeof(region):
    unavailable.append(dict(address=hex(address),error=k.GetLastError()));continue
  allocation=region.allocation or region.base
  if allocation not in allocations:
   path=c.create_unicode_buffer(32768)
   length=ps.GetMappedFileNameW(process._handle,allocation,path,len(path)) if region.kind in (0x1000000,0x40000) else 0
   assert length<len(path)
   allocations[allocation]=dict(base=hex(allocation),kind={0x20000:'private',0x40000:'mapped',0x1000000:'image'}.get(region.kind,hex(region.kind)),
    mapped_path=path.value if length else None,module=module_by_base.get(allocation),private_ws=0,shareable_ws=0,
    shareable_one_process=0,total_ws=0,observed_states=[])
  row=allocations[allocation];row['total_ws']+=4096
  shareable=bool(value&256);row['shareable_ws' if shareable else 'private_ws']+=4096
  if shareable and ((value>>5)&7)==1:row['shareable_one_process']+=4096
  if region.state not in row['observed_states']:row['observed_states'].append(region.state)
 owner._validate_owner()
 rows=sorted(allocations.values(),key=lambda r:r['total_ws'],reverse=True)
 totals={key:sum(r[key] for r in rows) for key in ('private_ws','shareable_ws','shareable_one_process','total_ws')}
 assert totals['private_ws']+totals['shareable_ws']==totals['total_ws']==(count-len(unavailable))*4096
 return dict(label=label,seconds=time.monotonic()-started,pages=count,totals=totals,allocations=rows,
  page_flags=flags,unavailable=unavailable,modules=catalog,
  scope='One QueryWorkingSet list followed by VirtualQueryEx/module metadata; sequential, not atomic. Shared bit means sharable, not exclusive ownership. No page contents, target calls, injection, suspension or trimming.')

exe=root/'dist/nemoterm.exe';digest=hashlib.sha256(exe.read_bytes()).hexdigest()
assert digest=='dfae1cdea10e091d209aa56ce291b63e3ae5ada2f02035254c3c3398cda6c5ab'
record=dict(executable_sha256=digest,product_source='6e05bd1a70515ede970323eb633563021d80ac3e',
 fixture_source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
 windows=platform.win32_ver(),diagnostic_only=True,scope='Idle single-view 160x48 comparison; not workload or peak acceptance; frontend only',
 completed=False,cases=[])
try:
 for renderer,kind in (('gdi',0),('directx',2)):
  profile='ws-attribution-'+uuid.uuid4().hex;keypath='Software\\Nemo\\Nemoterm\\Sessions\\'+profile
  folder=base/renderer;folder.mkdir();report=folder/'child-report.json';control=folder/'child-control.json'
  row=dict(renderer=renderer,profile=profile,snapshots=[]);record['cases'].append(row)
  try:
   with winreg.CreateKey(winreg.HKEY_CURRENT_USER,keypath) as key:
    for name,value in dict(WarnOnClose=0,CloseOnExit=1,NemoRenderer=kind).items():winreg.SetValueEx(key,name,0,winreg.REG_DWORD,value)
   with OwnedJob() as job:
    process=job.spawn([str(exe),'-load',profile,'--cols','160','--rows','48','--font','SarasaTermSC Nerd Font Light',
     '-e',sys.executable,str(work/'tests/mouse_fixture.py'),str(report),str(control)],
     creationflags=subprocess.CREATE_NO_WINDOW,env=dict(os.environ,NEMOTERM_CONPTY='bundled'))
    try:
     row['pid']=process.pid;window=wait_for(lambda:find_window(process.pid));child=wait_for(lambda:read_snapshot(report))
     row['actual_renderer']=int(u.GetPropW(window,'NemotermRenderer') or 0)
     assert row['actual_renderer']=={'gdi':1,'directx':3}[renderer]
     row['grid']=[child['columns'],child['rows']];assert row['grid']==[160,48]
     row['snapshots'].append(snapshot(process,job,'ready'))
     time.sleep(2)
     row['snapshots'].append(snapshot(process,job,'idle-after-two-seconds'))
     write_snapshot(control,dict(stop=True));row['exit_code']=process.wait(timeout=10)
     assert row['exit_code']==0
    finally:row['cleanup']=job.finish(grace=5)
    assert not row['cleanup']['terminated_remaining']
  finally:
   winreg.DeleteKey(winreg.HKEY_CURRENT_USER,keypath)
   (base/'results.json').write_text(json.dumps(record,indent=2)+'\n')
  print(json.dumps(dict(renderer=renderer,snapshots=[s['totals'] for s in row['snapshots']],cleanup=row['cleanup'])),flush=True)
 record['completed']=True
finally:
 if sys.exc_info()[0]:record['error']=repr(sys.exc_info()[1])
 record['source_sha256']={name:hashlib.sha256((work/name).read_bytes()).hexdigest() for name in ('tests/owned_job.py','tests/native_test_utils.py','tests/handle_snapshot.py','tests/thread_snapshot.py','tests/working_set_regions.py','tests/mouse_fixture.py','vendor/putty-0.85/windows/nemo_d3d11.c')}
 (base/'results.json').write_text(json.dumps(record,indent=2)+'\n')
 (base/'controller.py').write_bytes(Path(__file__).read_bytes())
