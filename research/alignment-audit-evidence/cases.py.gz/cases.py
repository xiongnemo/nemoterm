ESC, CSI, DCS, ST = '\x1b', '\x1b[', '\x1bP', '\x1b\\'
RESET = CSI+'65;1"p'+ESC+'c'
ALIGN = ESC+'#8'
Q = CSI+'6n'+DCS+'$qm'+ST+DCS+'$qr'+ST+DCS+'$qs'+ST+CSI+'?6$p'+CSI+'?69$p'+DCS+'$q"q'+ST
CASES = {
    'cursor': RESET+CSI+'7;13H'+ALIGN+Q,
    'rendition': RESET+CSI+'1;2;3;4:3;5;7;8;9;53;31;44;58:2::1:2:3m'+ALIGN+Q,
    'rgb': RESET+CSI+'38:2::1:2:3;48:2::4:5:6m'+ALIGN+Q,
    'vertical-margins': RESET+CSI+'4;17r'+CSI+'7;13H'+ALIGN+Q,
    'horizontal-margins': RESET+CSI+'?69h'+CSI+'8;67s'+CSI+'7;13H'+ALIGN+Q,
    'origin-margins': RESET+CSI+'4;17r'+CSI+'?69h'+CSI+'8;67s'+CSI+'?6h'+CSI+'3;5H'+ALIGN+Q,
    'pending-wrap': RESET+CSI+'1;80HX'+ALIGN+'Q'+Q,
    'wrap-disabled': RESET+CSI+'?7l'+CSI+'1;80HX'+ALIGN+'Q'+Q+CSI+'?7$p',
    'dec-protection': RESET+CSI+'1"qABC'+ALIGN+Q,
    'iso-protection': RESET+ESC+'VABC'+ALIGN+Q,
    'saved-cursor': RESET+CSI+'31m'+CSI+'7;13H'+ESC+'7'+ALIGN+Q+ESC+'8'+Q,
    'alternate-screen': RESET+CSI+'7;13H'+CSI+'?1049h'+CSI+'5;12H'+ALIGN+Q+CSI+'?1049l'+Q,
    'double-width': RESET+CSI+'7;13H'+ESC+'#6'+ALIGN+CSI+'1;80HX'+Q,
    'after-charset': RESET+ESC+')0'+chr(14)+CSI+'7;13H'+ALIGN+Q,
}
