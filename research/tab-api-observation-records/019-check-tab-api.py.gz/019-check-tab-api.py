from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];project=root.parents[1]
base=root/'build/tab-api-comparison';base.mkdir()
exe=project/'build/tabs-close-worktree/build/ci-owned-8a41ad7/product/nemoterm.exe'
accepted=project/'dist/nemoterm.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='4e25f1652d0d622c1b5a46658e9881f36dd3ecce4d7e22847a68d70a3f42d614'
assert hashlib.sha256(accepted.read_bytes()).hexdigest()=='c110843b1fd5a551d654df094fa716c1ea1c48383d90e642b964d7dfb3d15e26'
cases=[('before-'+str(i),'old',exe,'opengl','right',False) for i in (1,2)]
cases += [('after-'+r,'new',exe,r,s,False) for r,s in [('gdi','top'),('opengl','right'),('directx','left')]]
cases += [('memory-'+r,'new',accepted,r,s,True) for r,s in [('gdi','top'),('directx','left')]]
cases += [('close-host-canary','canary',exe,'gdi','top',False)]
for name,variant,image,renderer,side,memory in cases:
    dest=base/name
    for directory in ('dist','research','build','tools'):(dest/directory).mkdir(parents=True)
    shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
    target=dest/'tests/tabs_window_smoke.py'
    if variant=='old':target.write_bytes(subprocess.check_output(['git','show','HEAD:tests/tabs_window_smoke.py'],cwd=root))
    if variant=='canary':
        source=target.read_text();needle="u.PostMessageW(first['hwnd'],0x10,0,0)"
        assert source.count(needle)==1
        target.write_text(source.replace(needle,"u.PostMessageW(host,0x10,0,0)  # Deliberate owned-host closure for failure diagnostics."),encoding='utf-8')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(image,dest/'dist/nemoterm.exe')
results=[]
for name,variant,image,renderer,side,memory in cases:
    dest=base/name;print('Starting '+name,flush=True)
    args=['--renderer',renderer,'--side',side]
    args += ['--cols','160','--rows','48','--workload-memory'] if memory else ['--cols','88','--rows','35','--font','Consolas']
    with (dest/'controller.log').open('w') as log:
        run=subprocess.run([sys.executable,str(project/'build/rtl-worktree/build/run-owned-check.py'),str(dest),'tabs',*args],stdout=log,stderr=subprocess.STDOUT)
    path=dest/'research'/f"{'workload-tabs' if memory else 'tabs'}-{renderer}-{side}-observed.json"
    observed=json.loads(path.read_text()) if path.exists() else {}
    controller=json.loads((dest/'research/tabs-controller.json').read_text())
    record=dict(name=name,variant=variant,executable_sha256=hashlib.sha256(image.read_bytes()).hexdigest(),
                exit_code=run.returncode,checks=len(observed.get('checks',[])),actual=observed.get('actual_renderer'),
                phase=observed.get('phase'),error=observed.get('error'),seconds=controller['seconds'],
                first_tab_close=observed.get('first_tab_close'),host_close=observed.get('host_close'),cleanup=controller['cleanup'])
    if memory:
        data=json.loads((dest/'research'/f'workload-tabs-{renderer}-{side}-memory.json').read_text())
        record.update(samples=data['sample_count'],peaks=data['peaks']['frontend'],injected=data['injected'])
    if variant=='canary':
        record['expected_failure_observed']=(run.returncode!=0 and observed.get('phase')=='close-first-tab'
                and observed.get('first_tab_close',{}).get('sibling_alive') is False and 'process_before_cleanup' in observed)
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps(record),flush=True)
    if run.returncode:print((dest/'controller.log').read_text()[-1800:],flush=True)
assert all(r['exit_code']==0 for r in results if r['variant']=='new'),results
assert all(r.get('expected_failure_observed') for r in results if r['variant']=='canary'),results
