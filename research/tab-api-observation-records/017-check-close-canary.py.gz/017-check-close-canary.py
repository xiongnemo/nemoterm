from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];project=root.parents[1]
dest=root/'build/close-canary-early-01'
exe=project/'build/tabs-close-worktree/build/ci-owned-8a41ad7/product/nemoterm.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='4e25f1652d0d622c1b5a46658e9881f36dd3ecce4d7e22847a68d70a3f42d614'
for directory in ('dist','research','build','tools'):(dest/directory).mkdir(parents=True)
shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(exe,dest/'dist/nemoterm.exe')
target=dest/'tests/tabs_window_smoke.py';source=target.read_text()
start=source.index("            evidence['phase']='close-first-tab'")
end=source.index("            evidence['phase']='sibling-output'",start)
block=source[start:end]
assert block.count("u.PostMessageW(first['hwnd'],0x10,0,0)")==1
block=block.replace("u.PostMessageW(first['hwnd'],0x10,0,0)","u.PostMessageW(host,0x10,0,0)  # Deliberate owned-host close.")
marker='            # Measure before any injected capture helper loads into the PID.'
assert source.count(marker)==1
source=source.replace(marker,block+marker)
target.write_text(source,encoding='utf-8')
with (dest/'controller.log').open('w') as log:
    run=subprocess.run([sys.executable,str(project/'build/rtl-worktree/build/run-owned-check.py'),str(dest),'tabs',
                        '--renderer','gdi','--side','top','--cols','88','--rows','35','--font','Consolas'],stdout=log,stderr=subprocess.STDOUT)
d=json.loads((dest/'research/tabs-gdi-top-observed.json').read_text())
result=dict(exit_code=run.returncode,expected_failure_observed=(run.returncode!=0 and d.get('phase')=='close-first-tab'
            and d.get('first_tab_close',{}).get('sibling_alive') is False and 'process_before_cleanup' in d),
            phase=d.get('phase'),first_tab_close=d.get('first_tab_close'),process_before_cleanup=d.get('process_before_cleanup'),
            cleanup=d.get('owned_job_cleanup'),error=d.get('error'))
(dest/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print({k:v for k,v in result.items() if k!='process_before_cleanup'},flush=True)
assert result['expected_failure_observed'],result
