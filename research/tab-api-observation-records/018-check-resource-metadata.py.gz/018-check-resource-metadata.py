from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];project=root.parents[1]
dest=root/'build/tab-resource-metadata-01'
exe=project/'build/tabs-close-worktree/build/ci-owned-8a41ad7/product/nemoterm.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='4e25f1652d0d622c1b5a46658e9881f36dd3ecce4d7e22847a68d70a3f42d614'
for directory in ('dist','research','build','tools'):(dest/directory).mkdir(parents=True)
shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(exe,dest/'dist/nemoterm.exe')
target=dest/'tests/tabs_window_smoke.py';source=target.read_text()
needle="            evidence['initial']=initial;evidence['two_tabs']=baseline;evidence['cycles']=[]"
assert source.count(needle)==1
source=source.replace(needle,needle+'''
            from handle_snapshot import OwnedHandleSnapshot,compare
            handles_observer=OwnedHandleSnapshot(process,job)
            evidence['resource_metadata']=dict(diagnostic_only=True,memory_acceptance=False)
            metadata=evidence['resource_metadata']
            metadata['baseline_handles']=handles_observer.snapshot('resource-baseline')
            metadata['baseline_state']={}
            record_owned_failure(process,job,metadata['baseline_state'],'resource-baseline')
''')
needle="                record_owned_failure(process,job,evidence,'tabs-'+evidence['phase'])"
assert source.count(needle)==1
source=source.replace(needle,needle+'''
                if 'resource_metadata' in evidence:
                    try:
                        metadata['failure_handles']=handles_observer.snapshot('resource-failure')
                        metadata['handle_difference']=compare(metadata['baseline_handles'],metadata['failure_handles'])
                    except Exception as observation_error:
                        metadata['error']=repr(observation_error)
''')
target.write_text(source,encoding='utf-8')
with (dest/'controller.log').open('w') as log:
    run=subprocess.run([sys.executable,str(project/'build/rtl-worktree/build/run-owned-check.py'),str(dest),'tabs',
                        '--renderer','opengl','--side','right','--cols','88','--rows','35','--font','Consolas'],stdout=log,stderr=subprocess.STDOUT)
p=dest/'research/tabs-opengl-right-observed.json';d=json.loads(p.read_text())
metadata=d.get('resource_metadata',{});difference=metadata.get('handle_difference',{})
result=dict(diagnostic_only=True,memory_acceptance=False,exit_code=run.returncode,phase=d.get('phase'),error=d.get('error'),
            checks=len(d['checks']),handle_delta=difference.get('count_delta'),type_deltas=difference.get('type_deltas'),
            inner_cleanup=d.get('owned_job_cleanup'))
for key,state in [('baseline',metadata.get('baseline_state',{}).get('process_before_cleanup',{})),
                  ('failure',d.get('process_before_cleanup',{}))]:
    result[key+'_windows']=[v['kind'] for v in state.get('windows',[])]
    result[key+'_thread_modules']=[v.get('module') for v in state.get('threads',{}).get('threads',[])]
(dest/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
raise SystemExit(2)  # A diagnostic observation never becomes an acceptance pass.
