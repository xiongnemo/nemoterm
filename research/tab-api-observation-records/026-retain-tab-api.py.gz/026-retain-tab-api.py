from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path(__file__).resolve().parents[1];project=root.parents[1]
dest=root/'research/tab-api-observation-records';dest.mkdir()
folders=[root/'build/tab-api-comparison',root/'build/tab-resource-metadata-01',root/'build/close-canary-early-01']
paths=[p for folder in folders for p in folder.rglob('*') if p.is_file() and p.suffix in ('.json','.log','.png')
       and not any(s in p.relative_to(folder).parts for s in ('tests','tools','dist'))]
paths += [p for folder in folders for p in folder.rglob('tabs_window_smoke.py')]
paths += [root/'build'/n for n in ('check-tab-api.py','check-resource-metadata.py','check-close-canary.py')]
paths += [Path(__file__),root/'.github/workflows/ci.yml',root/'docs/REQUIREMENTS.md']
paths += [root/'tests'/n for n in ('tabs_window_smoke.py','automation_capture.py','owned_failure_state.py',
          'resource_settle.py','frida_test_utils.py','thread_snapshot.py','handle_snapshot.py','tabs_hover_probe.js')]
ci=project/'build/ci-main-8a41ad7'
paths += [ci/(kind+'-'+suffix) for kind in ('core','single','census') for suffix in ('run.json','run.log','artifacts.json')]
paths += list((ci/'msvc/research').glob('tabs-close-repeat-*.json'))
paths += [ci/'msvc/build/native-crashes/application-errors.json',
          ci/'single-evidence/build/single-exe-check/research/single-exe-validation.json']
manifest=dict(source_base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    scope='Use opt-in API for tab pixel capture; retain lifecycle failure state. No product change or resolution of earlier CI crash/resource failures claimed.',
    comparison=json.loads((folders[0]/'results.json').read_text()),
    diagnostic=json.loads((folders[1]/'result.json').read_text()),
    canary=json.loads((folders[2]/'result.json').read_text()),records=[])
for i,p in enumerate(sorted(set(paths))):
    data=p.read_bytes();archive=dest/f'{i:03d}-{p.name}.gz';archive.write_bytes(gzip.compress(data,mtime=0))
    assert gzip.decompress(archive.read_bytes())==data
    try:original=p.relative_to(root).as_posix()
    except ValueError:original='project/'+p.relative_to(project).as_posix()
    manifest['records'].append(dict(path=original,archive=archive.relative_to(root).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(root/'research/tab-api-observation-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(dict(records=len(manifest['records']),compressed_bytes=sum(p.stat().st_size for p in dest.iterdir())))
