"""Build the pinned upstream with its optional tcap keyboard enabled; capture only."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess,sys,tempfile
root=Path(__file__).resolve().parents[1]
work=root/'build/tab-callback-diagnostic-worktree'
stage=root/('build/'+(sys.argv[1] if len(sys.argv)>1 else 'set-tcap-reference-02'));stage.mkdir(exist_ok=False)
original=Path('/tmp/nemoterm-legacy-reference-5RtbUr')
commit='5c75ead9a75d4b2e666ca06fa94503b5766ed93f'
assert subprocess.check_output(['git','-C',str(original),'rev-parse','HEAD'],text=True).strip()==commit
config=['./configure','--enable-wide-chars','--enable-sixel-graphics','--enable-tcap-fkeys','--disable-toolbar','--disable-luit']
if len(sys.argv)>2:
    source=Path(sys.argv[2])
    assert source.is_dir() and source.parent.name.startswith('nemoterm-tcap-reference-')
    shutil.copy2(root/'build/set-tcap-reference-01/build.log',stage/'build.log')
else:
    source=Path(tempfile.mkdtemp(prefix='nemoterm-tcap-reference-'))/'source'
    with (stage/'build.log').open('w') as log:
        subprocess.run(['git','clone','--no-hardlinks',str(original),str(source)],stdout=log,stderr=subprocess.STDOUT,check=True)
        subprocess.run(['git','checkout','--detach',commit],cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
        subprocess.run(config,cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
        subprocess.run(['make','-j4'],cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
assert subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()==commit
subprocess.run(['git','-C',str(source),'diff','--exit-code'],check=True)
macros=subprocess.check_output(['gcc','-dM','-E','-DHAVE_CONFIG_H','-D_DEFAULT_SOURCE',
    '-D_XOPEN_SOURCE=700','-DNARROWPROTO=1','-DFUNCPROTO=15','-I.','-I/usr/include/freetype2',
    '-I/usr/include/libpng16','-include','ptyx.h','-x','c','/dev/null'],cwd=source,text=True)
(stage/'preprocessor-defines.txt').write_text(macros)
for symbol in ('OPT_TCAP_FKEYS','OPT_TCAP_QUERY'):
    assert re.search(r'^#define '+symbol+r' 1$',macros,re.M),symbol
for name in ('xterm_set_tcap_oracle.py','xterm_udk_oracle.py','xterm_locator_oracle.py'):
    shutil.copy2(work/'tests'/name,stage/name)
shutil.copy2(__file__,stage/Path(__file__).name)
for name in ('xtermcap.c','input.c','charproc.c','misc.c','ctlseqs.txt','xterm.man','xtermcfg.h','config.log','version.h'):
    shutil.copy2(source/name,stage/('xterm-'+name))
shutil.copy2(source/'xterm',stage/'xterm-executable')
identity=dict(source_commit=commit,source_directory=str(source),configure=config,
    executable_sha256=hashlib.sha256((source/'xterm').read_bytes()).hexdigest(),
    global_input=False,clipboard_access=False,private_display=True)
(stage/'IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n')
subprocess.run([sys.executable,str(stage/'xterm_set_tcap_oracle.py'),'--xterm',str(source/'xterm'),
    '--output',str(stage/'xterm.json')],check=True)
