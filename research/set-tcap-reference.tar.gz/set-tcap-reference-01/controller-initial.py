"""Build the pinned upstream with its optional tcap keyboard enabled; capture only."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile
root=Path(__file__).resolve().parents[1]
work=root/'build/tab-callback-diagnostic-worktree'
stage=root/'build/set-tcap-reference-01';stage.mkdir(exist_ok=False)
original=Path('/tmp/nemoterm-legacy-reference-5RtbUr')
commit='5c75ead9a75d4b2e666ca06fa94503b5766ed93f'
assert subprocess.check_output(['git','-C',str(original),'rev-parse','HEAD'],text=True).strip()==commit
source=Path(tempfile.mkdtemp(prefix='nemoterm-tcap-reference-'))/'source'
with (stage/'build.log').open('w') as log:
    subprocess.run(['git','clone','--no-hardlinks',str(original),str(source)],stdout=log,stderr=subprocess.STDOUT,check=True)
    subprocess.run(['git','checkout','--detach',commit],cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
    config=['./configure','--enable-wide-chars','--enable-sixel-graphics','--enable-tcap-fkeys','--disable-toolbar','--disable-luit']
    subprocess.run(config,cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
    subprocess.run(['make','-j4'],cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run(['git','-C',str(source),'diff','--exit-code'],check=True)
assert '#define OPT_TCAP_FKEYS 1' in (source/'xtermcfg.h').read_text()
for name in ('xterm_set_tcap_oracle.py','xterm_udk_oracle.py','xterm_locator_oracle.py'):
    shutil.copy2(work/'tests'/name,stage/name)
shutil.copy2(__file__,stage/Path(__file__).name)
for name in ('xtermcap.c','input.c','charproc.c','misc.c','ctlseqs.txt','xterm.man','xtermcfg.h','config.log','version.h'):
    shutil.copy2(source/name,stage/('xterm-'+name))
shutil.copy2(source/'xterm',stage/'xterm-executable')
identity=dict(source_commit=commit,source_directory=str(source),configure=config,
    executable_sha256=hashlib.sha256((source/'xterm').read_bytes()).hexdigest(),
    global_input=False,clipboard_access=False,private_display=True)
(stage/'IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n')
subprocess.run([sys.executable,str(stage/'xterm_set_tcap_oracle.py'),'--xterm',str(source/'xterm'),
    '--output',str(stage/'xterm.json')],check=True)
