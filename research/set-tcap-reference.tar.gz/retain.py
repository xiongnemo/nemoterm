from pathlib import Path
import hashlib,json,tarfile
root=Path(__file__).resolve().parents[1]
work=root/'build/tab-callback-diagnostic-worktree'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
stages=[root/f'build/set-tcap-reference-{i:02d}' for i in (1,2,3)]
results=[]
for stage,count,steps in [(stages[1],60,458),(stages[2],71,568)]:
    result=load(stage/'xterm.json');identity=load(stage/'IDENTITY.json')
    assert identity['source_commit']=='5c75ead9a75d4b2e666ca06fa94503b5766ed93f'
    assert result['completed'] and len(result['cases'])==count
    assert sum(len(v['steps']) for v in result['cases'].values())==steps
    assert result['executable_sha256']==identity['executable_sha256']==sha(stage/'xterm-executable')
    assert result['executable_sha256']=='5cf13eb0677c8f0a930ed80c7871c80edf50e19d0ec74106b391a3569b9fa15c'
    for name,value in result['cases'].items():
        assert value['completed'] and value['exit_code']==0 and not value['stderr'],name
        for s in value['steps']:
            assert bytes.fromhex(s['wire_with_barriers_hex']).count(b'\x1b[0n')==2
    results.append(dict(stage=stage.name,cases=count,steps=steps,identity=identity))
library=root/'build/tcap-library-lifetime-01';control=load(library/'results.json')
assert len(control['cases'])==5 and all(v['exit_code']==0 for v in control['cases'].values())
files={}
for stage in stages+[library]:
    for p in sorted(stage.rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc':continue
        if stage==stages[1] and p.name=='xterm-executable':continue
        files[stage.name+'/'+p.relative_to(stage).as_posix()]=p
for name in ('research/set-tcap-reference.md','tests/xterm_set_tcap_oracle.py','tests/tcap_library_probe.c'):
    files['final-source/'+name]=work/name
files['retain.py']=Path(__file__)
records=[dict(path=n,bytes=p.stat().st_size,sha256=sha(p)) for n,p in files.items()]
target=work/'research/set-tcap-reference.tar.gz';assert not target.exists()
with tarfile.open(target,'w:gz',compresslevel=9) as archive:
    for name,path in files.items():archive.add(path,arcname=name,recursive=False)
with tarfile.open(target,'r:gz') as archive:
    assert len(archive.getmembers())==len(records)
    for record in records:
        stream=archive.extractfile(record['path']);assert stream is not None
        assert hashlib.file_digest(stream,'sha256').hexdigest()==record['sha256']
manifest=dict(archive=dict(path=target.name,bytes=target.stat().st_size,sha256=sha(target)),
    captures=results,library_control=control,files=records,
    scope='Unmodified XTerm and independent ncurses observations only; no Nemoterm implementation or acceptance')
(work/'research/set-tcap-reference-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest['archive']),flush=True)
