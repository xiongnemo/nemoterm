from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path(__file__).resolve().parents[1]
work=root/'build/tab-callback-diagnostic-worktree'
stage=root/'build/tcap-library-lifetime-01';stage.mkdir(exist_ok=False)
source=work/'tests/tcap_library_probe.c'
shutil.copy2(source,stage/source.name);shutil.copy2(__file__,stage/Path(__file__).name)
image=stage/'probe'
with (stage/'build.log').open('w') as log:
    subprocess.run(['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror',str(source),'-o',str(image),'-ltinfo'],
                   stdout=log,stderr=subprocess.STDOUT,check=True)
result=dict(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    executable_sha256=hashlib.sha256(image.read_bytes()).hexdigest(),
    library_packages=subprocess.check_output(['dpkg-query','-W','libncurses-dev','libtinfo6'],text=True),
    dependencies=subprocess.check_output(['ldd',str(image)],text=True),cases={})
for name in ('vt100','linux','xterm-256color','screen','tmux'):
    run=subprocess.run([str(image),name],capture_output=True)
    (stage/(name+'.jsonl')).write_bytes(run.stdout)
    result['cases'][name]=dict(exit_code=run.returncode,stderr=run.stderr.decode(),
        snapshots=[json.loads(line) for line in run.stdout.decode().splitlines()])
    (stage/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    assert run.returncode==0 and not run.stderr
    snapshots=result['cases'][name]['snapshots']
    assert snapshots[1]['current_database'] and not snapshots[2]['current_database'] and snapshots[3]['current_database']
    assert snapshots[1]['strings']==snapshots[3]['strings']
    assert all(value is None for value in snapshots[2]['strings'].values())
    print(name,'selected values cleared by del_curterm and restored by setupterm',flush=True)
