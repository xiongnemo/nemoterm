"""Stream the complete ordinary CI checkpoint without loading pixel records into RAM."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile

root=Path(__file__).resolve().parents[1];work=root/'build/udk-worktree'
base=root/'build/ci-locator-complete-8e8321c';source='8e8321c336bac4e6c7c21327f0e4b7b646367043'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
sha=lambda data:hashlib.sha256(data).hexdigest()
run=json.loads((base/'ordinary-run.json').read_text())
assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(43715235781,source,'completed','success')
assert len(run['jobs'])==4 and all(j['conclusion']=='success' for j in run['jobs'])
frontend=base/'portable/nemoterm.exe';image_sha=digest(frontend)
host=json.loads((base/'portable/SOURCE-HOST.json').read_text(encoding='utf-8-sig'))
assert host['SourceCommit']==source and digest(base/'portable/OpenConsole.exe')==host['Executable']['SHA256']
assert host['MicrosoftTerminalCommit']=='f6de9e0618015def1c9dda5b82f9d3abf03eb799'
native_path=next((base/'core-evidence').rglob('control-cancellation-observed.json'))
native=json.loads(native_path.read_text(encoding='utf-8'))
assert native['completed'] and native['executable_sha256']==image_sha and native['reference_case_count']==413
marker=b'\x1bP>|Nemoterm(PuTTY 0.85)\x1b\\'
for prefix,name,count in [('ansi','ansi_conformance_native_cases.py',177),('cancel','control_cancellation_native_cases.py',236)]:
    import ast
    tree=ast.parse(subprocess.check_output(['git','show',f'{source}:tests/{name}'],cwd=work).decode('utf-8'))
    values={node.targets[0].id:ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign)}
    assert len(values['CASES'])==count
    for case,sequence,expected in values['CASES']:
        assert bytes.fromhex(native['cases'][prefix+'-'+case])==expected+marker,case
assert len(native['exercise']['pixel_pairs'])==3
for pair in native['exercise']['pixel_pairs'].values():assert pair['literal_sha256']==pair['control_sha256']
assert not native['cleanup']['terminated_remaining'] and native['cleanup']['after']['active']==0
workloads=[]
for path in sorted((base/'core-evidence').rglob('*workload-tabs-*-observed.json')):
    data=json.loads(path.read_text())
    assert data['completed'] and data['memory_limit_passed'] and data['executable_sha256']==image_sha
    assert not data['memory_instrumented'] and not data['process_tree_memory']['injected']
    assert data['memory_limit_required']
    is_dx=data['renderer']=='directx'
    expected_limit=25000000 if is_dx else 20000000
    assert data['memory_limit_bytes']==expected_limit and data['memory_limit_inclusive']==is_dx
    assert data['peak_private_ws']<=expected_limit if is_dx else data['peak_private_ws']<expected_limit
    assert not data['owned_job_cleanup']['terminated_remaining'] and data['owned_job_cleanup']['after']['active']==0
    record=dict(path=path.relative_to(base).as_posix(),renderer=data['renderer'],actual_renderer=data['actual_renderer'],
        font=data['font'],grid=data['actual_grid'],frontend_peaks=data['process_tree_memory']['peaks']['frontend'],
        private_limit_bytes=expected_limit,passed=True,natural_cleanup=True)
    if path.name.startswith('unicode-'):
        observations=data['post_memory_kitty_unicode']
        assert len(observations)==4 and all(x['matched'] and x['after_memory_sampling'] and not x['injected'] for x in observations)
        record['post_memory_cells']=sum(x['cells_verified'] for x in observations)
    workloads.append(record)
assert len(workloads)==12 and sum(w.get('post_memory_cells',0) for w in workloads)==25048

locator_path=next((base/'core-evidence').rglob('locator-window-observed.json'))
locator=json.loads(locator_path.read_text())
assert locator['completed'] and locator['physical_input'] and locator['executable_sha256']==image_sha
assert len(locator['checks'])==27 and not locator['cleanup']['terminated_remaining'] and locator['cleanup']['after']['active']==0
for name,check in locator['checks'].items():
    prefix=bytes.fromhex(check['reply_hex'])+b'\x1b[0n'
    assert bytes.fromhex(check['wire_with_barrier_hex'])==prefix,name
    if 'event_reply_hex' in check:
        assert bytes.fromhex(check['event_wire_with_barriers_hex'])==prefix+bytes.fromhex(check['event_reply_hex'])+b'\x1b[0n',name
assert locator['shift_selection_pixels']['before_sha256']!=locator['shift_selection_pixels']['after_sha256']
entries={'controller.py':Path(__file__)}
for path in base.glob('ordinary-*'):
    if path.is_file():entries[path.name]=path
artifacts=json.loads((base/'ordinary-artifacts.json').read_text(encoding='utf-8'))['artifacts']
for folder,prefix in [('core-evidence','test-results-windows-'),('ordinary-msvc','cluster-msvc-diagnostics-'),('sanitizers','test-results-sanitizers-'),('portable','nemoterm-windows-x64-')]:
    artifact=next(a for a in artifacts if a['name']==prefix+source)
    artifact_id=artifact['id']
    receipt=base/(folder+'-download.json')
    assert json.loads(receipt.read_text())['artifact_id']==artifact_id
    entries[receipt.name]=receipt
    for path in (base/folder).rglob('*'):
        if path.is_file():entries[path.relative_to(base).as_posix()]=path
# The shared 'msvc' download directory previously held both workflow kinds.
# Use only the fresh ordinary-msvc download above, never that mixed directory.
for name in ('tests/locator_window_smoke.py','tests/mouse_fixture.py','tests/locator_reference.h','scripts/generate-locator-reference.py','vendor/putty-0.85/terminal/nemo_locator_terminal.inc','vendor/putty-0.85/test/test_locator_terminal.c','vendor/putty-0.85/putty.h','vendor/putty-0.85/windows/window.c','.github/workflows/ci.yml','scripts/build.ps1','scripts/test.ps1','scripts/build-single-exe.ps1',
             'scripts/prepare-single-exe.py','native/single_exe/entry.cpp','tests/tabs_window_smoke.py',
             'tests/tab_workload_memory.py','tests/memory_limits.py','tests/native_test_utils.py','tests/owned_job.py','scripts/generate-ansi-reference.py','tests/ansi_conformance_reference.h','tests/ansi_conformance_native_cases.py','tests/control_cancellation_native_cases.py','tests/control_cancellation_window_smoke.py','tests/protocol_oracle_window.py','scripts/generate-cancellation-reference.py','vendor/putty-0.85/test/test_cancellation_terminal.c','vendor/putty-0.85/terminal/terminal.c','vendor/putty-0.85/terminal/terminal.h','vendor/putty-0.85/test/test_ansi_terminal.c'):
    entries['source/'+name]=subprocess.check_output(['git','show',f'{source}:{name}'],cwd=work)
source_matches=[]
for name,key in [('scripts/prepare-single-exe.py','OverlaySHA256'),('native/single_exe/entry.cpp','EntrySHA256')]:
    raw=entries['source/'+name];expected=host[key]
    encoding='git_blob' if sha(raw)==expected else 'crlf_checkout' if sha(raw.replace(b'\n',b'\r\n'))==expected else None
    assert encoding,(name,expected)
    source_matches.append(dict(path=name,sha256=expected,encoding=encoding))
archive=work/'research/dec-locator-ordinary.tar.gz';archive.parent.mkdir(exist_ok=True);records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,value in sorted(entries.items()):
        info=tarfile.TarInfo(name)
        if isinstance(value,bytes):
            info.size=len(value);checksum=sha(value);tar.addfile(info,io.BytesIO(value))
        else:
            info.size=value.stat().st_size;checksum=digest(value)
            with value.open('rb') as stream:tar.addfile(info,stream)
        records.append(dict(path=name,raw_bytes=info.size,raw_sha256=checksum))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path']
        assert hashlib.file_digest(tar.extractfile(member),'sha256').hexdigest()==record['raw_sha256']
manifest=dict(source=source,run=43715235781,conclusion='success',jobs=4,
    locator_native=dict(phases=27,shift_selection_pixels=locator['shift_selection_pixels'],resized_grid=locator['resized_grid'],exact_wire_checked=True,natural_cleanup=True),frontend=dict(sha256=image_sha,bytes=frontend.stat().st_size),source_console_host=host,source_matches=source_matches,workloads=workloads,native_comparison=dict(reference_streams=413,ansi=177,cancellation=236,binary_only_core=84,pixel_pairs=native['exercise']['pixel_pairs'],natural_cleanup=True),
    limits='Ordinary portable MinGW frontend and its identified source host; remote Consolas grids only. This is not the single-image distribution or local 160x48 Sarasa acceptance. The roughly 50 MB total target applies to GDI; current DX memory is accepted. This image includes Locator, CAN/SUB parity and the 413 native reference streams; it predates DECUDK.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
        archive_sha256=digest(archive),records=records))
(work/'research/dec-locator-ordinary-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,workloads=len(workloads))))
