import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/ci-io-7a3b95e';exe=base/'product/nemoterm.exe'
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
for label,fixture,args in [('local-automation','automation',[]),
    ('local-workload-gdi','tabs',['--renderer','gdi','--side','top','--cols','160','--rows','48','--workload-memory'])]:
    dest=base/label;assert not dest.exists(),dest
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),fixture,*args],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    print(json.dumps(dict(label=label,exit_code=code,executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest())),flush=True)
    if code:
        print((dest/'controller.log').read_text(encoding='utf-8')[-4500:],flush=True)
        raise SystemExit(code)
