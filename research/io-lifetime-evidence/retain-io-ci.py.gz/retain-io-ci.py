import datetime,gzip,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1];base=root/'build/ci-io-7a3b95e'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
path=root/'research/io-lifetime-validation.json';m=read(path);files=[]
def retain(p,name):
    raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);dest=root/'research/io-lifetime-evidence'/(name+'.gz')
    assert not dest.exists(),dest;dest.write_bytes(packed)
    files.append(dict(path=dest.relative_to(root).as_posix(),bytes=len(packed),sha256=sha(packed),
        raw_bytes=len(raw),raw_sha256=sha(raw),encoding='gzip'))
for name in ('core','single'):
    run=read(base/(name+'-run.json'))
    assert run['status']=='completed' and run['conclusion']=='success' and run['headSha']==m['source_commit']
    assert all(j['conclusion']=='success' for j in run['jobs'])
    m['remote_ci'][name].update(status='success',jobs=[dict(name=j['name'],conclusion=j['conclusion']) for j in run['jobs']])
    for suffix in ('-run.json','-run.log','-artifacts.json'):retain(base/(name+suffix),'ci-'+name+suffix)
image=(base/'product/nemoterm.exe').read_bytes();digest=sha(image)
assert digest=='b1a1f25ca3014714b03de2559ce695281b3ef26bc3c2b450f8ca3e85cdceec50'
summary=read(base/'single-evidence/build/single-exe-check/research/single-exe-validation.json')
assert summary['executable_sha256']==digest and summary['executable_directory_files']==['nemoterm.exe']
assert len(summary['passed_checks'])==len(set(summary['passed_checks']))==101
artifact=next(a for a in read(base/'single-artifacts.json')['artifacts'] if a['name']=='nemoterm-single-exe-x64-'+m['source_commit'])
m['ci_image']=dict(bytes=len(image),sha256=digest,artifact_id=artifact['id'],expires_at=artifact['expires_at'],
    archive_digest=artifact['digest'],passed_checks=summary['passed_checks'])
retain(base/'single-evidence/build/single-exe-check/research/single-exe-validation.json','ci-single-exe-validation.json')
for renderer in ('gdi','directx'):
    p=base/'single-evidence/build/single-exe-check/research'/f'automation-{renderer}-observed.json'
    v=read(p);assert v['completed'] and len(v['checks'])==10 and v['exe_sha256']==digest
    retain(p,'ci-'+p.name)
for folder,prefix in [('core-evidence/test-results','ci-mingw-'),('sanitizers','ci-sanitizer-')]:
    for p in (base/folder).glob('*.log'):
        if p.name.startswith(('test_','terminal-')):retain(p,prefix+p.name)
retain(base/'msvc/handle-io-msvc.log','ci-handle-io-msvc.log')
checks=[]
for label,fixture in [('local-automation','automation'),('local-workload-gdi','tabs'),
    ('control-c1-gdi','tabs'),('repeat-io-gdi','tabs')]:
    folder=base/label
    ctl=read(folder/'research'/f'{fixture}-controller.json');assert not ctl['cleanup']['after']['active']
    v=read(folder/'research'/('automation-gdi-observed.json' if fixture=='automation' else 'workload-tabs-gdi-top-observed.json'))
    item=dict(label=label,controller=ctl,completed=v['completed'],checks=v['checks'],error=v.get('error'))
    if fixture=='automation':
        assert v['completed'] and len(v['checks'])==10 and v['capture_differing_channels']==0
        item['io_contexts']=v['io_contexts']
        for p in Path(v['folder']).glob('*.png'):retain(p,label+'-'+p.name)
    else:
        assert v['actual_grid']==[160,48] and v['font']=='SarasaTermSC Nerd Font Light'
        memory=read(folder/'research/workload-tabs-gdi-top-memory.json');assert not memory['injected'] and not memory['errors']
        item.update(baseline=v['two_tabs'],cycles=v['cycles'],peaks=memory['peaks'],samples=memory['sample_count'],
            seconds=memory['seconds'],inner_cleanup=v['owned_job_cleanup'])
        assert (folder/'tests/tabs_window_smoke.py').read_bytes().replace(b'\r\n',b'\n')==(root/'tests/tabs_window_smoke.py').read_bytes().replace(b'\r\n',b'\n')
    checks.append(item)
    for p in (folder/'research').iterdir():
        if p.is_file():retain(p,label+'-'+p.name)
    for relative in (fixture+'.log','controller.log','tests/'+fixture+'_window_smoke.py'):
        retain(folder/relative,label+'-'+relative.replace('/','_'))
retain(base/'gdi-startup-comparison.json','gdi-startup-comparison.json')
for name in ('check-io-ci-image.py','compare-gdi-startup.py','retain-io-ci.py'):retain(root/'build'/name,name)
m.update(downloaded_image_checks=checks,promotion='pending: local GDI startup resource failure reproduced twice',
    recorded_ci_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
m['files']+=files
for f in m['files']:
    b=(root/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'] and sha(gzip.decompress(b))==f['raw_sha256']
path.write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(total=len(m['files']),new_files=len(files),image=m['ci_image'],promotion=m['promotion']),indent=2))
