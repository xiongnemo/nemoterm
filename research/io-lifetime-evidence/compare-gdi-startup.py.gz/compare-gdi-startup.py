import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/ci-io-7a3b95e'
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
results=[]
for label,exe in [('control-c1-gdi',root.parent/'c1-worktree/build/ci-c1-43534154789/product/nemoterm.exe'),
                  ('repeat-io-gdi',base/'product/nemoterm.exe')]:
    dest=base/label;assert not dest.exists(),dest
    for folder in ('dist','research','build'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),'tabs','--renderer','gdi','--side','top',
            '--cols','160','--rows','48','--workload-memory'],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    observed=json.loads((dest/'research/workload-tabs-gdi-top-observed.json').read_text(encoding='utf-8'))
    result=dict(label=label,exit_code=code,executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),
        baseline=observed.get('two_tabs'),cycles=observed.get('cycles'),error=observed.get('error'))
    results.append(result);print(json.dumps(result),flush=True)
(base/'gdi-startup-comparison.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
raise SystemExit(1 if any(r['exit_code'] for r in results) else 0)
