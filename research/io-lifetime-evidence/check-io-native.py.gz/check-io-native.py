import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
runtime=root.parent/'alignment-worktree/build/native-gdi/dist'
host=root.parent/'rtl-worktree/build/ci-underline-43508892024/source-host'
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
source='37ef26dae839319f7bf703bb648038c343c357f1'
exe=root/'build/core/nemoterm.exe'
cases=[('automation',['--renderer','gdi']),('session',['--renderer','gdi']),
       ('session_restart',['--renderer','gdi']),('shutdown',['--renderer','all'])]
for name,args in cases:
    dest=root/'build'/('native-io-'+name)
    assert not dest.exists(),dest
    for folder in ('research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(runtime,dest/'dist')
    shutil.copy2(exe,dest/'dist/nemoterm.exe')
    shutil.copytree(root/'tests',dest/'tests')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    with (dest/'host-install.log').open('w',encoding='utf-8') as log:
        subprocess.run(['pwsh','-NoProfile','-File',str(root/'scripts/install-source-conpty-host.ps1'),
            '-SourceDirectory',str(host),'-Destination',str(dest/'dist'),'-ExpectedCommit',source],
            cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),name,*args],
            cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    print(json.dumps(dict(name=name,executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),exit_code=code)),flush=True)
    if code:
        print((dest/'controller.log').read_text(encoding='utf-8')[-5000:])
        raise SystemExit(code)
