import datetime,gzip,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
out=root/'research/io-lifetime-evidence';out.mkdir(exist_ok=False)
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
manifest=dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=source,
    unit_scenarios=['idle-output','input-eof-close','input-error-close','output-error-close',
        'completed-read-close','completed-write-close','transfer'],iterations_per_scenario=40,
    unit_compilers=['MinGW GCC','MSVC 19.44'],memory_acceptance=False,files=[],native=[])
def retain(p,name):
    raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);dest=out/(name+'.gz')
    assert not dest.exists(),dest
    dest.write_bytes(packed)
    manifest['files'].append(dict(path=dest.relative_to(root).as_posix(),bytes=len(packed),sha256=sha(packed),
        raw_bytes=len(raw),raw_sha256=sha(raw),encoding='gzip'))
changed=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',source],cwd=root,text=True).splitlines()
manifest['source_sha256']={p:sha((root/p).read_bytes().replace(b'\r\n',b'\n')) for p in changed}
manifest['source_hash_format']='SHA-256 of UTF-8 checkout files with CRLF normalized to LF'
manifest['images']={}
for label,name in [('before','build/test_handle_io-before.exe'),('mingw_test','build/core/test_handle_io.exe'),
    ('msvc_test','build/core-msvc/test_handle_io.exe'),('frontend','build/core/nemoterm.exe')]:
    b=(root/name).read_bytes();manifest['images'][label]=dict(path=name,sha256=sha(b),bytes=len(b))
for name in ['configure.log','core-build-initial.log','core-build-02.log','initial-results.json',
    'initial-idle-output.log','initial-input-eof-close.log','initial-output-error-close.log','initial-transfer.log',
    'handle-io-before.c','test_handle_io-initial.c','core-build-fixed.log','handle-io-fixed.log',
    'core-build-fixed-02.log','handle-io-fixed-02.log','configure-msvc.log','core-build-msvc.log',
    'handle-io-msvc.log','check-io-native.py','retain-io.py']:
    retain(root/'build'/name,name)
for name in ('automation','session','session_restart','shutdown'):
    folder=root/'build'/('native-io-'+name)
    controller=read(folder/'research'/f'{name}-controller.json')
    assert controller['completed'] and controller['exit_code']==0
    assert not controller['cleanup']['terminated_remaining'] and not controller['cleanup']['after']['active']
    observations=[]
    for p in (folder/'research').glob('*observed.json'):
        value=read(p);assert value['completed'],p
        observations.append(dict(name=p.name,checks=value.get('checks',[]),cases=len(value.get('cases',[]))))
    manifest['native'].append(dict(name=name,controller=controller,observations=observations))
    for p in (folder/'research').glob('*.json'):retain(p,name+'-'+p.name)
    for p in folder.glob('*.log'):retain(p,name+'-'+p.name)
    if name=='automation':
        v=read(folder/'research/automation-gdi-observed.json')
        assert len(v['checks'])==10 and v['capture_differing_channels']==0
        manifest['io_snapshots']=v['io_contexts']
        for p in Path(v['folder']).glob('*.png'):retain(p,'automation-'+p.name)
manifest['remote_ci']={label:dict(id=run,status='pending',url=f'https://github.com/xiongnemo/nemoterm/actions/runs/{run}')
    for label,run in [('single',43539454999),('core',43539455051)]}
for f in manifest['files']:
    b=(root/f['path']).read_bytes()
    assert len(b)==f['bytes'] and sha(b)==f['sha256'] and sha(gzip.decompress(b))==f['raw_sha256']
(root/'research/io-lifetime-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(records=len(manifest['files']),native=manifest['native']),indent=2))
