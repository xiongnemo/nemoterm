"""Retain the completed GDI gate on the exact CI single image, without promotion."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
from PIL import Image

root=Path(__file__).resolve().parents[1]
stage=root/'build/local-gdi-single-product-12ee33b-01'
work=root/'build/gdi-dense-memory-worktree'
source='12ee33baa970363ddde687b3e612f9154e386356'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
identity=load(stage/'IDENTITY.json')
assert identity['source_commit']==identity['fixture_commit']==source
assert identity['source_run']==43736421137 and identity['artifact_id']==14172342252
digest='64195969a8f2e6653f854d598f169810107ee808d66eaa1088cf9e3ced6b259f'
assert identity['executable_sha256']==digest and sha((stage/'dist/nemoterm.exe').read_bytes())==digest
assert (stage/'dist/nemoterm.exe').stat().st_size==4544000
assert [p.name for p in (stage/'dist').iterdir()]==['nemoterm.exe']
results=load(stage/'logs/results.json')
selected=results[:3]
assert [r['name'] for r in selected]==['shutdown','startup-size','unicode-kitty-memory-gdi']
assert all(r.get('exit_code')==0 for r in selected)
for result in selected:
    for record in result['observations']:
        path=stage/record['path'];assert path.stat().st_size==record['bytes'] and sha(path.read_bytes())==record['sha256']
research=stage/'case-evidence/unicode-kitty-memory-gdi/research'
observed=load(research/'unicode-kitty-workload-tabs-gdi-top-observed.json')
memory=load(research/'unicode-kitty-workload-tabs-gdi-top-memory.json')
assert observed['completed'] and observed['phase']=='complete' and observed['memory_limit_passed']
assert observed['executable_sha256']==digest and observed['actual_renderer']==1
assert observed['font']=='SarasaTermSC Nerd Font Light' and observed['actual_grid']==[160,48]
assert observed['session_seconds']==1800 and len(observed['checks'])==10
assert observed['memory_limit_bytes']==20_000_000 and not observed['memory_limit_inclusive']
assert observed['peak_private_ws']==19_226_624 and not observed['memory_instrumented']
assert not memory['errors'] and not memory['injected'] and len(memory['samples'])==memory['sample_count']==3876
for key in ('private_ws','total_ws','private_commit'):
    assert memory['peaks']['frontend'][key]==max(s['groups']['frontend'][key] for s in memory['samples'])
assert observed['process_tree_memory']['peaks']==memory['peaks']
assert observed['host_close']['exit_code']==0
cleanup=observed['owned_job_cleanup']
assert cleanup['after']==dict(total=56,active=0,terminated=0) and not cleanup['terminated_remaining']
assert not cleanup['remaining_processes']
pixels=observed['post_memory_kitty_unicode']
assert len(pixels)==4 and sum(p['cells_verified'] for p in pixels)==29072
strips=0
for pixel in pixels:
    assert pixel['matched'] and pixel['after_memory_sampling'] and not pixel['injected']
    assert pixel['grid']==[160,48] and len(pixel['rows'])==46 and all(row['matched'] for row in pixel['rows'])
    for row in pixel['rows']:
        if 'image' not in row:continue
        with Image.open(research/row['image']) as image:
            image=image.convert('RGB');assert image.size==(1264,1)
            assert all(image.getpixel((column*8+4,0))==(0,0,255) for column in range(158))
        strips+=1
assert strips==12
shutdown=load(stage/'case-evidence/shutdown/research/shutdown-window-observed.json')
assert shutdown['completed'] and shutdown['executable_sha256']==digest and len(shutdown['cases'])==12
assert all(c['exit_code']==0 and not c['cleanup']['terminated_remaining'] for c in shutdown['cases'])
startup=load(stage/'case-evidence/startup-size/research/startup-size-observed.json')
assert startup['executable_sha256']==digest and len(startup['checks'])==2

entries={'IDENTITY.json':stage/'IDENTITY.json','controller.py':stage/'controller.py',
         'cases.json':stage/'cases.json','retainer.py':Path(__file__),
         'selected-results.json':(json.dumps(selected,indent=2)+'\n').encode()}
for result in selected:
    folder=stage/'case-evidence'/result['name']
    for path in folder.rglob('*'):
        if path.is_file():entries[path.relative_to(stage).as_posix()]=path
    entries['logs/'+result['name']+'.log']=stage/'logs'/(result['name']+'.log')
for folder in ['tests','tools']:
    for path in (stage/folder).rglob('*'):
        if not path.is_file() or '__pycache__' in path.parts:continue
        name=path.relative_to(stage).as_posix()
        assert path.read_bytes()==subprocess.check_output(['git','show',source+':'+name],cwd=work)
        entries[name]=path
entries['font-mapper-preflight.json']=stage/'research/font-mapper-preflight.json'
archive=work/'research/gdi-image-cache-product-gdi.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,value in sorted(entries.items()):
        raw=value if isinstance(value,bytes) else value.read_bytes()
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,bytes=len(raw),sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for record in records:assert sha(tar.extractfile(record['path']).read())==record['sha256']
manifest=dict(source=source,identity=identity,completed=True,
    scope='Exact successful CI single image: completed local dense GDI workload, shutdown and startup-size groups. Remaining product groups are not certified by this record; no promotion.',
    font=observed['font'],grid=[160,48],sample_count=memory['sample_count'],sampled_seconds=memory['seconds'],
    frontend_peaks=memory['peaks']['frontend'],private_limit_bytes=20_000_000,private_limit_inclusive=False,
    verified_image_cells=29072,retained_pixel_strips=strips,tab_checks=observed['checks'],
    host_close=observed['host_close'],cleanup=cleanup,shutdown_cases=12,startup_checks=2,
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes())),records=records)
(archive.parent/'gdi-image-cache-product-gdi-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ['completed','frontend_peaks','sample_count','verified_image_cells','archive']},indent=2))
