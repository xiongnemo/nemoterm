from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];project=root.parents[1]
base=root/'build/renderer-capture-comparison';base.mkdir()
exe=project/'build/iterm-images-worktree/build/ci-iterm-3187ec5/product/nemoterm.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='8e52b517787fb508937611b15eb48855ab0e73521978f579d853cf48d9748585'
old=subprocess.check_output(['git','show','de8981d:tests/renderer_window_smoke.py'],cwd=root)
(base/'original-fixture.py').write_bytes(old)
results=[]
for name in ['old-replay','api-capture']:
    dest=base/name
    for directory in ('dist','research','build','tools'):(dest/directory).mkdir(parents=True)
    shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
    if name=='old-replay':(dest/'tests/renderer_window_smoke.py').write_bytes(old)
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(exe,dest/'dist/nemoterm.exe')
    with (dest/'controller.log').open('w') as log:
        result=subprocess.run([sys.executable,str(project/'build/rtl-worktree/build/run-owned-check.py'),str(dest),'renderer'],stdout=log,stderr=subprocess.STDOUT)
    observed=dest/'research/renderer-observed.json'
    d=json.loads(observed.read_text()) if observed.exists() else {}
    record=dict(name=name,exit_code=result.returncode,completed=d.get('completed'),modes=[dict(requested=m['requested'],active=m.get('active'),checks=len(m['checks'])) for m in d.get('modes',[])])
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps(record),flush=True)
    if result.returncode:
        print((dest/'controller.log').read_text()[-3500:])
        if name=='api-capture':raise SystemExit(result.returncode)
