"""Retain intermittent external clipboard access and the original failed retry."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path(__file__).resolve().parents[1]
stage=root/'build/local-gdi-display-cache-12ee33b'
work=root/'build/gdi-dense-memory-worktree'
report=stage/'research/kitty-unicode-selection-gdi-observed.json'
d=json.loads(report.read_text());folder=Path(d['folder'])
assert not d['completed'] and not d['checks'] and not d['input_operations']
assert 'saved=SavedClipboard(window)' in d['error'] and 'OpenClipboard(hwnd)' in d['error']
assert not d['cleanup']['terminated_remaining'] and d['cleanup']['after']['active']==0
assert not d['cleanup']['remaining_processes'] and d['cleanup']['after']['terminated']==0
assert folder.name.endswith('aadf5f11c8a548c9b57d0da3e249f20e')
entries={'observed.json':report,'controller.log':stage/'logs/unicode-selection-gdi-02.log',
         'IDENTITY.json':stage/'IDENTITY.json','retainer.py':Path(__file__)}
for path in folder.rglob('*'):
    if path.is_file():entries['fixture/'+path.relative_to(folder).as_posix()]=path
for name in ['gdi-clipboard-current-preflight.json','gdi-clipboard-after-retry.json',
             'gdi-clipboard-station-rights.json','gdi-clipboard-job-rights.json']:
    entries['external/'+name]=root/'build'/name
for name in ['kitty_unicode_selection_window_smoke.py','clipboard_test_utils.py','native_test_utils.py']:
    entries['tests/'+name]=stage/'tests'/name
before=json.loads(entries['external/gdi-clipboard-current-preflight.json'].read_text())
after=json.loads(entries['external/gdi-clipboard-after-retry.json'].read_text())
assert before['open_success'] and before['closed_if_opened'] and not before['contents_read'] and not before['contents_changed']
assert not after['open_success'] and after['error']==5 and not after['contents_read'] and not after['contents_changed']
sha=lambda raw:hashlib.sha256(raw).hexdigest()
archive=work/'research/gdi-image-cache-clipboard-retry.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,path in sorted(entries.items()):
        raw=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,bytes=len(raw),sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for record in records:assert sha(tar.extractfile(record['path']).read())==record['sha256']
manifest=dict(source='12ee33baa970363ddde687b3e612f9154e386356',completed=False,checks=0,
    reason='External OpenClipboard(NULL) succeeds immediately before the retry, then fails with error 5 afterward; native fixture still fails before selection or clipboard modification. Cause unconfirmed.',
    null_window_caveat='GetOpenClipboardWindow returning NULL does not exclude a lock opened without a window handle.',
    documentation='https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-getopenclipboardwindow',
    cleanup=d['cleanup'],archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes())),records=records)
(archive.parent/'gdi-image-cache-clipboard-retry-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(completed=False,checks=0,archive=manifest['archive'])))
