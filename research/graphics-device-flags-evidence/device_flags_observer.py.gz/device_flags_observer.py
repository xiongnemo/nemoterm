"""Bounded entry/return observation in a newly owned test process."""
import frida

SCRIPT = r'''
const result={hooks:[],events:[],errors:[],truncated:false};
const listeners=[];
let counter=0;
const observer=Process.attachModuleObserver({onAdded(module){
  if(module.name.toLowerCase()!=='d3d11.dll')return;
  try {
    const address=module.getExportByName('D3D11CreateDevice');
    result.hooks.push({module:module.name,entry:'D3D11CreateDevice'});
    listeners.push(Interceptor.attach(address,{
      onEnter(args){
        if(counter++>=16){result.truncated=true;return;}
        this.entry={flags:args[3].toUInt32(),driver_type:args[1].toUInt32(),
          adapter_supplied:!args[0].isNull(),requested_levels:[],thread:this.threadId};
        this.level=args[8];
        const count=args[5].toUInt32();
        this.entry.requested_level_count=count;
        if(count>16){result.errors.push('Feature level list exceeds observation bound');return;}
        if(!args[4].isNull()) for(let i=0;i<count;i++) this.entry.requested_levels.push(args[4].add(i*4).readU32());
        const caller=Process.findModuleByAddress(this.returnAddress);
        this.entry.caller=caller?caller.name+'+'+this.returnAddress.sub(caller.base):'unknown';
        result.events.push(this.entry);
      },
      onLeave(ret){
        if(!this.entry)return;
        this.entry.hresult=ret.toUInt32();
        if(ret.toInt32()>=0 && !this.level.isNull()) this.entry.selected_level=this.level.readU32();
      }
    }));
  }catch(e){result.errors.push(String(e));}
}});
rpc.exports={freeze(){observer.detach();for(const l of listeners)l.detach();return result;}};
'''

class DeviceFlags:
    def __init__(self, pid):
        self.pid=pid
        self.session=self.script=None
        self.errors=[]

    def start(self):
        self.session=frida.attach(self.pid)
        self.script=self.session.create_script(SCRIPT)
        self.script.on('message',lambda message,data:self.errors.append(message) if message['type']=='error' else None)
        self.script.load()

    def freeze(self):
        result=self.script.exports_sync.freeze()
        result['errors'].extend(self.errors)
        return result

    def close(self):
        if self.script:
            self.script.unload()
            self.script=None
        if self.session:
            self.session.detach()
            self.session=None
