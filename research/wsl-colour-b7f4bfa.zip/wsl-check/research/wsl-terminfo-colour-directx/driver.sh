set -euo pipefail
cd -- "$(dirname -- "$0")"
exec 2>stderr.txt
trap 'echo "$?" > exit' EXIT
await() { for ((i=0;i<600;i++)); do [[ ! -f stop ]] || exit 22; [[ ! -f "$1" ]] || return 0; sleep .1; done; exit 23; }
{ printf '%s\n' "$TERM" "$COLORTERM" "$TERM_PROGRAM"; dpkg-query -W ncurses-bin ncurses-term; tput -V; sha256sum "$(command -v tput)"; } > identity.txt
[[ "$TERM" == xterm-256color && "$COLORTERM" == truecolor && "$TERM_PROGRAM" == nemoterm ]]
printf '\033[2J\033[HCOL_PRIOR_SCREEN'
for type in xterm xterm-256color xterm-direct; do
  await "go-$type"
  (
    export TERM="$type"
    infocmp -x "$TERM" > "$type.ti"
    tput colors > "$type.count"
    case "$type" in xterm) a=2; b=2;; xterm-256color) a=68; b=68;; xterm-direct) a=$((0x12569a)); b=$((0x12569b));; esac
    tput setab "$a" > "$type.bg"; tput setaf "$b" > "$type.fg"
    {
      tput smcup; tput clear; tput civis
      printf '\033]4;2;rgb:25/a3/4c\033\\'
      tput cup 2 4; cat "$type.bg"; printf '    '; tput sgr0
      tput cup 2 10; tput rev; cat "$type.fg"; printf '    '; tput sgr0
      if [[ "$COLORTERM" == truecolor ]]; then
        tput cup 2 16; printf '\033[48;2;18;86;155m    '; tput sgr0
      fi
      tput cup 6 0; printf 'COL_DRAWN:%s:' "$type"
    } | tee "$type.vt"
    await "leave-$type"
    tput sgr0; tput cnorm; tput rmcup
  )
  printf '\033[9;1HCOL_RESTORED:%s:' "$type"
done
await finish
