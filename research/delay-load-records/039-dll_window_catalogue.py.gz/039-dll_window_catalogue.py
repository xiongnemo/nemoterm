import ctypes as c
from ctypes import wintypes as w
from pathlib import Path
from thread_snapshot import modules

u=c.WinDLL('user32')
Callback=c.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
u.EnumWindows.argtypes=[Callback,w.LPARAM]
u.EnumChildWindows.argtypes=[w.HWND,Callback,w.LPARAM]
u.GetWindowThreadProcessId.argtypes=[w.HWND,c.POINTER(w.DWORD)]
u.GetClassNameW.argtypes=[w.HWND,w.LPWSTR,c.c_int]
u.GetParent.argtypes=[w.HWND];u.GetParent.restype=w.HWND
u.IsWindowVisible.argtypes=[w.HWND]

def catalogue(owner):
    owner._validate_owner()
    found={}
    @Callback
    def child(hwnd,_):
        pid=w.DWORD();tid=u.GetWindowThreadProcessId(hwnd,c.byref(pid))
        if pid.value==owner.process.pid:
            name=c.create_unicode_buffer(256)
            u.GetClassNameW(hwnd,name,len(name))
            found[int(hwnd)]=dict(hwnd=int(hwnd),tid=tid,kind=name.value,
                parent=u.GetParent(hwnd),visible=bool(u.IsWindowVisible(hwnd)))
        return True
    @Callback
    def top(hwnd,_):
        child(hwnd,0)
        pid=w.DWORD();u.GetWindowThreadProcessId(hwnd,c.byref(pid))
        if pid.value==owner.process.pid:u.EnumChildWindows(hwnd,child,0)
        return True
    u.EnumWindows(top,0)
    loaded=modules(owner.handle)
    return dict(windows=list(found.values()),modules=[m['path'] for m in loaded])
