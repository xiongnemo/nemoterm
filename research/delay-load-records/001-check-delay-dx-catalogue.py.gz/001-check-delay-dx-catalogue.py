"""Diagnostic-only paired DLL experiment; retain all original acceptance gates.

Only newly spawned job-owned Nemoterm windows are enumerated; no global input,
focus change, injection or IME setting modification is added by this observer.
Each case is bounded by the existing 180-second outer controller. Stop at first
failed original assertion. Records are local Win32 observations, not REA Evidence.
"""
import hashlib,json,shutil,subprocess,sys
from pathlib import Path

root=Path(__file__).resolve().parents[1]
base=root/'build/delay-dx-catalogue';base.mkdir(exist_ok=False)
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
before=root/'build/integrated-input-close/nemoterm.exe'
after=root/'build/delay-load-probe/image/nemoterm.exe'
assert json.loads(before.with_name('image.json').read_text())['inputs']==json.loads(after.with_name('image.json').read_text())['inputs']
helper='''import ctypes as c
from ctypes import wintypes as w
from pathlib import Path
from thread_snapshot import modules

u=c.WinDLL('user32')
Callback=c.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
u.EnumWindows.argtypes=[Callback,w.LPARAM]
u.EnumChildWindows.argtypes=[w.HWND,Callback,w.LPARAM]
u.GetWindowThreadProcessId.argtypes=[w.HWND,c.POINTER(w.DWORD)]
u.GetClassNameW.argtypes=[w.HWND,w.LPWSTR,c.c_int]
u.GetParent.argtypes=[w.HWND];u.GetParent.restype=w.HWND
u.IsWindowVisible.argtypes=[w.HWND]

def catalogue(owner):
    owner._validate_owner()
    found={}
    @Callback
    def child(hwnd,_):
        pid=w.DWORD();tid=u.GetWindowThreadProcessId(hwnd,c.byref(pid))
        if pid.value==owner.process.pid:
            name=c.create_unicode_buffer(256)
            u.GetClassNameW(hwnd,name,len(name))
            found[int(hwnd)]=dict(hwnd=int(hwnd),tid=tid,kind=name.value,
                parent=u.GetParent(hwnd),visible=bool(u.IsWindowVisible(hwnd)))
        return True
    @Callback
    def top(hwnd,_):
        child(hwnd,0)
        pid=w.DWORD();u.GetWindowThreadProcessId(hwnd,c.byref(pid))
        if pid.value==owner.process.pid:u.EnumChildWindows(hwnd,child,0)
        return True
    u.EnumWindows(top,0)
    loaded=modules(owner.handle)
    return dict(windows=list(found.values()),modules=[m['path'] for m in loaded])
'''
results=[]
for label,exe,mode,side in [('baseline-directx',before,'directx','left'),
                          ('delayed-directx',after,'directx','left')]:
    dest=base/label
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    (dest/'tests/dll_window_catalogue.py').write_text(helper)
    p=dest/'tests/tabs_window_smoke.py';source=p.read_text()
    anchor='''                return dict(handles=count.value,gdi=u.GetGuiResources(handle,0),user=u.GetGuiResources(handle,1),
                            injected=injected_observer,**memory_sample(handle))'''
    replacement='''                result=dict(handles=count.value,gdi=u.GetGuiResources(handle,0),user=u.GetGuiResources(handle,1),
                            injected=injected_observer,**memory_sample(handle))
                from dll_window_catalogue import catalogue
                evidence.setdefault('resource_catalogues',[]).append(dict(sample=result,
                    phase=memory_sampler.phase if memory_sampler else 'after-memory',
                    **catalogue(thread_observer.owner)))
                return result'''
    assert source.count(anchor)==1;source=source.replace(anchor,replacement)
    anchor="            evidence['completed']=True"
    assert source.count(anchor)==1
    source=source.replace(anchor,"            evidence.update(diagnostic_completed=True,completed=False,memory_acceptance=False)")
    p.write_text(source)
    (dest/'diagnostic-fixture.json').write_text(json.dumps(dict(
        scope='read-only window/module metadata at original resource checks; original numeric gates unchanged',
        acceptance=False,executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),
        original_fixture_sha256=hashlib.sha256((root/'tests/tabs_window_smoke.py').read_bytes()).hexdigest(),
        fixture_sha256=hashlib.sha256(p.read_bytes()).hexdigest()),indent=2)+'\n')
    with (dest/'controller.log').open('w') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),'tabs','--renderer',mode,
            '--side',side,'--cols','160','--rows','48','--workload-memory'],
            cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    record=dict(label=label,exit_code=code,acceptance=False)
    memory=list((dest/'research').glob('*-memory.json'))
    if memory:
        data=json.loads(memory[0].read_text());record.update(peaks=data['peaks']['frontend'],samples=data['sample_count'])
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(record,flush=True)
    if code:
        print((dest/'controller.log').read_text()[-2000:]);raise SystemExit(code)
