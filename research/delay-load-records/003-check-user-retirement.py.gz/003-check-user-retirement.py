"""Retain post-failure USER lifetime without turning the failed sample green."""
import json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=root/'build/delay-load-catalogue/delayed-gdi'
dest=root/'build/user-retirement-probe';dest.mkdir(exist_ok=False)
for folder in ('dist','tests','tools'):shutil.copytree(source/folder,dest/folder)
for folder in ('research','build'):(dest/folder).mkdir()
p=dest/'tests/tabs_window_smoke.py';code=p.read_text()
anchor="                assert sample['handles']<=baseline['handles']+6,(baseline,sample)"
replacement="""                if (sample['handles']>baseline['handles']+6 or
                    sample['gdi']>baseline['gdi']+3 or sample['user']>baseline['user']+2):
                    # Preserve the original verdict. Observe only after the
                    # exact original failed sample, then assert on that sample.
                    history=[];evidence['post_failure_resources']=history
                    started=time.monotonic()
                    for _ in range(40):
                        time.sleep(.05)
                        history.append(dict(seconds=time.monotonic()-started,**resources()))
                assert sample['handles']<=baseline['handles']+6,(baseline,sample)"""
assert code.count(anchor)==1;p.write_text(code.replace(anchor,replacement))
(dest/'diagnostic-fixture.json').write_text(json.dumps(dict(
    scope='two seconds of owned resource samples after failed original sample; original assertion retained',
    acceptance=False),indent=2)+'\n')
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
with (dest/'controller.log').open('w') as log:
    result=subprocess.run([sys.executable,str(controller),str(dest),'tabs',
        '--renderer','gdi','--side','top','--cols','160','--rows','48','--workload-memory'],
        stdout=log,stderr=subprocess.STDOUT,cwd=root)
print((dest/'controller.log').read_text()[-2500:]);raise SystemExit(result.returncode)
