import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];base=root/'build/delay-load-probe';results=[]
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
before=root/'build/integrated-input-close/nemoterm.exe';after=base/'image/nemoterm.exe'
a=json.loads(before.with_name('image.json').read_text());b=json.loads(after.with_name('image.json').read_text())
assert a['inputs']==b['inputs'],'Link input drift invalidates this comparison'
for label,exe,name,args in [
    ('startup',after,'startup_visibility',[]),('automation',after,'automation',['--renderer','directx']),
    ('baseline-gdi',before,'tabs',['--renderer','gdi','--side','top']),
    ('delayed-gdi',after,'tabs',['--renderer','gdi','--side','top']),
    ('baseline-directx',before,'tabs',['--renderer','directx','--side','left']),
    ('delayed-directx',after,'tabs',['--renderer','directx','--side','left'])]:
    dest=base/label;assert not dest.exists()
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    if name=='tabs':args+=['--cols','160','--rows','48','--workload-memory']
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),name,*args],
            cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    record=dict(label=label,exit_code=code)
    memory=list((dest/'research').glob('*-memory.json'))
    if memory:
        data=json.loads(memory[0].read_text());record.update(peaks=data['peaks']['frontend'],samples=data['sample_count'])
    results.append(record);print(record,flush=True)
    (base/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    if code:
        print((dest/'controller.log').read_text(encoding='utf-8')[-2500:]);raise SystemExit(code)
