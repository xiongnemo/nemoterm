"""Retain the diagnostic-only active-tab close observation on the exact prior image."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/bell-modes-worktree'
base=root/'build/ci-bell-state-a87c01e';source='a87c01ee2022159e07ecd94c7bc8805307643211'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'bell-state-run.json').read_bytes())
assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(43724456785,source,'completed','failure')
artifacts=json.loads((base/'bell-state-artifacts.json').read_bytes())['artifacts']
receipt=json.loads((base/'diagnostic-download.json').read_bytes())
artifact=next(a for a in artifacts if a['id']==receipt['artifact_id'])
assert artifact['name']=='bell-window-state-'+source and receipt['source']==source
b=base/'diagnostic';provenance=json.loads((b/'bell-state-provenance.json').read_text(encoding='utf-8-sig'))
assert provenance['fixture_source']==source and provenance['diagnostic_failed_baseline']
assert provenance['image_source']=='f25294c452e05fa45115cc46423ed647e95950ec'
assert provenance['image_run']==43723767151 and provenance['image_conclusion']=='failure'
assert provenance['artifact_id']==14165686917
assert provenance['image_sha256'].lower()=='bb407c52853e9e9003b9b853e418495940033182c15f714efabe31f9115b9955'
data=json.loads((b/'research/bell-window-state-observed.json').read_bytes())
assert not data['completed'] and len(data['checks'])==18 and data['executable_sha256']==provenance['image_sha256'].lower()
assert all(c['renderer']==0 for c in data['checks'])
last=data['checks'][-1];before=data['checks'][-2]['after']
assert last['name']=='inactive-host-active-tab-close'
assert last['after']['foreground']==before['foreground'] and last['after']['active']!=before['active']
assert any(e['api']=='FlashWindowEx' and e['flags']==0 for e in last['api'])
entries={'source/retainer.py':Path(__file__).read_bytes()}
for name in ('tests/bell_window_state_smoke.py','tests/session_fixture.py','tests/native_test_utils.py',
             'tests/fixture_io.py','tests/mouse_fixture.py','tests/owned_job.py',
             'tests/protocol_oracle_window.py','tools/nemoterm_debug.py','.github/workflows/ansi-conformance.yml'):
    entries['source/'+name]=subprocess.check_output(['git','show',source+':'+name],cwd=work)
for p in base.rglob('*'):
    if p.is_file():entries[p.relative_to(base).as_posix()]=p.read_bytes()
archive=work/'research/bell-active-close.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(entries.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path'] and sha(tar.extractfile(member).read())==record['raw_sha256']
manifest=dict(fixture_source=source,run=43724456785,conclusion='failure',artifact_id=artifact['id'],image_provenance=provenance,
    failure='Closing the selected tab in an unfocused GDI host changes the selected session and issues a FlashWindowEx STOP although the foreground remains the other application.',
    scope='Diagnostic-only image reuse from a failed overall job; it does not accept that job or image. DirectX and focus-protocol bytes were not reached in this run.',
    image_retained_in='research/bell-lifecycle-native.tar.gz',
    bundle=dict(path=archive.relative_to(work).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),records=records))
(work/'research/bell-active-close-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Retained',len(records),'records,',archive.stat().st_size,'bytes')
