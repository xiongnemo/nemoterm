import gzip,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
ci=root/'build/ci-sixel-palette-e436ecd'
exe=ci/'product/nemoterm.exe'
sha=hashlib.sha256(exe.read_bytes()).hexdigest()
validation=ci/'single-evidence/build/single-exe-check/research/single-exe-validation.json'
v=json.loads(validation.read_text());assert sha==v['executable_sha256'] and len(v['passed_checks'])==105
files=[ci/n for n in ['core-run.json','core-artifacts.json','single-run.json','single-artifacts.json']]
files += [validation,validation.with_name('single-exe-observed.json')]
files += [validation.with_name(f'sixel-palette-{m}-observed.json') for m in ['gdi','opengl','directx']]
local=root/'build/ci-palette-local'
for p in local.rglob('*'):
    if not p.is_file() or any(n in p.relative_to(local).parts for n in ['dist','tests','tools','__pycache__']):continue
    if p.suffix in ['.json','.log','.bmp','.png']:files.append(p)
files += [root/'build/check-ci-palette-image.py',root/'build/watch-sixel-palette-ci.py',Path(__file__)]
dest=root/'research/sixel-palette-ci-records';dest.mkdir(exist_ok=False);records=[]
for p in sorted(set(files)):
    data=p.read_bytes();archive=dest/f'{len(records):03d}-{p.name}.gz';archive.write_bytes(gzip.compress(data,mtime=0))
    records.append(dict(path=str(p.relative_to(root)).replace('\\','/'),archive=str(archive.relative_to(root)).replace('\\','/'),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
manifest=dict(source='e436ecdad1a81e570e409c2bc856d77f4d098c45',image_sha256=sha,image_bytes=exe.stat().st_size,
    kind='CI and local owned Win32 observations, not REA-server Evidence',records=records)
(root/'research/sixel-palette-ci-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
for r in records:
    data=gzip.decompress((root/r['archive']).read_bytes());assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
print('Verified',len(records),'records;',sum((root/r['archive']).stat().st_size for r in records),'compressed bytes')
