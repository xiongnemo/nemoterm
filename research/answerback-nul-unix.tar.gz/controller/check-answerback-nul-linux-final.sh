#!/bin/sh
set -eu
compiler=$1
case "$compiler" in gcc|clang) ;; *) exit 2;; esac
root=/mnt/c/Users/nemo/Documents/Projects/nemoterm
source="$root/build/gdi-dense-memory-worktree"
evidence="$root/build/answerback-nul-linux-$compiler-03"
mkdir "$evidence"
build=$(cat "$root/build/answerback-nul-linux-$compiler-02/build-directory.txt")
printf '%s\n' "$build" > "$evidence/build-directory.txt"
GIT_DIR="$root/.git/worktrees/gdi-dense-memory-worktree"
GIT_WORK_TREE="$source"
export GIT_DIR GIT_WORK_TREE
"$compiler" --version > "$evidence/compiler.txt"
git -C "$source" rev-parse HEAD > "$evidence/base-source.txt"
git -C "$source" diff -- vendor/putty-0.85/unix/unicode.c > "$evidence/source.diff"
sha256sum "$source/vendor/putty-0.85/unix/unicode.c" "$source/vendor/putty-0.85/utils/ctrlparse.c" "$source/vendor/putty-0.85/test/test_queries.c" > "$evidence/sources.sha256"
cmake --build "$build" --target test_queries test_ansi_terminal test_keyboard test_state_control --parallel 4 > "$evidence/build.log" 2>&1
for target in test_queries test_ansi_terminal test_keyboard test_state_control; do
    ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1 timeout 120 "$build/$target" > "$evidence/$target.log" 2>&1
    printf '%s %s passed\n' "$compiler" "$target"
done
