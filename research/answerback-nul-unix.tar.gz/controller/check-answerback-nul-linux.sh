#!/bin/sh
set -eu
compiler=$1
case "$compiler" in gcc|clang) ;; *) exit 2;; esac
root=/mnt/c/Users/nemo/Documents/Projects/nemoterm
source="$root/build/gdi-dense-memory-worktree"
evidence="$root/build/answerback-nul-linux-$compiler-02"
mkdir "$evidence"
build=$(mktemp -d "/tmp/nemoterm-answerback-$compiler-XXXXXX")
printf '%s\n' "$build" > "$evidence/build-directory.txt"
"$compiler" --version > "$evidence/compiler.txt"
GIT_DIR="$root/.git/worktrees/gdi-dense-memory-worktree"
GIT_WORK_TREE="$source"
export GIT_DIR GIT_WORK_TREE
git -C "$source" rev-parse HEAD > "$evidence/base-source.txt"
git -C "$source" diff -- vendor/putty-0.85/unix/unicode.c vendor/putty-0.85/utils/ctrlparse.c vendor/putty-0.85/test/test_queries.c > "$evidence/source.diff" 2> "$evidence/git-diff-stderr.log"
sha256sum "$source/vendor/putty-0.85/unix/unicode.c" "$source/vendor/putty-0.85/utils/ctrlparse.c" "$source/vendor/putty-0.85/test/test_queries.c" > "$evidence/sources.sha256"
cmake -S "$source/vendor/putty-0.85" -B "$build" -G Ninja -DCMAKE_C_COMPILER="$compiler" -DPUTTY_GTK_VERSION=NONE -DPUTTY_GSSAPI=OFF '-DCMAKE_C_FLAGS=-g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer' '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined' > "$evidence/configure.log" 2>&1
cmake --build "$build" --target test_queries test_terminal test_keyboard test_state_control --parallel 4 > "$evidence/build.log" 2>&1
for target in test_queries test_terminal test_keyboard test_state_control; do
    ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1 timeout 120 "$build/$target" > "$evidence/$target.log" 2>&1
    printf '%s %s passed\n' "$compiler" "$target"
done
