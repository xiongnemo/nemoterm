from pathlib import Path
import hashlib,json,tarfile
root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
ci=root/'build/ci-answerback-config-23c90fe'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
run=load(ci/'ansi-components-run.json')
assert run['headSha']=='23c90fe3eb54d21b0d8c128c2d2a41090095b6d4' and run['conclusion']=='failure'
jobs={j['name']:j['conclusion'] for j in run['jobs']}
assert jobs['linux (gcc)']==jobs['linux (clang)']=='failure' and jobs['msvc']=='success'
for compiler in ('gcc','clang'):
    assert (ci/'ansi-components'/compiler/'test_queries.log').read_text().strip()=='FATAL ERROR: Out of memory'
    final=root/'build'/('answerback-nul-linux-'+compiler+'-03')
    assert (final/'base-source.txt').read_text().strip()==run['headSha']
    checksums=(final/'sources.sha256').read_text().splitlines()
    assert checksums[0].split()[0]==sha(work/'vendor/putty-0.85/unix/unicode.c')
    for test,ending in [('test_queries','Query suite passed'),('test_ansi_terminal','ANSI bytewise: 243 unchanged XTerm streams, 0 failures'),
                        ('test_keyboard','Keyboard protocol suite passed'),('test_state_control','State control suite passed')]:
        text=(final/(test+'.log')).read_text()
        assert ending in text,(compiler,test,text[-300:])
        assert 'ERROR: AddressSanitizer' not in text and 'runtime error:' not in text
files=[]
def add(p,name):files.append(dict(path=name,source=p,bytes=p.stat().st_size,sha256=sha(p)))
for p in (ci/'ansi-components').rglob('*'):
    if p.is_file():add(p,'original-ci/'+p.relative_to(ci).as_posix())
for name in ('ansi-components-run.json','ansi-components-artifacts.json'):add(ci/name,'original-ci/'+name)
for compiler in ('gcc','clang'):
    for attempt in ('01','02','03'):
        directory=root/'build'/('answerback-nul-linux-'+compiler+'-'+attempt)
        for p in directory.iterdir():
            if p.is_file():add(p,'local/'+directory.name+'/'+p.name)
for name in ('vendor/putty-0.85/unix/unicode.c','vendor/putty-0.85/utils/ctrlparse.c','vendor/putty-0.85/test/test_queries.c'):
    add(work/name,'source/'+name)
for name in ('check-answerback-nul-linux.sh','check-answerback-nul-linux-resume.sh','check-answerback-nul-linux-final.sh','retain-answerback-nul.py'):
    add(root/'build'/name,'controller/'+name)
archive=work/'research/answerback-nul-unix.tar.gz';assert not archive.exists()
with tarfile.open(archive,'x:gz') as tar:
    for record in files:tar.add(record['source'],arcname=record['path'],recursive=False)
validation=dict(completed=True,scope='Unix conversion-loop repair and unchanged binary-answerback regression; Windows and complete product acceptance are separate.',
    failed_component_run=43755825392,base_source=run['headSha'],
    original_result=dict(gcc='FATAL ERROR: Out of memory',clang='FATAL ERROR: Out of memory',msvc='Query suite passed'),
    local_compilers=['gcc','clang'],sanitizers=['address','undefined'],local_suites_per_compiler=4,
    final_source_sha256=sha(work/'vendor/putty-0.85/unix/unicode.c'),
    setup_failures='Local attempt 01 stopped at a Windows-form worktree git path; attempt 02 initially named the Windows-only test_terminal target. Existing configurations were resumed with verified Unix targets; failed preparation/build records are preserved.',
    intermediate_variant='Attempt 02 used a one-byte NUL step; final attempt 03 consumes through the NUL byte including any preceding shift sequence.',
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),
    files=[{k:v for k,v in r.items() if k!='source'} for r in files])
(work/'research/answerback-nul-unix-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps({k:v for k,v in validation.items() if k!='files'},indent=2))
