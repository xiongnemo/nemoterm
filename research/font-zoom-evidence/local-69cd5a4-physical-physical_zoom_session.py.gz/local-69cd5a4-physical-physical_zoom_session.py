"""Owned fixture for Sky input; never injects keyboard or mouse itself."""
from native_test_utils import *
from protocol_oracle_window import saved_profile
from owned_job import OwnedJob
import re

folder=root/'build/physical-zoom';folder.mkdir(parents=True,exist_ok=True)
report,control=folder/'report.json',folder/'control.json'
record=folder/'observed.json'
exe=(root/'dist/nemoterm.exe').resolve()
action=sys.argv[1]
if action=='start':
    evidence=dict(executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),
        input_method='Sky scoped SendInput',memory_acceptance=False,checks=[])
    profile=dict(NemoRenderer=0,NemoTabs=0,WarnOnClose=0,TrueColour=1,FontHeight=12,
        LockSize=0,NemoZoomModifiers=2,NemoZoomInBinding=0x37a,NemoZoomOutBinding=0x37b,NemoZoomResetBinding=0x379)
    with saved_profile(profile) as args,OwnedJob() as job:
        process=job.spawn([str(exe),'--automation',*args,'--cols','80','--rows','24',
            '--font','SarasaTermSC Nerd Font Light','-e',sys.executable,
            str(root/'tests/mouse_fixture.py'),str(report),str(control),'300'],
            env=dict(os.environ,NEMOTERM_CONPTY='bundled',NEMOTERM_TEST_EXACT_OUTPUT='1',
                     NEMOTERM_TEST_UTF8_INPUT='1'),creationflags=subprocess.CREATE_NO_WINDOW)
        evidence['pid']=process.pid;write_snapshot(record,evidence)
        try:
            wait_for(lambda:read_snapshot(report))
            write_snapshot(control,dict(phase='initial',sequence='\x1b]2;Nemoterm physical zoom test\x07'
                '\x1b[2J\x1b[HPhysical input fixture\r\nSarasa font: M e\u0301 \u4e2d\u6587'
                '\r\nCtrl+Shift+F11 larger / F12 smaller / F10 reset\x1b[16t\x1b[18t\x1b[5n'))
            wait_for(lambda:read_snapshot(report).get('phase')=='initial')
            print(json.dumps(dict(pid=process.pid,report=str(report))),flush=True)
            assert process.wait(timeout=320)==0
            evidence=read_snapshot(record);evidence['cleanup']=job.finish(grace=5)
            evidence['natural_exit']=not evidence['cleanup']['terminated_remaining']
            write_snapshot(record,evidence)
        finally:
            cleanup=job.finish(grace=0)
            if cleanup['terminated_remaining']:
                evidence=read_snapshot(record);evidence['cleanup_failure']=cleanup;write_snapshot(record,evidence)
elif action=='measure':
    label=sys.argv[2];before=read_snapshot(report)
    seq='\x1b[?1000;1006h' if '--mouse' in sys.argv else ''
    write_snapshot(control,dict(phase=label,preserve_mouse=True,sequence=seq+'\x1b[16t\x1b[18t\x1b[5n'))
    current=wait_snapshot(lambda:read_snapshot(report),lambda a:a.get('phase')==label and bytes.fromhex(a.get('hex','')).endswith(b'\x1b[0n'))
    match=re.fullmatch(rb'\x1b\[6;(\d+);(\d+)t\x1b\[8;(\d+);(\d+)t\x1b\[0n',bytes.fromhex(current['hex']))
    assert match,current
    ch,cw,rows,cols=map(int,match.groups())
    check=dict(label=label,cell=[cw,ch],grid=[cols,rows],before=before,query=current)
    evidence=read_snapshot(record);evidence['checks'].append(check);write_snapshot(record,evidence)
    print(json.dumps(check))
elif action=='stop':write_snapshot(control,dict(stop=True))
else:raise SystemExit(action)
