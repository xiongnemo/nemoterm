/* Only the fixture-owned host's leave tracking is simulated. The controller
 * sends WM_MOUSEMOVE / WM_MOUSELEAVE explicitly; no system cursor is moved. */
const trackAddress=Process.getModuleByName('user32.dll').getExportByName('TrackMouseEvent');
const originalTrack=new NativeFunction(trackAddress,'int',['pointer']);
Interceptor.replace(trackAddress,new NativeCallback(function(event) {
    if (event.add(8).readPointer().equals(ownedHost)) return 1;
    return originalTrack(event);
},'int',['pointer']));

const events=[];
const getProc=new NativeFunction(Process.getModuleByName('user32.dll').getExportByName('GetWindowLongPtrW'),'pointer',['pointer','int']);
Interceptor.attach(getProc(ownedHost,-4),{
    onEnter(args) {
        if (!args[0].equals(ownedHost)) return;
        const msg=args[1].toUInt32();
        if ([0x200,0x2a3,0x113,0x5,0x6].includes(msg)) {
            events.push({msg,wp:args[2].toUInt32(),lp:args[3].toInt32(),ms:Date.now()});
            if(events.length>256)events.shift();
        }
    }
});
rpc.exports.events=()=>events;
