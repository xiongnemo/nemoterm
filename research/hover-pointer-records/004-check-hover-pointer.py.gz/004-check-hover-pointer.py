from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];project=root.parents[1]
base=root/'build/hover-pointer';base.mkdir()
exe=project/'build/iterm-images-worktree/build/ci-iterm-3187ec5/product/nemoterm.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='8e52b517787fb508937611b15eb48855ab0e73521978f579d853cf48d9748585'
fixture=(root/'tests/tabs_window_smoke.py').read_text()
needle='            x,y=position(0);u.SendMessageW(host,0x200,0,x|(y<<16))'
assert fixture.count(needle)==1
fixture=fixture.replace(needle,needle+'\n            assert u.PostMessageW(host,0x200,0,0x7fff7fff)  # Controlled queued interference, owned host only.')
cases=[('before','directx','left',False)]+[(r+'-'+side,r,side,True) for r,side in [('directx','left'),('gdi','top'),('opengl','bottom'),('directx','right')]]
results=[]
for name,renderer,side,fixed in cases:
    dest=base/name
    for directory in ('dist','research','build','tools'):(dest/directory).mkdir(parents=True)
    shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
    (dest/'tests/tabs_window_smoke.py').write_text(fixture,encoding='utf-8')
    if not fixed:
        probe=dest/'tests/tabs_hover_probe.js';text=probe.read_text()
        assert text.count('const ignored=(flags&7)===0;')==1
        probe.write_text(text.replace('const ignored=(flags&7)===0;','const ignored=false; // Observe original queued mouse behavior.'))
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(exe,dest/'dist/nemoterm.exe')
    with (dest/'controller.log').open('w') as log:
        run=subprocess.run([sys.executable,str(project/'build/rtl-worktree/build/run-owned-check.py'),str(dest),'tabs','--renderer',renderer,'--side',side],stdout=log,stderr=subprocess.STDOUT)
    observed=dest/f'research/tabs-{renderer}-{side}-observed.json'
    d=json.loads(observed.read_text()) if observed.exists() else {}
    record=dict(name=name,exit_code=run.returncode,completed=d.get('completed'),checks=len(d.get('checks',[])),hover=d.get('hover_observations'),error=d.get('error'))
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps({k:v for k,v in record.items() if k!='hover'}),flush=True)
    if not fixed:
        assert run.returncode==1 and len(d['checks'])==4 and 'Timed out' in d['error']
        assert any(e['msg']==0x200 and e['flags']==0 and e['lp']==0x7fff7fff for e in d['hover_observations']['events'])
    else:
        if run.returncode:print((dest/'controller.log').read_text()[-2800:]);raise SystemExit(run.returncode)
        assert d['hover_observations']['ignored'] and not d['owned_job_cleanup']['terminated_remaining']
