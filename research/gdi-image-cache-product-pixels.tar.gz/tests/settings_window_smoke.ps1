param([switch]$TabHost)
# Exercise the real startup settings dialog, save/load and local-session launch.
# UI Automation is scoped to a new process; no global mouse or keyboard input.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class ShellSettingsNative {
    private delegate bool EnumChildProc(IntPtr hwnd, IntPtr data);
    [DllImport("user32.dll")] private static extern bool EnumWindows(EnumChildProc callback, IntPtr data);
    [DllImport("user32.dll")] private static extern bool EnumChildWindows(IntPtr hwnd, EnumChildProc callback, IntPtr data);
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] private static extern int GetClassNameW(IntPtr hwnd, System.Text.StringBuilder name, int capacity);
    public static IntPtr Terminal(int pid, bool tabbed) {
        IntPtr found=IntPtr.Zero;
        EnumWindows((hwnd,data)=> {
            uint owner; GetWindowThreadProcessId(hwnd,out owner);
            if (owner!=(uint)pid) return true;
            if (tabbed) {
                var name=new System.Text.StringBuilder(128);
                GetClassNameW(hwnd,name,name.Capacity);
                if (name.ToString()=="NemotermHost") found=Content(hwnd);
            } else if (GetPropW(hwnd,"NemotermRenderer")!=IntPtr.Zero) found=hwnd;
            return found==IntPtr.Zero;
        },IntPtr.Zero);
        return found;
    }
    public static IntPtr Content(IntPtr host) {
        IntPtr found=IntPtr.Zero;
        EnumChildWindows(host,(hwnd,data)=> {
            if (GetPropW(hwnd,"NemotermRenderer")!=IntPtr.Zero) {found=hwnd;return false;}
            return true;
        },IntPtr.Zero);
        return found;
    }
    [DllImport("user32.dll")] public static extern IntPtr SendMessageW(IntPtr hwnd, uint msg, IntPtr wp, IntPtr lp);
    [DllImport("user32.dll")] public static extern IntPtr GetParent(IntPtr hwnd);
    [DllImport("user32.dll")] public static extern int GetDlgCtrlID(IntPtr hwnd);
    [DllImport("user32.dll")] public static extern bool PostMessageW(IntPtr hwnd, uint msg, IntPtr wp, IntPtr lp);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern IntPtr GetPropW(IntPtr hwnd, string name);
    [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr hwnd);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    public static extern bool MoveFileExW(string source, string destination, uint flags);
    public static System.Threading.Thread HoldSnapshotReader(string path) {
        var reader=new System.IO.FileStream(path,System.IO.FileMode.Open,
            System.IO.FileAccess.Read,System.IO.FileShare.ReadWrite);
        var thread=new System.Threading.Thread(()=> {
            try {System.Threading.Thread.Sleep(100);} finally {reader.Dispose();}
        });
        thread.IsBackground=true;thread.Start();return thread;
    }
}
'@
$root = Split-Path $PSScriptRoot -Parent
$exe = Join-Path $root 'dist/nemoterm.exe'
if ($env:NEMOTERM_TEST_EXE) { $exe = $env:NEMOTERM_TEST_EXE }
$python = (Get-Command python.exe -ErrorAction Stop).Source
$fixtureProfile = 'settings-test-' + [Guid]::NewGuid().ToString('N')
$profilePath = 'HKCU:\Software\Nemo\Nemoterm\Sessions\' + $fixtureProfile
$directory = Join-Path ([IO.Path]::GetTempPath()) $fixtureProfile
New-Item -ItemType Directory -Path $directory | Out-Null
$report = Join-Path $directory 'report.json'
$controlFile = Join-Path $directory 'control.json'
$app = $null
$scope = [System.Windows.Automation.TreeScope]::Descendants

function Wait-Value([scriptblock]$Read) {
    $deadline = [DateTime]::UtcNow.AddSeconds(8)
    do {
        $value = & $Read
        if ($value) { return $value }
        Start-Sleep -Milliseconds 30
    } while ([DateTime]::UtcNow -lt $deadline)
    throw 'Timed out waiting for owned settings fixture'
}
function Find-Name($parent, [string]$name, [string]$class = '') {
    $condition = New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::NameProperty, $name)
    if ($class) {
        $condition = New-Object System.Windows.Automation.AndCondition($condition,
            (New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ClassNameProperty, $class)))
    }
    return $parent.FindFirst($scope, $condition)
}
function Dialog($process) {
    $condition = New-Object System.Windows.Automation.AndCondition(
        (New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ProcessIdProperty, $process.Id)),
        (New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ClassNameProperty, 'PuTTYConfigBox')))
    return Wait-Value {
        if ($process.HasExited) { throw "Settings exited before opening: $($process.ExitCode)" }
        [System.Windows.Automation.AutomationElement]::RootElement.FindFirst([System.Windows.Automation.TreeScope]::Children, $condition)
    }
}
function Select-Node($dialog, [string]$name) {
    $node = Wait-Value { Find-Name $dialog $name }
    $node.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern).Select()
    try {
        Wait-Value { $node.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern).Current.IsSelected } | Out-Null
    } catch {
        $nativeCheck=[ShellSettingsNative]::SendMessageW([IntPtr]$node.Current.NativeWindowHandle,0xF0,[IntPtr]::Zero,[IntPtr]::Zero).ToInt32()
        Write-Output "Selection did not settle: $name; class=$($node.Current.ClassName); native-check=$nativeCheck"
        throw
    }
    return $node
}
function Invoke-Button($dialog, [string]$name) {
    $button = Wait-Value { Find-Name $dialog $name }
    $button.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
}
function Write-Control($value) {
    $temporary = $controlFile + '.tmp'
    [IO.File]::WriteAllText($temporary, ($value | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding($false)))
    # Match fixture_io.py: replacement must remain atomic while the child
    # briefly holds a read handle. Move-Item -Force is not an atomic replace.
    $deadline=[DateTime]::UtcNow.AddSeconds(2)
    while (![ShellSettingsNative]::MoveFileExW($temporary,$controlFile,1)) {
        $errorCode=[Runtime.InteropServices.Marshal]::GetLastWin32Error()
        if ($errorCode -notin @(5,32,33) -or [DateTime]::UtcNow -ge $deadline) {
            throw (New-Object ComponentModel.Win32Exception($errorCode))
        }
        Start-Sleep -Milliseconds 10
    }
}
function Check-Grapheme([string]$phase, [string]$prefix, [bool]$enabled) {
    $esc=[string][char]27
    $tech=[char]::ConvertFromUtf32(0x1f469)+[char]0x200d+[char]::ConvertFromUtf32(0x1f4bb)
    Write-Control @{phase=$phase;sequence=($prefix+$esc+'[2J'+$esc+'[H'+$tech+$esc+'[6n'+$esc+'[?2027$p')}
    $expected=if ($enabled) {'1b5b313b33521b5b3f323032373b312479'} else {'1b5b313b35521b5b3f323032373b322479'}
    $reply=Wait-Value {
        if (Test-Path -LiteralPath $report) {
            $value=Get-Content -LiteralPath $report -Raw | ConvertFrom-Json
            if ($value.error) {throw $value.error}
            if ($value.phase -eq $phase -and $value.hex -eq $expected) {$value}
        }
    }
    return @{phase=$phase;enabled=$enabled;reply=$reply.hex}
}
function Set-GraphemePreference([bool]$enabled) {
    [ShellSettingsNative]::PostMessageW($termHandle,0x111,[IntPtr]0x50,[IntPtr]::Zero) | Out-Null
    $dialog=Dialog $app
    $node=Find-Name $dialog 'Window'
    $node.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand()
    Select-Node $dialog 'Translation' | Out-Null
    $preferenceControl=Wait-Value {Find-Name $dialog $graphemeLabel}
    $toggle=$preferenceControl.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
    $current=$toggle.Current.ToggleState -eq [System.Windows.Automation.ToggleState]::On
    if ($current -ne $enabled) {$toggle.Toggle()}
    $handle=[IntPtr]$dialog.Current.NativeWindowHandle
    Invoke-Button $dialog 'Apply'
    Wait-Value {![ShellSettingsNative]::IsWindow($handle)} | Out-Null
}
function Binding-Controls($dialog, $expected, [string]$page = 'Bindings') {
    $bindingNode = Select-Node $dialog 'Bindings'
    if ($page -ne 'Bindings') {
        $bindingNode.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand()
        Select-Node $dialog $page | Out-Null
    }
    $combos = $dialog.FindAll($scope, (New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ControlTypeProperty, [System.Windows.Automation.ControlType]::ComboBox)))
    if ($combos.Count -ne $expected.Count) { throw 'Missing binding controls' }
    for ($i=0; $i -lt $expected.Count; $i++) {
        $combo=$combos[$i]
        if ($combo.Current.IsOffscreen -or !$dialog.Current.BoundingRectangle.Contains($combo.Current.BoundingRectangle)) { throw 'Binding control clipped' }
        $selected=[ShellSettingsNative]::SendMessageW([IntPtr]$combo.Current.NativeWindowHandle,0x147,[IntPtr]::Zero,[IntPtr]::Zero).ToInt32()
        if ($selected -ne $expected[$i]) { throw "Binding $i expected $($expected[$i]), got $selected" }
    }
    return ,$combos
}
function Set-Combo($combo, [int]$index) {
    $handle=[IntPtr]$combo.Current.NativeWindowHandle
    [ShellSettingsNative]::SendMessageW($handle,0x14E,[IntPtr]$index,[IntPtr]::Zero) | Out-Null
    $id=[ShellSettingsNative]::GetDlgCtrlID($handle)
    [ShellSettingsNative]::SendMessageW([ShellSettingsNative]::GetParent($handle),0x111,[IntPtr]($id -bor (1 -shl 16)),$handle) | Out-Null
}
function Check-HyperlinkControls($dialog) {
    $terminal=Wait-Value { Find-Name $dialog 'Terminal' }
    $terminal.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand()
    Select-Node $terminal 'Hyperlinks' | Out-Null
    foreach ($label in @('Disable OSC 8 hyperlinks','Allow registered custom URI schemes')) {
        $control=Wait-Value { Find-Name $dialog $label }
        if ($control.Current.IsOffscreen -or !$dialog.Current.BoundingRectangle.Contains($control.Current.BoundingRectangle)) {
            throw 'Hyperlink option clipped or missing'
        }
        if ($control.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern).Current.ToggleState -ne [System.Windows.Automation.ToggleState]::Off) {
            throw 'Unexpected hyperlink preference'
        }
    }
}
function Selection-Colour-Controls($dialog) {
    $window=Wait-Value { Find-Name $dialog 'Window' }
    $window.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand()
    $selection=Select-Node $dialog 'Selection'
    $selection.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand()
    # Scope this lookup to Selection: Window also has a separate Colours page.
    Select-Node $selection 'Colours' | Out-Null
    $background=Wait-Value { Find-Name $dialog 'Use custom background colour' }
    $text=Wait-Value { Find-Name $dialog 'Use custom text colour' }
    $condition=New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ClassNameProperty,'Edit')
    $edits=@($dialog.FindAll($scope,$condition) | Sort-Object { $_.Current.BoundingRectangle.Top }, { $_.Current.BoundingRectangle.Left })
    if ($edits.Count -ne 6) { throw 'Expected six selection RGB fields' }
    foreach ($control in @($background,$text)+( $edits )+@(
        (Find-Name $dialog 'Choose background colour...'),(Find-Name $dialog 'Choose text colour...'))) {
        if (!$control -or $control.Current.IsOffscreen -or
            !$dialog.Current.BoundingRectangle.Contains($control.Current.BoundingRectangle)) {
            throw 'Selection colour control clipped or missing'
        }
    }
    return @{background=$background;text=$text;edits=$edits}
}
function Attribute-Colour-Controls($dialog) {
    $window=Wait-Value { Find-Name $dialog 'Window' }
    $window.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand()
    $nameCondition=New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::NameProperty,'Colours')
    $colours=$window.FindFirst([System.Windows.Automation.TreeScope]::Children,$nameCondition)
    if (!$colours) { throw 'Window Colours tree item missing' }
    $colours.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand()
    Select-Node $colours 'Attributes' | Out-Null
    $combos=$dialog.FindAll($scope,(New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ControlTypeProperty,[System.Windows.Automation.ControlType]::ComboBox)))
    if ($combos.Count -ne 1) { throw 'Expected one attribute selector' }
    $condition=New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ClassNameProperty,'Edit')
    $edits=@($dialog.FindAll($scope,$condition) | Sort-Object { $_.Current.BoundingRectangle.Left })
    if ($edits.Count -ne 3) { throw 'Expected three attribute RGB fields' }
    $flags=@('Use colour for this attribute','Use a custom attribute colour','Keep its original text style','Override application text colours') | ForEach-Object { Find-Name $dialog $_ }
    foreach ($control in @($combos[0])+$edits+$flags+@((Find-Name $dialog 'Choose attribute colour...'))) {
        if (!$control -or $control.Current.IsOffscreen -or !$dialog.Current.BoundingRectangle.Contains($control.Current.BoundingRectangle)) { throw 'Attribute colour control clipped or missing' }
    }
    return @{selector=$combos[0];edits=$edits;flags=$flags}
}
function Check-AttributeColours([string]$phase,[string]$prefix,[string[]]$colours) {
    $esc=[string][char]27; $bel=[string][char]7
    Write-Control @{phase=$phase;sequence=($prefix+$esc+']5;0;?;1;?;2;?;3;?;4;?'+$bel)}
    $expected=''
    for ($i=0;$i -lt 5;$i++) { $expected+=$esc+']5;'+$i+';rgb:'+$colours[$i]+$bel }
    $hex=-join ([Text.Encoding]::UTF8.GetBytes($expected) | ForEach-Object { $_.ToString('x2') })
    $reply=Wait-Value {
        if (Test-Path -LiteralPath $report) {
            $value=Get-Content -LiteralPath $report -Raw | ConvertFrom-Json
            if ($value.error) { throw $value.error }
            if ($value.phase -eq $phase -and $value.hex -eq $hex) { $value }
        }
    }
    return @{phase=$phase;reply=$reply.hex}
}
function Check-SelectionColours([string]$phase,[string]$prefix,[string]$background,[string]$foreground) {
    $esc=[string][char]27
    $bel=[string][char]7
    Write-Control @{phase=$phase;sequence=($prefix+$esc+']17;?;;?'+$bel)}
    $expected=$esc+']17;rgb:'+$background+$bel+$esc+']19;rgb:'+$foreground+$bel
    $expectedHex=-join ([Text.Encoding]::UTF8.GetBytes($expected) | ForEach-Object { $_.ToString('x2') })
    $reply=Wait-Value {
        if (Test-Path -LiteralPath $report) {
            $value=Get-Content -LiteralPath $report -Raw | ConvertFrom-Json
            if ($value.error) { throw $value.error }
            if ($value.phase -eq $phase -and $value.hex -eq $expectedHex) { $value }
        }
    }
    return @{phase=$phase;reply=$reply.hex}
}
try {
    Write-Control @{phase='atomic-before'}
    $heldReader=[ShellSettingsNative]::HoldSnapshotReader($controlFile)
    Write-Control @{phase='atomic-after'}
    $heldReader.Join()
    if ((Get-Content -LiteralPath $controlFile -Raw | ConvertFrom-Json).phase -ne 'atomic-after') {throw 'Owned control snapshot replacement failed'}
    New-Item -Path $profilePath -Force | Out-Null
    New-ItemProperty -Path $profilePath -Name WarnOnClose -Value 0 -PropertyType DWord | Out-Null
    # This is the visible GUI under test, not a background helper. Hidden
    # startup also hides the modal dialog from the UI Automation tree.
    $app = Start-Process -FilePath $exe -ArgumentList @('-load', $fixtureProfile, '--settings') -PassThru
    $dialog = Dialog $app
    foreach ($name in @('Terminal', 'Keyboard')) {
        $node = Wait-Value { Find-Name $dialog $name }
        $node.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand()
    }
    Check-HyperlinkControls $dialog
    Select-Node $dialog 'Screen queries' | Out-Null
    $checksumLabel = 'Allow applications to query screen checksums'
    $checksum = Wait-Value { Find-Name $dialog $checksumLabel }
    if ($checksum.Current.IsOffscreen -or !$dialog.Current.BoundingRectangle.Contains($checksum.Current.BoundingRectangle)) {
        throw 'Screen checksum control clipped'
    }
    $checksumToggle = $checksum.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
    if ($checksumToggle.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::Off) { throw 'Screen checksum queries enabled by default' }
    $checksumToggle.Toggle()
    Select-Node $dialog 'Extended' | Out-Null
    Select-Node $dialog 'All keys' | Out-Null
    Select-Node $dialog 'CSI-u' | Out-Null
    $win32Label = 'Preserve Windows key events (experimental)'
    $win32 = Wait-Value { Find-Name $dialog $win32Label }
    $win32Toggle = $win32.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
    if ($win32Toggle.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::Off) { throw 'Experimental Win32 input was enabled by default' }
    $win32Toggle.Toggle()
    # All visible controls must remain within the fixed-height dialog.
    $bounds = $dialog.Current.BoundingRectangle
    if ($win32.Current.IsOffscreen -or !$bounds.Contains($win32.Current.BoundingRectangle)) { throw 'Win32 input option clipped' }
    foreach ($name in @('Off', 'Compatible', 'Modified keys', 'All keys', 'xterm (27~)', 'CSI-u')) {
        $node = Find-Name $dialog $name
        if (!$node -or $node.Current.IsOffscreen -or !$bounds.Contains($node.Current.BoundingRectangle)) {
            throw "Clipped or missing setting: $name"
        }
        $selected = $node.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern).Current.IsSelected
        if ($selected -ne ($name -in @('All keys', 'CSI-u'))) { throw "Incorrect radio selection: $name" }
    }
    python "$PSScriptRoot/settings_capture.py" $app.Id $dialog.Current.NativeWindowHandle
    if ($LASTEXITCODE) { throw 'Owned settings capture failed' }
    $windowNode = Find-Name $dialog 'Window'
    $windowNode.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand()
    Select-Node $dialog 'Window' | Out-Null
    $reflowLabel = 'Reflow main-screen text when columns change'
    $reflow = Wait-Value { Find-Name $dialog $reflowLabel }
    if ($reflow.Current.IsOffscreen -or !$bounds.Contains($reflow.Current.BoundingRectangle)) { throw 'Reflow option clipped' }
    $toggle = $reflow.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
    if ($toggle.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::On) { throw 'Reflow was not enabled by default' }
    $toggle.Toggle()
    $columns=Find-Name $dialog 'Columns' 'Edit'
    $rows=Find-Name $dialog 'Rows' 'Edit'
    if ($columns.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value -ne '160' -or
        $rows.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value -ne '48') { throw 'Default grid was not 160 x 48' }
    Select-Node $dialog 'Translation' | Out-Null
    $graphemeLabel='Use grapheme cluster widths at startup'
    $grapheme=Wait-Value {Find-Name $dialog $graphemeLabel}
    $graphemeToggle=$grapheme.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
    if ($graphemeToggle.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::Off) {throw 'Grapheme startup mode enabled by default'}
    foreach ($translationControl in @($grapheme,(Find-Name $dialog 'Enable VT100 line drawing even in UTF-8 mode'))) {
        if (!$translationControl -or $translationControl.Current.IsOffscreen -or !$bounds.Contains($translationControl.Current.BoundingRectangle)) {throw 'Translation control clipped'}
    }
    $graphemeToggle.Toggle()
    python "$PSScriptRoot/settings_capture.py" $app.Id $dialog.Current.NativeWindowHandle grapheme-settings.png
    if ($LASTEXITCODE) {throw 'Grapheme settings capture failed'}
    $defaultBindings=@(3,3,3,22,0,0,1)
    $customBindings=@(6,24,5,25,3,26,5)
    $combos=Binding-Controls $dialog $defaultBindings
    for ($i=0;$i -lt 7;$i++) { Set-Combo $combos[$i] $customBindings[$i] }
    Binding-Controls $dialog $customBindings | Out-Null
    # A duplicate shortcut opens a modal error. Post only the notification so
    # the test thread can inspect and dismiss that owned modal window.
    Set-Combo $combos[2] 6
    $pasteHandle=[IntPtr]$combos[3].Current.NativeWindowHandle
    [ShellSettingsNative]::SendMessageW($pasteHandle,0x14E,[IntPtr]24,[IntPtr]::Zero) | Out-Null
    $pasteId=[ShellSettingsNative]::GetDlgCtrlID($pasteHandle)
    [ShellSettingsNative]::PostMessageW([ShellSettingsNative]::GetParent($pasteHandle),0x111,[IntPtr]($pasteId -bor (1 -shl 16)),$pasteHandle) | Out-Null
    $errorCondition=New-Object System.Windows.Automation.AndCondition(
        (New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ProcessIdProperty,$app.Id)),
        (New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ClassNameProperty,'#32770')))
    $errorDialog=Wait-Value { $dialog.FindFirst([System.Windows.Automation.TreeScope]::Descendants,$errorCondition) }
    Invoke-Button $errorDialog 'OK'
    Wait-Value { [ShellSettingsNative]::SendMessageW($pasteHandle,0x147,[IntPtr]::Zero,[IntPtr]::Zero).ToInt32() -eq 25 } | Out-Null
    Set-Combo $combos[2] 5
    Invoke-Button $dialog 'Reset bindings'
    $combos=Binding-Controls $dialog $defaultBindings
    for ($i=0;$i -lt 7;$i++) { Set-Combo $combos[$i] $customBindings[$i] }
    python "$PSScriptRoot/settings_capture.py" $app.Id $dialog.Current.NativeWindowHandle bindings-settings.png
    if ($LASTEXITCODE) { throw 'Bindings settings capture failed' }
    $defaultShellBindings=@(0,0,0,0,0,0,0,0)
    $customShellBindings=@(7,45,7,46,7,47,7,48)
    $shellCombos=Binding-Controls $dialog $defaultShellBindings 'Commands'
    for ($i=0;$i -lt 8;$i++) { Set-Combo $shellCombos[$i] $customShellBindings[$i] }
    Binding-Controls $dialog $customShellBindings 'Commands' | Out-Null
    python "$PSScriptRoot/settings_capture.py" $app.Id $dialog.Current.NativeWindowHandle shell-marks-settings.png
    if ($LASTEXITCODE) { throw 'Shell integration settings capture failed' }
    Select-Node $dialog 'Rendering' | Out-Null
    Select-Node $dialog 'Tabs' | Out-Null
    $tabs=Wait-Value { Find-Name $dialog 'Open sessions in tabs' }
    $tabsToggle=$tabs.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
    if ($tabsToggle.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::Off) { throw 'Staged tab host unexpectedly enabled by default' }
    if ($TabHost) { $tabsToggle.Toggle() }
    foreach ($label in @('Open sessions in tabs','Top','Bottom','Left','Right','Preview terminal on hover')) {
        $node=Find-Name $dialog $label
        if (!$node -or $node.Current.IsOffscreen -or !$bounds.Contains($node.Current.BoundingRectangle)) { throw "Clipped tab setting: $label" }
    }
    Select-Node $dialog 'Left' | Out-Null
    $tabBindings=@(3,20,3,23,2,72,3,72)
    $tabCombos=Binding-Controls $dialog $tabBindings 'Tabs'
    foreach ($choice in @(@(4,6),@(5,14),@(6,6),@(7,16))) { Set-Combo $tabCombos[$choice[0]] $choice[1] }
    $tabBindings=@(3,20,3,23,6,14,6,16)
    Binding-Controls $dialog $tabBindings 'Tabs' | Out-Null
    python "$PSScriptRoot/settings_capture.py" $app.Id $dialog.Current.NativeWindowHandle tabs-settings.png
    if ($LASTEXITCODE) { throw 'Tab settings capture failed' }
    Select-Node $dialog 'Rendering' | Out-Null
    if (!(Find-Name $dialog 'GDI (low memory)').GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern).Current.IsSelected) { throw 'GDI was not the default renderer' }
    Select-Node $dialog 'DirectX (GPU composition)' | Out-Null
    python "$PSScriptRoot/settings_capture.py" $app.Id $dialog.Current.NativeWindowHandle rendering-settings.png
    if ($LASTEXITCODE) { throw 'Rendering settings capture failed' }
    $selectionColours=Selection-Colour-Controls $dialog
    foreach ($control in @($selectionColours.background,$selectionColours.text)) {
        if ($control.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern).Current.ToggleState -ne
            [System.Windows.Automation.ToggleState]::Off) { throw 'Selection colours did not default to inverse video' }
    }
    $selectionRGB=@(17,34,51,221,238,255)
    for ($i=0;$i -lt $selectionRGB.Count;$i++) {
        $selectionColours.edits[$i].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue([string]$selectionRGB[$i])
    }
    foreach ($control in @($selectionColours.background,$selectionColours.text)) {
        $toggle=$control.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
        if ($toggle.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::On) { throw 'Editing RGB did not enable the custom selection colour' }
        $toggle.Toggle();$toggle.Toggle()
    }
    python "$PSScriptRoot/settings_capture.py" $app.Id $dialog.Current.NativeWindowHandle selection-colour-settings.png
    if ($LASTEXITCODE) { throw 'Selection colour settings capture failed' }
    $attributes=Attribute-Colour-Controls $dialog
    $attributeRGB=@(@(17,34,51),@(68,85,102),@(119,136,153),@(170,187,204),@(221,238,255))
    for ($index=0;$index -lt 5;$index++) {
        Set-Combo $attributes.selector $index
        foreach ($flag in $attributes.flags) {
            if ($flag.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern).Current.ToggleState -ne [System.Windows.Automation.ToggleState]::Off) { throw 'Attribute options unexpectedly enabled on refresh' }
        }
        for ($channel=0;$channel -lt 3;$channel++) {
            $attributes.edits[$channel].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue([string]$attributeRGB[$index][$channel])
        }
        $custom=$attributes.flags[1].GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
        if ($custom.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::On) { throw 'RGB edit did not enable custom attribute colour' }
        $custom.Toggle();$custom.Toggle()
        if ($index -in @(0,4)) { $attributes.flags[0].GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern).Toggle() }
        if ($index -eq 0) { $attributes.flags[2].GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern).Toggle() }
    }
    $attributes.flags[3].GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern).Toggle()
    Set-Combo $attributes.selector 0
    for ($channel=0;$channel -lt 3;$channel++) {
        if ([int]$attributes.edits[$channel].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value -ne $attributeRGB[0][$channel]) { throw 'Switching attributes lost stored RGB' }
    }
    python "$PSScriptRoot/settings_capture.py" $app.Id $dialog.Current.NativeWindowHandle attribute-colour-settings.png
    if ($LASTEXITCODE) { throw 'Attribute colour settings capture failed' }
    Select-Node $dialog 'Selection' | Out-Null
    $copyOnly = Find-Name $dialog 'Copy only'
    if (!$copyOnly.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern).Current.IsSelected) {
        throw 'Copy only was not the default'
    }
    Select-Node $dialog 'Copy and paste' | Out-Null
    Select-Node $dialog 'Session' | Out-Null
    $chooseShell = Wait-Value { Find-Name $dialog 'Choose shell on startup' }
    if ($chooseShell.Current.IsOffscreen -or !$bounds.Contains($chooseShell.Current.BoundingRectangle)) { throw 'Shell startup option clipped' }
    $chooseShell.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern).Toggle()
    $shellCombo = $dialog.FindFirst($scope, (New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ControlTypeProperty, [System.Windows.Automation.ControlType]::ComboBox)))
    if (!$shellCombo -or $shellCombo.Current.IsOffscreen -or !$bounds.Contains($shellCombo.Current.BoundingRectangle)) { throw 'Shell selector clipped or missing' }
    $shellHandle = [IntPtr]$shellCombo.Current.NativeWindowHandle
    [ShellSettingsNative]::SendMessageW($shellHandle, 0x14E, [IntPtr]4, [IntPtr]::Zero) | Out-Null
    $fixtureShellControlId = [ShellSettingsNative]::GetDlgCtrlID($shellHandle)
    [ShellSettingsNative]::SendMessageW([ShellSettingsNative]::GetParent($shellHandle), 0x111, [IntPtr]($fixtureShellControlId -bor (1 -shl 16)), $shellHandle) | Out-Null
    python "$PSScriptRoot/settings_capture.py" $app.Id $dialog.Current.NativeWindowHandle shell-settings.png
    if ($LASTEXITCODE) { throw 'Shell settings capture failed' }
    $sessionNode = Find-Name $dialog 'Session'
    $sessionNode.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand()
    Select-Node $dialog 'Shell' | Out-Null
    $cwdLabel = 'Starting directory (blank inherits launcher):'
    $inheritLabel = 'Use reported directory for duplicated sessions'
    $cwdEdit = Wait-Value { Find-Name $dialog $cwdLabel 'Edit' }
    $inherit = Wait-Value { Find-Name $dialog $inheritLabel }
    foreach ($node in @($cwdEdit, $inherit)) {
        if ($node.Current.IsOffscreen -or !$bounds.Contains($node.Current.BoundingRectangle)) { throw 'Directory control clipped' }
    }
    $fixtureCwd = Join-Path $directory ('working ' + [char]0x4e2d)
    New-Item -ItemType Directory -Path $fixtureCwd | Out-Null
    $cwdEdit.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue($fixtureCwd)
    $inheritToggle = $inherit.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern)
    if ($inheritToggle.Current.ToggleState -ne [System.Windows.Automation.ToggleState]::On) { throw 'Directory inheritance was not enabled by default' }
    $inheritToggle.Toggle()
    python "$PSScriptRoot/settings_capture.py" $app.Id $dialog.Current.NativeWindowHandle cwd-settings.png
    if ($LASTEXITCODE) { throw 'Directory settings capture failed' }
    Select-Node $dialog 'Session' | Out-Null
    $saved = Wait-Value { Find-Name $dialog 'Saved Sessions' 'Edit' }
    $saved.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue($fixtureProfile)
    Invoke-Button $dialog 'Save'
    if ((Get-ItemProperty -LiteralPath $profilePath).NemoChooseShell -ne 1) { throw 'Shell startup preference was not saved' }
    if ((Get-ItemProperty -LiteralPath $profilePath).NemoShell -ne 'git-bash') { throw 'Selected default shell was not saved' }
    $values = Get-ItemProperty -LiteralPath $profilePath
    if ($values.NemoAttributeCustomColours -ne 31 -or $values.NemoAttributeColourModes -ne 49 -or $values.NemoAttributeKeepStyles -ne 1 -or
        $values.NemoAttributeBoldColour -ne 0x112233 -or $values.NemoAttributeUnderlineColour -ne 0x445566 -or $values.NemoAttributeBlinkColour -ne 0x778899 -or
        $values.NemoAttributeReverseColour -ne 0xaabbcc -or $values.NemoAttributeItalicColour -ne 0xddeeff) { throw 'Attribute colour preferences did not save' }
    if ($values.NemoSelectionBackgroundEnabled -ne 1 -or $values.NemoSelectionForegroundEnabled -ne 1 -or
        $values.NemoSelectionBackground -ne 0x112233 -or $values.NemoSelectionForeground -ne 0xddeeff) {
        throw 'Selection colours were not saved'
    }
    if ($values.NemoAllowChecksum -ne 1) { throw 'Screen checksum preference was not saved' }
    if ($values.NemoGraphemeWidths -ne 1) {throw 'Grapheme startup preference was not saved'}
    if ($values.NemoTabSide -ne 2 -or $values.NemoTabs -ne [int][bool]$TabHost -or
        $values.NemoNextTabBinding -ne 0x64e -or $values.NemoPreviousTabBinding -ne 0x650) { throw 'Tab settings did not save' }
    if ($values.NemoCopyBinding -ne 0x658 -or $values.NemoPasteBinding -ne 0x559 -or
        $values.NemoCopyPasteBinding -ne 0x35a -or $values.NemoRectangleModifiers -ne 6 -or
        $values.NemoRenderer -ne 2) { throw 'Bindings or renderer did not save' }
    if ($values.NemoPreviousPromptBinding -ne 0x778 -or $values.NemoNextPromptBinding -ne 0x779 -or
        $values.NemoSelectCommandBinding -ne 0x77a -or $values.NemoSelectOutputBinding -ne 0x77b) {
        throw 'Shell integration bindings did not save'
    }
    $expectedHex = -join ([Text.Encoding]::UTF8.GetBytes($fixtureCwd) | ForEach-Object { $_.ToString('X2') })
    if ($values.NemoStartingDirectoryUtf8Hex -ne $expectedHex -or $values.NemoInheritDirectory -ne 0) { throw 'Unicode directory settings were not saved' }
    if ($values.NemoModifyOtherKeys -ne 3 -or $values.NemoFormatOtherKeys -ne 1 -or $values.RightClickCopyAndPaste -ne 1 -or $values.NemoReflow -ne 0 -or $values.NemoWin32Input -ne 1) { throw 'Settings were not saved' }
    Invoke-Button $dialog 'Cancel'
    if (!$app.WaitForExit(3000) -or $app.ExitCode -ne 0) { throw 'Settings cancel failed' }

    $app = Start-Process -FilePath $exe -ArgumentList @('-load', $fixtureProfile) -PassThru
    $dialog = Dialog $app
    Invoke-Button $dialog 'Cancel'
    if (!$app.WaitForExit(3000) -or $app.ExitCode -ne 0) { throw 'Automatic startup shell chooser failed' }

    # Windows PowerShell 5 does not interpret `e; construct ESC explicitly.
    Write-Control @{phase='settings-launch';sequence=([char]27 + '[?4m' + [char]27 + '[?4g')}
    $fixture = Join-Path $PSScriptRoot 'mouse_fixture.py'
    # The child remains alive across several modal UIA rounds. Each operation
    # still has its own short deadline; this is only the owned child's ceiling.
    $arguments = @('-load', $fixtureProfile, '--settings', '-e', ('"'+$python+'"'), ('"'+$fixture+'"'), ('"'+$report+'"'), ('"'+$controlFile+'"'), '300')
    $app = Start-Process -FilePath $exe -ArgumentList $arguments -PassThru
    $dialog = Dialog $app
    $reloadedShell = Wait-Value { Find-Name $dialog 'Choose shell on startup' }
    if ($reloadedShell.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern).Current.ToggleState -ne [System.Windows.Automation.ToggleState]::On) { throw 'Shell startup preference did not reload' }
    $shellCombo = $dialog.FindFirst($scope, (New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ControlTypeProperty, [System.Windows.Automation.ControlType]::ComboBox)))
    if ([ShellSettingsNative]::SendMessageW([IntPtr]$shellCombo.Current.NativeWindowHandle, 0x147, [IntPtr]::Zero, [IntPtr]::Zero).ToInt32() -ne 4) { throw 'Selected default shell did not reload' }
    if (Find-Name $dialog 'Connection') { throw 'Local terminal exposed network settings' }
    $sessionNode = Find-Name $dialog 'Session'
    $sessionNode.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand()
    Select-Node $dialog 'Shell' | Out-Null
    $reloadedCwd = Wait-Value { Find-Name $dialog $cwdLabel 'Edit' }
    if ($reloadedCwd.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value -ne $fixtureCwd) { throw 'Unicode directory did not reload' }
    $reloadedInheritance = Wait-Value { Find-Name $dialog $inheritLabel }
    if ($reloadedInheritance.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern).Current.ToggleState -ne [System.Windows.Automation.ToggleState]::Off) { throw 'Directory inheritance did not reload' }
    foreach ($name in @('Terminal', 'Keyboard')) {
        $node = Wait-Value { Find-Name $dialog $name }
        $node.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand()
    }
    Select-Node $dialog 'Extended' | Out-Null
    $reloadedWin32 = Wait-Value { Find-Name $dialog $win32Label }
    if ($reloadedWin32.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern).Current.ToggleState -ne [System.Windows.Automation.ToggleState]::On) { throw 'Win32 preference did not reload' }
    Select-Node $dialog 'Screen queries' | Out-Null
    $reloadedChecksum = Wait-Value { Find-Name $dialog $checksumLabel }
    if ($reloadedChecksum.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern).Current.ToggleState -ne [System.Windows.Automation.ToggleState]::On) { throw 'Screen checksum preference did not reload' }
    Select-Node $dialog 'Window' | Out-Null
    $reloaded = Wait-Value { Find-Name $dialog $reflowLabel }
    if ($reloaded.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern).Current.ToggleState -ne [System.Windows.Automation.ToggleState]::Off) { throw 'Reflow preference did not reload' }
    $windowNode=Find-Name $dialog 'Window'
    $windowNode.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand()
    Select-Node $dialog 'Translation' | Out-Null
    $reloadedGrapheme=Wait-Value {Find-Name $dialog $graphemeLabel}
    if ($reloadedGrapheme.GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern).Current.ToggleState -ne [System.Windows.Automation.ToggleState]::On) {throw 'Grapheme startup preference did not reload'}
    Binding-Controls $dialog $customBindings | Out-Null
    Binding-Controls $dialog $customShellBindings 'Commands' | Out-Null
    Binding-Controls $dialog $tabBindings 'Tabs' | Out-Null
    if (!(Find-Name $dialog 'Left').GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern).Current.IsSelected) { throw 'Tab position did not reload' }
    Select-Node $dialog 'Rendering' | Out-Null
    if (!(Find-Name $dialog 'DirectX (GPU composition)').GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern).Current.IsSelected) { throw 'Renderer did not reload' }
    $attributes=Attribute-Colour-Controls $dialog
    for ($index=0;$index -lt 5;$index++) {
        Set-Combo $attributes.selector $index
        $expectedFlags=@(($index -in @(0,4)),$true,($index -eq 0),$true)
        for ($i=0;$i -lt 4;$i++) {
            $enabled=$attributes.flags[$i].GetCurrentPattern([System.Windows.Automation.TogglePattern]::Pattern).Current.ToggleState -eq [System.Windows.Automation.ToggleState]::On
            if ($enabled -ne $expectedFlags[$i]) { throw 'Attribute flag did not reload independently' }
        }
        for ($channel=0;$channel -lt 3;$channel++) {
            if ([int]$attributes.edits[$channel].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value -ne $attributeRGB[$index][$channel]) { throw 'Attribute RGB did not reload' }
        }
    }
    Invoke-Button $dialog 'Open'
    $observed = Wait-Value {
        if (Test-Path -LiteralPath $report) {
            $value = Get-Content -LiteralPath $report -Raw | ConvertFrom-Json
            if ($value.error) { throw $value.error }
            if ($value.hex -eq '1b5b3e343b336d1b5b3e343b3166') { $value }
        }
    }
    $termHandle=Wait-Value {
        $app.Refresh()
        if ($app.HasExited) { throw "Settings child ended before renderer lookup: exit $($app.ExitCode)" }
        # A process can have a settings dialog, host and transient windows.
        # Find the exact terminal belonging to this PID, rather than relying
        # on .NET's heuristic MainWindowHandle selection.
        $content=[ShellSettingsNative]::Terminal($app.Id,[bool]$TabHost)
        if ($content -ne [IntPtr]::Zero) { $content }
    }
    $initialRenderer=[ShellSettingsNative]::GetPropW($termHandle,'NemotermRenderer').ToInt32()
    $selectionColourChecks=@(Check-SelectionColours 'selection-colour-startup' '' '1111/2222/3333' 'dddd/eeee/ffff')
    $esc=[string][char]27;$bel=[string][char]7
    $attributeReplies=@('1111/2222/3333','4444/5555/6666','7777/8888/9999','aaaa/bbbb/cccc','dddd/eeee/ffff')
    $attributeChecks=@(Check-AttributeColours 'attribute-startup' '' $attributeReplies)
    $attributeOverride=@('ffff/0000/0000')+$attributeReplies[1..4]
    $attributeChecks+=Check-AttributeColours 'attribute-application-override' ($esc+']5;0;red'+$bel+$esc+']6;0;0'+$bel) $attributeOverride
    $selectionColourChecks+=Check-SelectionColours 'selection-colour-app-override' ($esc+']17;red;;blue'+$bel) 'ffff/0000/0000' '0000/0000/ffff'
    $graphemeChecks=@(Check-Grapheme 'grapheme-startup' '' $true)
    $graphemeChecks+=Check-Grapheme 'grapheme-app-disable' ([char]27+'[?2027l') $false
    $rendererChanges=@()
    foreach ($mode in @('GDI (low memory)','OpenGL (GPU composition)','DirectX (GPU composition)','GDI (low memory)')) {
        [ShellSettingsNative]::PostMessageW($termHandle,0x111,[IntPtr]0x50,[IntPtr]::Zero) | Out-Null
        $dialog=Dialog $app
        Check-HyperlinkControls $dialog
        $node=Find-Name $dialog 'Window'
        $node.GetCurrentPattern([System.Windows.Automation.ExpandCollapsePattern]::Pattern).Expand()
        Select-Node $dialog 'Rendering' | Out-Null
        Select-Node $dialog $mode | Out-Null
        $dialogHandle=[IntPtr]$dialog.Current.NativeWindowHandle
        Invoke-Button $dialog 'Apply'
        Wait-Value { ![ShellSettingsNative]::IsWindow($dialogHandle) } | Out-Null
        $allowed=if ($mode -eq 'GDI (low memory)') {@(1)} elseif ($mode -eq 'OpenGL (GPU composition)') {@(1,2)} else {@(1,3)}
        if ($mode -eq 'OpenGL (GPU composition)' -and $env:NEMOTERM_REQUIRE_OPENGL -eq '1') {$allowed=@(2)}
        if ($mode -eq 'DirectX (GPU composition)' -and $env:NEMOTERM_REQUIRE_DIRECTX -eq '1') {$allowed=@(3)}
        $active=Wait-Value { $value=[ShellSettingsNative]::GetPropW($termHandle,'NemotermRenderer').ToInt32(); if ($value -in $allowed) { $value } }
        if ($mode -eq 'GDI (low memory)' -and $active -ne 1) { throw 'Live GDI switch failed' }
        # EndDialog can destroy the settings HWND before its caller finishes
        # reconfiguring the renderer. A terminal query/reply completes that
        # transition before recording the renderer actually used by the frame.
        $earlyRenderer=$active
        $graphemeChecks+=Check-Grapheme ('grapheme-preserved-'+($rendererChanges.Count+1)) '' $false
        $active=Wait-Value { $value=[ShellSettingsNative]::GetPropW($termHandle,'NemotermRenderer').ToInt32(); if ($value -in $allowed) { $value } }
        $rendererChanges += @{requested=$mode;active=$active;before_query_barrier=$earlyRenderer}
    }
    $graphemeChecks+=Check-Grapheme 'grapheme-app-enable' ([char]27+'[?2027h') $true
    Set-GraphemePreference $false
    $graphemeChecks+=Check-Grapheme 'grapheme-live-disabled' '' $false
    Set-GraphemePreference $true
    $graphemeChecks+=Check-Grapheme 'grapheme-live-enabled' '' $true
    $attributeChecks+=Check-AttributeColours 'attribute-unrelated-settings' '' $attributeOverride
    $graphemeChecks+=Check-Grapheme 'grapheme-soft-reset' ([char]27+'[!p') $false
    $attributeChecks+=Check-AttributeColours 'attribute-soft-reset-defaults' '' $attributeReplies
    $graphemeChecks+=Check-Grapheme 'grapheme-hard-reset' ([char]27+'[?2027h'+[char]27+'c') $false
    $attributeChecks+=Check-AttributeColours 'attribute-hard-reset-defaults' '' $attributeReplies
    $selectionColourChecks+=Check-SelectionColours 'selection-colour-unrelated-settings' '' 'ffff/0000/0000' '0000/0000/ffff'
    $attributeChecks+=Check-AttributeColours 'attribute-override-after-reset' ($esc+']5;0;red'+$bel) $attributeOverride
    $attributeChecks+=Check-AttributeColours 'attribute-configured-reset' ($esc+']105;0'+$bel) $attributeReplies
    $selectionColourChecks+=Check-SelectionColours 'selection-colour-configured-reset' ($esc+']117'+$bel+$esc+']119'+$bel) '1111/2222/3333' 'dddd/eeee/ffff'
    [ShellSettingsNative]::PostMessageW($termHandle,0x111,[IntPtr]0x50,[IntPtr]::Zero) | Out-Null
    $dialog=Dialog $app
    Check-HyperlinkControls $dialog
    $selectionColours=Selection-Colour-Controls $dialog
    for ($i=0;$i -lt $selectionRGB.Count;$i++) {
        if ([int]$selectionColours.edits[$i].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value -ne $selectionRGB[$i]) {
            throw 'Selection RGB did not reload into the live settings dialog'
        }
    }
    $selectionColours.edits[0].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue('85')
    $selectionColours.edits[1].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue('102')
    $selectionColours.edits[2].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue('119')
    $attributes=Attribute-Colour-Controls $dialog
    Set-Combo $attributes.selector 0
    $attributes.edits[0].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue('16')
    $attributes.edits[1].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue('32')
    $attributes.edits[2].GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue('48')
    $handle=[IntPtr]$dialog.Current.NativeWindowHandle
    Invoke-Button $dialog 'Apply'
    Wait-Value { ![ShellSettingsNative]::IsWindow($handle) } | Out-Null
    $selectionColourChecks+=Check-SelectionColours 'selection-colour-live-apply' '' '5555/6666/7777' 'dddd/eeee/ffff'
    $attributeChecks+=Check-AttributeColours 'attribute-live-apply' '' (@('1010/2020/3030')+$attributeReplies[1..4])
    $evidence = @{executable_sha256=(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLower();
        default_grid=@(160,48);tab_host=[bool]$TabHost;saved_tab_side=2;saved_tab_bindings=$tabBindings;saved_bindings=$customBindings;duplicate_binding_rejected=$true;live_renderer_changes=$rendererChanges;
        saved_shell_bindings=$customShellBindings;saved_renderer=2;initial_renderer=$initialRenderer;
        grapheme_default=$false;saved_grapheme=$true;grapheme_checks=$graphemeChecks;
        selection_colour_default='inverse';saved_selection_rgb=$selectionRGB;selection_colour_checks=$selectionColourChecks;
        saved_attribute_rgb=$attributeRGB;saved_attribute_modes=49;saved_attribute_keep_styles=1;attribute_colour_checks=$attributeChecks;
        saved_level=3;saved_format=1;copy_only_default=$true;saved_copy_and_paste=$true;
        reflow_default=$true;saved_reflow=$false;win32_default=$false;saved_win32=$true;cancel_exit=0;local_launch=$true;
        checksum_default=$false;saved_checksum=$true;
        hyperlink_settings_startup=$true;hyperlink_settings_live=$true;
        saved_shell='git-bash';saved_choose_shell=$true;explicit_command_overrides_shell=$true;
        saved_unicode_directory=$fixtureCwd;saved_directory_inheritance=$false;query=$observed}
    $evidenceName=if ($TabHost) {'research/tabs-settings-window-observed.json'} else {'research/settings-window-observed.json'}
    [IO.File]::WriteAllText((Join-Path $root $evidenceName),
        ($evidence | ConvertTo-Json -Depth 5), (New-Object Text.UTF8Encoding($false)))
    Write-Control @{stop=$true}
    if (!$app.WaitForExit(5000) -or $app.ExitCode -ne 0) { throw 'Fixture shutdown failed' }
    Write-Output 'Native settings save/load, visible controls and local launch passed'
} catch {
    Write-Output $_.ScriptStackTrace
    if (Test-Path -LiteralPath $report) {
        Write-Output 'Last owned child report:'
        Get-Content -LiteralPath $report -Raw
    }
    if ($app -and $app.HasExited) { Write-Output "Owned process exit: $($app.ExitCode)" }
    if ($app -and !$app.HasExited) {
        $owner = New-Object System.Windows.Automation.PropertyCondition([System.Windows.Automation.AutomationElement]::ProcessIdProperty, $app.Id)
        $windows = [System.Windows.Automation.AutomationElement]::RootElement.FindAll([System.Windows.Automation.TreeScope]::Children, $owner)
        foreach ($window in $windows) {
            Write-Output ($window.Current | Select-Object Name, ClassName | ConvertTo-Json -Compress)
            $window.FindAll($scope, [System.Windows.Automation.Condition]::TrueCondition) | ForEach-Object { Write-Output $_.Current.Name }
        }
    }
    throw
} finally {
    if ($app -and !$app.HasExited) { $app.Kill(); $app.WaitForExit() }
    if (Test-Path -LiteralPath $profilePath) { Remove-Item -LiteralPath $profilePath }
    # Delete only these known fixture files, then the empty owned directory.
    foreach ($name in @('report.json', 'report.tmp', 'control.json', 'control.json.tmp')) {
        $path = Join-Path $directory $name
        if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path }
    }
    if ($fixtureCwd -and (Test-Path -LiteralPath $fixtureCwd)) { Remove-Item -LiteralPath $fixtureCwd }
    Remove-Item -LiteralPath $directory
}
