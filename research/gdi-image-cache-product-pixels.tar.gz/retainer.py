"""Review and retain seven completed pixel cases from the exact CI single image."""
from pathlib import Path
from collections import Counter
import hashlib,json,subprocess,tarfile
from PIL import Image
root=Path(__file__).resolve().parents[1]
stage=root/'build/local-gdi-single-product-continuation-12ee33b-01'
work=root/'build/gdi-dense-memory-worktree'
source='12ee33baa970363ddde687b3e612f9154e386356'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p):
    with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
identity=load(stage/'IDENTITY.json')
assert identity['source_commit']==identity['fixture_commit']==source
image_sha=digest(stage/'dist/nemoterm.exe')
assert image_sha==identity['executable_sha256']=='64195969a8f2e6653f854d598f169810107ee808d66eaa1088cf9e3ced6b259f'
cases=load(stage/'cases.json')[:7]
results=load(stage/'logs/results.json')[:7]
assert len(results)==7 and [r['name'] for r in results]==[name for name,_ in cases]
paths={};summaries=[]
for result in results:
    name=result['name'];assert result['exit_code']==0 and not result.get('controller_timeout')
    for record in result['observations']:
        path=stage/record['path']
        assert path.stat().st_size==record['bytes'] and digest(path)==record['sha256']
        paths[path]=record['path']
    paths[stage/'logs'/f'{name}.log']=f'logs/{name}.log'
    reports=list((stage/'case-evidence'/name/'research').glob('*observed.json'))
    assert len(reports)==1
    data=load(reports[0]);checks=data.get('checks',data.get('phases'))
    geometry=name.startswith('unicode-geometry-');renderer=name.rsplit('-',1)[-1]
    assert data['completed'] and data['executable_sha256']==image_sha
    assert len(checks)==(19 if geometry else 32) and all(check['matched'] for check in checks)
    assert data['actual_renderer']=={'gdi':0,'opengl':1,'directx':2}[renderer]
    assert not data['clipboard_access'] and not data['global_input']
    assert not data['cleanup']['terminated_remaining'] and data['cleanup']['after']['active']==0
    folder=stage/'case-evidence'/name/Path(data['folder']).relative_to(stage)
    for check in checks:
        with Image.open(folder/check.get('png',check.get('image'))) as picture:
            if geometry:
                picture=picture.convert('RGB')
                assert picture.size==(check['geometry']['width'],check['geometry']['height'])
                counts=Counter(picture.getdata())
                for colour,rgb in [('red',(255,0,0)),('blue',(0,0,255))]:
                    value=check['counts'][colour]
                    assert counts[rgb]==value['expected']==value['actual']
                    assert not value['missing'] and not value['unexpected']
            else:picture.verify()
        if check.get('bmp'):assert digest(folder/check['bmp'])==check['bmp_sha256']
    if name=='unicode-presented-gdi':
        capture=data['presented_capture']
        assert not capture['wm_print'] and not capture['desktop_dc'] and capture['topmost_restored'] and capture['closed']
    summaries.append(dict(name=name,stages=len(checks),renderer=renderer,capture=data['capture']))
assert sum(summary['stages'] for summary in summaries)==185
for name in subprocess.check_output(['git','ls-tree','-r','--name-only',source,'--','tests','tools/nemoterm_debug.py'],cwd=work,text=True).splitlines():
    assert (stage/name).read_bytes()==subprocess.check_output(['git','show',source+':'+name],cwd=work)
    paths[stage/name]=name
for name in ('IDENTITY.json','controller.py','cases.json','continuation.json'):
    paths[stage/name]=name
review=dict(identity=identity,completed=True,scope='Seven completed native pixel cases only; other product acceptance remains separate.',groups=7,stages=185,native=summaries,results=results)
checkpoint=root/'build/gdi-product-pixels-review-12ee33b.json'
with checkpoint.open('x',encoding='utf-8') as stream:json.dump(review,stream,indent=2);stream.write('\n')
paths[checkpoint]='review.json';paths[Path(__file__)]='retainer.py'
archive=work/'research/gdi-image-cache-product-pixels.tar.gz';records=[]
with archive.open('xb') as raw,tarfile.open(fileobj=raw,mode='w:gz') as bundle:
    for path,name in sorted(paths.items(),key=lambda pair:pair[1]):
        records.append(dict(path=name,bytes=path.stat().st_size,sha256=digest(path)))
        bundle.add(path,arcname=name,recursive=False)
review.pop('results')
review.update(archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=digest(archive)),records=records)
manifest=work/'research/gdi-image-cache-product-pixels-validation.json'
with manifest.open('x',encoding='utf-8') as stream:json.dump(review,stream,indent=2);stream.write('\n')
print(json.dumps(dict(groups=7,stages=185,archive=review['archive'],records=len(records)),indent=2))
