"""Continue independent exact-product cases; preserve original failures and passes."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,time

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--destination',type=Path,required=True)
a=p.parse_args()
root=Path(__file__).resolve().parents[1]
original=root/'build/local-gdi-single-product-12ee33b-01'
work=root/'build/gdi-dense-memory-worktree'
stage=a.destination.resolve()
assert not stage.exists(),'Use a fresh destination to preserve evidence'
load=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
identity=load(original/'IDENTITY.json')
source='12ee33baa970363ddde687b3e612f9154e386356'
assert identity['source_commit']==identity['fixture_commit']==source
assert digest(original/'dist/nemoterm.exe')==identity['executable_sha256']=='64195969a8f2e6653f854d598f169810107ee808d66eaa1088cf9e3ced6b259f'
prior=load(original/'logs/results.json');all_cases=load(original/'cases.json')
assert len(all_cases)==39 and len(prior)==15
assert all(r.get('exit_code')==0 for r in prior[:14])
assert prior[-1]['name']=='input-byte' and prior[-1]['exit_code']==1
for result in prior:
    for record in result['observations']:
        path=original/record['path']
        assert digest(path)==record['sha256'] and path.stat().st_size==record['bytes']
passed={r['name'] for r in prior if r.get('exit_code')==0}
deferred={'input-byte','input-wide'}
cases=[case for case in all_cases if case[0] not in passed|deferred]
assert len(cases)==23 and len(passed)==14
stage.mkdir(parents=True)
for folder in ('dist','tests','tools','logs','research','build','case-evidence'):(stage/folder).mkdir()
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',source,'--','tests','tools/nemoterm_debug.py'],cwd=work,text=True).splitlines()
for name in paths:
    data=subprocess.check_output(['git','show',source+':'+name],cwd=work)
    assert (original/name).read_bytes()==data,name
    target=stage/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
shutil.copy2(original/'dist/nemoterm.exe',stage/'dist/nemoterm.exe')
shutil.copy2(original/'research/font-mapper-preflight.json',stage/'research/font-mapper-preflight.json')
shutil.copy2(Path(__file__),stage/'controller.py')
(stage/'IDENTITY.json').write_text(json.dumps(dict(identity,scope='Continuation of independent cases; initial IME failure remains open. No promotion.'),indent=2)+'\n')
(stage/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
(stage/'continuation.json').write_text(json.dumps(dict(original=str(original),prior_results_sha256=digest(original/'logs/results.json'),
    reused_passes=sorted(passed),deferred=sorted(deferred),reason='Actual foreground preparation failed; keep IME gate unresolved while independent tests continue.'),indent=2)+'\n')
env=dict(os.environ,NEMOTERM_TEST_EXE=str(stage/'dist/nemoterm.exe'),NEMOTERM_REQUIRE_OPENGL='1',
    NEMOTERM_REQUIRE_DIRECTX='1',NEMOTERM_TEST_FONT='SarasaTermSC Nerd Font Light',
    NEMOTERM_SHUTDOWN_DEADLINE_SECONDS='120',NEMOTERM_TEST_TRACEBACK_SECONDS='60')
env.pop('CI',None);env.pop('GITHUB_ACTIONS',None)
results=[]
def observations():
    # Retain build diagnostics as well as research reports, including failures.
    return {path.relative_to(stage).as_posix():digest(path)
            for folder in ('research','build') for path in (stage/folder).rglob('*') if path.is_file()}
for name,arguments in cases:
    print('Starting independent exact-product case:',name,flush=True)
    before=observations();started=time.monotonic()
    with (stage/'logs'/f'{name}.log').open('w',encoding='utf-8') as log:
        try:
            completed=subprocess.run([sys.executable,*arguments],cwd=stage,env=env,stdout=log,stderr=subprocess.STDOUT,
                                     timeout=1800 if '-memory-' in name else 300)
            record=dict(name=name,exit_code=completed.returncode,seconds=time.monotonic()-started)
        except subprocess.TimeoutExpired:
            record=dict(name=name,controller_timeout=True,seconds=time.monotonic()-started)
    record['observations']=[]
    for relative,checksum in observations().items():
        if before.get(relative)==checksum:continue
        target=stage/'case-evidence'/name/relative
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(stage/relative,target)
        record['observations'].append(dict(path=target.relative_to(stage).as_posix(),bytes=target.stat().st_size,sha256=checksum))
    results.append(record);(stage/'logs/results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps({key:value for key,value in record.items() if key!='observations'}),flush=True)
    if record.get('exit_code')!=0:raise SystemExit(1)
assert [p.name for p in (stage/'dist').iterdir()]==['nemoterm.exe']
assert digest(stage/'dist/nemoterm.exe')==identity['executable_sha256']
print('23 independent cases passed; two IME cases remain required. No promotion.',flush=True)
