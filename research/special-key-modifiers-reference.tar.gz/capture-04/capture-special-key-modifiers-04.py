from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
stage=root/'build/special-key-modifiers-reference-04'
stage.mkdir(exist_ok=False)
source=Path('/tmp/nemoterm-legacy-reference-5RtbUr')
commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
assert commit=='5c75ead9a75d4b2e666ca06fa94503b5766ed93f'
subprocess.run(['git','-C',str(source),'diff','--exit-code'],check=True)
for name in ['xterm_special_keys_oracle.py','xterm_udk_oracle.py','xterm_locator_oracle.py']:
    shutil.copy2(work/'tests'/name,stage/name)
shutil.copy2(__file__,stage/Path(__file__).name)
for name in ['input.c','charproc.c','keysym2ucs.c','xterm.man','ctlseqs.txt','version.h']:
    shutil.copy2(source/name,stage/('xterm-'+name))
identity=dict(source_commit=commit,source_directory=str(source),
    executable_sha256=hashlib.sha256((source/'xterm').read_bytes()).hexdigest(),
    global_input=False,clipboard_access=False,private_display=True)
(stage/'IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n')
subprocess.run([sys.executable,str(stage/'xterm_special_keys_oracle.py'),'--xterm',str(source/'xterm'),
                '--output',str(stage/'xterm.json')],check=True)



