from pathlib import Path
import hashlib,json,tarfile
root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
stage=root/'build/answerback-config-native-02'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline=root/'build/answerback-config-baseline-01.log'
fixed=root/'build/answerback-config-fixed-01.log'
assert baseline.read_text().count('0 != 1 / 0 != 0x1')==8
assert fixed.read_text().strip()=='Query suite passed'
identity=load(stage/'IDENTITY.json');image=stage/'dist/nemoterm.exe'
assert sha(image)==identity['nemoterm.exe']['sha256']
expected={'literal':b'LEFT^!^0^ ^:^/RIGHT^END','controls':b'\r\n\0\x1b\x7f^','numeric':b'\r\r\r\0','empty':b''}
reports=list((stage/'research').glob('*-observed.json'));assert len(reports)==8
processes=0
for path in reports:
    report=load(path);label=path.name.split('-')[2]
    assert report['completed'] and report['executable_sha256']==sha(image) and len(report['cases'])==20
    assert report['reference_case_count']==0 and len(report['direct_case_names'])==20
    assert not report['cleanup']['terminated_remaining'] and report['cleanup']['after']['active']==0
    processes+=report['cleanup']['after']['total']
    for name,reply in report['cases'].items():
        want=b'' if name=='within-osc' else expected[label]+(b'\x1b[1;1R' if name=='within-csi' else b'')
        assert bytes.fromhex(reply)==want+b'\x1b[0n',(path,name)
        assert report['case_metadata'][name]['input_cp'] in (28591,65001)
files=[]
def add(p,name):files.append(dict(path=name,source=p,bytes=p.stat().st_size,sha256=sha(p)))
add(baseline,'core/baseline.log');add(fixed,'core/fixed.log')
for p in (stage/'dist').iterdir():add(p,'image/'+p.name)
add(stage/'IDENTITY.json','image/IDENTITY.json')
for number in ('01','02'):
    current=root/'build'/('answerback-config-native-'+number)
    add(current/'native.log','native-'+number+'/native.log')
    for p in (current/'research').glob('*-observed.json'):add(p,'native-'+number+'/'+p.name)
    add(current/'tests/answerback_config_window_smoke.py','native-'+number+'/fixture.py')
for p in (stage/'tests').glob('*'):
    if p.is_file():add(p,'fixtures/tests/'+p.name)
for name in ('vendor/putty-0.85/utils/ctrlparse.c','vendor/putty-0.85/test/test_queries.c','vendor/putty-0.85/doc/config.but'):
    add(work/name,'source/'+name)
add(Path(__file__),'controller/retain-answerback-config.py')
archive=work/'research/answerback-config.tar.gz';assert not archive.exists()
with tarfile.open(archive,'x:gz') as tar:
    for record in files:tar.add(record['source'],arcname=record['path'],recursive=False)
validation=dict(completed=True,scope='PuTTY-style answerback configuration contract; not full xterm or single-image acceptance.',
    base_source='69496bb888ec96dc620978689e8d0ae7f1711a34',
    core_invalid_vectors=15,core_valid_vectors=13,core_enquiry_checks=3,baseline_invalid_failures=8,
    native_checks=160,input_code_pages=[28591,65001],configuration_profiles=list(expected),
    executable_sha256=sha(image),natural_cleanup=True,naturally_exited_processes=processes,
    physical_input=False,clipboard_access=False,
    original_log_note='Native-01 used the generic helper reference argument and printed XTerm incorrectly. Expected data are the documented configuration contract; native-02 explicitly uses direct cases and retains all original records.',
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),
    files=[{k:v for k,v in r.items() if k!='source'} for r in files])
(work/'research/answerback-config-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps({k:v for k,v in validation.items() if k!='files'},indent=2))
