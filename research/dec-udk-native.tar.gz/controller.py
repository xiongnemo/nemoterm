from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1]; work=root/'build/udk-worktree'
base=root/'build/ci-udk-native-1aff8c8'
run=json.loads((base/'udk-window-run.json').read_bytes()); source=run['headSha']
assert source=='1aff8c85c3805727d72d255fef10eeef180b032e' and run['databaseId']==43718137156 and run['conclusion']=='success'
assert [j['conclusion'] for j in run['jobs'] if j['name']=='udk-native']==['success']
sha=lambda raw:hashlib.sha256(raw).hexdigest()
b=base/'diagnostic'; image=b/'build/single-exe-dist/nemoterm.exe'; image_sha=sha(image.read_bytes())
assert image_sha==json.loads((b/'udk-image.json').read_text(encoding='utf-8-sig'))['Hash'].lower()
data=json.loads((b/'research/udk-window-observed.json').read_bytes())
assert data['completed'] and data['physical_input'] and data['executable_sha256']==image_sha
with tarfile.open(work/'research/dec-udk-reference.tar.gz') as archive:
 raw=archive.extractfile('9b798e2/reference/dec-udk-xterm.json').read()
assert sha(raw)==data['reference_sha256']; reference=json.loads(raw)
assert len(data['cases'])==89 and sum(len(v) for v in data['cases'].values())==232
for name,steps in data['cases'].items():
 for step,original in zip(steps,reference['cases'][name]['steps'],strict=True):
  assert all(step[key]==original[key] for key in ('sequence_hex','actions','reply_hex','wire_with_barriers_hex')),(name,step)
assert set(data['core_only'])=={'payload-binary','eight-bit-dcs'}
assert data['profiles']['vt220']['LinuxFunctionKeys']==7 and data['profiles']['default']['LinuxFunctionKeys']==6
assert len(data['cleanup'])==2 and all(not d['terminated_remaining'] and d['after']['active']==0 for d in data['cleanup'])
assert bytes.fromhex(data['udk_after_kitty_wire'])==b'\x1b[0nA\x1b[0n'
assert bytes.fromhex(data['kitty_priority_wire']).startswith(b'\x1b[0n\x1b[17;')
for test in ('udk','dec_status','keyboard','mok','win32_input'):
 text=(b/f'udk-{test}.log').read_text(encoding='utf-8-sig')
 assert 'passed' in text,test
paths=['vendor','native','scripts/build-single-exe.ps1','scripts/prepare-single-exe.py']
subprocess.run(['git','diff','--exit-code','f8a20d3',source,'--',*paths],cwd=work,check=True)
artifacts=json.loads((base/'udk-window-artifacts.json').read_bytes())['artifacts']
artifact=next(a for a in artifacts if a['id']==14163122366)
assert artifact['name']=='udk-native-'+source
entries={'controller.py':Path(__file__).read_bytes()}
for p in base.rglob('*'):
 if p.is_file(): entries[p.relative_to(base).as_posix()]=p.read_bytes()
for name in ('.github/workflows/ansi-conformance.yml','tests/udk_window_smoke.py','tests/mouse_fixture.py',
             'tests/native_test_utils.py','tests/owned_job.py','tests/protocol_oracle_window.py',
             'tests/dec_status_window_smoke.py','tests/keyboard_window_smoke.py','tests/mok_window_smoke.py',
             'tests/win32_input_window_smoke.py','vendor/putty-0.85/terminal/nemo_udk_terminal.inc',
             'vendor/putty-0.85/terminal/terminal.c','vendor/putty-0.85/terminal/terminal.h',
             'vendor/putty-0.85/windows/window.c','vendor/putty-0.85/windows/nemo_key_input.c',
             'vendor/putty-0.85/putty.h','vendor/putty-0.85/config.c','vendor/putty-0.85/conf-enums.h',
             'scripts/build-single-exe.ps1','scripts/prepare-single-exe.py','native/single_exe/entry.cpp'):
 entries['source/'+name]=subprocess.check_output(['git','show',source+':'+name],cwd=work)
archive=work/'research/dec-udk-native.tar.gz'; records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
 for name,raw in sorted(entries.items()):
  info=tarfile.TarInfo(name); info.size=len(raw); tar.addfile(info,io.BytesIO(raw))
  records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive,'r|gz') as tar:
 for member,record in zip(tar,records,strict=True):
  assert member.name==record['path'] and sha(tar.extractfile(member).read())==record['raw_sha256']
manifest=dict(source=source,run=43718137156,conclusion='success',artifact_id=artifact['id'],expires=artifact['expires_at'],
 image=dict(sha256=image_sha,bytes=image.stat().st_size),native_cases=89,native_streams=232,core_only=data['core_only'],
 profiles=data['profiles'],kitty_priority_wire=data['kitty_priority_wire'],udk_after_kitty_wire=data['udk_after_kitty_wire'],
 natural_cleanup=True,regressions=['dec_status','keyboard','mok','win32_input'],
 production_equivalence=dict(component='f8a20d3',paths=paths,git_diff_exit=0),
 scope='Physical keys and exact bytes through a source-built single image on disposable Windows CI. Core retains raw binary cases; complete product and local acceptance are separate.',
 bundle=dict(path=archive.relative_to(work).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),records=records))
(work/'research/dec-udk-native-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Native UDK retained:',len(records),archive.stat().st_size,manifest['image'])
