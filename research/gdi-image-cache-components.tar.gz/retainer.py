"""Validate and retain the three-compiler image paint-cache regression."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
base=root/'build/ci-gdi-display-cache-12ee33b'
source='12ee33baa970363ddde687b3e612f9154e386356'
run=json.loads((base/'components-run.json').read_text())
assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(43736421112,source,'completed','success')
assert len(run['jobs'])==3 and all(j['conclusion']=='success' for j in run['jobs'])
artifacts=json.loads((base/'components-artifacts.json').read_text())['artifacts']
sha=lambda raw:hashlib.sha256(raw).hexdigest()
test=subprocess.check_output(['git','show',source+':vendor/putty-0.85/test/test_grapheme_terminal.c'],cwd=work)
terminal=subprocess.check_output(['git','show',source+':vendor/putty-0.85/terminal/terminal.c'],cwd=work)
compilers=[]
for compiler in ('gcc','clang','msvc'):
    folder=base/'components'/f'kitty-transport-{compiler}-{source}'
    artifact=next(a for a in artifacts if a['name']==folder.name)
    receipt=json.loads(folder.with_name(folder.name+'-download.json').read_text())
    assert artifact['id']==receipt['artifact_id'] and receipt['source']==source
    win=compiler=='msvc';encoding='utf-8-sig'
    log=(folder/('paint-cache-test.log' if win else 'paint-cache-sanitizers.log')).read_text(encoding=encoding)
    cell=32 if win else 40
    assert f'Image paint cache: {48*160*cell} bytes, 0 extension-bearing cells, {cell}-byte cells' in log
    assert 'Grapheme terminal suite passed' in log
    source_hash=(folder/('paint-cache-source.txt' if win else 'paint-cache-source.sha256')).read_text(encoding=encoding).lower()
    terminal_hash=(folder/('terminal-sources.txt' if win else 'terminal-sources.sha256')).read_text(encoding=encoding).lower()
    for raw,record in ((test,source_hash),(terminal,terminal_hash)):
        assert sha(raw) in record or (win and sha(raw.replace(b'\n',b'\r\n')) in record)
    original=(folder/('terminal-test.log' if win else 'terminal-sanitizers.log')).read_text(encoding=encoding)
    assert '728 states; 0 failed states' in original and '32 exact core copies checked' in original
    assert 'Sixel terminal suite passed' in original
    compilers.append(dict(compiler=compiler,artifact=artifact['id'],paint_cache_bytes=48*160*cell,
                          extensions=0,unicode_reference_states=728,exact_core_copies=32,sanitized=not win))
entries={p.relative_to(base).as_posix():p for p in (base/'components').rglob('*') if p.is_file()}
for name in ('components-run.json','components-run.log','components-artifacts.json','components-observed-at.txt'):
    entries[name]=base/name
entries['retainer.py']=Path(__file__)
entries['source/test_grapheme_terminal.c']=test
entries['source/terminal.c']=terminal
archive=work/'research/gdi-image-cache-components.tar.gz';records=[]
with archive.open('xb') as f,gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,value in sorted(entries.items()):
        raw=value if isinstance(value,bytes) else value.read_bytes()
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,bytes=len(raw),sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path'] and sha(tar.extractfile(member).read())==record['sha256']
manifest=dict(source=source,run=43736421112,conclusion='success',compilers=compilers,
    scope='Three-compiler cache allocation, live text and core image/selection regression; full product and local process-memory acceptance remain separate.',
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes())),records=records)
(archive.parent/'gdi-image-cache-components-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(compilers=compilers,archive=manifest['archive'],records=len(records)),indent=2))
