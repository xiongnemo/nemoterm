"""Retain minimized hosted-resize failure and six renderer/side passes."""
from pathlib import Path
import hashlib,json,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/gdi-dense-memory-worktree';research=work/'research'
runtime=root/'build/local-cli-profile-candidate-02/dist'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sha=digest(runtime/'nemoterm.exe');paths={};checks=[]
for path in sorted(research.glob('command-line-profile-resize-fixed-*-observed.json')):
    data=load(path);assert data['executable_sha256']==sha and not data.get('error')
    assert data['tab_host'] and len(data['modes'])==4
    normal=data['modes'][0];requested=normal['requested_renderer']
    assert normal['active_renderer']==requested+1
    assert [len(mode['checks']) for mode in data['modes']]==[42,5,5,6]
    for mode in data['modes']:
        assert mode['exit_code']==0 and not mode['cleanup']['terminated_remaining'] and mode['cleanup']['after']['active']==0
    assert normal['minimized_output_preserved']
    checks.append(dict(path=path.name,side=data['tab_side'],renderer=normal['active_renderer'],phases=58))
    paths[path]='reports/'+path.name
assert len(checks)==6 and {c['side'] for c in checks if c['renderer']==1}=={'top','bottom','left','right'}
assert {c['renderer'] for c in checks}=={1,2,3}
baseline=load(research/'command-line-profile-resize-baseline-observed.json')
assert "'restored-request', [442, 463], [650, 502]" in baseline['error']
assert baseline['modes'][0]['cleanup']['terminated_remaining']
for name in ('command-line-profile-resize-baseline-observed.json','command-line-profile-resize-baseline.log',
             'tabs-geometry-window-observed.json','geometry-0.png','window-resize-gdi.png','window-resize-gpu-2.png','window-resize-gpu-3.png'):
    paths[research/name]='reports/'+name
for path in (work/'build').glob('command-line-profile-*resize*.log'):paths[path]='logs/'+path.name
paths[work/'build/command-line-profile-geometry.log']='logs/geometry.log'
for name in ('vendor/putty-0.85/windows/window.c','vendor/putty-0.85/windows/pterm.c','tests/window_resize_window_smoke.py',
             'tests/geometry_window_smoke.py','tests/tabs_regression_suite.py'):
    paths[work/name]='source/'+name
for path in runtime.iterdir():paths[path]='runtime/'+path.name
paths[Path(__file__)]='retainer.py'
archive=research/'host-restore-size.tar.gz';records=[]
with archive.open('xb') as raw,tarfile.open(fileobj=raw,mode='w:gz') as bundle:
    for path,name in sorted(paths.items(),key=lambda pair:pair[1]):
        records.append(dict(path=name,bytes=path.stat().st_size,sha256=digest(path)));bundle.add(path,arcname=name,recursive=False)
summary=dict(scope='Portable native minimized/restore resize regression; no single-image, foreground or full memory acceptance.',
    base_commit='020e2f9d48e5897f8a769923e7855911ca44c9de',executable_sha256=sha,executable_bytes=(runtime/'nemoterm.exe').stat().st_size,
    checks=checks,phases=sum(c['phases'] for c in checks),baseline_forced_cleanup=True,
    runtime={path.name:dict(bytes=path.stat().st_size,sha256=digest(path)) for path in runtime.iterdir()},
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=digest(archive)),records=records)
with (research/'host-restore-size-validation.json').open('x',encoding='utf-8') as stream:json.dump(summary,stream,indent=2);stream.write('\n')
print(json.dumps(dict(phases=summary['phases'],executable_sha256=sha,archive=summary['archive'],records=len(records)),indent=2))
