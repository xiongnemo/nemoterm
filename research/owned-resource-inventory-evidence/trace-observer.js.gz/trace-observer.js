'use strict';
// Selected creation/close APIs and USER timers, never object names or payloads.
// No changed arguments/returns. Injection affects counts and scheduling.
const began=Date.now(), limit=4096, durationMs=45000, hooks=[], live=new Map();
let total=0, enabled=true, overflow=false, batch=[];
const mods=()=>Process.enumerateModules().map(m=>({name:m.name,base:m.base.toString(),size:m.size}));
const initialModules=mods();
const counts=new NativeFunction(Process.getModuleByName('user32.dll').getExportByName('GetGuiResources'),'uint',['pointer','uint']);
const users=()=>counts(ptr('0xffffffffffffffff'),1);
function frames(context){try{return Thread.backtrace(context,Backtracer.ACCURATE).slice(0,16).map(p=>p.toString());}catch(e){return [String(e)];}}
function flush(){if(batch.length){send({kind:'events',events:batch});batch=[];}}
function emit(v){if(!enabled)return null;if(total>=limit){overflow=true;enabled=false;return null;}
    v.sequence=++total;v.unix_ms=Date.now();batch.push(v);if(batch.length>=32)flush();return v.sequence;}
for(const [api,type] of [['NtCreateEvent','Event'],['NtOpenEvent','Event'],
                       ['NtCreateIoCompletion','IoCompletion'],['NtOpenIoCompletion','IoCompletion']]){
 hooks.push(Interceptor.attach(Process.getModuleByName('ntdll.dll').getExportByName(api),{
  onEnter(args){this.watch=enabled;if(!this.watch)return;this.out=args[0];this.frames=frames(this.context);},
  onLeave(status){if(!this.watch||!enabled)return;
   if(status.toInt32()<0){emit({api,operation:'create-failed',type,status:status.toString()});return;}
   const handle=this.out.readPointer().toString();const generation=emit({api,operation:'create',type,handle,thread:this.threadId,frames:this.frames});
   if(generation!==null)live.set(handle,{handle,type,generation});}
 }));
}
hooks.push(Interceptor.attach(Process.getModuleByName('ntdll.dll').getExportByName('NtClose'),{
 onEnter(args){this.entry=enabled?live.get(args[0].toString()):undefined;},
 onLeave(status){if(!this.entry||!enabled)return;emit({api:'NtClose',operation:'close',...this.entry,status:status.toString()});
  if(status.toInt32()>=0&&live.get(this.entry.handle)?.generation===this.entry.generation)live.delete(this.entry.handle);}
}));
for(const api of ['NtUserSetTimer','NtUserKillTimer']){
 hooks.push(Interceptor.attach(Process.getModuleByName('win32u.dll').getExportByName(api),{
  onEnter(args){this.watch=enabled;if(!this.watch)return;this.hwnd=args[0].toString();this.id=args[1].toString();
   this.delay=api==='NtUserSetTimer'?args[2].toUInt32():null;this.before=users();this.frames=frames(this.context);},
  onLeave(result){if(this.watch&&enabled)emit({api,operation:'timer',hwnd:this.hwnd,id:this.id,delay:this.delay,
   result:result.toString(),before:this.before,after:users(),thread:this.threadId,frames:this.frames});}
 }));
}
send({kind:'ready',pid:Process.id,began,limit,durationMs,initialModules});
const flushTimer=setInterval(flush,1000);
setTimeout(()=>{enabled=false;clearInterval(flushTimer);for(const hook of hooks)hook.detach();Interceptor.flush();flush();
 send({kind:'finished',pid:Process.id,ended:Date.now(),total,overflow,outstanding:Array.from(live.values()),finalModules:mods(),
  limitations:['Selected APIs after attach only; duplicate and other creation paths are not tracked',
   'Counts are process-wide sequential reads; other threads can change them between calls',
   'Unmatched handle generations are not proof of leaks; injection affects timing and memory']});},durationMs);
