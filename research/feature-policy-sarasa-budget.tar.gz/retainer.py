"""Retain the completed portable workload and its genuine GDI budget failure."""
from pathlib import Path
import gzip, hashlib, io, json, tarfile
from PIL import Image

root=Path(__file__).resolve().parents[1]
stage=root/'build/local-feature-policy-preflight-846b525-900s'
work=root/'build/feature-policy-worktree'
research=stage/'research'
observed=json.loads((research/'unicode-kitty-workload-tabs-gdi-top-observed.json').read_text())
memory=json.loads((research/'unicode-kitty-workload-tabs-gdi-top-memory.json').read_text())
identity=json.loads((stage/'IDENTITY.json').read_text())
assert not observed['completed'] and observed['phase']=='memory-acceptance'
assert not observed['memory_limit_passed'] and observed['memory_limit_bytes']==20_000_000
assert observed['peak_private_ws']==20_746_240
assert not memory['errors'] and not memory['injected']
assert len(memory['samples'])==memory['sample_count']==2874
for key in ('private_ws','total_ws','private_commit'):
    assert memory['peaks']['frontend'][key]==max(s['groups']['frontend'][key] for s in memory['samples'])
assert observed['process_tree_memory']['peaks']==memory['peaks']
cleanup=observed['owned_job_cleanup']
assert not cleanup['terminated_remaining'] and cleanup['after']['active']==0
assert observed['host_close']['exit_code']==0 and len(observed['checks'])==10
pixels=observed['post_memory_kitty_unicode']
assert len(pixels)==4 and sum(p['cells_verified'] for p in pixels)==29072
images=0
for pixel in pixels:
    assert pixel['matched'] and pixel['after_memory_sampling'] and not pixel['injected']
    assert pixel['grid']==[160,48] and len(pixel['rows'])==46
    assert all(row['matched'] for row in pixel['rows'])
    for row in pixel['rows']:
        if 'image' not in row:continue
        with Image.open(research/row['image']) as image:
            image=image.convert('RGB');assert image.size==(1264,1)
            assert all(image.getpixel((column*8+4,0))==(0,0,255) for column in range(158))
        images+=1
assert images==12
entries={p.relative_to(stage).as_posix():p for folder in ('research','logs') for p in (stage/folder).rglob('*') if p.is_file()}
for name in ('IDENTITY.json','tests/session_fixture.py','tests/mouse_fixture.py','tests/tabs_window_smoke.py',
             'tests/kitty_unicode_tab_workload.py','tests/tab_workload_memory.py'):
    entries[name]=stage/name
entries['retainer.py']=Path(__file__)
records=[];archive=work/'research/feature-policy-sarasa-budget.tar.gz'
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,path in sorted(entries.items()):
        raw=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644
        tar.addfile(info,io.BytesIO(raw));records.append(dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
manifest=dict(source='846b525bd0c7cbeacf71d12596d0a264d82eb5c6',fixture='59544ad8b077ab5f87f1cb0b06d5f2fe8b2d2c85',
    identity=identity,completed=False,scope='Portable MinGW preflight; genuine GDI private-working-set failure, not single-image acceptance.',
    failure=observed['error'],phase=observed['phase'],private_limit_bytes=20_000_000,
    sample_count=memory['sample_count'],sampled_seconds=memory['seconds'],frontend_peaks=memory['peaks']['frontend'],
    verified_image_cells=29072,retained_pixel_strips=images,other_checks=observed['checks'],host_close=observed['host_close'],
    cleanup=cleanup,archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),records=records)
(archive.parent/'feature-policy-sarasa-budget-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ('completed','sample_count','frontend_peaks','verified_image_cells','archive')},indent=2))
