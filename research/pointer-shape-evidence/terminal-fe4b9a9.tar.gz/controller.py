from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile

root=Path(__file__).resolve().parents[1]
work=root/'build/pointer-shape-worktree'
sha=lambda b:hashlib.sha256(b).hexdigest()
runs=[('98116eb6872c016ea15c582234825e2460014de4',43694691231,'failure'),
      ('fe4b9a9be53d1e55c72b02b5848a0fdc89f99d29',43694995351,'success')]
component=('vendor/putty-0.85/terminal/nemo_pointer.c','vendor/putty-0.85/terminal/nemo_pointer.h',
           'tests/test_pointer_shapes.c','tests/pointer_shape_reference.h')
terminal=('vendor/putty-0.85/terminal/terminal.c','vendor/putty-0.85/terminal/terminal.h',
          'vendor/putty-0.85/putty.h','vendor/putty-0.85/test/test_pointer_terminal.c',
          'tests/pointer_terminal_reference.h')
extra=('.github/workflows/pointer-shapes.yml','scripts/generate-pointer-reference.py',
       'vendor/putty-0.85/CMakeLists.txt','vendor/putty-0.85/windows/CMakeLists.txt',
       'vendor/putty-0.85/unix/CMakeLists.txt')
files={'controller.py':Path(__file__).read_bytes()};identities=[];matches=[]
component_line='Pointer component: 4740 checks; 504 independent stages; 34 state bytes'
for source,run_id,result in runs:
    short=source[:7];base=root/f'build/ci-pointer-terminal-{short}'
    run=json.loads((base/'pointer-components-run.json').read_text())
    assert (run['headSha'],run['databaseId'],run['conclusion'])==(source,run_id,result)
    jobs=[j for j in run['jobs'] if j['name'].startswith('pointer-components /')]
    assert len(jobs)==3 and all(j['conclusion']==result for j in jobs)
    identities.append(dict(source=source,run=run_id,url=run['url'],conclusion=result))
    blobs={p:subprocess.check_output(['git','show',f'{source}:{p}'],cwd=work) for p in component+terminal+extra}
    for compiler in ('gcc','clang','msvc'):
        folder=base/compiler
        assert (folder/'normal.log').read_text(encoding='utf-8-sig').strip()==component_line
        if compiler!='msvc':
            assert (folder/'sanitizers.log').read_text().strip()==component_line
        for paths,prefix in ((component,''),(terminal,'terminal-')):
            if compiler=='msvc':
                hashes=[]
                for entry in json.loads((folder/(prefix+'sources.json')).read_text(encoding='utf-8-sig')):
                    name=next(p for p in paths if entry['Path'].replace('\\','/').endswith('/'+p))
                    hashes.append((name,entry['Hash'].lower()))
            else:
                hashes=[(name,digest) for digest,name in (s.split() for s in (folder/(prefix+'sources.sha256')).read_text().splitlines())]
            assert len(hashes)==len(paths)
            for name,digest in hashes:
                blob=blobs[name]
                encoding='git_blob' if digest==sha(blob) else 'crlf_checkout' if digest==sha(blob.replace(b'\n',b'\r\n')) else None
                assert encoding,(source,compiler,name,digest)
                matches.append(dict(source=source,compiler=compiler,path=name,sha256=digest,encoding=encoding))
        if result=='success':
            observed=(folder/'terminal.log').read_text(encoding='utf-8-sig').splitlines()
            assert observed==[
                'original chunks: 552 exact upstream replies, 3 explicit cancellation-policy replies; 555 matching pointer states',
                'bytewise: 552 exact upstream replies, 3 explicit cancellation-policy replies; 555 matching pointer states',
                'Pointer terminal: 555 upstream stages x 2 fragmentation modes; 1141 presentations; passed']
            assert (folder/'queries.log').read_text(encoding='utf-8-sig').strip()=='Query suite passed'
        elif compiler=='msvc':
            assert 'Do not compile this code base with NDEBUG defined!' in (folder/'terminal-build.log').read_text(encoding='utf-8-sig')
            assert not (folder/'terminal.log').exists()
        else:
            log=(folder/'terminal.log').read_text()
            assert log.count('pointer reply mismatch')==6
            assert '1139 presentations; FAILED' in log
    for p in base.rglob('*'):
        if p.is_file():files[short+'/'+p.relative_to(base).as_posix()]=p.read_bytes()
    for name,raw in blobs.items():files[short+'/source/'+name]=raw
archive=work/'research/pointer-shape-evidence/terminal-fe4b9a9.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for record in records:assert sha(tar.extractfile(record['path']).read())==record['raw_sha256']
manifest=dict(runs=identities,compilers=['gcc','clang','msvc'],sanitizers=['gcc','clang'],
    terminal_stages_per_fragmentation=555,fragmentation_modes=['original chunks','bytewise'],
    exact_upstream_replies_per_mode=552,matching_pointer_states_per_mode=555,
    cancellation_policy_differences=['cancel-18/step-1','cancel-1a/step-1','cancel-1b5b306d/step-1'],
    component_checks_per_execution=4740,component_stages=504,lazy_state_bytes=34,
    source_matches=matches,
    scope='Real terminal parser and frontend callback model; Windows pointer display remains disconnected. No new product, native cursor pixel or memory acceptance. Local desktop testing remains paused.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
        archive_sha256=sha(archive.read_bytes()),records=records))
(work/'research/pointer-shape-terminal-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,source_matches=len(matches))))
