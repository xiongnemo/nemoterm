from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/pointer-shape-worktree'
base=root/'build/ci-pointer-drop-replay-068f87e';source='068f87ed5a92eaba7528b66bad03f0a8cc70fe2e'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'tabs-run.json').read_text())
assert (run['databaseId'],run['headSha'],run['conclusion'])==(43700206613,source,'success')
identity=json.loads((base/'diagnostic/identity.json').read_text(encoding='utf-8-sig'))
image_sha='862216d30cb5f5a27d9507c4e6ddfe7170de32f5871433c3af14f8f666b8cc6a'
assert identity['executable_sha256']==image_sha and identity['source_run']=='43699496703'
assert identity['fixture_commit']==source and identity['fixture']=='drop' and identity['frida_version'] is None
files={'controller.py':Path(__file__).read_bytes()};matches=[];replays=[]
for p in base.rglob('*'):
    if p.is_file():files[p.relative_to(base).as_posix()]=p.read_bytes()
for item in identity['fixture_hashes']:
    path=item['Path'].replace('\\','/')
    name=next(path[path.index('/'+prefix)+1:] for prefix in ('tests/','tools/') if '/'+prefix in path)
    raw=subprocess.check_output(['git','show',f'{source}:{name}'],cwd=work)
    expected=item['Hash'].lower()
    encoding='git_blob' if sha(raw)==expected else 'crlf_checkout' if sha(raw.replace(b'\n',b'\r\n'))==expected else None
    assert encoding,(name,expected)
    files['source/'+name]=raw;matches.append(dict(path=name,sha256=expected,encoding=encoding))
name='.github/workflows/tabs-close-replay.yml'
files['source/'+name]=subprocess.check_output(['git','show',f'{source}:{name}'],cwd=work)
subprocess.run(['git','diff','--exit-code',identity['source_commit'],source,'--','vendor','native',
    'scripts/build.ps1','scripts/build-single-exe.ps1','scripts/prepare-single-exe.py'],cwd=work,check=True)
for i in range(1,4):
    obs=json.loads((base/f'diagnostic/replay-{i}-observed.json').read_text())
    assert obs['completed'] and obs['exe_sha256']==image_sha and len(obs['checks'])==50
    assert len(obs['cleanup'])==6 and all(not r['terminated_remaining'] and r['after']['active']==0 for r in obs['cleanup'])
    parsers=obs['shell_parser_processes']
    assert {p['shell'] for p in parsers}=={'pwsh','powershell','git-bash'}
    assert all(p['completed'] and p['timeout_seconds']==20 for p in parsers)
    replays.append(dict(iteration=i,checks=len(obs['checks']),natural_cleanup=True,
        external_shell_seconds={p['shell']:p['elapsed_seconds'] for p in parsers}))
archive=work/'research/pointer-shape-evidence/drop-replay-068f87e.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for r in records:assert sha(tar.extractfile(r['path']).read())==r['raw_sha256']
manifest=dict(fixture_source=source,run=43700206613,executable_source=identity['source_commit'],executable_sha256=image_sha,
    source_matches=matches,replays=replays,
    scope='Three passing GDI drop replays against the exact failed image, with the original 20-second external-shell deadline. The initial timeout remains unexplained; this is not a product fix or full acceptance.',
    product_record='research/pointer-shape-windows-validation.json',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
        archive_sha256=sha(archive.read_bytes()),records=records))
(work/'research/pointer-drop-replay-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,source_matches=len(matches))))
