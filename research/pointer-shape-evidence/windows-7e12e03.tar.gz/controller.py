"""Retain the corrected native checkpoint and the first full-product failure."""
from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile

root = Path(__file__).resolve().parents[1]
work = root/'build/pointer-shape-worktree'
base = root/'build/ci-pointer-complete-7e12e03'
source = '7e12e03e5bb2824e7aaf82a5873f1e584ef6bc22'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
files = {'controller.py': Path(__file__).read_bytes()}
matches = []
for kind, run_id, conclusion in [('pointer-components',43699492458,'success'), ('single',43699496703,'failure')]:
    run = json.loads((base/(kind+'-run.json')).read_text())
    assert (run['databaseId'],run['headSha'],run['status'],run['conclusion']) == (run_id,source,'completed',conclusion)
    for f in base.glob(kind+'-*'):
        if f.is_file(): files[f.name] = f.read_bytes()
for folder in ('msvc','gcc','clang','single-evidence','unverified-product'):
    receipt = base/(folder+'-download.json')
    files[receipt.name] = receipt.read_bytes()
    for f in (base/folder).rglob('*'):
        if f.is_file(): files[f.relative_to(base).as_posix()] = f.read_bytes()

def blob(name):
    key = 'source/'+name
    if key not in files: files[key] = subprocess.check_output(['git','show',f'{source}:{name}'],cwd=work)
    return files[key]

def verify(name, expected):
    raw = blob(name)
    mode = 'git_blob' if sha(raw)==expected else 'crlf_checkout' if sha(raw.replace(b'\n',b'\r\n'))==expected else None
    assert mode,(name,expected)
    matches.append(dict(path=name,sha256=expected,encoding=mode))

for compiler in ('gcc','clang'):
    for f in (base/compiler).glob('*sources.sha256'):
        for line in f.read_text().splitlines():
            expected,name=line.split(maxsplit=1);verify(name.strip(),expected)
    assert '5580341 checks; 776 shape/size cases' in (base/compiler/'glyph.log').read_text()
    assert '555 upstream stages x 2 fragmentation modes' in (base/compiler/'terminal.log').read_text()
for f in (base/'msvc').glob('*sources.json'):
    for item in json.loads(f.read_text(encoding='utf-8-sig')):
        path=item['Path'].replace('\\','/')
        name=next(path[path.index('/'+p)+1:] for p in ('vendor/','tests/') if '/'+p in path)
        verify(name,item['Hash'].lower())
for name in ('tests/pointer_window_smoke.py','tests/drop_window_smoke.py','tests/session_fixture.py',
             'tests/mouse_fixture.py','tests/native_test_utils.py','tests/fixture_io.py','tests/owned_job.py',
             'tests/automation_window_smoke.py','tests/clipboard_test_utils.py','tools/nemoterm_debug.py',
             'vendor/putty-0.85/windows/nemo_debug_ui.inc','vendor/putty-0.85/windows/CMakeLists.txt',
             'scripts/build-single-exe.ps1','scripts/prepare-single-exe.py','scripts/test-single-exe.ps1',
             'native/single_exe/entry.cpp','.github/workflows/pointer-shapes.yml','.github/workflows/single-exe.yml'):
    blob(name)

focused = base/'msvc/pointer-single/nemoterm.exe'
focused_sha = sha(focused.read_bytes())
meta=json.loads((base/'msvc/pointer-single-image.json').read_text(encoding='utf-8-sig'))
assert focused_sha==meta['Hash'].lower()=='d02c4e4bf154236366dfef57594a7d20d7592500712d3fbc5a998ed91fa39cb8'
native=(base/'msvc/pointer-native.log').read_text(encoding='utf-8-sig')
assert '141028 checks; 30 shapes; 13 sizes; 104 custom cursors; 39000 cache reads; passed' in native
assert 'After atlases and cursor cleanup: user=1 gdi=3' in native
obs=json.loads((base/'msvc/research/pointer-native-window/observed.json').read_text())
assert obs['completed'] and obs['exit_code']==0 and obs['exe_sha256']==focused_sha
assert len(obs['checks'])==53 and len(obs['wire'])==44 and all(x['matched'] for x in obs['wire'])
assert len(obs['hidden_tab_samples'])==len(obs['outside_view_unchanged']['samples'])==30
assert not obs['cleanup']['terminated_remaining'] and obs['cleanup']['after']['active']==0

failed=base/'unverified-product/nemoterm.exe';failed_sha=sha(failed.read_bytes())
assert failed_sha=='862216d30cb5f5a27d9507c4e6ddfe7170de32f5871433c3af14f8f666b8cc6a'
drop=json.loads((base/'single-evidence/build/single-exe-check/research/drop-gdi-observed.json').read_text())
assert drop['exe_sha256']==failed_sha and len(drop['checks'])==13 and not drop.get('completed')
assert drop['checks'][-1]=='powershell: file and folder drop preserves shell quoting and bracketed paste'
failure_log=(base/'single-evidence/build/single-exe-check/logs/drop-gdi.log').read_text()
assert 'subprocess.TimeoutExpired' in failure_log and 'powershell.exe' in failure_log and 'timed out after 20 seconds' in failure_log

archive=work/'research/pointer-shape-evidence/windows-7e12e03.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for r in records:assert sha(tar.extractfile(r['path']).read())==r['raw_sha256']
manifest=dict(source=source,source_matches=matches,
    pointer_run=dict(id=43699492458,conclusion='success',executable_sha256=focused_sha,executable_bytes=focused.stat().st_size,
        native_resource_checks=141028,native_cursor_checks=53,wire_round_trips=44,glyph_checks_per_linux_compiler=5580341,
        cleanup=obs['cleanup'],limits='Remote default-DPI cursor checkpoint, not complete product or local memory acceptance.'),
    full_single_run=dict(id=43699496703,conclusion='failure',executable_sha256=failed_sha,executable_bytes=failed.stat().st_size,
        failure='Standalone Windows PowerShell argument-parser process exceeded the original 20-second deadline after terminal path bytes passed.',
        completed_drop_checks=13,limits='The early failure prevents later protocol, graphics and memory gates; do not promote this executable.'),
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
                archive_sha256=sha(archive.read_bytes()),records=records))
(work/'research/pointer-shape-windows-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,source_matches=len(matches))))
