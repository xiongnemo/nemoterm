"""Retain exact-source remote cursor diagnostics, including failed observations."""
from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile

root = Path(__file__).resolve().parents[1]
work = root/'build/pointer-shape-worktree'
digest = lambda raw: hashlib.sha256(raw).hexdigest()
specs = [
    ('49e13b154aad482415e01c731346685fcf6aaaa4', 43697828780, 'ci-pointer-single-49e13b1', 'pointer-components', 'failure'),
    ('bbdd37fb7e05c20cb3f4bec5fc8ca705d12b7796', 43698295314, 'ci-pointer-glyph-bbdd37f', 'pointer-components', 'success'),
    ('25eccbf8dc482702db87c229e86bd93192a628b5', 43698751106, 'ci-pointer-replay-25eccbf', 'pointer-window', 'failure'),
    ('a101a9de711cf7073609c78c0f363e13a2e608f0', 43698989783, 'ci-pointer-replay-a101a9d', 'pointer-window', 'failure'),
    ('7e12e03e5bb2824e7aaf82a5873f1e584ef6bc22', 43699397756, 'ci-pointer-replay-7e12e03', 'pointer-window', 'success'),
]
paths = (
    'vendor/putty-0.85/terminal/nemo_pointer.c', 'vendor/putty-0.85/terminal/nemo_pointer.h',
    'vendor/putty-0.85/windows/nemo_pointer_win.c', 'vendor/putty-0.85/windows/nemo_pointer_win.h',
    'vendor/putty-0.85/windows/nemo_pointer_glyph.c', 'vendor/putty-0.85/windows/nemo_pointer_glyph.h',
    'vendor/putty-0.85/windows/window.c', 'vendor/putty-0.85/windows/win-gui-seat.h',
    'vendor/putty-0.85/windows/nemo_link_ui.c', 'vendor/putty-0.85/windows/nemo_tabs_host.inc',
    'vendor/putty-0.85/windows/nemo_debug_ui.inc', 'vendor/putty-0.85/windows/CMakeLists.txt',
    'tests/test_pointer_cursor.c', 'tests/test_pointer_glyph.c', 'tests/pointer_window_smoke.py',
    'tests/session_fixture.py', 'tests/mouse_fixture.py', 'tests/native_test_utils.py',
    'tests/owned_job.py', 'tests/fixture_io.py', 'tools/nemoterm_debug.py',
    '.github/workflows/pointer-shapes.yml', '.github/workflows/protocol-reference.yml',
)
files = {'controller.py': Path(__file__).read_bytes()}
runs, matches = [], []

def source_blob(source, name):
    key = source[:7]+'/source/'+name
    if key not in files:
        files[key] = subprocess.check_output(['git', 'show', f'{source}:{name}'], cwd=work)
    return files[key]

def verify_source(source, name, expected):
    blob = source_blob(source, name)
    encoding = 'git_blob' if digest(blob) == expected else (
        'crlf_checkout' if digest(blob.replace(b'\n', b'\r\n')) == expected else None)
    assert encoding, (source, name, expected)
    matches.append(dict(source=source, path=name, sha256=expected, encoding=encoding))

image_sha = '2627957c29e54cc6a79bcf61e61eac06381563be4fd070b95c04c2f8271bde1b'
for source, run_id, folder, kind, conclusion in specs:
    base = root/'build'/folder
    run = json.loads((base/(kind+'-run.json')).read_text())
    assert (run['headSha'], run['databaseId'], run['status'], run['conclusion']) == (
        source, run_id, 'completed', conclusion)
    item = dict(source=source, run=run_id, url=run['url'], conclusion=conclusion)
    for name in paths: source_blob(source, name)
    for manifest in base.rglob('*sources.sha256'):
        for line in manifest.read_text().splitlines():
            expected, name = line.split(maxsplit=1)
            verify_source(source, name.strip(), expected)
    for manifest in base.rglob('*sources.json'):
        for entry in json.loads(manifest.read_text(encoding='utf-8-sig')):
            path = entry['Path'].replace('\\', '/')
            name = next(path[path.index('/'+prefix)+1:] for prefix in ('vendor/', 'tests/') if '/'+prefix in path)
            verify_source(source, name, entry['Hash'].lower())
    if source.startswith('49e13b1'):
        image = base/'msvc/pointer-single/nemoterm.exe'
        assert digest(image.read_bytes()) == image_sha
        meta = json.loads((base/'msvc/pointer-single-image.json').read_text(encoding='utf-8-sig'))
        assert meta['Hash'].lower() == image_sha
        log = (base/'msvc/pointer-native.log').read_text(encoding='utf-8-sig')
        assert '141028 checks; 30 shapes; 13 sizes; 104 custom cursors; 39000 cache reads; passed' in log
        assert 'cold=0 first=3 repeated=3' in log and 'After atlases and cursor cleanup: user=1 gdi=3' in log
        assert len(list((base/'msvc').glob('pointer-mask-*.bin'))) == 104
        for compiler in ('gcc', 'clang'):
            assert 'hy*stride+hx/8' in (base/compiler/'glyph.log').read_text()
        observed = json.loads((base/'msvc/research/pointer-native-window/observed.json').read_text())
        assert observed['checks'] == [] and observed['wire'][0]['matched']
        item.update(single_image=dict(sha256=image_sha, bytes=image.stat().st_size),
                    native_resource_checks=141028, custom_cursors=104,
                    observer_control_gdi=[0, 3, 3], final_resources=dict(user=1, gdi=3),
                    limits='Glyph hotspot tests fail at some fractional sizes; first actual cursor read fails after a successful OSC 22 round trip.')
    elif source.startswith('bbdd37f'):
        for compiler in ('gcc', 'clang'):
            assert '5580341 checks; 776 shape/size cases' in (base/compiler/'glyph.log').read_text()
            assert '555 upstream stages x 2 fragmentation modes' in (base/compiler/'terminal.log').read_text()
        item.update(glyph_checks_per_compiler=5580341, glyph_cases=776,
                    compilers=['GCC ASan/UBSan', 'Clang ASan/UBSan'],
                    limits='Linux components and terminal replay only; MSVC intentionally skipped.')
    else:
        source_blob(source, '.github/workflows/pointer-window-replay.yml')
        replay = json.loads((base/'diagnostic/pointer-replay-identity.json').read_text())
        assert replay['source_commit'] == specs[0][0] and replay['executable_sha256'] == image_sha
        assert replay['artifact_id'] == 14155004108 and replay['fixture_commit'] == source
        for name, expected in replay['fixture_sha256'].items(): verify_source(source, name, expected)
        observed = json.loads((base/'diagnostic/research/pointer-native-window/observed.json').read_text())
        assert observed['exe_sha256'] == image_sha
        assert not observed['cleanup']['terminated_remaining'] and observed['cleanup']['after']['active'] == 0
        assert all(w['matched'] for w in observed['wire'])
        item.update(executable_source=specs[0][0], executable_sha256=image_sha,
                    cursor_checks=len(observed['checks']), wire_round_trips=len(observed['wire']),
                    cleanup=observed['cleanup'], error=observed.get('error'))
        if source.startswith('25eccbf'):
            samples = observed['pointer_failure']['samples']
            assert observed['checks'] == [] and samples and all(s['flags'] == 2 and not s['handle'] for s in samples)
            item['diagnosis'] = 'CURSOR_SUPPRESSED with no selected cursor; SetCursorPos alone did not deliver mouse-class input.'
        elif source.startswith('a101a9d'):
            assert len(observed['checks']) == 51 and not observed.get('completed')
            item['diagnosis'] = 'Actual mouse-class input clears suppression and 51 checks pass; tab-strip baseline sampled before its queued cursor update.'
        else:
            assert observed['completed'] and observed['exit_code'] == 0 and len(observed['checks']) == 53
            assert len(observed['hidden_tab_samples']) == len(observed['outside_view_unchanged']['samples']) == 30
            assert len(observed['wire']) == 44
            item['diagnosis'] = '53 native cursor checks, 44 exact OSC 22 replies, hidden-tab and tab-strip isolation, natural five-process exit.'
        item['limits'] = 'Exact older 49e13b1 single-image diagnostic at runner default DPI; does not test the later hotspot fix, current product memory, or the user desktop.'
    for path in base.rglob('*'):
        if path.is_file(): files[source[:7]+'/'+path.relative_to(base).as_posix()] = path.read_bytes()
    runs.append(item)

archive = work/'research/pointer-shape-evidence/native-diagnostics-7e12e03.tar.gz'
records = []
with archive.open('xb') as out, gzip.GzipFile(filename='', fileobj=out, mode='wb', mtime=0) as gz, tarfile.open(fileobj=gz, mode='w|') as tar:
    for name, raw in sorted(files.items()):
        info = tarfile.TarInfo(name); info.size = len(raw); tar.addfile(info, io.BytesIO(raw))
        records.append(dict(path=name, raw_bytes=len(raw), raw_sha256=digest(raw)))
with tarfile.open(archive) as tar:
    for record in records: assert digest(tar.extractfile(record['path']).read()) == record['raw_sha256']
manifest = dict(runs=runs, source_matches=matches,
    scope='Retained failed and successful remote diagnostics; accepted local executable unchanged.',
    bundle=dict(path=archive.relative_to(work).as_posix(), archive_bytes=archive.stat().st_size,
                archive_sha256=digest(archive.read_bytes()), records=records))
(work/'research/pointer-shape-native-diagnostic-validation.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(dict(runs=len(runs), records=len(records), bytes=archive.stat().st_size, source_matches=len(matches))))
