from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile

root=Path(__file__).resolve().parents[1]
work=root/'build/pointer-shape-worktree'
base=root/'build/ci-pointer-components-51fe4b2'
source='51fe4b2cc6bbf0cc5d74f7a18adcccb3a4730160'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'pointer-components-run.json').read_text())
assert run['headSha']==source and run['conclusion']=='success' and run['databaseId']==43693144294
assert len([j for j in run['jobs'] if j['conclusion']=='success'])==3
paths=('vendor/putty-0.85/terminal/nemo_pointer.c','vendor/putty-0.85/terminal/nemo_pointer.h',
       'tests/test_pointer_shapes.c','tests/pointer_shape_reference.h')
blobs={p:subprocess.check_output(['git','show',f'{source}:{p}'],cwd=work) for p in paths}
source_matches=[]
for compiler in ('gcc','clang','msvc'):
    p=base/compiler
    assert (p/'normal.log').read_text(encoding='utf-8-sig').strip()=='Pointer component: 4740 checks; 504 independent stages; 34 state bytes'
    if compiler!='msvc':
        assert (p/'sanitizers.log').read_text().strip()=='Pointer component: 4740 checks; 504 independent stages; 34 state bytes'
        hashes=[line.split() for line in (p/'sources.sha256').read_text().splitlines()]
        hashes=[(name,digest) for digest,name in hashes]
    else:
        hashes=[]
        for entry in json.loads((p/'sources.json').read_text(encoding='utf-8-sig')):
            name=next(path for path in paths if entry['Path'].replace('\\','/').endswith('/'+path))
            hashes.append((name,entry['Hash'].lower()))
    assert len(hashes)==4
    for name,digest in hashes:
        blob=blobs[name]
        match='git_blob' if digest==sha(blob) else 'crlf_checkout' if digest==sha(blob.replace(b'\n',b'\r\n')) else None
        assert match,(compiler,name,digest)
        source_matches.append(dict(compiler=compiler,path=name,sha256=digest,encoding=match))
files={p.relative_to(base).as_posix():p.read_bytes() for p in base.rglob('*') if p.is_file()}
files['controller.py']=Path(__file__).read_bytes()
for name,blob in blobs.items():files['source/'+name]=blob
archive=work/'research/pointer-shape-evidence/components-51fe4b2.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for r in records:assert sha(tar.extractfile(r['path']).read())==r['raw_sha256']
manifest=dict(run=run['databaseId'],url=run['url'],source=source,
    compilers=['gcc','clang','msvc'],sanitizers=['gcc','clang'],
    checks_per_execution=4740,independent_stages=504,state_bytes=34,source_matches=source_matches,
    scope='Standalone complete-payload component only; no terminal dispatch, native pointer, full-product or process memory acceptance.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
        archive_sha256=sha(archive.read_bytes()),records=records))
(work/'research/pointer-shape-component-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,source_matches=len(source_matches))))
