from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile

root=Path(__file__).resolve().parents[1];work=root/'build/pointer-shape-worktree'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
specs=[
 ('20517a777f57bdd6e564ee90df8e2bc84aa059ce',43696036146,'ci-pointer-native-20517a7','wrong fixture executable output name; native resource test not reached'),
 ('b54d2e844b311f05b52df58a13efbcc263c89ec8',43696254901,'ci-pointer-native-b54d2e8','post-atlas GDI baseline assertion'),
 ('41d980746247946f8909ce0f414451dde465f884',43696811396,'ci-pointer-window-41d9807','post-atlas GDI baseline assertion; monochrome observer control did not account for colour-atlas resources'),
 ('63d010b3dd826bd40c7b9dcf6c5c8f466d35e7ab',43697085659,'ci-pointer-window-63d010b','post-atlas GDI baseline assertion and system-ConPTY first-query timeout')]
paths=('vendor/putty-0.85/windows/nemo_pointer_win.c','vendor/putty-0.85/windows/nemo_pointer_win.h',
 'vendor/putty-0.85/windows/nemo_pointer_glyph.c','vendor/putty-0.85/windows/nemo_pointer_glyph.h',
 'vendor/putty-0.85/windows/window.c','vendor/putty-0.85/windows/win-gui-seat.h',
 'vendor/putty-0.85/windows/nemo_link_ui.c','vendor/putty-0.85/windows/nemo_tabs_host.inc',
 'tests/test_pointer_cursor.c')
files={'controller.py':Path(__file__).read_bytes()};runs=[];source_matches=[]
for source,run_id,folder,reason in specs:
    base=root/'build'/folder;short=source[:7]
    run=json.loads((base/'pointer-components-run.json').read_text())
    assert (run['headSha'],run['databaseId'],run['conclusion'])==(source,run_id,'failure')
    jobs=[j for j in run['jobs'] if j['name'].startswith('pointer-components /')]
    assert len(jobs)==3 and [j['conclusion'] for j in jobs].count('success')==2
    blobs={p:subprocess.check_output(['git','show',f'{source}:{p}'],cwd=work) for p in paths}
    for item in json.loads((base/'msvc/pointer-native-sources.json').read_text(encoding='utf-8-sig')):
        name=next(p for p in paths if item['Path'].replace('\\','/').endswith('/'+p))
        digest=item['Hash'].lower();blob=blobs[name]
        encoding='git_blob' if digest==sha(blob) else 'crlf_checkout' if digest==sha(blob.replace(b'\n',b'\r\n')) else None
        assert encoding,(source,name,digest)
        source_matches.append(dict(source=source,path=name,sha256=digest,encoding=encoding))
    record=dict(source=source,run=run_id,url=run['url'],failure=reason)
    image=base/'msvc/pointer-terminal-build/nemoterm.exe'
    if short=='20517a7':
        assert not image.exists();record['exact_frontend_retained']=False
    else:
        metadata=json.loads((base/'msvc/pointer-frontend.json').read_text(encoding='utf-8-sig'))
        digest=sha(image.read_bytes());assert digest==metadata['Hash'].lower()
        record['frontend']=dict(bytes=image.stat().st_size,sha256=digest)
        log=(base/'msvc/pointer-native.log').read_text(encoding='utf-8-sig')
        assert 'GR_GDIOBJECTS) <= baseline_gdi' in log
        assert all((base/f'msvc/pointer-atlas-{size}.bmp').is_file() for size in (32,48,96))
        if short in ('41d9807','63d010b'):
            assert len(list((base/'msvc').glob('pointer-mask-*.bin')))==104
            assert 'warmed user=105 gdi=104' in log and 'user=1 gdi=3' in log
    if short=='63d010b':
        observed=json.loads((base/'msvc/research/pointer-native-window/observed.json').read_text())
        assert observed['checks']==[] and not observed.get('completed')
        assert observed['exe_sha256']==record['frontend']['sha256']
        assert not observed['cleanup']['terminated_remaining'] and observed['cleanup']['after']['active']==0
        record['window_failure']=dict(checks=0,first_query_timeout=True,natural_cleanup=True,
            limits='No raw child report or traffic log retained by this first fixture; cannot locate which side of the system-host path omitted the reply.')
    for p in base.rglob('*'):
        if p.is_file():
            # These three local previews were derived from the retained BMPs;
            # keep original CI records in this bundle, not duplicate conversions.
            if p.name in ('pointer-atlas-32.png','pointer-atlas-96.png','zoom-out-detail.png'):continue
            files[short+'/'+p.relative_to(base).as_posix()]=p.read_bytes()
    for name,raw in blobs.items():files[short+'/source/'+name]=raw
    for name in ('.github/workflows/pointer-shapes.yml','vendor/putty-0.85/windows/CMakeLists.txt'):
        files[short+'/source/'+name]=subprocess.check_output(['git','show',f'{source}:{name}'],cwd=work)
    if short in ('41d9807','63d010b'):
        name='tests/pointer_window_smoke.py'
        files[short+'/source/'+name]=subprocess.check_output(['git','show',f'{source}:{name}'],cwd=work)
    runs.append(record)
archive=work/'research/pointer-shape-evidence/native-initial-failures.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for r in records:assert sha(tar.extractfile(r['path']).read())==r['raw_sha256']
manifest=dict(runs=runs,source_matches=source_matches,
    scope='Failed Windows resource/window diagnostics; no product or local acceptance. All runs predate the fractional-size hotspot fix.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
      archive_sha256=sha(archive.read_bytes()),records=records))
(work/'research/pointer-shape-native-initial-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,source_matches=len(source_matches))))
