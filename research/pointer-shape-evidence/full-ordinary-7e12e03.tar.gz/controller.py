"""Stream the complete ordinary CI checkpoint without loading pixel records into RAM."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile

root=Path(__file__).resolve().parents[1];work=root/'build/pointer-shape-worktree'
base=root/'build/ci-pointer-complete-7e12e03';source='7e12e03e5bb2824e7aaf82a5873f1e584ef6bc22'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
sha=lambda data:hashlib.sha256(data).hexdigest()
run=json.loads((base/'ordinary-run.json').read_text())
assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(43699494654,source,'completed','success')
assert len(run['jobs'])==4 and all(j['conclusion']=='success' for j in run['jobs'])
frontend=base/'portable/nemoterm.exe';image_sha=digest(frontend)
host=json.loads((base/'portable/SOURCE-HOST.json').read_text(encoding='utf-8-sig'))
assert host['SourceCommit']==source and digest(base/'portable/OpenConsole.exe')==host['Executable']['SHA256']
assert host['MicrosoftTerminalCommit']=='f6de9e0618015def1c9dda5b82f9d3abf03eb799'
workloads=[]
for path in sorted((base/'core-evidence').rglob('*workload-tabs-*-observed.json')):
    data=json.loads(path.read_text())
    assert data['completed'] and data['memory_limit_passed'] and data['executable_sha256']==image_sha
    assert not data['memory_instrumented'] and not data['process_tree_memory']['injected']
    assert data['memory_limit_required']
    is_dx=data['renderer']=='directx'
    expected_limit=25000000 if is_dx else 20000000
    assert data['memory_limit_bytes']==expected_limit and data['memory_limit_inclusive']==is_dx
    assert data['peak_private_ws']<=expected_limit if is_dx else data['peak_private_ws']<expected_limit
    assert not data['owned_job_cleanup']['terminated_remaining'] and data['owned_job_cleanup']['after']['active']==0
    record=dict(path=path.relative_to(base).as_posix(),renderer=data['renderer'],actual_renderer=data['actual_renderer'],
        font=data['font'],grid=data['actual_grid'],frontend_peaks=data['process_tree_memory']['peaks']['frontend'],
        private_limit_bytes=expected_limit,passed=True,natural_cleanup=True)
    if path.name.startswith('unicode-'):
        observations=data['post_memory_kitty_unicode']
        assert len(observations)==4 and all(x['matched'] and x['after_memory_sampling'] and not x['injected'] for x in observations)
        record['post_memory_cells']=sum(x['cells_verified'] for x in observations)
    workloads.append(record)
assert len(workloads)==12 and sum(w.get('post_memory_cells',0) for w in workloads)==25048

entries={'controller.py':Path(__file__)}
for path in base.glob('ordinary-*'):
    if path.is_file():entries[path.name]=path
for folder,artifact_id in [('core-evidence',14156239362),('ordinary-msvc',14155443800),('sanitizers',14155732724),('portable',14157222414)]:
    receipt=base/(folder+'-download.json')
    assert json.loads(receipt.read_text())['artifact_id']==artifact_id
    entries[receipt.name]=receipt
    for path in (base/folder).rglob('*'):
        if path.is_file():entries[path.relative_to(base).as_posix()]=path
# The shared 'msvc' download directory previously held both workflow kinds.
# Use only the fresh ordinary-msvc download above, never that mixed directory.
for name in ('.github/workflows/ci.yml','scripts/build.ps1','scripts/test.ps1','scripts/build-single-exe.ps1',
             'scripts/prepare-single-exe.py','native/single_exe/entry.cpp','tests/tabs_window_smoke.py',
             'tests/tab_workload_memory.py','tests/memory_limits.py','tests/native_test_utils.py','tests/owned_job.py'):
    entries['source/'+name]=subprocess.check_output(['git','show',f'{source}:{name}'],cwd=work)
source_matches=[]
for name,key in [('scripts/prepare-single-exe.py','OverlaySHA256'),('native/single_exe/entry.cpp','EntrySHA256')]:
    raw=entries['source/'+name];expected=host[key]
    encoding='git_blob' if sha(raw)==expected else 'crlf_checkout' if sha(raw.replace(b'\n',b'\r\n'))==expected else None
    assert encoding,(name,expected)
    source_matches.append(dict(path=name,sha256=expected,encoding=encoding))
archive=work/'research/pointer-shape-evidence/full-ordinary-7e12e03.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,value in sorted(entries.items()):
        info=tarfile.TarInfo(name)
        if isinstance(value,bytes):
            info.size=len(value);checksum=sha(value);tar.addfile(info,io.BytesIO(value))
        else:
            info.size=value.stat().st_size;checksum=digest(value)
            with value.open('rb') as stream:tar.addfile(info,stream)
        records.append(dict(path=name,raw_bytes=info.size,raw_sha256=checksum))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records):
        assert member.name==record['path']
        assert hashlib.file_digest(tar.extractfile(member),'sha256').hexdigest()==record['raw_sha256']
manifest=dict(source=source,run=43699494654,conclusion='success',jobs=4,
    frontend=dict(sha256=image_sha,bytes=frontend.stat().st_size),source_console_host=host,source_matches=source_matches,workloads=workloads,
    limits='Ordinary portable MinGW frontend and its identified source host; remote Consolas grids only. This is not the single-image distribution or local 160x48 Sarasa acceptance. DirectX total working set remains above the roughly 50 MB goal.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
        archive_sha256=digest(archive),records=records))
(work/'research/pointer-shape-ordinary-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,workloads=len(workloads))))
