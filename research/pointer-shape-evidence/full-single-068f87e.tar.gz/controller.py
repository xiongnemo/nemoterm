"""Retain the complete successful single-image checkpoint, streaming large evidence."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/pointer-shape-worktree'
base=root/'build/ci-pointer-single-068f87e';source='068f87ed5a92eaba7528b66bad03f0a8cc70fe2e'
pointer_source='7e12e03e5bb2824e7aaf82a5873f1e584ef6bc22'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'single-run.json').read_text())
assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(43700454093,source,'completed','success')
assert len(run['jobs'])==1 and run['jobs'][0]['conclusion']=='success'
research=base/'single-evidence/build/single-exe-check/research'
validation=json.loads((research/'single-exe-validation.json').read_text(encoding='utf-8-sig'))
image=base/'product/nemoterm.exe';image_sha=digest(image)
assert image_sha==validation['executable_sha256']=='81fa088331057f694472a6c32583bd42097c35e27431cae14c7fe0164756f4d5'
assert image.stat().st_size==validation['executable_bytes']==4532224
assert len(validation['passed_checks'])==len(set(validation['passed_checks']))==154
assert validation['executable_directory_files']==['nemoterm.exe']
paths=['vendor','native','scripts/build.ps1','scripts/build-single-exe.ps1','scripts/prepare-single-exe.py']
subprocess.run(['git','diff','--exit-code',pointer_source,source,'--',*paths],cwd=work,check=True)
workloads=[]
for path in sorted(research.glob('*workload-tabs-*-observed.json')):
    data=json.loads(path.read_text())
    assert data['completed'] and data['memory_limit_passed'] and data['executable_sha256']==image_sha
    assert not data['memory_instrumented'] and not data['process_tree_memory']['injected']
    assert data['memory_limit_required'] and not data['process_tree_memory']['errors']
    dx=data['renderer']=='directx';limit=25000000 if dx else 20000000
    assert data['memory_limit_bytes']==limit and data['memory_limit_inclusive']==dx
    assert data['peak_private_ws']<=limit if dx else data['peak_private_ws']<limit
    cleanup=data['owned_job_cleanup']
    assert not cleanup['terminated_remaining'] and cleanup['after']['active']==0
    record=dict(path=path.relative_to(base).as_posix(),renderer=data['renderer'],actual_renderer=data['actual_renderer'],
        font=data['font'],grid=data['actual_grid'],frontend_peaks=data['process_tree_memory']['peaks']['frontend'],
        process_tree_peaks=data['process_tree_memory']['peaks'],private_limit_bytes=limit,passed=True,natural_cleanup=True)
    if path.name.startswith('unicode-'):
        samples=data['post_memory_kitty_unicode']
        assert len(samples)==4 and all(x['matched'] and x['after_memory_sampling'] and not x['injected'] for x in samples)
        record['post_memory_cells']=sum(x['cells_verified'] for x in samples)
    workloads.append(record)
assert len(workloads)==12 and sum(x.get('post_memory_cells',0) for x in workloads)==25048
drops=[]
for renderer in ('gdi','directx'):
    data=json.loads((research/f'drop-{renderer}-observed.json').read_text())
    assert data['completed'] and data['exe_sha256']==image_sha and len(data['checks'])==50
    assert all(not c['terminated_remaining'] and c['after']['active']==0 for c in data['cleanup'])
    parsers=data['shell_parser_processes']
    assert all(p['completed'] and p['timeout_seconds']==20 for p in parsers)
    drops.append(dict(renderer=renderer,checks=50,external_shell_seconds={p['shell']:p['elapsed_seconds'] for p in parsers}))
artifacts=json.loads((base/'single-artifacts.json').read_text())['artifacts']
product=next(a for a in artifacts if a['id']==14158135421)
assert product['name']=='nemoterm-single-exe-x64-'+source and not product['expired']
entries={'controller.py':Path(__file__)}
for path in base.rglob('*'):
    if path.is_file():entries[path.relative_to(base).as_posix()]=path
for name in ('.github/workflows/single-exe.yml','scripts/build-single-exe.ps1','scripts/test-single-exe.ps1',
             'scripts/prepare-single-exe.py','native/single_exe/entry.cpp','tests/drop_window_smoke.py',
             'tests/tabs_window_smoke.py','tests/tab_workload_memory.py','tests/memory_limits.py',
             'tests/native_test_utils.py','tests/owned_job.py'):
    entries['source/'+name]=subprocess.check_output(['git','show',f'{source}:{name}'],cwd=work)
archive=work/'research/pointer-shape-evidence/full-single-068f87e.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,value in sorted(entries.items()):
        info=tarfile.TarInfo(name)
        if isinstance(value,bytes):
            info.size=len(value);checksum=sha(value);tar.addfile(info,io.BytesIO(value))
        else:
            info.size=value.stat().st_size;checksum=digest(value)
            with value.open('rb') as stream:tar.addfile(info,stream)
        records.append(dict(path=name,raw_bytes=info.size,raw_sha256=checksum))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records):
        assert member.name==record['path'] and hashlib.file_digest(tar.extractfile(member),'sha256').hexdigest()==record['raw_sha256']
manifest=dict(source=source,run=43700454093,conclusion='success',validation=validation,
    production_equivalence=dict(source=pointer_source,paths=paths,git_diff_exit=0,
        scope='Same production source as ordinary CI and focused cursor tests; these were separately linked binaries.'),
    product_artifact=dict(id=product['id'],name=product['name'],expires_at=product['expires_at'],
        url=f"https://github.com/xiongnemo/nemoterm/actions/runs/43700454093/artifacts/{product['id']}"),
    workloads=workloads,drops=drops,
    limits='Remote Consolas grids; not local 160x48 Sarasa acceptance. The GDI total target is approximately 50 MB. Current DX memory is accepted by the user; no further DX optimization is required. The first standalone PowerShell timeout remains unexplained.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
        archive_sha256=digest(archive),records=records))
(work/'research/pointer-shape-single-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,checks=len(validation['passed_checks']),
    artifact_id=product['id'],expires_at=product['expires_at'],drops=drops)))
