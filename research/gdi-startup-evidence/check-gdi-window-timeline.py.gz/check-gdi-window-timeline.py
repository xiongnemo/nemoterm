from pathlib import Path
root=Path(__file__).resolve().parents[1]
original=(root/'build/check-gdi-fast-windows.py').read_text(encoding='utf-8')
source=original.replace("dest=root/'build/gdi-fast-windows'","dest=root/'build/gdi-window-timeline-02'")
assert source!=original
source=source.replace("replace('            for i in range(12):',",'''replace('        try:\\n            if args.workload_memory:',"""        timeline_stop=threading.Event();evidence['startup_timeline']=[]
        def observe_startup():
            deadline=time.monotonic()+15
            try:
                while not timeline_stop.is_set() and time.monotonic()<deadline:
                    count=w.DWORD()
                    if not k.GetProcessHandleCount(handle,c.byref(count)):raise c.WinError()
                    state=owned_window_metadata(process.pid,'startup')
                    state.update(handles=count.value,gdi=u.GetGuiResources(handle,0),user=u.GetGuiResources(handle,1))
                    evidence['startup_timeline'].append(state)
                    timeline_stop.wait(.02)
            except BaseException as error:evidence['startup_observer_error']=repr(error)
        timeline_thread=threading.Thread(target=observe_startup,daemon=True);timeline_thread.start()
        try:
            if args.workload_memory:""")
replace('            for i in range(12):',''')
source=source.replace("                    evidence['failure_metadata']=full_metadata('failure')", "                    timeline_stop.set();timeline_thread.join(2)\n                    evidence['failure_metadata']=full_metadata('failure')")
a='replace("            evidence[\'completed\']=True", "            evidence[\'final_metadata\']=full_metadata(\'final\')\\n            evidence[\'diagnostic_completed\']=True\\n            raise SystemExit(2)")'
b='''replace("            evidence['checks'].append('12 create/close cycles retain one shared renderer without handle growth')",
    "            timeline_stop.set();timeline_thread.join(2)\\n            evidence['post_cycles_metadata']=full_metadata('post-cycles')\\n            evidence['checks'].append('12 create/close cycles retain one shared renderer without handle growth')")
replace("            evidence['completed']=True", "            evidence['diagnostic_completed']=True\\n            raise SystemExit(2)")
replace('        finally:\\n            try:', '        finally:\\n            timeline_stop.set();timeline_thread.join(2)\\n            try:')'''
assert source.count(a)==1;source=source.replace(a,b)
source=source.replace("purpose='Fast owned window class/module metadata adjacent to original baseline and samples; slow handle/thread queries only after failure or full workload'", "purpose='Bounded 15-second external startup timeline, owned window classes and original assertions; module catalogue before shutdown; no memory acceptance'")
compile(source,'timeline-preparation','exec')
(root/'build/check-gdi-window-timeline-expanded.py').write_text(source,encoding='utf-8')
exec(compile(source,str(__file__),'exec'))
