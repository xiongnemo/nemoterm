import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
source_root=root.parent/'io-lifetime-worktree'
exe=source_root/'build/ci-io-7a3b95e/product/nemoterm.exe'
dest=root/'build/gdi-fast-windows';assert not dest.exists()
for folder in ('dist','research','build'):(dest/folder).mkdir(parents=True,exist_ok=True)
shutil.copytree(source_root/'tests',dest/'tests')
for name in ('thread_snapshot.py','handle_snapshot.py'):
    shutil.copy2(root/'tests'/name,dest/'tests'/name)
shutil.copy2(exe,dest/'dist')
p=dest/'tests/tabs_window_smoke.py';original=p.read_text(encoding='utf-8');source=original
def replace(a,b):
    global source
    assert source.count(a)==1,a;source=source.replace(a,b)
helper='''u.GetClassLongPtrW.argtypes,u.GetClassLongPtrW.restype=[w.HWND,c.c_int],c.c_size_t
u.GetWindowLongPtrW.argtypes,u.GetWindowLongPtrW.restype=[w.HWND,c.c_int],c.c_ssize_t

def owned_window_metadata(pid,label):
    found={};begun=time.monotonic()
    def record(hwnd):
        owner=w.DWORD();tid=u.GetWindowThreadProcessId(hwnd,c.byref(owner))
        if owner.value!=pid:return
        name=c.create_unicode_buffer(256);u.GetClassNameW(hwnd,name,len(name))
        found[int(hwnd)]=dict(hwnd=int(hwnd),tid=tid,kind=name.value,
            parent=int(u.GetParent(hwnd) or 0),visible=bool(u.IsWindowVisible(hwnd)),
            class_module=u.GetClassLongPtrW(hwnd,-16),instance=u.GetWindowLongPtrW(hwnd,-6))
    @callback
    def child(hwnd,_):record(hwnd);return True
    @callback
    def top(hwnd,_):
        owner=w.DWORD();u.GetWindowThreadProcessId(hwnd,c.byref(owner))
        if owner.value==pid:record(hwnd);u.EnumChildWindows(hwnd,child,0)
        return True
    u.EnumWindows(top,0)
    return dict(label=label,windows=list(found.values()),begun=begun,seconds=time.monotonic()-begun)

'''
replace('evidence=dict(executable_sha256=',helper+'evidence=dict(executable_sha256=')
replace('            for i in range(12):',"""            evidence.update(memory_acceptance=False,window_timeline=[owned_window_metadata(process.pid,'baseline')])
            def full_metadata(label):
                from thread_snapshot import OwnedThreadSnapshot
                from handle_snapshot import OwnedHandleSnapshot
                return dict(label=label,windows=owned_window_metadata(process.pid,label),
                    handles=OwnedHandleSnapshot(process,job).snapshot(label),
                    threads=OwnedThreadSnapshot(process,job).snapshot(label),resources=resources())
            for i in range(12):""")
needle="                assert sample['handles']<=baseline['handles']+6,(baseline,sample)"
replace(needle,"""                evidence['window_timeline'].append(owned_window_metadata(process.pid,'cycle-'+str(i)))
                if (sample['handles']>baseline['handles']+6 or sample['gdi']>baseline['gdi']+3
                        or sample['user']>baseline['user']+2):
                    evidence['failure_before_observation']=dict(cycle=i,baseline=baseline,sample=sample)
                    evidence['failure_metadata']=full_metadata('failure')
"""+needle)
replace("            evidence['completed']=True", "            evidence['final_metadata']=full_metadata('final')\n            evidence['diagnostic_completed']=True\n            raise SystemExit(2)")
compile(source,str(p),'exec');p.write_text(source,encoding='utf-8')
(dest/'research/diagnostic-fixture.json').write_text(json.dumps(dict(
    original_sha256=hashlib.sha256(original.encode()).hexdigest(),modified_sha256=hashlib.sha256(source.encode()).hexdigest(),
    purpose='Fast owned window class/module metadata adjacent to original baseline and samples; slow handle/thread queries only after failure or full workload',
    injection=False,memory_acceptance=False,stop_seconds=180),indent=2)+'\n',encoding='utf-8')
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
with (dest/'controller.log').open('w',encoding='utf-8') as log:
    code=subprocess.run([sys.executable,str(controller),str(dest),'tabs','--renderer','gdi',
        '--side','top','--cols','160','--rows','48','--workload-memory'],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
print((dest/'controller.log').read_text(encoding='utf-8')[-3500:],flush=True)
raise SystemExit(code)
