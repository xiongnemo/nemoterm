import datetime,gzip,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
out=root/'research/gdi-startup-evidence';out.mkdir(exist_ok=False)
m=dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    memory_acceptance=False,original_failure_resolved=False,files=[],cases={},
    preparation_failure=dict(script='check-gdi-window-timeline-initial.py',
        error='AssertionError:         finally:',reason='Substring matched both outer and nested finally clauses',
        target_started=False,correction='Use the unique outer finally followed by try; use a fresh destination'))
def retain(p,name):
    raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);dest=out/(name+'.gz')
    assert not dest.exists();dest.write_bytes(packed)
    m['files'].append(dict(path=dest.relative_to(root).as_posix(),bytes=len(packed),sha256=sha(packed),
        raw_bytes=len(raw),raw_sha256=sha(raw),encoding='gzip'))
for label in ('gdi-fast-windows','gdi-window-timeline-02','c1-window-timeline'):
    base=root/'build'/label
    v=read(base/'research/workload-tabs-gdi-top-observed.json');ctl=read(base/'research/tabs-controller.json')
    memory=read(base/'research/workload-tabs-gdi-top-memory.json')
    assert not ctl['cleanup']['after']['active'] and not ctl['cleanup']['terminated_remaining']
    assert not v['completed'] and len(v['checks'])==9
    assert not v.get('startup_observer_error') and not memory['errors']
    if label=='gdi-fast-windows':assert v['error']=="RuntimeError('Owned process is no longer running')"
    else:assert v['diagnostic_completed'] and ctl['exit_code']==2 and 'error' not in v
    case=dict(executable_sha256=v['executable_sha256'],baseline=v['two_tabs'],cycles=v['cycles'],
        controller=ctl,inner_cleanup=v['owned_job_cleanup'],checks=v['checks'],
        error=v.get('error'),diagnostic_completed=v.get('diagnostic_completed',False),
        memory_acceptance=False,diagnostic_peaks=memory['peaks'],timeline_samples=len(v.get('startup_timeline',[])))
    if 'startup_timeline' in v:
        ss=v['startup_timeline'];first_ui=next(i for i,s in enumerate(ss) if any(w['kind']=='NativeHWNDHost' for w in s['windows']))
        case['ui_transition']=[dict(seconds=s['begun']-ss[0]['begun'],handles=s['handles'],gdi=s['gdi'],user=s['user'],
            classes=[w['kind'] for w in s['windows']]) for s in ss[max(0,first_ui-2):first_ui+1]]
        case['first_second_tab_seconds']=next(s['begun']-ss[0]['begun'] for s in ss if sum(w['kind']=='Nemoterm' for w in s['windows'])==2)
        mods=v['post_cycles_metadata']['threads']['modules']
        case['class_modules']=[dict(kind=w['kind'],module=next((m['name'] for m in mods if m['base']==w['class_module']),None))
            for w in v['window_timeline'][0]['windows']]
    m['cases'][label]=case
    for p in sorted((base/'research').iterdir()):
        if p.is_file():retain(p,label+'-'+p.name)
    for rel in ('tabs.log','controller.log','tests/tabs_window_smoke.py','tests/thread_snapshot.py','tests/handle_snapshot.py','tests/owned_job.py'):
        retain(base/rel,label+'-'+rel.replace('/','_'))
for name in ('check-gdi-fast-windows.py','check-gdi-window-timeline.py','check-gdi-window-timeline-initial.py',
    'check-gdi-window-timeline-expanded.py','check-c1-window-timeline.py','check-c1-window-timeline-expanded.py',
    'gdi-window-class-strings.json','retain-gdi-startup.py'):
    retain(root/'build'/name,name)
for item in m['files']:
    b=(root/item['path']).read_bytes();raw=gzip.decompress(b)
    assert sha(b)==item['sha256'] and len(b)==item['bytes'] and sha(raw)==item['raw_sha256'] and len(raw)==item['raw_bytes']
(root/'research/gdi-startup-validation.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(records=len(m['files']),cases={k:dict(baseline=v['baseline'],transition=v.get('ui_transition'),
    peaks=v['diagnostic_peaks']) for k,v in m['cases'].items()}),indent=2))
