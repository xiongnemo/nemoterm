from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=(root/'build/check-gdi-window-timeline-expanded.py').read_text(encoding='utf-8')
for a,b in [
    ("exe=source_root/'build/ci-io-7a3b95e/product/nemoterm.exe'", "exe=root.parent/'c1-worktree/build/ci-c1-43534154789/product/nemoterm.exe'"),
    ("dest=root/'build/gdi-window-timeline-02'", "dest=root/'build/c1-window-timeline'")]:
    assert source.count(a)==1,a;source=source.replace(a,b)
compile(source,'c1-timeline-preparation','exec')
(root/'build/check-c1-window-timeline-expanded.py').write_text(source,encoding='utf-8')
exec(compile(source,str(__file__),'exec'))
