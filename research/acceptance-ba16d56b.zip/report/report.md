# Windows x64 试用验收：`ba16d56b`

[单文件 EXE](https://github.com/xiongnemo/nemoterm/actions/runs/44793711901/artifacts/14657592423) · [原始完整运行](https://github.com/xiongnemo/nemoterm/actions/runs/44793711901)
文件：4,942,336 字节，SHA-256 `b0b03507848b437aced6a326be2f2452035af53e16104234ba59e5ef984e3db8`。

严格交互：**79/81**。未通过：agent-image-codex, agent-image-system-codex。未执行：无。
全文按原始结果计分；完整运行还包括此报告未覆盖的协议和平台测试。

| 前端 / 负载 | 私有工作集峰值（字节） | 总工作集峰值（字节） | 私有提交峰值（字节） |
|---|---:|---:|---:|
| pterm / 24 轮 Codex | 3,772,416 | 22,732,800 | 4,452,352 |
| GDI / 24 轮 Codex | 5,500,928 | 34,582,528 | 6,905,856 |
| DirectX / 24 轮 Codex | 9,732,096 | 44,851,200 | 11,235,328 |
| GDI / 六种满屏负载 | 18,882,560 | 53,661,696 | 22,560,768 |
| DirectX / 六种满屏负载 | 29,446,144 | 74,747,904 | 33,296,384 |

Codex、Claude Code、OpenCode：18/18 项快捷键和右键行为通过。10 个窗口的实际 Shift 选区都复制出「中文」；选区及相邻字格见附件 `selection/selected.png`。
10 个真实 agent 窗口的启动、提交后共 20 次采样：前端已加载模块和测试作业进程均未发现已知 WebView/浏览器标记。此项只覆盖采样时刻。
GDI 和 DirectX 的 8 帧 Sixel 已核对。字体为 SarasaTermSC Nerd Light。

| Codex 粘贴时机 | 输入方式 | Ctrl+V 首次提交 | Ctrl+Shift+V 首次提交 | 原始用例结果 |
|---|---|---|---|---|
| first visible input | window API | text-only | text-only | failed |
| first visible input | physical | exact-image | text-only | failed |
| after idle redraw | window API | exact-image | exact-image | passed |
| after idle redraw | physical | exact-image | exact-image | passed |

真实应用窗口的前端私有工作集（十进制 MB）

| 客户端 | GDI | DirectX |
| --- | ---: | ---: |
| codex | 7.32 | 17.87 |
| claude | 11.88 | 18.15 |
| opencode | 11.87 | 17.97 |

从发现窗口到提交回复：759 次定时采样，另有 50 次操作节点采样。只计终端前端，不含 agent 和控制台宿主。取所有对应窗口的实测最大值；采样之间的瞬时峰值未知。
