from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path(__file__).resolve().parent.parent
work=root/'build/kitty-placement-worktree'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
files={}
early=root/'build/ci-main-2f478e7'
for p in sorted((early/'early-msvc').rglob('*')):
    if p.is_file():files['failed-job/'+p.relative_to(early/'early-msvc').as_posix()]=p.read_bytes()
files['failed-job/job.log']=(early/'early-msvc-job.log').read_bytes()
groups={
    'original-opengl':'msvc-tabs-replay-2f478e7',
    'original-gdi':'msvc-tabs-gdi-replay-2f478e7',
    'first-observer-failure':'tab-boundaries-2f478e7',
    'corrected-observer':'tab-boundaries-v2-2f478e7'}
results={}
for label,folder in groups.items():
    base=root/'build'/folder
    results[label]=json.loads((base/'results.json').read_text())
    for p in sorted(base.rglob('*')):
        if not p.is_file():continue
        relative=p.relative_to(base)
        if any(part in ('dist','tools','__pycache__') for part in relative.parts):continue
        if 'tests' in relative.parts and p.name not in ('tabs_window_smoke.py','tab_probe_boundary.py','tabs_hover_probe.js'):continue
        files[label+'/'+relative.as_posix()]=p.read_bytes()
for label in ('original-opengl','original-gdi','corrected-observer'):
    for row in results[label]:
        assert row['exit_code']==0 and row['completed'] and not row['cleanup']['terminated_remaining']
files['controller.py']=Path(__file__).read_bytes()
buffer=io.BytesIO();records=[]
with tarfile.open(fileobj=buffer,mode='w') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
archive=gzip.compress(buffer.getvalue(),mtime=0)
path='research/tab-probe-detach-evidence/local-and-first-failure.tar.gz'
(work/path).parent.mkdir(exist_ok=True);(work/path).write_bytes(archive)
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
    for record in records:assert sha(tar.extractfile(record['path']).read())==record['raw_sha256']
manifest=dict(source_commit='2f478e76f86d1241d7e697225fa9205d7db17846',run=43652684756,
    failed_job=132624406615,unverified_artifact=14136911157,
    executable_sha256='04339e0b69d0ca57492068380163b28a07fb856921c2d48246b3b9f8bea0bb78',
    failure=dict(exit_code=3221225477,phase='synchronized-tab-transfer',actual_backend='GDI',
                 first_tab_selection_after_probe_detach=True,root_cause='unproven',wer_events=[]),
    scope='Exact failed MSVC sidecar-host image; local failure not reproduced; not product acceptance',
    records_note='The uploaded hyperlink observation was already tracked at source and is not a fresh pass from the failed job',
    local=results,bundles=[dict(path=path,archive_bytes=len(archive),archive_sha256=sha(archive),records=records)])
(work/'research/tab-probe-detach-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(records=len(records),archive_bytes=len(archive),original_replays=6,corrected_observer_replays=2)))
