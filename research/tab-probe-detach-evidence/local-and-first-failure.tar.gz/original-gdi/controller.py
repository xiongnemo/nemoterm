from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

root = Path(__file__).resolve().parent.parent
base = root / 'build/msvc-tabs-gdi-replay-2f478e7'
base.mkdir(exist_ok=False)
source = root / 'build/ci-main-2f478e7/early-unverified-msvc'
digest = hashlib.sha256((source/'nemoterm.exe').read_bytes()).hexdigest()
assert digest == '04339e0b69d0ca57492068380163b28a07fb856921c2d48246b3b9f8bea0bb78'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip() == '2f478e76f86d1241d7e697225fa9205d7db17846'
paths = subprocess.check_output(['git','ls-tree','-r','--name-only','HEAD','--','tests','tools/nemoterm_debug.py'],cwd=root,text=True).splitlines()
identity = dict(source_commit='2f478e76f86d1241d7e697225fa9205d7db17846', run=43652684756,
    artifact_id=14136911157, executable_sha256=digest,
    runtime_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.iterdir()},
    fixture_sha256={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths})
(base/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
shutil.copy2(__file__,base/'controller.py')
results=[]
for repeat in range(1,4):
    stage=base/f'run-{repeat}';stage.mkdir()
    for name in paths:
        dest=stage/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,dest)
    shutil.copytree(source,stage/'dist')
    (stage/'research').mkdir()
    started=time.monotonic()
    with (stage/'run.log').open('w',encoding='utf-8') as log:
        result=subprocess.run([sys.executable,'tests/tabs_window_smoke.py','--renderer','gdi',
            '--side','right','--cols','88','--rows','35','--font','Consolas'],cwd=stage,
            env=dict(os.environ,NEMOTERM_TEST_EXE=str(stage/'dist/nemoterm.exe')),
            stdout=log,stderr=subprocess.STDOUT,timeout=180)
    row=dict(repeat=repeat,exit_code=result.returncode,seconds=time.monotonic()-started)
    observed=stage/'research/tabs-gdi-right-observed.json'
    if observed.exists():
        d=json.loads(observed.read_text())
        row.update(completed=d.get('completed'),phase=d.get('phase'),actual_renderer=d.get('actual_renderer'),
            error=d.get('error'),process=d.get('process_before_cleanup'),cleanup=d.get('owned_job_cleanup'))
    results.append(row);(base/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if result.returncode:sys.exit(result.returncode)
