from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
root=Path(__file__).resolve().parent.parent
fixture=root/'build/kitty-placement-worktree'
base=root/'build/tab-boundaries-v2-2f478e7';base.mkdir(exist_ok=False)
original=root/'build/msvc-tabs-replay-2f478e7/run-1'
records=[]
for renderer in ('gdi','opengl'):
    stage=base/renderer;stage.mkdir()
    for folder in ('tests','tools','dist'):
        shutil.copytree(original/folder,stage/folder,ignore=shutil.ignore_patterns('__pycache__'))
    for name in ('tabs_window_smoke.py','tab_probe_boundary.py','tabs_hover_probe.js'):
        shutil.copy2(fixture/'tests'/name,stage/'tests'/name)
    (stage/'research').mkdir()
    started=time.monotonic()
    with (stage/'run.log').open('w',encoding='utf-8') as log:
        result=subprocess.run([sys.executable,'tests/tabs_window_smoke.py','--renderer',renderer,
            '--side','right','--cols','88','--rows','35','--font','Consolas','--probe-boundaries'],
            cwd=stage,env=dict(os.environ,NEMOTERM_TEST_EXE=str(stage/'dist/nemoterm.exe')),
            stdout=log,stderr=subprocess.STDOUT,timeout=180)
    d=json.loads((stage/'research'/f'tabs-{renderer}-right-observed.json').read_text())
    row=dict(renderer=renderer,exit_code=result.returncode,seconds=time.monotonic()-started,
             completed=d['completed'],observations=d.get('probe_boundaries'),
             executable_sha256=d['executable_sha256'],actual_renderer=d.get('actual_renderer'),
             cleanup=d.get('owned_job_cleanup'))
    records.append(row);(base/'results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    assert not result.returncode and d['completed']
    assert not d['owned_job_cleanup']['terminated_remaining']
    snapshots=d['probe_boundaries']
    assert [s['label'] for s in snapshots] == ['after-load','before-detach','after-detach','after-select']
    assert not any('observation_error' in s or s['exit_code'] is not None for s in snapshots)
    assert not snapshots[0]['matches_initial_entry'] and not snapshots[1]['matches_initial_entry']
    assert snapshots[2]['matches_initial_entry'] and snapshots[3]['matches_initial_entry']
shutil.copy2(__file__,base/'controller.py')
print('Bounded owned entry snapshots detected installation and restoration on both local backends',flush=True)
