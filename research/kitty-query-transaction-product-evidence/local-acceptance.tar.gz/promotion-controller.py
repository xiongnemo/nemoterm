"""Promote only a reviewed exact product, retain its predecessor and all evidence."""
from pathlib import Path
import datetime,gzip,hashlib,io,json,os,shutil,subprocess,tarfile
root=Path(__file__).resolve().parent.parent
work=root/'build/kitty-features-worktree';source_work=work;base=root/'build/ci-query-product-752f3be'
stage=root/'build/query-transaction-product-752f3be/stage'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def sha_file(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
subprocess.run(['python',str(root/'build/review-query-product-752f3be.py'),str(stage)],check=True,cwd=root)
review=load(stage.parent/'review.json');identity=review['identity'];digest=identity['executable_sha256']
subprocess.run(['git','diff','--quiet',identity['source_commit'],'HEAD','--','vendor','native','scripts/build.ps1','scripts/build-single-exe.ps1','scripts/prepare-single-exe.py'],cwd=source_work,check=True)
manifest_path=work/'research/kitty-query-transaction-product-validation.json';manifest=load(manifest_path)
assert manifest['local_acceptance']=='pending'
assert manifest['single_executable_sha256']==digest and manifest['passed_single_checks']==143
artifact=next(a for a in load(base/'single-artifacts.json')['artifacts'] if a['id']==identity['artifact_id'])
expiry=artifact['expires_at']
old=root/'dist/nemoterm.exe';old_sha=sha(old.read_bytes())
assert old_sha=='dfae1cdea10e091d209aa56ce291b63e3ae5ada2f02035254c3c3398cda6c5ab'
assert [p.name for p in old.parent.iterdir()]==['nemoterm.exe']
backup=root/'build/accepted-before-query-transactions-6e05bd1.exe'
assert not backup.exists()
promotion=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=identity['source_commit'],
 executable_sha256=digest,executable_bytes=identity['executable_bytes'],artifact_id=identity['artifact_id'],
 previous_sha256=old_sha,backup=str(backup),groups=39,dist_files=['nemoterm.exe'])
# This receipt is a draft. No distribution or repository file is changed here.
promotion['status']='prepared'
draft=stage.parent/'prepared-promotion'
assert not draft.exists();draft.mkdir()
relative_manifest='research/kitty-query-transaction-product-validation.json'
inputs=['README.md','docs/PROTOCOLS.md','docs/REQUIREMENTS.md',
 'research/kitty-query-errors.md','research/kitty-feature-implementation.md',
 'research/kitty-feature-product.md','research/query-transaction-shutdown.md',relative_manifest]
original={}
for name in inputs:
 source_file=source_work/name;raw=source_file.read_bytes();original[name]=sha(raw)
 target=draft/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
work=draft
(work/'research/kitty-query-transaction-product-evidence').mkdir()
manifest_path=work/relative_manifest
files={}
for folder in ('research','logs'):
 for p in (stage/folder).rglob('*'):
  if p.is_file():files[p.relative_to(stage).as_posix()]=p
for name in ('IDENTITY.json','controller.py'):files[name]=stage/name
for name in ('review.json',):files[name]=stage.parent/name
files['review-controller.py']=root/'build/review-query-product-752f3be.py'
files['promotion-controller.py']=Path(__file__)
files['promotion-application-controller.py']=root/'build/apply-query-promotion-752f3be.py'
files['font-mapper-controller.py']=root/'build/probe-query-font-map.py'
files['gate-controller.py']=root/'build/test-query-product-gates.py'
for p in (root/'build/query-product-gate-controls').iterdir():
 if p.is_file():files['gate-controls/'+p.name]=p
rows=[];path='research/kitty-query-transaction-product-evidence/local-acceptance.tar.gz'
archive=work/path;assert not archive.exists()
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w|') as tar:
 for name,p in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=p.stat().st_size
  with p.open('rb') as stream:tar.addfile(info,stream)
  rows.append(dict(path=name,raw_bytes=info.size,raw_sha256=sha_file(p)))
with tarfile.open(archive,mode='r:gz') as tar:
 for row in rows:
  with tar.extractfile(row['path']) as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==row['raw_sha256']
fixture={p.relative_to(stage).as_posix():sha(p.read_bytes()) for name in ('tests','tools')
 for p in (stage/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts}
for name,d in fixture.items():
 raw=subprocess.check_output(['git','show',identity['fixture_source_commit']+':'+name],cwd=source_work)
 assert sha(raw)==d,name
manifest.update(local_acceptance=review,promotion=promotion,fixture_snapshot_sha256=fixture,artifact_expires=expiry)
manifest['bundles'].append(dict(path=path,archive_bytes=archive.stat().st_size,archive_sha256=sha_file(archive),records=rows))
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
g=review['frontend_peaks']['gdi'];d=review['frontend_peaks']['directx']
memory_table='\n'.join('| '+r['name']+' | '+str(r['samples'])+' | '+' | '.join(f"{r['peaks']['frontend'][k]:,}" for k in ('private_ws','total_ws','private_commit'))+' |' for r in review['memory'])
artifact_url=f"https://github.com/xiongnemo/nemoterm/actions/runs/43664330399/artifacts/{identity['artifact_id']}"
article=f'''# Accepted query-transaction single executable

The accepted local `dist/nemoterm.exe` comes from source
`{identity['source_commit']}`: **{identity['executable_bytes']:,} bytes**, SHA256
`{digest}`. Its runtime directory contains only this executable; the source-built
console host uses the same image. The earlier feature-query product is backed up
locally at `build/accepted-before-query-transactions-6e05bd1.exe`.

This version fixes a lost unfinished image upload when a malformed query header
is interleaved between chunks. The original product failure and the independent
upstream comparison remain in [the query-error record](kitty-query-errors.md).
The fix does not introduce a rollback buffer or an additional heap allocation.

[Ordinary CI 43664330393](https://github.com/xiongnemo/nemoterm/actions/runs/43664330393)
passes all four jobs. [Single-image CI 43664330399](https://github.com/xiongnemo/nemoterm/actions/runs/43664330399)
passes **143 groups**. [Download this exact product]({artifact_url}); it expires at
`{expiry}`. GCC, Clang and MSVC component checks passed at the preceding
`88743d3` product-fix commit; intervening changes affect tests and records only.
The current full core pipeline also covers sanitizers and the real-core replay.

## Downloaded product validation

All **39 local groups** pass: one suite containing 12 shutdown cases, 28 native
image suites and ten memory workloads. Image suites request SarasaTermSC Nerd
Font Light and require actual GDI, OpenGL and DirectX backends; fallback cannot
satisfy these checks. The retained OS font-mapper preflight is separate from the
terminal process.

| Fixture | Stages per actual renderer | Separate presented GDI stages |
| --- | ---: | ---: |
| Kitty image placement and lifecycle | 24 | 24 |
| Kitty font/window geometry | 12 | 12 |
| Compressed Kitty RGB/RGBA/PNG | 29 | 29 |
| Kitty feature-query state/reply replay | 176 | 176 |
| Kitty query errors during unfinished uploads | 216 | 216 |
| OSC 1337 static images | 32 | 32 |
| GIF animation | 36 | 36 |

All **1,575 API stages** and **525 direct GDI client-DC stages** pass. Replies are
compared byte-for-byte except one explicitly documented data-error control:
upstream and the strict local base64 decoder use different error codes, so that
control checks the same image ID/error envelope, unchanged seed pixels and the
cancelled upload. The unmodified upstream reply is retained alongside the actual
reply. Other queries and completion replies remain exact comparisons.

Every retained BMP is rehashed; geometry suites retain PNGs, whose red/blue pixel
counts and dimensions are independently rechecked. Their original capture-time
BMP hash is not represented as a separately retained BMP. All owned jobs exit
naturally, including shutdown cases.

## Ten uninjected memory workloads

Each workload uses an actual **160 x 48** Sarasa grid and two tabs. Sequential
sampling includes startup and resource settling, with no working-set trimming
and no injected observer or external crash debugger. GDI remains strictly below
20,000,000 private-working-set bytes; DirectX remains at or below 25,000,000.

| Workload record | Samples | Peak private WS (B) | Peak total WS (B) | Peak private commit (B) |
| --- | ---: | ---: | ---: | ---: |
{memory_table}

Frontend private-working-set peaks are **{g['private_ws']:,} bytes for GDI** and
**{d['private_ws']:,} for DirectX**. Total-working-set peaks are {g['total_ws']:,}
and {d['total_ws']:,}; DirectX still exceeds the approximate 50 MB total target.
Host/application/whole-tree samples and private commit remain separately recorded.
These finite workloads do not establish arbitrary-load or long-session bounds.

## Retention and remaining scope

`kitty-query-transaction-product-validation.json` indexes ordinary/single-image
CI evidence and **{len(rows):,} local records**, plus the promotion receipt in the
manifest and {len(fixture)} committed fixture hashes. Every archived record has a checked
SHA256 hash. Component evidence is in `kitty-query-errors-validation.json`.

File/shared-memory graphics transport, Unicode placeholders, relative placements
and Kitty animation remain open. These deterministic native fixtures do not
establish physical keyboard/wheel input, live IME candidate selection, cross-monitor
DPI or sustained real-application behavior. The earlier audible-bell confirmation
retains its original image identity in [the bell record](font-zoom-and-bell.md).
Shutdown lifetime checks use isolated Frida 17.23.3; other instrumentation uses
17.24.3. The [captured observer wait and bounded workaround](query-transaction-shutdown.md)
retain the original failure and failed alternatives. The historical tab access
violation and undumped shutdown incidents remain separate; passing replays do not
prove their causes. The full
original goal remains active.
'''
(work/'research/kitty-query-transaction-product.md').write_text(article,encoding='utf-8')

def edit(name,old_text,new_text):
 p=work/name;text=p.read_text(encoding='utf-8');assert text.count(old_text)==1,(name,old_text)
 p.write_text(text.replace(old_text,new_text),encoding='utf-8')

edit('README.md','下方单 EXE 已支持功能查询，在本机 GDI、OpenGL、DirectX 共通过 927 个像素与回包阶段，\n另通过 309 个直接读取 GDI 窗口客户区的阶段；包含既有图片、缩放、GIF 和新增功能查询。',
 '下方单 EXE 已支持功能查询，并修复错误查询打断图片上传的问题；在本机 GDI、OpenGL、DirectX\n共通过 1,575 个像素与回包阶段，另通过 525 个直接读取 GDI 窗口客户区的阶段。')
edit('README.md','[下载 `6e05bd1` 单文件产物](https://github.com/xiongnemo/nemoterm/actions/runs/43653882888/artifacts/14138801522)',
 f'[下载 `752f3be` 单文件产物]({artifact_url})')
edit('README.md','单文件 CI 共 140 组检查','单文件 CI 共 143 组检查')
edit('README.md','EXE 为 **4,515,840 字节**。',f"EXE 为 **{identity['executable_bytes']:,} 字节**。")
edit('README.md','2026-12-15 00:13 UTC',datetime.datetime.fromisoformat(expiry.replace('Z','+00:00')).strftime('%Y-%m-%d %H:%M UTC'))
edit('README.md','下载的 `6e05bd1` 在本机','下载的 `752f3be` 在本机')
edit('README.md','GDI 私有工作集最高 **16.84 MB**，DX 最高 **24.24 MB**。',f"GDI 私有工作集最高 **{g['private_ws']/1e6:.2f} MB**，DX 最高 **{d['private_ws']/1e6:.2f} MB**。")
edit('README.md','GDI 总工作集最高 **39.57 MB**，DX 最高 **59.82 MB**；',f"GDI 总工作集最高 **{g['total_ws']/1e6:.2f} MB**，DX 最高 **{d['total_ws']/1e6:.2f} MB**；")
p=work/'README.md';p.write_text(p.read_text().replace('research/kitty-feature-product.md','research/kitty-query-transaction-product.md'),encoding='utf-8')
p=work/'docs/PROTOCOLS.md';text=p.read_text();line=next(x for x in text.splitlines() if x.startswith('| kitty graphics：'))
replacement='| kitty graphics：`APC G control;payload ST` | 已证（有限子集） | 直接 RGB/RGBA/PNG、`o=z` 压缩、分块、图像及功能查询、放置/删除、裁剪缩放、三层叠放、滚动与主备屏生命周期已接入。已验收 `752f3be` 单 EXE 在实际 GDI/GL/DX 各通过 24 项图像、12 项几何、29 项压缩、176 个功能查询及 216 个查询错误阶段；错误查询头不会再清掉待完成上传。独立 GDI 客户区捕获和 GDI/DX 大窗口内存负载也通过。只报告实际实现的能力；文件/共享内存、Kitty 动画、相对放置及 Unicode 占位等仍未实现。见[功能查询实现](../research/kitty-feature-implementation.md)、[查询错误修复](../research/kitty-query-errors.md)及[成品验证](../research/kitty-query-transaction-product.md)。 |'
p.write_text(text.replace(line,replacement),encoding='utf-8')
p=work/'docs/REQUIREMENTS.md';text=p.read_text();heading='## Current accepted artifact (2026-11-15 Sydney)';assert text.count(heading)==1
current=f'''## Current accepted artifact (2026-11-15 Sydney)

The sole distribution file is `nemoterm.exe` from `{identity['source_commit']}`,
{identity['executable_bytes']:,} bytes, SHA256 `{digest}`. All four ordinary jobs,
143 single-image CI groups and 39 local groups pass. The
[exact-product record](../research/kitty-query-transaction-product.md) retains
1,575 API stages, 525 direct presented-GDI stages, 12 shutdown cases and ten
uninjected 160x48 Sarasa two-tab memory workloads. The earlier `6e05bd1` image
remains backed up; its pending-upload bug and failure evidence remain preserved.

GDI private WS peaks at {g['private_ws']:,} bytes and DirectX at {d['private_ws']:,},
passing the strict 20 MB / inclusive 25 MB gates. Total WS peaks at
{g['total_ws']:,} and {d['total_ws']:,}; the approximate 50 MB total target is still
unmet for DX. All owned jobs exit naturally. The malformed-header fix adds no
rollback buffer; query replay checks pending-image completion and wire replies.

The historical access violation and other shutdown/resource incidents remain
unresolved. Full graphics/protocol coverage, physical input/IME, multi-monitor
DPI and sustained real-agent behavior remain required work.

## Earlier feature-query artifact (2026-11-15 Sydney)'''
p.write_text(text.replace(heading,current),encoding='utf-8')
edit('research/kitty-query-errors.md','This is not yet new single-image or memory acceptance.',
 'This is the earlier development checkpoint; the formal replacement now passes\n[separate single-image and memory acceptance](kitty-query-transaction-product.md).')
edit('research/kitty-query-errors.md','native suites include the new replay. The accepted local executable remains\n`6e05bd1` until the replacement product passes its full pipeline and local checks.',
 'native suites include the new replay. The formal `752f3be` replacement passes\nall four ordinary jobs, 143 single-image CI groups and 39 local acceptance groups.\nIt now replaces `6e05bd1` in `dist`, with the earlier image preserved as a backup.')
edit('research/kitty-feature-implementation.md','The formal `6e05bd1` single EXE now passes\nfull CI and downloaded-product local acceptance, and replaces the earlier\ncompression image in `dist`. See [the exact product record](kitty-feature-product.md).',
 'The formal `752f3be` single EXE also preserves unfinished uploads when\ninterleaved query headers are rejected. It passes full CI and downloaded-product\nlocal acceptance; see [the current product record](kitty-query-transaction-product.md).')
p=work/'research/kitty-feature-product.md';text=p.read_text()
p.write_text(text.replace('# Accepted feature-query single executable','# Earlier accepted feature-query single executable',1).replace('\n\nThe accepted local',
 '\n\nThis historical checkpoint is superseded by the [query-transaction fix\nproduct](kitty-query-transaction-product.md). Its original measurements remain unchanged.\n\nThe then-accepted local',1),encoding='utf-8')


edit('research/kitty-feature-implementation.md',
 'the development fix. The accepted `6e05bd1` image still predates that fix.',
 'the development fix. That older image predates the fix; the current accepted\n`752f3be` product includes it, with failures and replacement validation retained.')
p=work/'research/query-transaction-shutdown.md'
p.write_text(p.read_text(encoding='utf-8')+f'''

## Full product follow-up

Source `752f3be` passes both complete workflows, including 143 single-image
groups and all four ordinary jobs. Its downloaded product, SHA256 `{digest}`,
also passes 39 local groups, including all 12 original shutdown cases with
actual GDI, OpenGL and DirectX and natural cleanup. Shutdown cases use isolated
17.23.3; the other instrumented suites retain 17.24.3. The original exit deadline
and lifetime assertions are unchanged. See the [exact-product acceptance and
retained observations](kitty-query-transaction-product.md). This bounded
validation does not reclassify the earlier failures or identify the causes of
the separate undumped incidents.
''',encoding='utf-8')
proposed={p.relative_to(draft).as_posix():sha(p.read_bytes()) for p in draft.rglob('*') if p.is_file()}
for name in proposed:
 if name not in original:assert not (source_work/name).exists(),name
prepared=dict(source_commit=identity['source_commit'],product_sha256=digest,previous_sha256=old_sha,
 draft=str(draft),stage=str(stage),backup=str(backup),original=original,proposed=proposed,
 application_controller_sha256=sha((root/'build/apply-query-promotion-752f3be.py').read_bytes()))
(stage.parent/'prepared-promotion.json').write_text(json.dumps(prepared,indent=2)+'\n')
print(json.dumps(dict(prepared=True,documents=len(proposed),local_records=len(rows),product_unchanged=sha(old.read_bytes())==old_sha)))
