"""Independently verify the retained exact-product local acceptance records."""
from pathlib import Path
import hashlib,json,sys
from collections import Counter
from PIL import Image
stage=Path(sys.argv[1]).resolve()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=load(stage/'IDENTITY.json');digest=sha(stage/'dist/nemoterm.exe')
assert identity['source_commit']=='752f3be71f8a0dce6e24d46af7dcf3d6d87c70a2' and identity['source_run']==43664330399
assert identity['fixture_source_commit']==identity['source_commit']
assert identity['shutdown_frida_version']=='17.23.3' and identity['other_frida_version']=='17.24.3'
assert digest==identity['executable_sha256'] and identity['ci_checks']==143
assert [p.name for p in (stage/'dist').iterdir()]==['nemoterm.exe']
results=load(stage/'logs/results.json')
assert len(results)==39 and all(r.get('exit_code')==0 for r in results),results
shutdown=load(stage/'research/shutdown-window-observed.json')
assert shutdown['frida_version']=='17.23.3'
assert shutdown['completed'] and shutdown['executable_sha256']==digest and len(shutdown['cases'])==12
for case in shutdown['cases']:
 assert case['exit_code']==0 and not case['cleanup']['terminated_remaining'],case
 assert case['active_renderer']=={'gdi':1,'opengl':2,'directx':3}[case['renderer']],case
 if case['observer']=='lifetime':
  events=case['events']
  freed=[e for e in events if e.get('event')=='seat-free']
  com=[e for e in events if e.get('event')=='com-uninitialize']
  returned=[e for e in events if e.get('event')=='com-uninitialize-return']
  assert len(freed)==len(com)==len(returned)==1,case
  assert freed[0]['success'] and not freed[0]['window_alive'],case
  assert all(e['seat_freed'] and not e['window_alive'] for e in (com[0],returned[0])),case
  assert sorted(returned[0]['detached_observers'])==['com','heap','window'],case
  assert not any(e.get('event')=='callback-after-seat-free' or e.get('type')=='error' for e in events),case
 elif case['observer']=='none':assert not case['injected'],case
 else:raise AssertionError(('Unexpected observer',case))
assert Counter(c['observer'] for c in shutdown['cases'])=={'none':6,'lifetime':6}

pixels=[];memory=[];api=presented=0
for p in sorted((stage/'research').glob('*observed.json')):
 d=load(p)
 if p.name.startswith(('kitty-image-','kitty-geometry-','kitty-compression-','kitty-features-','kitty-query-errors-','iterm-images-','gif-animation-')):
  assert d['completed'] and d['executable_sha256']==digest,p
  if 'command' in d:
   command=d['command'];assert command[command.index('--font')+1]=='SarasaTermSC Nerd Font Light',p
  else:assert d['font']=='SarasaTermSC Nerd Font Light',p
  renderer=d.get('requested_renderer',d.get('renderer'))
  assert d['actual_renderer']=={'gdi':0,'opengl':1,'directx':2}[renderer],p
  assert not d['cleanup']['terminated_remaining'] and d['cleanup']['after']['active']==0,p
  checks=d['checks'] if 'checks' in d else d['phases']
  for check in checks:
   assert check['matched'],(p,check['name'])
   if 'expected_reply_hex' in check:assert check['reply_hex']==check['expected_reply_hex'],(p,check['name'])
   if 'upstream_error_reply_hex' in check:
    actual=bytes.fromhex(check['reply_hex']);prefix=bytes.fromhex(check['expected_error_prefix_hex']);suffix=bytes.fromhex(check['expected_error_suffix_hex'])
    detail=actual[len(prefix):-len(suffix)]
    assert actual.startswith(prefix) and actual.endswith(suffix) and detail and b'\x1b' not in detail
   if 'bmp' in check:
    bmp=Path(d['folder'])/check['bmp'];bmp.resolve().relative_to(stage)
    assert sha(bmp)==check['bmp_sha256'],bmp
   else:
    # Geometry fixtures retain PNG and the original BMP's capture-time digest.
    # Recheck retained pixels, without pretending the original BMP is available.
    folders=[q for q in (stage/'research').glob(p.name.removesuffix('-observed.json')+'-*') if q.is_dir()]
    assert len(folders)==1,folders
    image=Image.open(folders[0]/check['image']).convert('RGB')
    assert image.size==(check['geometry']['width'],check['geometry']['height'])
    counts=Counter(image.get_flattened_data())
    for name,rgb in [('red',(255,0,0)),('blue',(0,0,255))]:
     record=check['counts'][name]
     assert counts[rgb]==record['actual']==record['expected'] and not record['missing'] and not record['unexpected']
  count=len(checks)
  if '-presented-gdi-' in p.name:presented+=count
  else:api+=count
  pixels.append(dict(name=p.name,stages=count,actual_renderer=d['actual_renderer'],capture=d['capture'],cleanup=d['cleanup']))
 if p.name.startswith(('workload-tabs-','inline-workload-tabs-','animated-workload-tabs-','kitty-workload-tabs-','compressed-kitty-workload-tabs-')):
  assert d['executable_sha256']==digest and d['font']=='SarasaTermSC Nerd Font Light',p
  assert d['actual_renderer']=={'gdi':1,'directx':3}[d['renderer']],p
  assert d['completed'] and d['memory_limit_passed'] and not d['memory_instrumented'],p
  assert d['actual_grid']==[160,48] and not d['process_tree_memory']['injected'],p
  assert not d['process_tree_memory']['diagnostic_only'] and not d['process_tree_memory']['errors'],p
  assert not d['owned_job_cleanup']['terminated_remaining'] and d['owned_job_cleanup']['after']['active']==0,p
  limit=20000000 if d['renderer']=='gdi' else 25000000
  peak=d['process_tree_memory']['peaks']['frontend']['private_ws']
  assert d['memory_limit_bytes']==limit and d['memory_limit_inclusive']==(d['renderer']=='directx')
  assert peak<limit if d['renderer']=='gdi' else peak<=limit
  memory.append(dict(name=p.name,renderer=d['renderer'],grid=d['actual_grid'],font=d['font'],
   samples=d['process_tree_memory']['sample_count'],peaks=d['process_tree_memory']['peaks'],
   limit_bytes=limit,limit_inclusive=d['memory_limit_inclusive'],cleanup=d['owned_job_cleanup']))
assert len(pixels)==28 and len(memory)==10,(len(pixels),len(memory))
assert (api,presented)==(1575,525),(api,presented)
summary=dict(identity=identity,groups=39,shutdown_cases=12,api_stages=api,presented_gdi_stages=presented,
 pixels=pixels,memory=memory,frontend_peaks={renderer:{key:max(r['peaks']['frontend'][key] for r in memory if r['renderer']==renderer)
  for key in ('private_ws','total_ws','private_commit')} for renderer in ('gdi','directx')})
(stage.parent/'review.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({key:summary[key] for key in ('identity','groups','api_stages','presented_gdi_stages','frontend_peaks')},indent=2))
