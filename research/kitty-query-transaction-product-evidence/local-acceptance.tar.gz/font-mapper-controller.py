from pathlib import Path
import ctypes as c,datetime,json
from ctypes import wintypes as w
root=Path(__file__).resolve().parents[1]
g=c.WinDLL('gdi32',use_last_error=True)
g.CreateCompatibleDC.argtypes=[w.HDC];g.CreateCompatibleDC.restype=w.HDC
g.CreateFontW.argtypes=[c.c_int]*5+[w.DWORD]*8+[w.LPCWSTR];g.CreateFontW.restype=w.HFONT
g.SelectObject.argtypes=[w.HDC,w.HGDIOBJ];g.SelectObject.restype=w.HGDIOBJ
g.GetTextFaceW.argtypes=[w.HDC,c.c_int,w.LPWSTR];g.GetTextFaceW.restype=c.c_int
g.GetGlyphIndicesW.argtypes=[w.HDC,w.LPCWSTR,c.c_int,c.POINTER(w.WORD),w.DWORD];g.GetGlyphIndicesW.restype=w.DWORD
g.DeleteObject.argtypes=[w.HGDIOBJ];g.DeleteDC.argtypes=[w.HDC]
dc=g.CreateCompatibleDC(None);assert dc
font=None;old=None
try:
 font=g.CreateFontW(-16,0,0,0,0,0,0,0,1,0,0,5,1,'SarasaTermSC Nerd Font Light');assert font
 old=g.SelectObject(dc,font);assert old and old!=c.c_void_p(-1).value
 face=c.create_unicode_buffer(128);assert g.GetTextFaceW(dc,len(face),face)
 glyph=w.WORD();result=g.GetGlyphIndicesW(dc,'中',1,c.byref(glyph),1)
 assert result!=0xffffffff and glyph.value not in (0,0xffff)
 assert face.value=='SarasaTermSC Nerd Font Light'
 record=dict(scope='Independent OS font-mapper preflight; does not observe fonts selected inside Nemoterm',
  requested_font='SarasaTermSC Nerd Font Light',resolved_font=face.value,native_cjk_glyph=True,
  cjk_glyph_index=glyph.value,nominal_pixels=16,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 path=root/'build/query-product-font-map-752f3be.json';assert not path.exists()
 path.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
finally:
 if old:g.SelectObject(dc,old)
 if font:g.DeleteObject(font)
 g.DeleteDC(dc)
