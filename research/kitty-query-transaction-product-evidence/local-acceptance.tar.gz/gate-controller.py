from pathlib import Path
import hashlib,json,subprocess,sys
root=Path(__file__).resolve().parents[1]
dest=root/'build/query-product-gate-controls';dest.mkdir(exist_ok=False)
exe=root/'dist/nemoterm.exe';before=hashlib.sha256(exe.read_bytes()).hexdigest()
records=[]
for name,evidence in [('unfinished-current-ci','ci-query-product-752f3be'),('failed-old-ci','ci-kitty-query-transactions-88743d3')]:
 data=json.loads((root/'build'/evidence/'single-run.json').read_text())
 if name=='unfinished-current-ci':assert data['status']!='completed'
 else:assert data['conclusion']=='failure'
 stage=dest/name;assert not stage.exists()
 result=subprocess.run([sys.executable,str(root/'build/accept-query-product-752f3be.py'),
  '--evidence',str(root/'build'/evidence),'--destination',str(stage),
  '--shutdown-python',str(root/'build/shutdown-python-17233-validation/Scripts/python.exe')],
  stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=30)
 (dest/(name+'.log')).write_text(result.stdout)
 assert result.returncode==1 and 'AssertionError' in result.stdout and not stage.exists()
 assert hashlib.sha256(exe.read_bytes()).hexdigest()==before
 records.append(dict(case=name,exit_code=result.returncode,stage_created=False,dist_unchanged=True))
(dest/'results.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records))
