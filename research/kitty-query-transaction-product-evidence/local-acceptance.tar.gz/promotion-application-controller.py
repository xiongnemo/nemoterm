"""Apply a reviewed draft only after rechecking all product and source identities."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-features-worktree'
base=root/'build/query-transaction-product-752f3be'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prepared=load(base/'prepared-promotion.json');draft=Path(prepared['draft']);stage=Path(prepared['stage'])
assert sha(Path(__file__))==prepared['application_controller_sha256']
assert prepared['source_commit']=='752f3be71f8a0dce6e24d46af7dcf3d6d87c70a2'
assert draft.resolve()==base.resolve()/'prepared-promotion' and stage.resolve()==base.resolve()/'stage'
subprocess.run(['python',str(root/'build/review-query-product-752f3be.py'),str(stage)],check=True)
review=load(base/'review.json');assert review['identity']['executable_sha256']==prepared['product_sha256']
for run in (43664330393,43664330399):
 r=json.loads(subprocess.check_output(['gh','run','view',str(run),'--repo','xiongnemo/nemoterm','--json','headSha,status,conclusion'],text=True))
 assert r['headSha']==prepared['source_commit'] and r['status']=='completed' and r['conclusion']=='success'
subprocess.run(['git','diff','--quiet',prepared['source_commit'],'HEAD','--','vendor','native','scripts/build.ps1','scripts/build-single-exe.ps1','scripts/prepare-single-exe.py'],cwd=work,check=True)
assert {p.relative_to(draft).as_posix() for p in draft.rglob('*') if p.is_file()}==set(prepared['proposed'])
for name,digest in prepared['proposed'].items():
 assert sha(draft/name)==digest,name
 if name in prepared['original']:assert sha(work/name)==prepared['original'][name],name
 else:assert not (work/name).exists(),name
old=root/'dist/nemoterm.exe';backup=Path(prepared['backup'])
assert sha(old)==prepared['previous_sha256']=='dfae1cdea10e091d209aa56ce291b63e3ae5ada2f02035254c3c3398cda6c5ab'
assert [p.name for p in old.parent.iterdir()]==['nemoterm.exe']
assert backup.resolve()==root.resolve()/'build/accepted-before-query-transactions-6e05bd1.exe' and not backup.exists()
manifest_name='research/kitty-query-transaction-product-validation.json';manifest=load(draft/manifest_name)
assert manifest['local_acceptance']==review and manifest['single_executable_sha256']==prepared['product_sha256']
temporary=old.with_name('nemoterm.next.exe');assert not temporary.exists()
shutil.copy2(old,backup);assert sha(backup)==prepared['previous_sha256']
shutil.copy2(stage/'dist/nemoterm.exe',temporary);assert sha(temporary)==prepared['product_sha256']
os.replace(temporary,old);assert sha(old)==prepared['product_sha256']
manifest['promotion'].update(status='applied',utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(base/'promotion.json').write_text(json.dumps(manifest['promotion'],indent=2)+'\n')
for name in prepared['proposed']:
 if name==manifest_name:continue
 target=work/name;target.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(draft/name,target);assert sha(target)==prepared['proposed'][name]
(work/manifest_name).write_text(json.dumps(manifest,indent=2)+'\n')
assert [p.name for p in old.parent.iterdir()]==['nemoterm.exe']
print(json.dumps(dict(promoted=sha(old),backup=sha(backup),documents=len(prepared['proposed']))))
