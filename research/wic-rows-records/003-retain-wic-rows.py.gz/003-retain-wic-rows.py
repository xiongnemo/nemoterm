from pathlib import Path
import gzip, hashlib, json, subprocess

root=Path(__file__).resolve().parents[1]
base=root/'build/wic-rows-native-01'
dest=root/'research/wic-rows-records'
dest.mkdir()
results=json.loads((base/'results.json').read_text())
assert len(results)==7 and results[-1]['exit_code']==1
assert results[-1]['peaks']['private_ws']==25055232
paths=[p for p in base.rglob('*') if p.is_file() and p.suffix in ('.json','.log','.png')
       and not any(s in p.relative_to(base).parts for s in ('tests','tools','dist'))]
paths += [root/'build'/n for n in ('check-wic-rows.py','link-wic-rows-01.py','build-wic-rows.log',
          'wic-rows-single-01/link.rsp','wic-rows-single-01/link.log','wic-rows-single-01/image.json')]
paths += [Path(__file__),root/'vendor/putty-0.85/windows/nemo_wic.c']
paths += [root/'tests'/n for n in ('iterm_image_window_smoke.py','tabs_window_smoke.py',
          'tab_workload_memory.py','memory_limits.py','automation_capture.py','tabs_hover_probe.js')]
manifest=dict(scope='Rejected PNG scanline CopyPixels experiment: pixels pass; no memory benefit established; GIF private WS fails',
              source_base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
              results=results,not_run=['after-gdi-png'],records=[])
for i,p in enumerate(sorted(set(paths))):
    data=p.read_bytes();archive=dest/f'{i:03d}-{p.name}.gz'
    archive.write_bytes(gzip.compress(data,mtime=0))
    assert gzip.decompress(archive.read_bytes())==data
    manifest['records'].append(dict(path=p.relative_to(root).as_posix(),archive=archive.relative_to(root).as_posix(),
                                   bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(root/'research/wic-rows-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(dict(records=len(manifest['records']),compressed_bytes=sum(p.stat().st_size for p in dest.iterdir())))
