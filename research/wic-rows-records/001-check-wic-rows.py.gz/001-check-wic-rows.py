from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];base=root/'build/wic-rows-native-01';base.mkdir()
old=root/'build/staging-single-01/nemoterm.exe';new=root/'build/wic-rows-single-01/nemoterm.exe'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='9300a9cd87fc9f9fc4dff39408c07221addce0febc70e0b7b7fa2f7a3fee42c0'
assert hashlib.sha256(new.read_bytes()).hexdigest()=='aafe6a4ea3b0a232bd493d4ac8ba7361c1ecd0d46e89967a5d6a191da8586c88'
memory=['--renderer','directx','--side','left','--cols','160','--rows','48','--workload-memory']
cases=[('before-static-directx','iterm_image',['--renderer','directx'],old)]
cases += [(f'after-static-{r}','iterm_image',['--renderer',r],new) for r in ('gdi','opengl','directx')]
cases += [('before-directx-png','tabs',memory+['--inline-images'],old),
          ('after-directx-png','tabs',memory+['--inline-images'],new),
          ('after-directx-gif','tabs',memory+['--animated-images'],new),
          ('after-gdi-png','tabs',['--renderer','gdi','--side','top','--cols','160','--rows','48','--workload-memory','--inline-images'],new)]
results=[]
for name,test,args,exe in cases:
 dest=base/name
 for directory in ('dist','research','build','tools'):(dest/directory).mkdir(parents=True)
 shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
 shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(exe,dest/'dist/nemoterm.exe')
for name,test,args,exe in cases:
 dest=base/name;print('Starting '+name,flush=True)
 with (dest/'controller.log').open('w') as log:
  run=subprocess.run([sys.executable,str(root.parent/'rtl-worktree/build/run-owned-check.py'),str(dest),test,*args],stdout=log,stderr=subprocess.STDOUT)
 record=dict(name=name,exit_code=run.returncode,executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest())
 for p in (dest/'research').glob('*-memory.json'):
  d=json.loads(p.read_text());record.update(samples=d['sample_count'],peaks=d['peaks']['frontend'],injected=d['injected'])
 for p in (dest/'research').glob('*-controller.json'):
  d=json.loads(p.read_text());record['seconds']=d['seconds'];record['cleanup']=d['cleanup']
 results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps(record),flush=True)
 if run.returncode:
  print((dest/'controller.log').read_text()[-2500:],flush=True)
  if name.startswith('after-'):raise SystemExit(run.returncode)
print('All post-change native cases passed',flush=True)
