set nocompatible encoding=utf-8 mouse=a ttymouse=sgr
set nonumber norelativenumber nowrap nofoldenable noshowmode noruler noshowcmd laststatus=0
set shortmess+=I ttimeout ttimeoutlen=100 nobackup nowritebackup noswapfile
let s:next_request = 1
function! NemoObserve(timer) abort
  if filereadable('stop') | qa! | endif
  let id = s:next_request
  if !filereadable('request-'.id) | return | endif
  let state={'request_id':id, 'grid':[&columns,&lines], 'cursor':[line('.'),col('.')], 'mode':mode(1), 'term':&term, 'mouse':&mouse, 'ttymouse':&ttymouse, 'lines':getline(1,'$')}
  call writefile([json_encode(state)],'state-'.id.'.tmp')
  if rename('state-'.id.'.tmp','state-'.id.'.json') == 0
    let s:next_request += 1
  endif
endfunction
augroup NemoEvidence
  autocmd!
  autocmd VimEnter * call timer_start(30, function('NemoObserve'), {'repeat': -1})
  autocmd InsertEnter * call writefile(['enter'], 'insert-events', 'a')
  autocmd InsertLeave * call writefile(['leave'], 'insert-events', 'a')
  autocmd VimResized * call writefile([printf('%dx%d', &columns, &lines)], 'resizes', 'a')
augroup END
