"""Retain explicitly superseded workflows without interpreting cancellation as success."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/bell-modes-worktree'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
sources={
    '5a1bcdb':'5a1bcdbf4636b6062a08af77d9791a9ebdbb1221',
    'f9e6e82':'f9e6e82a1a9d7c4fb968668e1c5b26e6515dfa1a'}
bases={'5a1bcdb':root/'build/ci-bell-complete-5a1bcdb','f9e6e82':root/'build/ci-bell-single-f9e6e82'}
runs=[('5a1bcdb','ordinary',43725655091,'Superseded by the source correction after the unchanged image reproduced the notification defect.'),
      ('5a1bcdb','single',43725655080,'Superseded early by the explicit 60-minute workflow budget correction.'),
      ('f9e6e82','single',43725867215,'Superseded by the source correction after the unchanged image reproduced the notification defect.')]
entries={'source/retainer.py':Path(__file__).read_bytes()};results=[]
for short,kind,number,reason in runs:
    data=json.loads((bases[short]/(kind+'-run.json')).read_bytes())
    assert (data['databaseId'],data['headSha'],data['status'],data['conclusion'])==(number,sources[short],'completed','cancelled')
    results.append(dict(source=sources[short],run=number,kind=kind,conclusion='cancelled',reason=reason))
for short,base in bases.items():
    for p in base.rglob('*'):
        if not p.is_file():continue
        path=p.relative_to(base).as_posix()
        # The separately retained bell-native failure is already immutable.
        if path.startswith(('diagnostic/','diagnostic-download.','bell-window-')):continue
        entries[short+'/'+path]=p.read_bytes()
    for name in ('.github/workflows/ci.yml','.github/workflows/single-exe.yml','scripts/test-single-exe.ps1',
                 'tests/bell_modes_window_smoke.py','tests/bell_window_state_smoke.py','tests/owned_window_focus.py'):
        entries[short+'/source/'+name]=subprocess.check_output(['git','show',sources[short]+':'+name],cwd=work)
changed=subprocess.check_output(['git','diff','--name-only',sources['5a1bcdb'],sources['f9e6e82']],cwd=work,text=True).splitlines()
assert changed==['.github/workflows/single-exe.yml']
archive=work/'research/bell-superseded-workflows.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(entries.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path'] and sha(tar.extractfile(member).read())==record['raw_sha256']
manifest=dict(runs=results,accepted=False,scope='Original partial output and cancellations are retained. No full-product pass is inferred. The separate native defect is retained in bell-activation-native and bell-activation-trace.',
    bundle=dict(path=archive.relative_to(work).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),records=records))
(work/'research/bell-superseded-workflows-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Retained',len(records),'records,',archive.stat().st_size,'bytes')
