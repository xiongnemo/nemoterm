from pathlib import Path
import gzip,hashlib,json,subprocess

root=Path(__file__).resolve().parents[1];project=root.parents[1]
dest=root/'research/iso2022-input-records-02'
files=set((root/'build').glob('input-*.log'))
files.update((root/'build/charset-input-linux').glob('*.log'))
files.add(root/'build/charset-input-linux/results.json')
for pattern in ('charset-input*','charset-paste-only*','xclip-install.log'):
    files.update((root/'build/reference').glob(pattern))
for folder in ('charset-native-01','charset-native-02','charset-native-ci-01','charset-native-ci-02'):
    base=root/'build'/folder
    files.update((base/'research').glob('*'))
    files.update(base.glob('*.log'))
    files.add(base/'tests/iso2022_window_smoke.py')
for path in (root/'build/charset-memory-01').rglob('*'):
    if 'research' in path.parts or path.suffix=='.log' or path.name=='results.json':files.add(path)
for path in ['tools/generate_charset_tables.py','tools/generate_charset_input_reference.py',
    'tests/charset_input_reference.h','tests/xterm_charset_input_oracle.py','tests/iso2022_window_smoke.py',
    'tests/test_charset.c','tests/charset_reference.h','tests/charset_parser_reference.h','tests/charset_state_reference.h',
    'vendor/putty-0.85/terminal/nemo_charset.c','vendor/putty-0.85/terminal/nemo_charset.h',
    'vendor/putty-0.85/terminal/nemo_charset_data.h','vendor/putty-0.85/terminal/terminal.c',
    'vendor/putty-0.85/test/test_state_control.c','build/check-charset-input.py',
    'build/check-charset-memory.py','build/check-charset-ci-native.py','build/run-charset-native.py',
    'build/link-charset-input.py','build/make-charset-input-union.py','build/retain-input.py',
    'build/charset-input-single-01/link.log','build/charset-input-single-02/link.log',
    'build/charset-input-single-02/link.rsp','build/charset-input-single-02/image.json',
    '.github/workflows/ci.yml','scripts/test-single-exe.ps1']:
    files.add(root/path)
for name in ['native_test_utils.py','owned_job.py','automation_capture.py','protocol_oracle_window.py',
             'fixture_io.py','mouse_fixture.py']:
    files.add(root/'build/charset-native-02/tests'/name)
files.add(root/'build/charset-native-02/tools/nemoterm_debug.py')
memory=root/'build/charset-memory-01/after-directx'
for name in ['tabs_window_smoke.py','native_test_utils.py','owned_job.py','automation_capture.py',
             'memory_limits.py','tab_workload_memory.py','resource_settle.py','fixture_io.py',
             'thread_snapshot.py','owned_failure_state.py','frida_test_utils.py','tab_menu_checks.py']:
    files.add(memory/'tests'/name)
reference=Path('//wsl.localhost/Debian/tmp/nemoterm-xterm-reference')
for name in ('charsets.c','charsets.h','input.c','button.c'):files.add(reference/name)
ci=project/'build/ci-charsets-parser-9abf339'
for name in ('core-run.json','single-run.json','core-artifacts.json','single-artifacts.json'):
    files.add(ci/name)
files={path for path in files if not path.is_dir()}
for path in files:assert path.is_file(),path
dest.mkdir(exist_ok=False)
records=[]
for i,path in enumerate(sorted(files,key=str)):
    if path.is_dir():continue
    assert path.is_file(),path
    content=path.read_bytes();name=f'{i:03}-{path.name}.gz'
    packed=gzip.compress(content,mtime=0);(dest/name).write_bytes(packed)
    assert gzip.decompress(packed)==content
    records.append(dict(source=str(path.relative_to(root)) if path.is_relative_to(root) else str(path),
        archive=f'{dest.name}/{name}',bytes=len(content),sha256=hashlib.sha256(content).hexdigest()))
def identity(path):
    content=path.read_bytes()
    return dict(path=str(path),bytes=len(content),sha256=hashlib.sha256(content).hexdigest())
parent_ci=[]
for kind in ('core','single'):
    data=json.loads((ci/(kind+'-run.json')).read_text())
    assert data['headSha']=='9abf3396520b858e637d521de4616a6c664c68ca'
    assert data['conclusion']=='success'
    parent_ci.append(dict(kind=kind,id=data['databaseId'],head=data['headSha'],conclusion=data['conclusion'],url=data['url']))
report=dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    state='input-native-development-checkpoint-not-promoted',records=records,
    input_reference=dict(selections=53,unicode_codepoints=586,keyboard_reference_accepted=False),
    built_single=identity(root/'build/charset-input-single-02/nemoterm.exe'),
    accepted_unchanged=identity(project/'dist/nemoterm.exe'),parent_ci=parent_ci,
    parent_ci_image=identity(ci/'product/nemoterm.exe'),
    local_native_runs=['charset-native-01','charset-native-02','charset-native-ci-02'],
    failed_native_runs=['charset-native-ci-01'],
    memory_runs=json.loads((root/'build/charset-memory-01/results.json').read_text()),
    validation=['8 Linux suites normal and ASan/UBSan/leak checks passed',
        'Windows frontend and 8 MSVC suites passed',
        'MSVC W4 WX standalone mapping build and 15360 output reference cells passed',
        'Actual GDI/OpenGL/DirectX pixels, logical text, API paste and input passed',
        'Unchanged finite-workload memory/resource gates passed for accepted and candidate images'],
    limitations=['new input commit full CI pending','UPSS reassignment pending','lower-level output matrix pending',
        'extended legacy checksums pending','no independent keyboard parity claim',
        'no system clipboard acceptance in these new native tests','no all-agent memory acceptance',
        'DirectX total working set still above approximately 50 MB','prior native tab-close crash unresolved'])
assert report['accepted_unchanged']['sha256']=='c110843b1fd5a551d654df094fa716c1ea1c48383d90e642b964d7dfb3d15e26'
(root/'research/iso2022-input-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(records=len(records),archive_bytes=sum(p.stat().st_size for p in dest.glob('*.gz')),
    built=report['built_single'],accepted=report['accepted_unchanged'],parent_ci_image=report['parent_ci_image']),indent=2))
