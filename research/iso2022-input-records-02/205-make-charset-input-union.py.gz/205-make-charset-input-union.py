from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parents[1]
values={0x4e2d,0x1f642};sources=[]
values.update(range(0xff61,0xffa0))
for path in sorted((root/'build/reference').glob('charsets-canonical-*.json')):
    data=json.loads(path.read_text())
    for case in data['cases'].values():values.update(case['cells'])
    sources.append(dict(name=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
values=sorted(x for x in values if x>=32 and not 127<=x<160)
text=''.join(map(chr,values))
(root/'build/reference/charset-input-union.txt').write_text(text,encoding='utf-8',newline='')
(root/'build/reference/charset-input-union.json').write_text(json.dumps(dict(codepoints=values,sources=sources),indent=2)+'\n')
print(len(values))
