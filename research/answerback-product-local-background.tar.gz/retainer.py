"""Review the remaining background cases and preserve any unchanged memory-gate failure."""
from pathlib import Path
from collections import Counter
import hashlib,json,tarfile
from PIL import Image

root=Path(__file__).resolve().parents[1]
stage=root/'build/local-answerback-product-253855b-01'
research=root/'build/gdi-dense-memory-worktree/research'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p):
    with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
identity=load(stage/'IDENTITY.json');sha=identity['executable_sha256']
assert sha==digest(stage/'dist/nemoterm.exe')=='f086fde1d97b33d231281a939dcf855150b2270726e672d99b68fca631e32107'
assert identity['source_commit']==identity['fixture_commit']=='253855b481b2ccd6a13dae5490c42f19c8b9dd64'
results=load(stage/'logs/results.json');cases=load(stage/'cases.json')
assert len(results)==len(cases)==41 and [r['name'] for r in results]==[c[0] for c in cases]
assert all(r.get('exit_code')==0 for r in results[:-1])
assert results[-1]['name']=='unicode-kitty-memory-directx' and results[-1].get('exit_code') in (0,1)
prefix=load(research/'answerback-product-local-gdi-validation.json')
assert prefix['executable_sha256']==sha and prefix['reviewed_groups']==[r['name'] for r in results[:13]]
assert digest(research/prefix['archive']['path'])==prefix['archive']['sha256']
for name,checksum in identity['fixtures'].items():assert digest(stage/name)==checksum
paths={};reports={};memory=[];native=[]
for result in results[13:]:
    name=result['name'];folder=stage/'case-evidence'/name
    assert not result.get('controller_timeout') and result['observations']
    for record in result['observations']:
        path=(stage/record['path']).resolve();assert path.is_relative_to(folder)
        assert path.stat().st_size==record['bytes'] and digest(path)==record['sha256']
        paths[path]=record['path']
    paths[stage/'logs'/f'{name}.log']=f'logs/{name}.log'
    owned=[]
    for path in (folder/'research').glob('*observed.json'):
        data=load(path)
        if not ('executable_sha256' in data or 'exe_sha256' in data):continue
        assert data.get('executable_sha256',data.get('exe_sha256'))==sha,path
        if name!='unicode-kitty-memory-directx':assert data.get('completed',True) and not data.get('error'),path
        if 'cleanup' in data:
            cleanups=data['cleanup'] if isinstance(data['cleanup'],list) else [data['cleanup']]
            for cleanup in cleanups:assert not cleanup['terminated_remaining'] and cleanup['after']['active']==0
        owned.append((path,data))
    assert owned,name
    reports[name]=owned
    if name.startswith(('unicode-pixels-','unicode-geometry-')):
        assert len(owned)==1
        _,data=owned[0];geometry=name.startswith('unicode-geometry-')
        checks=data.get('checks',data.get('phases'))
        assert len(checks)==(19 if geometry else 32) and all(c['matched'] for c in checks)
        renderer=name.rsplit('-',1)[-1]
        assert data['actual_renderer']=={'gdi':0,'opengl':1,'directx':2}[renderer]
        assert not data['clipboard_access'] and not data['global_input']
        captures=folder/Path(data['folder']).relative_to(stage)
        for check in checks:
            with Image.open(captures/check.get('png',check.get('image'))) as picture:
                if geometry:
                    picture=picture.convert('RGB')
                    assert picture.size==(check['geometry']['width'],check['geometry']['height'])
                    counts={rgb:count for count,rgb in picture.getcolors(picture.width*picture.height)}
                    for colour,rgb in [('red',(255,0,0)),('blue',(0,0,255))]:
                        value=check['counts'][colour]
                        assert counts.get(rgb,0)==value['actual']==value['expected']
                        assert not value['missing'] and not value['unexpected']
                else:picture.verify()
            if check.get('bmp'):assert digest(captures/check['bmp'])==check['bmp_sha256']
        native.append(dict(name=name,stages=len(checks),renderer=renderer,capture=data['capture']))
    if '-memory-' in name:
        assert len(owned)==1
        path,data=owned[0];samples=load(path.with_name(path.name.replace('-observed','-memory')))
        assert data['actual_grid']==[160,48] and data['font']=='SarasaTermSC Nerd Font Light'
        assert not data['memory_instrumented'] and not samples['injected'] and not samples['errors']
        assert samples['sample_count']==len(samples['samples'])>0
        assert data['process_tree_memory']['peaks']==samples['peaks']
        for key in ('private_ws','total_ws','private_commit'):
            assert samples['peaks']['frontend'][key]==max(s['groups']['frontend'][key] for s in samples['samples'])
        assert data['peak_private_ws']>=samples['peaks']['frontend']['private_ws']
        dx=data['renderer']=='directx';limit=25_000_000 if dx else 20_000_000
        assert data['actual_renderer']==(3 if dx else 1)
        assert data['memory_limit_required'] and data['memory_limit_bytes']==limit and data['memory_limit_inclusive']==dx
        passed=data['peak_private_ws']<=limit if dx else data['peak_private_ws']<limit
        assert data['memory_limit_passed']==passed and data['completed']==passed
        assert result['exit_code']==(0 if passed else 1)
        if not passed:assert name=='unicode-kitty-memory-directx' and data['phase']=='memory-acceptance'
        assert len(data['checks'])==(10 if 'kitty' in name else 9) and data['host_close']['exit_code']==0
        cleanup=data['owned_job_cleanup']
        assert not cleanup['terminated_remaining'] and cleanup['after']['active']==0
        count=0
        if name=='unicode-kitty-memory-directx':
            assert len(data['post_memory_kitty_unicode'])==4
            assert cleanup['after']=={'total':56,'active':0,'terminated':0}
            for capture in data['post_memory_kitty_unicode']:
                assert capture['matched'] and capture['after_memory_sampling'] and not capture['injected']
                assert capture['grid']==[160,48] and len(capture['rows'])==46 and all(r['matched'] for r in capture['rows'])
                count+=capture['cells_verified']
                for row in capture['rows']:
                    if 'image' not in row:continue
                    with Image.open(folder/'research'/row['image']) as picture:
                        assert picture.size==(row['patch'][2],1)
                        assert picture.convert('RGB').getcolors(picture.width)==[(picture.width,(0,0,255))]
            assert count==29072
        memory.append(dict(name=name,passed=passed,renderer=data['renderer'],samples=samples['sample_count'],
            seconds=samples['seconds'],peaks=samples['peaks'],verified_image_cells=count,cleanup=cleanup))

def report(case,name):return next(d for p,d in reports[case] if p.name==name)
shells=report('shells','shell-window-observed.json')
assert set(shells['launches'])=={s['id'] for s in shells['detected'] if s['available']}
assert set(shells['launches'])=={'pwsh','powershell','busybox-ash','git-bash','wsl-bash','cmd'}
assert all(s['command_executed'] for s in shells['launches'].values())
session=report('session','session-window-gdi-observed.json')
assert len(session['checks'])==7 and session['frontend_exit']==0
assert not session['owned_job_cleanup']['terminated_remaining'] and session['owned_job_cleanup']['after']['active']==0
assert len(report('session-restart','session-restart-observed.json')['cycles'])==4
assert len(report('font-zoom','font-zoom-observed.json')['modes'])==4
assert len(reports['feature-policy'])==3 and all(len(d['cases'])==24 for _,d in reports['feature-policy'])
for renderer,actual in [('gdi',1),('directx',3)]:
    value=report('automation-'+renderer,'automation-'+renderer+'-observed.json')
    assert len(value['checks'])==10
for side in ('top','bottom','left','right'):
    value=report('tabs-'+side,f'tabs-gdi-{side}-observed.json')
    assert len(value['checks'])==9 and value['actual_renderer']==1
    assert value['font']=='SarasaTermSC Nerd Font Light' and value['actual_grid']==[160,48]
    assert not value['owned_job_cleanup']['terminated_remaining'] and value['owned_job_cleanup']['after']['active']==0
assert len(native)==6 and sum(n['stages'] for n in native)==153 and len(memory)==11

for name in ('IDENTITY.json','all-cases.json','cases.json','controller.py','logs/results.json'):
    paths[stage/name]=name
paths[Path(__file__)]='retainer.py'
archive=research/'answerback-product-local-background.tar.gz';records=[]
with archive.open('xb') as raw,tarfile.open(fileobj=raw,mode='w:gz') as bundle:
    for path,name in sorted(paths.items(),key=lambda pair:pair[1]):
        records.append(dict(path=name,bytes=path.stat().st_size,sha256=digest(path)))
        bundle.add(path,arcname=name,recursive=False)
with tarfile.open(archive) as bundle:
    assert len(set(bundle.getnames()))==len(bundle.getnames())==len(records)
    for record in records:
        raw=bundle.extractfile(record['path']).read()
        assert len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256']
summary=dict(identity=identity,accepted_candidate=False,executed_background_groups=41,
    passed_background_groups=sum(r['exit_code']==0 for r in results),
    failed_groups=[dict(name=r['name'],exit_code=r['exit_code']) for r in results if r['exit_code']!=0],
    earlier_checkpoint=prefix['archive'],shells=list(shells['launches']),native=native,memory=memory,
    scope='Complete background execution only; failed gates are not waived. Eight desktop/clipboard groups and the original full protocol/application scope remain open. No promotion or DX optimization.',
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=digest(archive)),records=records)
with (research/'answerback-product-local-background-validation.json').open('x',encoding='utf-8') as stream:
    json.dump(summary,stream,indent=2);stream.write('\n')
print(json.dumps({k:summary[k] for k in ('accepted_candidate','executed_background_groups','passed_background_groups','failed_groups','archive')},indent=2))
