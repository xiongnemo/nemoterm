from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-relative-worktree'
base=root/'build/ci-kitty-unicode-geometry-6520e3c'
run=json.loads((base/'run.json').read_text(encoding='utf-8-sig'))
assert run['databaseId']==43679054777 and run['conclusion']=='success'
evidence=json.loads((base/'reference/rea-evidence.json').read_text());capture=evidence['normalized_result']
assert capture['exit']['code']==0 and capture['exit']['reason']=='exited' and not capture['truncated']
assert capture['cleanup']['owned_process_group']=='verified' and capture['cleanup']['temporary_root']=='removed'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
digest=sha(base/'reference/observations.json')
assert digest=='c6a03613d5f5df5313ee7f07610bb4ac2b0615428a9ab5efd61f9fd06e59656a'
assert any(p.get('sha256')==digest for p in capture['files_after'])
files={p.relative_to(base).as_posix():p for p in base.rglob('*') if p.is_file()}
files['controllers/retain.py']=Path(__file__)
files['controllers/fixture.py']=work/'tests/kitty_unicode_geometry_oracle.py'
path=work/'research/kitty-unicode-evidence/font-geometry-reference.tar.gz';records=[]
with path.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w|') as tar:
    for name,p in sorted(files.items()):
        raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw)
        tar.addfile(info,io.BytesIO(raw));records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(p)))
with tarfile.open(path) as tar:
    for r in records:assert hashlib.sha256(tar.extractfile(r['path']).read()).hexdigest()==r['raw_sha256']
bundle=dict(path=path.relative_to(work).as_posix(),archive_bytes=path.stat().st_size,archive_sha256=sha(path),records=records)
manifest=work/'research/kitty-unicode-validation.json';data=json.loads(manifest.read_text())
data['font_geometry_reference']=dict(run=run['databaseId'],source_commit=run['headSha'],observations_sha256=digest,
    evidence_id=evidence['evidence_id'],cases=153,cell_width_range=[4,12],cell_height_range=[10,26],
    claim='Fresh upstream rectangles per explicit cell geometry; no GPU pixels or incremental rescale sequence captured')
data['bundles'].append(bundle)
manifest.write_text(json.dumps(data,indent=2)+'\n')
print('Retained complete REA font-cell reference:',len(records),'records',bundle['archive_bytes'],'bytes')
