from pathlib import Path
import gzip,hashlib,io,json,statistics,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-relative-worktree'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
files={};runs={};paired={}
for label,folder,source,conclusion in (
    ('fixed-owner','ci-kitty-cell-index-e05a60f','e05a60f0da38555923babd8c5ba779f782032ff9','failure'),
    ('lazy-owner','ci-kitty-cell-lazy-5f0c70f','5f0c70f4653b535497a157a1cdd4c1b67f92e9d9','success')):
    base=root/'build'/folder;run=json.loads((base/'components-run.json').read_text())
    assert run['headSha']==source and run['status']=='completed' and run['conclusion']==conclusion
    runs[label]=dict(source=source,run=run['databaseId'],url=run['url'],conclusion=conclusion)
    for p in base.rglob('*'):
        if p.is_file():files[label+'/'+p.relative_to(base).as_posix()]=p.read_bytes()
    if label!='lazy-owner':continue
    for compiler in ('gcc','clang','msvc'):
        directory=base/f'components/kitty-transport-{compiler}-{source}'
        assert sha((directory/'placements-baseline.c').read_bytes())=='1e3e8a381108afbf1be5e539dfb5ffd845b36d03e790f13975606fcd600457b0'
        terminal='terminal-test.log' if compiler=='msvc' else 'terminal-sanitizers.log'
        raw=(directory/terminal).read_bytes()
        for token in (b'728 states; 0 failed states',b'238 states; 0 failed states',
                      b'32 exact core copies checked',b'Sixel terminal suite passed'):
            assert token in raw
        rows={name:[json.loads(line) for line in (directory/file).read_text(encoding='utf-8-sig').splitlines()]
              for name,file in [('before','placements-baseline-benchmark.jsonl'),('after','placements-benchmark.jsonl')]}
        assert all(len(data)==42 for data in rows.values())
        paired[compiler]=[]
        for templates in (1,16):
            for cells in (256,512,1024,2048,4096,7268,8192):
                result=dict(templates=templates,cells=cells)
                for name,data in rows.items():
                    group=[r for r in data if (r['templates'],r['cells'])==(templates,cells)]
                    assert sorted(r['repeat'] for r in group)==[0,1,2]
                    result[name]=dict(
                        create_ms=statistics.median(r['create_ticks']/r['clock_hz']*1000 for r in group),
                        view_pass_ms=statistics.median(r['view_ticks']/r['clock_hz']/r['view_passes']*1000 for r in group),
                        clear_ms=statistics.median(r['clear_ticks']/r['clock_hz']*1000 for r in group),
                        placement_bytes=group[0]['placement_bytes'],baseline_bytes=group[0]['baseline_bytes'])
                assert result['after']['placement_bytes']-result['before']['placement_bytes']==5136
                paired[compiler].append(result)
files['controller.py']=Path(__file__).read_bytes()
archive=work/'research/kitty-unicode-evidence/cell-index-comparison.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for r in records:assert sha(tar.extractfile(r['path']).read())==r['raw_sha256']
path=work/'research/kitty-cell-performance-validation.json';data=json.loads(path.read_text())
assert 'indexed_comparison' not in data
data['indexed_comparison']=dict(runs=runs,paired=paired,active_owner_extra_bytes=5136,
    idle_owner_extra_bytes=8,placement_object_extra_bytes=0,
    scope='Identical test/compiler flags and same runner per pair; 3 clock() repetitions. Not a native painting or process-memory measurement.',
    failed_candidate='Fixed arrays broke the existing under-8-KiB empty-owner test; MSVC rejected a shadowed local. Both corrected; original failures retained.',
    checks='19,749 candidate placement assertions; 19,745 old-owner assertions (4 extra transactional-admission checks for dynamic index allocation). Terminal replay and sanitizers pass.')
data['indexed_bundle']=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
    archive_sha256=sha(archive.read_bytes()),records=records)
path.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(records=len(records),archive_bytes=archive.stat().st_size,runs=runs)))
