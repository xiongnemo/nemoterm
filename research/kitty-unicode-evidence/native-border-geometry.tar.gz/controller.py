"""Retain both failures and complete renderer/geometry regression evidence."""
from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile

root=Path(__file__).resolve().parents[1]
work=root/'build/kitty-relative-worktree'
reports=root/'build/kitty-unicode-border-native-reports'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
files={};runs=[]
def add(name,path):
    assert name not in files,name
    files[name]=path.read_bytes()
def capture(name,report,expected,log,folder_pattern=None):
    d=json.loads(report.read_text());checks=d.get('checks',d.get('phases'))
    assert not d['global_input'] and not d['clipboard_access']
    assert not d['cleanup']['terminated_remaining'] and not d['cleanup']['remaining_processes']
    if 'profile_removed' in d:assert d['profile_removed']
    if expected is not None:
        assert d['completed'] and len(checks)==expected and all(c['matched'] for c in checks)
    else:assert not d['completed'] and not checks[-1]['matched']
    mapping=dict(method='explicit report folder')
    if d.get('folder'):folder=Path(d['folder'])
    else:
        candidates=[]
        for folder in (work/'research').glob(folder_pattern):
            p=folder/'checks.json'
            if p.is_file() and json.loads(p.read_text())==checks:candidates.append(folder)
        mapping=dict(method='exact checks JSON; controller-log completion time disambiguates identical runs',
                     candidates=[dict(path=str(p),checks_mtime=(p/'checks.json').stat().st_mtime) for p in candidates],
                     controller_log_mtime=log.stat().st_mtime)
        if len(candidates)>1:
            candidates=[p for p in candidates if abs((p/'checks.json').stat().st_mtime-log.stat().st_mtime)<2]
        assert len(candidates)==1,(name,candidates)
        folder=candidates[0]
    prefix='native/'+name
    add(prefix+'/observed.json',report)
    add(prefix+'/controller.log',log)
    for p in folder.rglob('*'):
        if p.is_file():add(prefix+'/'+p.relative_to(folder).as_posix(),p)
    runs.append(dict(name=name,completed=d['completed'],stages=len(checks),
        matched=sum(c['matched'] for c in checks),actual_renderer=d['actual_renderer'],
        executable_sha256=d['executable_sha256'],capture=d['capture'],
        font=d.get('font') or d['command'][d['command'].index('--font')+1],
        report=prefix+'/observed.json',cleanup=d['cleanup'],folder_mapping=mapping))

capture('border-baseline',root/'build/kitty-unicode-border-baseline.json',None,
        root/'build/kitty-unicode-border-baseline.log')
capture('oversized-reference-apcs',root/'build/kitty-unicode-geometry-baseline-01.json',None,
        root/'build/kitty-unicode-geometry-gdi-01.log','kitty-unicode-geometry-gdi-*')
for renderer in ('gdi','opengl','directx','presented-gdi'):
    capture('border-'+renderer,reports/f'kitty-unicode-{renderer}.json',32,
            root/f'build/kitty-unicode-border-{renderer}.log')
    capture('geometry-'+renderer,reports/f'kitty-unicode-geometry-{renderer}.json',19,
            root/f'build/kitty-unicode-geometry-{renderer}-02.log',f'kitty-unicode-geometry-{renderer}-*')
for renderer in ('gdi','opengl','directx'):
    for suite,count in (('kitty-image',24),('kitty-compression',29),('kitty-geometry',12)):
        log=(f'kitty-unicode-border-ordinary-geometry-{renderer}.log' if suite=='kitty-geometry'
             else f'kitty-unicode-border-{suite.replace("-","_")}-{renderer}.log')
        capture(suite+'-'+renderer,reports/f'{suite}-{renderer}.json',count,root/'build'/log,f'{suite}-{renderer}-*')
capture('consolas-border',reports/'consolas-kitty_unicode.json',32,
        root/'build/kitty-unicode-border-consolas-kitty_unicode.log')
capture('consolas-roundoff-baseline',reports/'consolas-kitty_unicode_geometry-baseline.json',None,
        root/'build/kitty-unicode-border-consolas-kitty_unicode_geometry.log','kitty-unicode-geometry-gdi-*')
final_reports=root/'build/kitty-unicode-roundoff-reports'
for font in ('sarasa','consolas'):
    for renderer in ('gdi','opengl','directx','presented-gdi'):
        for suite,count in (('border',32),('geometry',19)):
            name=f'{font}-{suite}-{renderer}'
            log=('kitty-unicode-border-consolas-geometry-roundoff.log' if name=='consolas-geometry-gdi'
                 else f'kitty-unicode-roundoff-{name}.log')
            capture('final-'+name,final_reports/f'{name}.json',count,root/'build'/log,
                    f'kitty-unicode-geometry-{renderer}-*')
for renderer in ('gdi','opengl','directx'):
    for suite,count in (('kitty-image',24),('kitty-compression',29),('kitty-geometry',12)):
        name=f'{suite}-{renderer}'
        capture('final-'+name,final_reports/f'{name}.json',count,
                root/f'build/kitty-unicode-roundoff-{name}.log',f'{suite}-{renderer}-*')
for name in ('kitty-unicode-border-build.log','kitty-unicode-border-core-build.log',
             'kitty-unicode-border-test_sixel_terminal.log','kitty-unicode-border-test_terminal.log',
             'kitty-unicode-border-test_grapheme_terminal.log'):
    add('regressions/'+name,root/'build'/name)
for name in ('kitty_unicode_window_smoke.py','kitty_geometry_window_smoke.py','kitty_unicode_geometry_window_smoke.py',
             'kitty_image_window_smoke.py','kitty_compression_window_smoke.py','sixel_palette_window_smoke.py',
             'protocol_oracle_window.py','mouse_fixture.py','native_test_utils.py','owned_job.py','presented_window_capture.py'):
    add('source/'+name,work/'tests'/name)
for name in ('SOURCE-HOST.json','CONPTY-RUNTIME.json'):add('runtime/'+name,work/'build'/name)
add('source/nemo_kitty_paint.c',work/'vendor/putty-0.85/windows/nemo_kitty_paint.c')
add('source/before-roundoff-nemo_kitty_paint.c',root/'build/kitty-unicode-border-before-roundoff.c')
add('regressions/roundoff-build.log',root/'build/kitty-unicode-border-roundoff-build.log')
add('controller-argument-error.log',root/'build/kitty-unicode-roundoff-controller-argument-error.log')
files['source/baseline-nemo_kitty_paint.c']=subprocess.check_output(['git','show',
    '191c6411faddec119304e7148fa47d0bdc1fd12f:vendor/putty-0.85/windows/nemo_kitty_paint.c'],cwd=work)
add('reference/shaders.c',root/'build/kitty-graphics-reference/shaders.c')
assert sha(files['reference/shaders.c'])=='21707111331ba7467eea27a13ab1d195a520f8ef761666c8b43b2b75b3f0532f'
add('source/kitty_unicode_geometry_reference.json',work/'tests/kitty_unicode_geometry_reference.json')
add('source/generate-kitty-unicode-geometry-reference.py',work/'scripts/generate-kitty-unicode-geometry-reference.py')
add('controller.py',Path(__file__))
path=work/'research/kitty-unicode-evidence/native-border-geometry.tar.gz';records=[]
with path.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(path) as tar:
    for r in records:assert sha(tar.extractfile(r['path']).read())==r['raw_sha256']
bundle=dict(path=path.relative_to(work).as_posix(),archive_bytes=path.stat().st_size,
            archive_sha256=sha(path.read_bytes()),records=records)
manifest=work/'research/kitty-unicode-validation.json';data=json.loads(manifest.read_text())
final_runs=[r for r in runs if r['name'].startswith('final-')]
final_sha=sha((work/'build/nemoterm.exe').read_bytes())
assert len(final_runs)==25 and all(r['completed'] and r['executable_sha256']==final_sha for r in final_runs)
data['native_border_geometry']=dict(runs=runs,passed_pixel_states=sum(r['stages'] for r in runs if r['completed']),
    final_pixel_states=sum(r['stages'] for r in final_runs),
    border_baseline_source='191c6411faddec119304e7148fa47d0bdc1fd12f',
    preliminary_frontend_sha256='8e8a7eb96d632626d7492635e1b55347d59b8ed992a59cd78d95138bbcecf4c9',
    fixed_frontend_sha256=final_sha,
    runtime='Local MinGW frontend plus unchanged source-built 3ee3235 headless host; not single-file acceptance',
    border_cause='Partial virtual cells sampled outside the raster and repeated edge pixels instead of transparency',
    roundoff_cause='Consolas 7x15 cell geometry placed an exact bottom-edge sample a few double-precision ulps inside the raster, adding one row. Only machine-roundoff-sized raster-border coordinates are canonicalized; interior sampling and all pixel assertions remain unchanged.',
    reference_transport='Two upstream APC payloads exceed 4096 base64 characters. The initial native run returned E2BIG. Legal chunk normalization preserves every decoded byte and now checks exact graphics replies.',
    geometry_scope='153 fresh upstream cell sizes provide rectangles. Native transitions cover 19 states per renderer; no claim that all 153 sizes ran natively. Nearest-neighbour sampling differs from Kitty GPU linear filtering.',
    memory_acceptance=False,physical_input=False)
data['bundles'].append(bundle)
data['scope']='Development Unicode-image implementation: core, transparent borders, font zoom, resize and history checks pass. Fresh combined-image CI, selection and uninjected memory acceptance remain pending.'
manifest.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(records=len(records),archive_bytes=bundle['archive_bytes'],
    runs=len(runs),passed_pixel_states=data['native_border_geometry']['passed_pixel_states'])))
