from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-relative-worktree'
base=root/'build/ci-profile-exact-failure-af03e5a';directory=base/'diagnostic'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'tabs-run.json').read_text())
assert run['headSha']=='af03e5a60fcb01a0e09a5171c2af0e876e44cde2' and run['conclusion']=='success'
identity=json.loads((directory/'identity.json').read_text(encoding='utf-8-sig'))
digest='992cabb4d424235e92f46586230c5282dab1ad3a92d1cef3bd7f1b63ff759115'
assert identity['executable_sha256']==digest and identity['repetitions']==12
assert identity['source_run']=='43687495119' and identity['capture_failure_dumps'] and identity['frida_version']=='17.24.3'
results=[]
for p in sorted(directory.glob('replay-*-observed.json')):
    d=json.loads(p.read_text());assert d['completed'] and len(d['checks'])==7 and d['frontend_exit']==0
    assert d['executable_sha256']==digest and d['failure_dump_enabled'] and not d['memory_acceptance']
    assert not d.get('failure_dump') and not d['owned_job_cleanup']['terminated_remaining']
    results.append(dict(name=p.name,checks=7,exit_code=0,owned_processes=d['owned_job_cleanup']['after']['total']))
assert len(results)==12 and not list(directory.glob('profiles-failure-*'))
controls=json.loads((directory/'failure-dump-controls/controls/results.json').read_text())
assert len(controls)==3 and all(r['passed'] for r in controls)
files={p.relative_to(base).as_posix():p.read_bytes() for p in base.rglob('*') if p.is_file()}
files['controller.py']=Path(__file__).read_bytes()
archive=work/'research/kitty-unicode-evidence/single-profile-exact-replays.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for r in records:assert sha(tar.extractfile(r['path']).read())==r['raw_sha256']
data=dict(run=run['databaseId'],url=run['url'],fixture_source=run['headSha'],conclusion='success',
    original_source=identity['source_commit'],executable_sha256=digest,results=results,controls_passed=3,
    terminal_dumps=0,scope='Twelve finite exact-image passes with original Frida version and exit deadline; no terminal failure reproduced, no root cause or product acceptance claim.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
        archive_sha256=sha(archive.read_bytes()),records=records))
(work/'research/unicode-single-profile-replays.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,replays=len(results))))
