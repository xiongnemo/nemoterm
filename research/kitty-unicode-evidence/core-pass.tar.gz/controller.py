from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-relative-worktree'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def archive(relative,files):
    path=work/relative;records=[]
    with path.open('xb') as output,gzip.GzipFile(filename='',fileobj=output,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w|') as tar:
        for name,p in sorted(files.items()):
            raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw)
            tar.addfile(info,io.BytesIO(raw));records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(p)))
    with tarfile.open(path) as tar:
        for r in records:assert hashlib.sha256(tar.extractfile(r['path']).read()).hexdigest()==r['raw_sha256']
    return dict(path=relative,archive_bytes=path.stat().st_size,archive_sha256=sha(path),records=records)

base=root/'build/kitty-unicode-implementation-04'
exits=json.loads((base/'exits.json').read_text(encoding='utf-8-sig'));assert len(exits)==6 and not any(exits.values())
log=(base/'test_sixel_terminal.log').read_text(encoding='utf-8-sig')
assert 'Kitty relative replay: 238 states; 0 failed states' in log
assert '728 states; 0 failed states; 8 explicit xterm text-policy states' in log
assert log.count('Kitty Unicode xterm text policy matched: ')==8
files={}
for iteration in ('03','04'):
    folder=root/f'build/kitty-unicode-implementation-{iteration}'
    files.update({iteration+'/'+p.name:p for p in folder.iterdir() if p.is_file()})
changed=subprocess.check_output(['git','diff','--name-only'],cwd=work,text=True).splitlines()
changed+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=work,text=True).splitlines()
for name in changed:
    if name.startswith(('vendor/','tests/','scripts/','.github/')):
        files['source/'+name]=work/name
files['controller.py']=Path(__file__)
bundle=archive('research/kitty-unicode-evidence/core-pass.tar.gz',files)
path=work/'research/kitty-unicode-validation.json';data=json.loads(path.read_text())
data['scope']='Development core implementation: 720 raw Kitty states plus 8 explicit xterm text-policy states, 238 relative states; fresh hosted/native/single-image acceptance pending'
data['core_pass']=dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
    working_source_retained_in=bundle['path'],executable_sha256=sha(work/'build/test_sixel_terminal.exe'),
    test_exits=exits,raw_kitty_matches=720,xterm_text_policy_states=8,relative_matched_states=238,
    placement_checks=12635,strict_c99_placements='passed; retained with iterations 01/02')
data['bundles'].append(bundle)
path.write_text(json.dumps(data,indent=2)+'\n')

# The preceding relative build finished while Unicode work was in progress.
# Retain its completed run and downloadable product identity, without promoting it.
base=root/'build/ci-kitty-relative-656fed4'
run=json.loads((base/'single-run.json').read_text(encoding='utf-8-sig'))
assert run['databaseId']==43672313324 and run['conclusion']=='success'
files={name:base/name for name in ('single-run.json','single-run.log','single-artifacts.json',
    'single-observed-at.txt','product-download.json','single-evidence-download.json')}
files['build-single-exe.log']=base/'single-evidence/build-single-exe.log'
bundle=archive('research/kitty-relative-evidence/single-ci-656fed4.tar.gz',files)
path=work/'research/kitty-relative-ci-656fed4.json';data=json.loads(path.read_text())
data['single_executable']=dict(run=run['databaseId'],conclusion=run['conclusion'],
    source_commit=run['headSha'],sha256=sha(base/'product/nemoterm.exe'),bytes=(base/'product/nemoterm.exe').stat().st_size,
    bundle=bundle,accepted=False,reason='This run predates Unicode support and does not resolve the five failing core virtual-parent states in that source')
path.write_text(json.dumps(data,indent=2)+'\n')
print('Verified and retained final local core inputs/results and completed prior single-image CI metadata')
