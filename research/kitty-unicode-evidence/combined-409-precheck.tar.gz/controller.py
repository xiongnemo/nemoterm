from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-relative-worktree'
reports=root/'build/kitty-unicode-combined-409-reports'
host=root/'build/ci-kitty-unicode-border-4095697/source-host'
sha=lambda b:hashlib.sha256(b).hexdigest()
identity=json.loads((host/'SOURCE-HOST.json').read_text())
digest=sha((host/'nemoterm.exe').read_bytes())
assert identity['SourceCommit']=='40956977be5a59585c53cd67b17db36c2823a179'
assert identity['Executable']['SHA256']==digest
files={};runs=[]
for report in sorted(reports.glob('*.json')):
    d=json.loads(report.read_text());name=report.stem
    assert d['executable_sha256']==digest
    files['native/'+name+'/observed.json']=report.read_bytes()
    if name=='single-exe':
        assert d['host_same_image'] and d['launcher_exit_preserves_console'] and d['only_executable_in_directory']
        log='kitty-unicode-combined-409-single-exe.log'
    else:
        checks=d.get('checks',d.get('phases'))
        failed=name.endswith('failed-01')
        assert d['completed']==(not failed)
        assert not d['cleanup']['terminated_remaining'] and not d['cleanup']['remaining_processes']
        if not failed:assert all(c['matched'] for c in checks)
        if name.startswith('unicode_selection'):assert d['clipboard_restore_finished']
        folder=Path(d['folder'])
        for p in folder.rglob('*'):
            if p.is_file():files['native/'+name+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
        log=f'kitty-unicode-combined-409-{name}.log'
        if name=='unicode_geometry-directx':log='kitty-unicode-combined-409-unicode_geometry-directx-02.log'
        runs.append(dict(name=name,completed=d['completed'],matched=sum(c['matched'] for c in checks),
            actual_renderer=d['actual_renderer'],capture=d['capture'],
            clipboard_access=d['clipboard_access'],report='native/'+name+'/observed.json',cleanup=d['cleanup']))
    files['native/'+name+'/controller.log']=(root/'build'/log).read_bytes()
files['source/SOURCE-HOST.json']=(host/'SOURCE-HOST.json').read_bytes()
files['source/workflow-observed-running.json']=(host.parent/'core-run.json').read_bytes()
for name in ('single_exe_window_smoke.py','kitty_unicode_window_smoke.py','kitty_geometry_window_smoke.py',
             'kitty_unicode_geometry_window_smoke.py','kitty_unicode_selection_window_smoke.py','agent_key_probe.js'):
    files['source/'+name]=(work/'tests'/name).read_bytes()
files['controller.py']=Path(__file__).read_bytes()
path=work/'research/kitty-unicode-evidence/combined-409-precheck.tar.gz';records=[]
with path.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(path) as tar:
    for r in records:assert sha(tar.extractfile(r['path']).read())==r['raw_sha256']
manifest=work/'research/kitty-unicode-validation.json';data=json.loads(manifest.read_text())
data['combined_409_precheck']=dict(source_commit=identity['SourceCommit'],run=43681119193,
    source_host_artifact_id=14148651177,executable_sha256=digest,executable_bytes=identity['Executable']['Bytes'],
    runs=runs,passed_pixel_stages=204,passed_clipboard_copies=128,same_image_host=True,
    failed_attempt='DirectX geometry reached 16 passed stages; the clear-history reply ended with an extra DEL (0x7f) after correct geometry and status replies. Unchanged-input retry passed all 19 stages.',
    user_context='The user confirmed using the computer and then requested a pause in local interactive testing. The extra byte is not attributed to a specific physical action.',
    disposition='All owned fixture jobs exited normally. Local interactive tests are paused by user request; no further local UI/clipboard tests authorized until resumed.',
    memory_acceptance=False,physical_input=False,
    acceptance='Source-host combined-image precheck only; full current workflows and accepted-product verification remain separate, and dist is unchanged.')
data['bundles'].append(dict(path=path.relative_to(work).as_posix(),archive_bytes=path.stat().st_size,
    archive_sha256=sha(path.read_bytes()),records=records))
manifest.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(records=len(records),archive_bytes=path.stat().st_size,executable_sha256=digest)))
