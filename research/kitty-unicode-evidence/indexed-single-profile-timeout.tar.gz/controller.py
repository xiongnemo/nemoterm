from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-relative-worktree'
base=root/'build/ci-kitty-unicode-index-single-fd0c253'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'single-run.json').read_text());source='fd0c2535314e4a3d0609eaff465962c1d96b2b14'
assert run['headSha']==source and run['status']=='completed' and run['conclusion']=='failure'
exe=base/'unverified-product/nemoterm.exe';digest=sha(exe.read_bytes())
assert digest=='992cabb4d424235e92f46586230c5282dab1ad3a92d1cef3bd7f1b63ff759115'
directory=base/'single-evidence/build/single-exe-check/research'
assert not (directory/'single-exe-validation.json').exists()
assert not list(directory.glob('*workload-tabs-*-memory.json'))
profile=directory/'tabs-profiles-observed.json';d=json.loads(profile.read_text())
assert d['executable_sha256']==digest and not d['completed'] and len(d['checks'])==7
assert d['phase']=='close-host' and d['close_request']['posted']
assert d['error'].startswith('TimeoutExpired(') and d['error'].endswith(', 15)')
state=d['process_before_cleanup']
assert state['exit_code'] is None and state['exit_code_after_observation'] is None
assert state['job']['active']==7 and d['owned_job_cleanup']['terminated_remaining']
assert any(w['hwnd']==d['close_request']['hwnd'] and w['kind']=='NemotermHost' and w['visible'] for w in state['windows'])
files={}
for p in base.glob('single-*'):
    if p.is_file():files[p.relative_to(base).as_posix()]=p.read_bytes()
for p in (profile,exe):files[p.relative_to(base).as_posix()]=p.read_bytes()
copies=[];pixels=[]
for p in directory.glob('kitty-unicode-*-observed.json'):
    o=json.loads(p.read_text());assert o['completed'] and o['executable_sha256']==digest
    if 'selection-' in p.name:
        assert len(o['checks'])==16 and all(c['matched'] and c['shortcut_utf8_hex']==c['expected_utf8_hex']==c['right_click_utf8_hex'] for c in o['checks'])
        copies.append(dict(name=p.name,cases=16,exact_copies=32,actual_renderer=o['actual_renderer']))
    else:
        phases=o['phases'] if 'phases' in o else o['checks']
        pixels.append(dict(name=p.name,phases=len(phases),actual_renderer=o['actual_renderer']))
    files[p.relative_to(base).as_posix()]=p.read_bytes()
assert len(copies)==3 and len(pixels)==6 and sum(p['phases'] for p in pixels)==153
for p in base.rglob('application-errors.json'):files[p.relative_to(base).as_posix()]=p.read_bytes()
for p in (base/'single-evidence/build/single-exe-check/logs').glob('*tabs*'):
    if p.is_file():files[p.relative_to(base).as_posix()]=p.read_bytes()
files['controller.py']=Path(__file__).read_bytes()
archive=work/'research/kitty-unicode-evidence/indexed-single-profile-timeout.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for record in records:assert sha(tar.extractfile(record['path']).read())==record['raw_sha256']
data=dict(source=source,run=run['databaseId'],url=run['url'],conclusion='failure',
    executable_sha256=digest,executable_bytes=exe.stat().st_size,executable_retained=True,
    profile_checks=7,failed_phase=d['phase'],close_timeout_seconds=15,root_alive_after_timeout=True,
    owned_processes_alive_after_timeout=7,cleanup_forced=True,unicode_pixels=pixels,unicode_clipboard=copies,
    scope='Earlier native graphics checks pass; mixed-profile close timeout prevents later memory groups and final product validation. No memory acceptance or distribution promotion.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
        archive_sha256=sha(archive.read_bytes()),records=records))
(work/'research/unicode-single-profile-validation.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,executable_sha256=digest)))
