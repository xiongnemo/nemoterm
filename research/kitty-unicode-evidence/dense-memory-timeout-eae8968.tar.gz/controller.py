from pathlib import Path
import gzip, hashlib, io, json, tarfile

root=Path(__file__).resolve().parents[1]; work=root/'build/kitty-relative-worktree'
base=root/'build/ci-kitty-unicode-memory-eae8968'
source='eae896846561f73fa1c444808ca3f7319707857a'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'single-run.json').read_text())
assert run['headSha']==source and run['conclusion']=='cancelled' and run['status']=='completed'
annotations=json.loads((base/'single-check-annotations.json').read_text(encoding='utf-8-sig'))
assert any(a['message']=='The job has exceeded the maximum execution time of 45m0s' for a in annotations)
artifacts=json.loads((base/'single-artifacts.json').read_text())['artifacts']
assert len(artifacts)==1 and artifacts[0]['id']==14150517760
files={}
for p in base.glob('single-*'):
    if p.is_file():files[p.relative_to(base).as_posix()]=p.read_bytes()
directory=base/'single-evidence/build/single-exe-check/research'
assert not (directory/'single-exe-validation.json').exists()
assert not list(directory.glob('unicode-*workload*observed.json'))
assert not list(directory.glob('unicode-*workload*memory.json'))
exe_sha='68bd5992457ecd06632f9e05099e119a5439ae0760e3df59b14bc2f57c2686e8'
memory=[]; copies=[]
for p in sorted(directory.glob('*workload-tabs-*-memory.json')):
    data=json.loads(p.read_text())
    observed_path=p.with_name(p.name.replace('-memory.json','-observed.json'))
    observed=json.loads(observed_path.read_text())
    assert observed['completed'] and observed['memory_limit_passed']
    assert observed['executable_sha256']==exe_sha
    assert not data['injected'] and not data['diagnostic_only'] and not data['errors']
    peak=data['peaks']['frontend']['private_ws']; limit=observed['memory_limit_bytes']
    assert peak<=limit if observed['memory_limit_inclusive'] else peak<limit
    memory.append(dict(name=p.name,grid=observed['actual_grid'],font=observed['font'],
        renderer=observed['renderer'],frontend=data['peaks']['frontend'],limit_bytes=limit,
        inclusive=observed['memory_limit_inclusive'],samples=data['sample_count']))
    for record in (p,observed_path):files[record.relative_to(base).as_posix()]=record.read_bytes()
assert len(memory)==10
for p in sorted(directory.glob('kitty-unicode-selection-*-observed.json')):
    data=json.loads(p.read_text())
    assert data['completed'] and data['executable_sha256']==exe_sha and len(data['checks'])==16
    assert all(c['matched'] and c['shortcut_utf8_hex']==c['expected_utf8_hex']==c['right_click_utf8_hex'] for c in data['checks'])
    assert data['clipboard_restore_finished'] and not data['cleanup']['terminated_remaining']
    copies.append(dict(name=p.name,requested=data['requested_renderer'],actual=data['actual_renderer'],
        cases=16,exact_copies=32,physical_input=data['physical_input'],instrumented=data['instrumented']))
    files[p.relative_to(base).as_posix()]=p.read_bytes()
assert len(copies)==3 and [c['actual'] for c in copies]==[2,0,0]
log=base/'single-evidence/build/single-exe-check/logs/unicode-kitty-workload-tabs-gdi-top.log'
files[log.relative_to(base).as_posix()]=log.read_bytes()
assert 'line 142 in exercise' in log.read_text()
files['controller.py']=Path(__file__).read_bytes()
archive=work/'research/kitty-unicode-evidence/dense-memory-timeout-eae8968.tar.gz'; records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name); info.size=len(raw); tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for r in records:assert sha(tar.extractfile(r['path']).read())==r['raw_sha256']
data=dict(source=source,run=run['databaseId'],url=run['url'],conclusion='cancelled',
    reason='45-minute whole-job deadline',executable_sha256=exe_sha,executable_retained=False,
    completed_earlier_memory=memory,unicode_clipboard=copies,
    dense_unicode_memory_completed=False,frontend_stack_available=False,
    observed_wait='Python controller repeatedly blocked at synchronous MoveWindow; frontend cause not established',
    scope='No complete single-file validation or dense Unicode memory acceptance. Existing ten memory groups and 96 exact clipboard copies are partial evidence only.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
        archive_sha256=sha(archive.read_bytes()),records=records))
(work/'research/unicode-dense-memory-validation.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,memory_groups=len(memory),exact_copies=96)))
