"""Read retained remote dump structures; stack words are not an unwound trace."""
from pathlib import Path
import bisect, hashlib, json, struct, sys

base=Path(sys.argv[1]).resolve()
out=[]
for arm in ('gdi','directx'):
    directory=base/arm
    exe=(directory/'runtime/nemoterm.exe').read_bytes()
    pe=struct.unpack_from('<I',exe,60)[0]
    image_base=struct.unpack_from('<Q',exe,pe+24+24)[0]
    symbols=[]
    for line in (directory/'frontend-symbols.txt').read_text().splitlines():
        fields=line.split()
        if len(fields)==3 and fields[1] in ('t','T'):
            symbols.append((int(fields[0],16)-image_base,fields[2]))
    symbols.sort();addresses=[s[0] for s in symbols]
    for path in sorted(directory.glob('observations/resize-diagnostic-*/*/failure.dmp')):
        raw=path.read_bytes();assert raw[:4]==b'MDMP'
        count,offset=struct.unpack_from('<II',raw,8)
        streams={t:(size,rva) for t,size,rva in (struct.unpack_from('<III',raw,offset+12*i) for i in range(count))}
        for size,rva in streams.values():assert rva+size<=len(raw)
        size,rva=streams[4];modules=[]
        for i in range(struct.unpack_from('<I',raw,rva)[0]):
            at=rva+4+108*i
            address,length,checksum,timestamp,name_at=struct.unpack_from('<QIIII',raw,at)
            name_bytes=struct.unpack_from('<I',raw,name_at)[0]
            name=raw[name_at+4:name_at+4+name_bytes].decode('utf-16le').split('\\')[-1]
            modules.append(dict(name=name,base=address,bytes=length,timestamp=timestamp,checksum=checksum))
        def resolve(address):
            for module in modules:
                if module['base']<=address<module['base']+module['bytes']:
                    delta=address-module['base'];result=module['name']+'+'+hex(delta)
                    if module['name'].lower()=='nemoterm.exe':
                        i=bisect.bisect_right(addresses,delta)-1
                        if i>=0:result+=' ('+symbols[i][1]+'+'+hex(delta-addresses[i])+')'
                    return result
            return None
        cpu={}
        if 17 in streams:
            size,rva=streams[17];header,entry,count=struct.unpack_from('<III',raw,rva)
            assert header>=12 and entry>=64 and header+entry*count<=size
            for i in range(count):
                values=struct.unpack_from('<IIIIQQQQQQ',raw,rva+header+i*entry)
                cpu[values[0]]=dict(dump_flags=values[1],dump_error=values[2],exit_status=values[3],
                    created=values[4],kernel_100ns=values[6],user_100ns=values[7])
        size,rva=streams[3];threads=[]
        for i in range(struct.unpack_from('<I',raw,rva)[0]):
            at=rva+4+48*i;tid=struct.unpack_from('<I',raw,at)[0]
            stack,stack_size,stack_rva,context_size,context_rva=struct.unpack_from('<QIIII',raw,at+24)
            assert context_size>=256 and context_rva+context_size<=len(raw)
            assert stack_rva+stack_size<=len(raw)
            rip=struct.unpack_from('<Q',raw,context_rva+248)[0]
            rsp=struct.unpack_from('<Q',raw,context_rva+152)[0]
            candidates=[]
            for delta in range(max(0,rsp-stack),stack_size-7,8):
                pointer=struct.unpack_from('<Q',raw,stack_rva+delta)[0]
                if name:=resolve(pointer):candidates.append(dict(stack_address=hex(stack+delta),pointer=hex(pointer),symbol=name))
            threads.append(dict(tid=tid,rip=hex(rip),rsp=hex(rsp),instruction=resolve(rip),
                cpu=cpu.get(tid),raw_stack_pointer_candidates=candidates))
        result=dict(path=path.relative_to(base).as_posix(),sha256=hashlib.sha256(raw).hexdigest(),
            executable_sha256=hashlib.sha256(exe).hexdigest(),modules=modules,threads=threads,
            caveat='Captured instruction/CPU times; raw stack words are candidates, not an unwound call chain. Nearest frontend symbols come from the retained rebuilt image.')
        out.append(result)
        print(json.dumps(dict(path=result['path'],threads=[dict(tid=t['tid'],instruction=t['instruction'],cpu=t['cpu'],
            frontend_stack_candidates=[c['symbol'] for c in t['raw_stack_pointer_candidates'] if c['symbol'].startswith('nemoterm.exe')][:14]) for t in threads])))
(base/'dump-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
