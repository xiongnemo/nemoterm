from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-relative-worktree'
base=root/'build/ci-unicode-resize-baseline-84e6f80'
indexed=root/'build/ci-unicode-resize-diagnostic-84e6f80'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'dense-run.json').read_text())
assert run['headSha']=='84e6f80ef4eb631626fafd32ade9783547b112e8' and run['conclusion']=='failure'
analyses=json.loads((base/'dump-analysis.json').read_text());assert len(analyses)==4
results=[]
for arm in ('gdi','directx'):
    directory=base/arm;identity=json.loads((directory/'identity.json').read_text(encoding='utf-8-sig'))
    assert identity['production_source']=='eae896846561f73fa1c444808ca3f7319707857a'
    assert identity['fixture_source']==run['headSha'] and not identity['exact_failed_image']
    for item in identity['runtime_hashes']:
        name=item['Path'].replace('\\','/').split('/')[-1]
        assert sha((directory/'runtime'/name).read_bytes())==item['Hash'].lower()
    controls=json.loads((directory/'dump-controls/controls/results.json').read_text())
    assert len(controls)==3 and all(r['passed'] for r in controls)
    assert 'Timeout (0:03:00)!' in (directory/'workload.log').read_text()
    assert not list((directory/'observations').glob('*observed.json'))
    resizes=list((directory/'observations').glob('resize-diagnostic-*/resize-*.json'));assert len(resizes)==1
    record=json.loads(resizes[0].read_text());assert record['index']==0 and not record['returned']
    assert len(record['samples'])==2
    for sample in record['samples']:
        capture=sample['capture']
        assert capture['exit_code']==0 and capture['target_exit_after_capture'] is None
        assert not capture.get('error') and not capture['helper_cleanup']['terminated_remaining']
        assert not sample['resize_returned_during_capture']
    progress=json.loads(next((directory/'observations').glob('*progress*.json')).read_text())
    assert progress['phase']=='frame-0' and progress['operation']=='before-window-resize'
    candidate=json.loads(next((indexed/arm/'observations').glob('*observed.json')).read_text())
    assert progress['last_input']==candidate['workload']['unicode_inputs'][0]
    dumps=[a for a in analyses if a['path'].startswith(arm+'/')]
    threads=[max(d['threads'],key=lambda t:t['cpu']['user_100ns'] if t['cpu'] else -1) for d in dumps]
    assert threads[0]['tid']==threads[1]['tid'] and threads[0]['cpu']['created']==threads[1]['cpu']['created']
    delta=sum(threads[1]['cpu'][k]-threads[0]['cpu'][k] for k in ('kernel_100ns','user_100ns'))/1e7
    assert delta>25
    results.append(dict(renderer=arm,executable_sha256=sha((directory/'runtime/nemoterm.exe').read_bytes()),
        progress=progress['last_input'],resize_returned=False,dump_count=2,thread_id=threads[0]['tid'],
        instructions=[t['instruction'] for t in threads],cpu_delta_seconds=delta,
        first_input_matches_indexed_diagnostic=True))
files={p.relative_to(base).as_posix():p.read_bytes() for p in base.rglob('*') if p.is_file()}
files['controller.py']=Path(__file__).read_bytes()
files['dump-parser.py']=(root/'build/inspect-dense-resize-dumps.py').read_bytes()
archive=work/'research/kitty-unicode-evidence/preindex-native-resize-stall.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for record in records:assert sha(tar.extractfile(record['path']).read())==record['raw_sha256']
data=dict(run=run['databaseId'],url=run['url'],fixture_source=run['headSha'],
    production_source=identity['production_source'],conclusion='failure',results=results,
    outcome='180-second diagnostic watchdog stops both controllers at their first outstanding resize. Source rebuilds reproduce CPU-bound placement lookup during painting; no original single-image replay.',
    evidence_limit='Captured instructions and CPU times are direct dump fields. Raw stack words are candidates, not an unwound call chain. Different hosted runners do not provide a matched latency benchmark.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
                archive_sha256=sha(archive.read_bytes()),records=records))
(work/'research/unicode-preindex-stall-validation.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,results=results)))
