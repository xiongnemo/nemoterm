"""Collect exact-source workflow evidence without restarting or cancelling runs."""
from pathlib import Path
import concurrent.futures,datetime,json,subprocess,sys,time
root=Path(__file__).resolve().parents[1]
source=sys.argv[1];base=Path(sys.argv[2]).resolve();base.mkdir(exist_ok=True)
pending={kind:int(run) for kind,run in (arg.split('=') for arg in sys.argv[3:])}
previous={};deadline=time.monotonic()+3300
def read_command(command,timeout=30):
    for attempt in range(3):
        try:
            return subprocess.check_output(command,cwd=root,text=True,timeout=timeout,stderr=subprocess.PIPE)
        except (subprocess.CalledProcessError,subprocess.TimeoutExpired) as error:
            event={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attempt':attempt+1,
                   'command':command,'error':repr(error),'stderr':str(error.stderr or '')}
            with (base/'observer-errors.jsonl').open('a',encoding='utf-8') as log:log.write(json.dumps(event)+'\n')
            print('Observer read failed; CI state is unknown until refreshed',flush=True)
            if attempt==2:raise
            time.sleep(2*(attempt+1))
while pending:
    for kind,run in list(pending.items()):
        raw=read_command(['gh','run','view',str(run),'--json','databaseId,headSha,status,conclusion,jobs,url'])
        data=json.loads(raw);assert data['headSha']==source
        (base/(kind+'-run.json')).write_text(raw,encoding='utf-8')
        (base/(kind+'-observed-at.txt')).write_text(datetime.datetime.now(datetime.timezone.utc).isoformat(),encoding='utf-8')
        state=(data['status'],data['conclusion'])
        if previous.get(kind)!=state:print(kind,state,flush=True);previous[kind]=state
        if data['status']!='completed':continue
        (base/(kind+'-run.log')).write_text(read_command(['gh','run','view',str(run),'--log'],120),encoding='utf-8')
        raw=read_command(['gh','api',f'repos/xiongnemo/nemoterm/actions/runs/{run}/artifacts'])
        (base/(kind+'-artifacts.json')).write_text(raw,encoding='utf-8')
        artifacts=json.loads(raw)['artifacts']
        wanted=([('nemoterm-single-exe-x64-','product'),('single-exe-evidence-','single-evidence'),('unverified-single-exe-x64-','unverified-product')]
                if kind=='single' else [('test-results-windows-','core-evidence'),('test-results-sanitizers-','sanitizers'),
                ('cluster-msvc-diagnostics-','msvc'),('unverified-msvc-renderer-','unverified-msvc'),('nemoterm-windows-x64-','portable')])
        if kind=='census':wanted=[]
        if kind=='reference':wanted=[('kitty-graphics-reference-','reference')]
        if kind=='compression':wanted=[('kitty-compression-reference-','reference')]
        if kind=='features':wanted=[('kitty-features-reference-','reference')]
        if kind=='query-errors':wanted=[('kitty-query-errors-reference-','reference')]
        if kind=='tabs':wanted=[('tabs-close-diagnostic-','diagnostic')]
        if kind=='components':
            (base/'components').mkdir(exist_ok=True)
            wanted=[(f'kitty-transport-{compiler}-',f'components/kitty-transport-{compiler}-{source}') for compiler in ('gcc','clang','msvc')]
        def download(item):
            prefix,folder=item
            found=[a for a in artifacts if a['name']==prefix+source and not a['expired']]
            if not found:return dict(folder=folder,missing=True)
            # A completed prior download has an artifact-id receipt; never
            # mistake an existing partial directory for a verified artifact.
            receipt=base/(folder+'-download.json')
            if receipt.exists() and json.loads(receipt.read_text())['artifact_id']==found[0]['id']:
                return dict(folder=folder,artifact_id=found[0]['id'],previously_downloaded=True)
            subprocess.run(['gh','run','download',str(run),'-n',prefix+source,'-D',str(base/folder)],cwd=root,check=True,timeout=240)
            receipt.write_text(json.dumps({'artifact_id':found[0]['id'],'source':source}),encoding='utf-8')
            return dict(folder=folder,artifact_id=found[0]['id'])
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            for result in pool.map(download,wanted):print(json.dumps(result),flush=True)
        del pending[kind]
    assert time.monotonic()<deadline,'Observation deadline; leave running workflows intact'
    if pending:time.sleep(20)
print('Completed workflow evidence collected',flush=True)
