from pathlib import Path
import gzip,hashlib,json,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-relative-worktree'
manifest=dict(upstream_commit='8e5487e9d4a1dd79c3a769e0ba82326b8ad7c37f',
    scope='Independent compiled-upstream Unicode image reference; Nemoterm implementation and native acceptance pending',
    captures=[],bundles=[])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
destination=work/'research/kitty-unicode-evidence';destination.mkdir(exist_ok=True)
for folder,label,truncated in [('ci-kitty-unicode-ffdb7f6','rendered-journal-truncated',True),
                               ('ci-kitty-unicode-f536f4c','upstream-reference',False)]:
    base=root/'build'/folder
    run=json.loads((base/'unicode-run.json').read_text())
    evidence=json.loads((base/'reference/rea-evidence.json').read_text())
    capture=evidence['normalized_result']
    data=json.loads((base/'reference/observations.json').read_text())
    assert (data['case_count'],data['state_count'],len(data['diacritic_codepoints']))==(97,728,297)
    assert data['status']=='complete' and data['upstream_tests']['successful'] and data['upstream_tests']['run']==8
    assert not data['upstream_tests']['skipped'] and capture['truncated']==truncated
    assert capture['exit']['reason']=='exited' and capture['exit']['code']==0
    assert capture['cleanup']==dict(owned_process_group='verified',temporary_root='removed')
    digest=sha(base/'reference/observations.json')
    assert any(f.get('sha256')==digest for f in capture['files_after'])
    files={p.relative_to(base).as_posix():p for p in base.rglob('*') if p.is_file()}
    files['controllers/retainer.py']=Path(__file__)
    files['controllers/collector.py']=root/'build/watch-kitty-unicode-checkpoint.py'
    files['controllers/collector-base.py']=root/'build/watch-ci-checkpoint.py'
    path=destination/(label+'.tar.gz');rows=[]
    with path.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w|') as tar:
        for name,p in sorted(files.items()):
            info=tarfile.TarInfo(name);info.size=p.stat().st_size
            with p.open('rb') as f:tar.addfile(info,f)
            rows.append(dict(path=name,raw_bytes=info.size,raw_sha256=sha(p)))
    with tarfile.open(path,'r:gz') as tar:
        for row in rows:assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest()==row['raw_sha256']
    manifest['bundles'].append(dict(path=path.relative_to(work).as_posix(),archive_bytes=path.stat().st_size,
        archive_sha256=sha(path),records=rows))
    artifact=json.loads((base/'unicode-artifacts.json').read_text())['artifacts'][0]
    manifest['captures'].append(dict(label=label,source_commit=run['headSha'],run=run['databaseId'],
        conclusion=run['conclusion'],artifact_id=artifact['id'],observations_sha256=digest,
        evidence_id=evidence['evidence_id'],exit=capture['exit'],cleanup=capture['cleanup'],
        truncated=capture['truncated'],truncation_details=capture['truncation_details'],limitations=evidence['limitations'],
        upstream_tests=data['upstream_tests'],cases=97,states=728,diacritics=297))
    print(json.dumps(dict(label=label,observations_sha256=digest,records=len(rows),archive_bytes=path.stat().st_size)))
(work/'research/kitty-unicode-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
