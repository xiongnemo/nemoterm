from pathlib import Path
source=Path(__file__).with_name('watch-ci-checkpoint.py').read_text()
needle="        if kind=='query-errors':wanted=[('kitty-query-errors-reference-','reference')]"
assert source.count(needle)==1
source=source.replace(needle,needle+"\n        if kind=='unicode':wanted=[('kitty-unicode-reference-','reference')]")
exec(compile(source,str(Path(__file__)),'exec'))
