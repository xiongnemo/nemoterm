from pathlib import Path
import gzip,hashlib,json,re,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-relative-worktree'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def archive(relative,files):
    path=work/relative;rows=[]
    with path.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w|') as tar:
        for name,p in sorted(files.items()):
            info=tarfile.TarInfo(name);info.size=p.stat().st_size
            with p.open('rb') as f:tar.addfile(info,f)
            rows.append(dict(path=name,raw_bytes=info.size,raw_sha256=sha(p)))
    with tarfile.open(path,'r:gz') as tar:
        for row in rows:assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest()==row['raw_sha256']
    return dict(path=relative,archive_bytes=path.stat().st_size,archive_sha256=sha(path),records=rows)

base=root/'build/kitty-unicode-core-baseline'
record=json.loads((base/'baseline.json').read_text())
assert (record['states'],record['failed_states'],record['exit_code'])==(728,681,1)
assert sha(base/'core.log')==record['log_sha256']
(base/'compiler.txt').write_bytes(subprocess.check_output(['C:/Users/nemo/scoop/apps/mingw-msvcrt/current/bin/gcc.exe','--version']))
files={p.relative_to(base).as_posix():p for p in base.rglob('*') if p.is_file()}
files['controllers/capture.py']=root/'build/capture-kitty-unicode-baseline.py'
files['controllers/retain.py']=Path(__file__)
bundle=archive('research/kitty-unicode-evidence/core-baseline.tar.gz',files)
path=work/'research/kitty-unicode-validation.json';manifest=json.loads(path.read_text())
assert 'baseline' not in manifest
manifest['baseline']=record;manifest['bundles'].append(bundle)
path.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(kind='unicode-baseline',records=len(bundle['records']),bytes=bundle['archive_bytes'])))

base=root/'build/ci-kitty-relative-656fed4';source='656fed46c0dff401e657f394c2550f35e61effed'
runs={name:json.loads((base/(name+'-run.json')).read_text()) for name in ('core','components')}
assert all(r['headSha']==source and r['status']=='completed' and r['conclusion']=='failure' for r in runs.values())
logs=[base/'core-evidence/test-results/test_sixel_terminal.log',base/'sanitizers/terminal-image-sanitizers.log']
for compiler in ('gcc','clang','msvc'):
    p=base/f'components/kitty-transport-{compiler}-{source}'
    logs.append(p/('terminal-test.log' if compiler=='msvc' else 'terminal-sanitizers.log'))
failures=['virtual-parent/'+s for s in ('virtual-root','relative-child','placeholder','earlier-placeholder','erase-placeholders')]
for p in logs:
    t=p.read_text(encoding='utf-8-sig')
    assert re.findall(r'^Kitty relative failed state: (.+)$',t,re.M)==failures,p
    assert 'Kitty relative replay: 238 states; 5 failed states' in t,p
    assert 'ERROR: AddressSanitizer' not in t and 'runtime error:' not in t,p
    assert all('(Kitty relative replay:' in s for s in t.splitlines() if '/test/test_' in s),p
files={p.relative_to(base).as_posix():p for name in ('components','core-evidence','sanitizers','msvc') for p in (base/name).rglob('*') if p.is_file()}
for kind in ('core','components'):
    for suffix in ('run.json','run.log','artifacts.json','observed-at.txt'):
        p=base/(kind+'-'+suffix);files[p.name]=p
files['controllers/collector.py']=root/'build/watch-ci-checkpoint.py'
files['controllers/retainer.py']=Path(__file__)
bundle=archive('research/kitty-relative-evidence/ci-656fed4.tar.gz',files)
record=dict(source_commit=source,runs={k:dict(id=v['databaseId'],conclusion=v['conclusion'],
    jobs=[dict(name=j['name'],conclusion=j['conclusion']) for j in v['jobs']]) for k,v in runs.items()},
    matched_relative_states=233,failed_relative_states=failures,
    replay_logs=[p.relative_to(base).as_posix() for p in logs],
    scope='Completed core/component CI and MSVC native regression evidence; Unicode images and relative native/product acceptance remain pending',bundle=bundle)
(work/'research/kitty-relative-ci-656fed4.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(kind='relative-ci',records=len(bundle['records']),bytes=bundle['archive_bytes'])))
