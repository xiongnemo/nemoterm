from pathlib import Path
import hashlib,json,re,subprocess
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-relative-worktree'
base=root/'build/kitty-unicode-core-baseline';base.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip()
assert head=='f536f4c58de4103ab5b45e6a3f445f5c1c1f8edb'
assert not subprocess.check_output(['git','diff','--name-only','--','vendor/putty-0.85/terminal','vendor/putty-0.85/windows'],cwd=work)
(base/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=work))
paths=['tests/kitty_unicode_oracle.py','scripts/generate-kitty-unicode-reference.py',
       'vendor/putty-0.85/test/test_kitty_unicode.inc','vendor/putty-0.85/test/kitty_unicode_reference.h',
       'vendor/putty-0.85/test/test_kitty_terminal.inc','build/CMakeCache.txt']
for path in paths:
    p=base/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((work/path).read_bytes())
exe=work/'build/test_sixel_terminal.exe'
before=sha(exe)
result=subprocess.run([str(exe)],cwd=work,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
(base/'core.log').write_bytes(result.stdout)
assert sha(exe)==before and result.returncode==1
text=result.stdout.decode('utf-8')
match=re.search(r'Kitty Unicode replay: (\d+) states; (\d+) failed states',text)
assert match and int(match[1])==728
failures=re.findall(r'^Kitty Unicode failed state: (.+)$',text,re.M)
assert len(failures)==int(match[2])
assert 'Kitty relative replay: 238 states; 5 failed states' in text
assert all('(Kitty relative replay:' in s or '(Kitty Unicode replay:' in s for s in text.splitlines() if s.startswith('/putty/'))
record=dict(base_commit=head,executable_sha256=before,exit_code=result.returncode,
    states=728,failed_states=len(failures),failed_cases=len({x.split('/')[0] for x in failures}),
    failures=failures,log_sha256=sha(base/'core.log'),relative_failed_states=5,
    files={p:sha(work/p) for p in paths},scope='Unchanged 656fed4 production code with strict new Unicode replay; failing baseline only')
(base/'baseline.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('files','failures')}))
