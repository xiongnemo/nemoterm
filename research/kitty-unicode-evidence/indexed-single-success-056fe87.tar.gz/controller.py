from pathlib import Path, PureWindowsPath
import gzip,hashlib,io,json,subprocess,tarfile

root=Path(__file__).resolve().parents[1]
work=root/'build/kitty-relative-worktree'
base=root/'build/ci-kitty-index-profile-capture-056fe87'
native=base/'single-evidence/build/single-exe-check/research'
source='056fe87062d494127e5b880245f4b0db962463a0'
core_source='f01927ae12841fe7b657c5d86b3e637deb02b422'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
run=read(base/'single-run.json')
assert run['databaseId']==43690641263 and run['headSha']==source and run['conclusion']=='success'
assert all(j['conclusion']=='success' for j in run['jobs'])
subprocess.check_call(['git','diff','--quiet',core_source,source,'--','vendor','native',
    'scripts/build.ps1','scripts/build-single-exe.ps1','scripts/prepare-single-exe.py'],cwd=work)
core=read(work/'research/unicode-indexed-core-validation.json')
assert core['source']==core_source and core['conclusion']=='success' and core['jobs']==4
product=base/'product/nemoterm.exe'
digest=sha(product.read_bytes())
assert digest=='f36c3c997d37c668ab18054f1578d27192b989eb37942570eca0c1426134ddb8'
validation=read(native/'single-exe-validation.json')
assert validation['executable_sha256']==digest and validation['executable_bytes']==product.stat().st_size==4523520
assert len(validation['passed_checks'])==len(set(validation['passed_checks']))==154
assert validation['executable_directory_files']==['nemoterm.exe'] and validation['shutdown_frida_version']=='17.23.3'
controls=read(base/'single-evidence/build/profile-failure-dump/controls/results.json')
assert len(controls)==3 and all(c['passed'] for c in controls)
profiles=read(native/'tabs-profiles-observed.json')
assert profiles['completed'] and profiles['frontend_exit']==0 and len(profiles['checks'])==7
assert profiles['executable_sha256']==digest and not profiles['owned_job_cleanup']['terminated_remaining']
assert profiles['failure_dump_enabled'] and not profiles.get('failure_dump')
assert not list(native.glob('profiles-failure-*'))
memory=[];pixels=0
for p in sorted(native.glob('*-memory.json')):
    sample=read(p);record=read(p.with_name(p.name.replace('-memory','-observed')))
    assert record['completed'] and record['executable_sha256']==digest
    assert record['memory_limit_passed'] and not record['memory_instrumented']
    assert not record['owned_job_cleanup']['terminated_remaining']
    assert not any(sample[k] for k in ('injected','kernel_etw_recording','external_diagnostic','diagnostic_only','errors'))
    peak=sample['peaks']['frontend']['private_ws'];limit=record['memory_limit_bytes']
    assert peak<=limit if record['memory_limit_inclusive'] else peak<limit
    memory.append(dict(name=p.name,grid=record['actual_grid'],font=record['font'],
        renderer=record['actual_renderer'],frontend=sample['peaks']['frontend'],
        samples=sample['sample_count'],seconds=sample['seconds'],limit_bytes=limit,
        inclusive=record['memory_limit_inclusive']))
    if p.name.startswith('unicode-'):
        frames=record['post_memory_kitty_unicode']
        assert len(frames)==4
        for frame in frames:
            assert frame['matched'] and frame['after_memory_sampling'] and not frame['injected']
            assert all(row['matched'] for row in frame['rows'])
            pixels+=frame['cells_verified']
assert len(memory)==12 and pixels==25048
stages=0;copies=0;image_records=[]
for renderer in ('gdi','opengl','directx'):
    for kind in ('kitty-unicode','kitty-unicode-geometry','kitty-unicode-selection'):
        p=native/f'{kind}-{renderer}-observed.json';record=read(p)
        assert record['completed'] and record['executable_sha256']==digest
        assert not record['cleanup']['terminated_remaining']
        checks=record['phases'] if 'phases' in record else record['checks']
        assert all(c['matched'] for c in checks)
        if kind=='kitty-unicode-selection':
            assert record['clipboard_restore_finished']
            for c in checks:
                assert c['expected_utf8_hex']==c['shortcut_utf8_hex']==c['right_click_utf8_hex']
                copies+=2
        else:
            stages+=len(checks)
            if kind=='kitty-unicode':
                folder=native/PureWindowsPath(record['folder']).name
                for c in checks:
                    assert sha((folder/c['bmp']).read_bytes())==c['bmp_sha256']
        image_records.append(dict(name=p.name,actual_renderer=record['actual_renderer'],checks=len(checks)))
assert stages==153 and copies==96
artifacts=read(base/'single-artifacts.json')['artifacts']
artifact=next(a for a in artifacts if a['name']=='nemoterm-single-exe-x64-'+source)
assert artifact['id']==14153711098 and not artifact['expired']
accepted_digest='1655120a9a64bfd29b64f6ad0a5cc912484ba1d242ec560938591c03328e2cf1'
assert sha((root/'dist/nemoterm.exe').read_bytes())==accepted_digest
archive=work/'research/kitty-unicode-evidence/indexed-single-success-056fe87.tar.gz'
records=[]
paths=sorted(p for p in base.rglob('*') if p.is_file())
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0,compresslevel=6) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    # One record at a time: the original evidence expands to over 600 MB.
    for p in [*paths,Path(__file__)]:
        name='controller.py' if p==Path(__file__) else p.relative_to(base).as_posix()
        raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw)
        tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive,mode='r|gz') as tar:
    for entry,record in zip(tar,records,strict=True):
        assert entry.name==record['path'] and sha(tar.extractfile(entry).read())==record['raw_sha256']
manifest=dict(source=source,run=run['databaseId'],url=run['url'],conclusion='success',
    ordinary_run=core['run'],ordinary_source=core_source,unchanged_production=True,
    executable_sha256=digest,executable_bytes=product.stat().st_size,
    artifact_id=artifact['id'],expires_at=artifact['expires_at'],single_file_groups=154,
    uninjected_memory=memory,post_memory_cell_centres=pixels,native_unicode_stages=stages,
    exact_clipboard_copies=copies,native_images=image_records,profile_groups=7,profile_dump_controls=3,
    accepted_local_sha256=accepted_digest,local_acceptance=False,
    scope='Full single-image CI passes with unchanged indexed production source. Remote Consolas grids and GL fallback do not establish local 160x48 Sarasa or actual OpenGL acceptance. Earlier close failures remain unresolved; local distribution unchanged.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
        archive_sha256=sha(archive.read_bytes()),records=records))
(work/'research/unicode-indexed-single-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(records=len(records),archive_bytes=archive.stat().st_size,
                     groups=154,cell_centres=pixels,unicode_stages=stages,clipboard_copies=copies)))
