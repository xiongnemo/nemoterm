from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-relative-worktree'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={};runs=[]
for iteration in ('01','02'):
    for renderer in ('gdi','opengl','directx','presented-gdi'):
        report=root/f'build/kitty-unicode-native-baseline-01/{renderer}.json' if iteration=='01' else work/f'research/kitty-unicode-{renderer}-observed.json'
        d=json.loads(report.read_text());folder=Path(d['folder'])
        assert not d['cleanup']['terminated_remaining'] and not d['cleanup']['remaining_processes']
        assert d['profile_removed'] and not d['global_input'] if 'global_input' in d else d['profile_removed']
        if iteration=='02':assert d['completed'] and len(d['checks'])==30 and all(c['matched'] for c in d['checks'])
        elif renderer=='gdi':assert d['completed'] and len(d['checks'])==30
        else:assert not d['completed'] and d['checks'][-1]['name']=='erase-all-anchors-hides-child'
        prefix=iteration+'/'+renderer
        files[prefix+'/observed.json']=report
        files.update({prefix+'/'+p.relative_to(folder).as_posix():p for p in folder.rglob('*') if p.is_file()})
        log=root/f'build/kitty-unicode-native-{renderer}-{iteration}.log'
        files[prefix+'/controller.log']=log
        runs.append(dict(iteration=iteration,renderer=renderer,actual_renderer=d['actual_renderer'],
            completed=d['completed'],stages=len(d['checks']),matched=sum(c['matched'] for c in d['checks']),
            executable_sha256=d['executable_sha256'],font=d['command'][d['command'].index('--font')+1],
            capture=d['capture'],cleanup=d['cleanup'],report=prefix+'/observed.json'))
for name in ('kitty-unicode-repaint-build.log','kitty-unicode-repaint-regression-build.log','kitty-unicode-repaint-core.log',
             'kitty-unicode-repaint-graphemes.log','kitty-unicode-repaint-terminal.log'):
    files['regressions/'+name]=root/'build'/name
files['source/kitty_unicode_window_smoke.py']=work/'tests/kitty_unicode_window_smoke.py'
files['source/terminal.c']=work/'vendor/putty-0.85/terminal/terminal.c'
files['controller.py']=Path(__file__)
files['runtime/SOURCE-HOST.json']=work/'build/SOURCE-HOST.json'
files['runtime/CONPTY-RUNTIME.json']=work/'build/CONPTY-RUNTIME.json'
path=work/'research/kitty-unicode-evidence/native-repaint.tar.gz';records=[]
with path.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w|') as tar:
    for name,p in sorted(files.items()):
        raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw)
        tar.addfile(info,io.BytesIO(raw));records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(p)))
with tarfile.open(path) as tar:
    for r in records:assert hashlib.sha256(tar.extractfile(r['path']).read()).hexdigest()==r['raw_sha256']
bundle=dict(path=path.relative_to(work).as_posix(),archive_bytes=path.stat().st_size,archive_sha256=sha(path),records=records)
manifest=work/'research/kitty-unicode-validation.json';data=json.loads(manifest.read_text())
data['native_repaint']=dict(runs=runs,baseline_source='3ee3235e4f90e53dc81dc56604812ac322607b9f',
    fixed_source='Repaint generation change retained in native-repaint.tar.gz source/terminal.c',
    fixed_frontend='Local MinGW build with unchanged source-built headless host from 3ee3235; not a single-file acceptance',
    passed_pixel_states=120,memory_acceptance=False,physical_input=False,
    cause='After text removed the last virtual anchor, current-view-only invalidation left child pixels in the retained surface; API GDI snapshot forced repaint and masked the defect')
data['bundles'].append(bundle)
data['scope']='Core and development native Unicode image implementation; all 120 local renderer/presented checks pass after repaint fix; fresh combined single-image CI, resize/disposal and memory acceptance pending'
manifest.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(records=len(records),archive_bytes=bundle['archive_bytes'],runs=[{k:r[k] for k in ('iteration','renderer','completed','matched')} for r in runs])))
