from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-relative-worktree'
base=root/'build/ci-kitty-unicode-repaint-191c641'
old=root/'build/ci-kitty-unicode-3ee3235'
source='191c6411faddec119304e7148fa47d0bdc1fd12f'
files={};results={};sha=lambda b:hashlib.sha256(b).hexdigest()
for label,path in (('repaint',base),('superseded',old)):
    for kind in ('core','single','components'):
        d=json.loads((path/f'{kind}-run.json').read_text())
        assert d['status']=='completed'
        if label=='repaint':assert d['headSha']==source and d['conclusion']=='success'
        else:assert d['conclusion']==('success' if kind=='components' else 'cancelled')
        results[label+'-'+kind]=dict(run=d['databaseId'],source=d['headSha'],conclusion=d['conclusion'],url=d['url'])
        for suffix in ('run.json','run.log','artifacts.json','observed-at.txt'):
            p=path/f'{kind}-{suffix}';assert p.is_file()
            files[label+'/'+p.name]=p.read_bytes()
validation=base/'single-evidence/build/single-exe-check/research/single-exe-validation.json'
d=json.loads(validation.read_text());exe=base/'product/nemoterm.exe'
assert d['executable_sha256']==sha(exe.read_bytes()) and d['executable_bytes']==exe.stat().st_size
assert len(d['passed_checks'])==146 and d['executable_directory_files']==['nemoterm.exe']
files['repaint/single-exe-validation.json']=validation.read_bytes()
for name in ('kitty-unicode-selection-build.log','kitty-unicode-selection-core.log'):
    files['selection/'+name]=(root/'build'/name).read_bytes()
assert b'Kitty Unicode selections: 32 exact core copies checked' in files['selection/kitty-unicode-selection-core.log']
assert b'Sixel terminal suite passed' in files['selection/kitty-unicode-selection-core.log']
for name in ('test_kitty_unicode.inc','test_kitty_terminal.inc'):
    files['selection/'+name]=(work/'vendor/putty-0.85/test'/name).read_bytes()
files['controller.py']=Path(__file__).read_bytes()
archive=work/'research/kitty-unicode-evidence/ci-repaint-and-selection.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for r in records:assert sha(tar.extractfile(r['path']).read())==r['raw_sha256']
manifest=work/'research/kitty-unicode-validation.json';data=json.loads(manifest.read_text())
data['repaint_ci']=dict(results=results,single_executable_sha256=d['executable_sha256'],
    single_executable_bytes=d['executable_bytes'],passed_check_groups=146,
    superseded='Automatic same-branch concurrency cancellation when the repaint fix workflows were dispatched; not a test pass or diagnosed test failure',
    acceptance='191c641 predates transparent-border/roundoff fixes. Downloaded and verified, not promoted to dist.')
data['core_selection']=dict(copies=32,platform='Local Windows GCC 16.2',system_clipboard=False,
    cases='Main/alternate screen, application mouse on/off, linear/rectangle, mode 2027 on/off, repeated after image preparation',
    executable_sha256=sha((work/'build/test_sixel_terminal.exe').read_bytes()),
    scope='Exact original PUA and combining marks, expected platform newline, no forwarded mouse bytes; native clipboard/pixels still pending')
data['bundles'].append(dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
    archive_sha256=sha(archive.read_bytes()),records=records))
manifest.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(records=len(records),archive_bytes=archive.stat().st_size,results=results,
    core_selection_executable=data['core_selection']['executable_sha256'])))
