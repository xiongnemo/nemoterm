from pathlib import Path
import gzip, hashlib, io, json, statistics, tarfile

root=Path(__file__).resolve().parents[1]
work=root/'build/kitty-relative-worktree'
baseline=root/'build/ci-kitty-cell-baseline-a7e40bd'
failure=root/'build/ci-kitty-unicode-memory-eae8968'
source='a7e40bdc698dfa268b2bebe8c426d82e7a2d9130'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
files={}
run=json.loads((baseline/'components-run.json').read_text())
assert run['headSha']==source and run['status']=='completed' and run['conclusion']=='success'
assert all(j['conclusion']=='success' for j in run['jobs'])
for p in baseline.rglob('*'):
    if p.is_file():files['baseline/'+p.relative_to(baseline).as_posix()]=p.read_bytes()
summary={}
for compiler in ('gcc','clang','msvc'):
    p=baseline/f'components/kitty-transport-{compiler}-{source}/placements-benchmark.jsonl'
    rows=[json.loads(line) for line in p.read_text(encoding='utf-8-sig').splitlines()]
    assert len(rows)==42
    values=[]
    for templates in (1,16):
        for cells in (256,512,1024,2048,4096,7268,8192):
            chosen=[r for r in rows if (r['templates'],r['cells'])==(templates,cells)]
            assert sorted(r['repeat'] for r in chosen)==[0,1,2]
            assert all(r['clock_hz']>0 and r['view_passes']==4 for r in chosen)
            values.append(dict(cells=cells,templates=templates,
                create_ms=statistics.median(r['create_ticks']/r['clock_hz']*1000 for r in chosen),
                view_pass_ms=statistics.median(r['view_ticks']/r['clock_hz']/r['view_passes']*1000 for r in chosen),
                clear_ms=statistics.median(r['clear_ticks']/r['clock_hz']*1000 for r in chosen),
                placement_bytes=chosen[0]['placement_bytes'],baseline_bytes=chosen[0]['baseline_bytes']))
    summary[compiler]=values
failed=json.loads((failure/'core-run.json').read_text())
assert failed['headSha']=='eae896846561f73fa1c444808ca3f7319707857a' and failed['conclusion']=='failure'
for suffix in ('run.json','run.log','artifacts.json','observed-at.txt'):
    p=failure/f'core-{suffix}';files['close-failure/'+p.name]=p.read_bytes()
for name in ('test-results/tabs-profiles-observed.json','test-results/tabs-profiles.log',
             'test-results/CONPTY-RUNTIME.json','test-results/SOURCE-HOST.json',
             'build/native-crashes/application-errors.json'):
    p=failure/'core-evidence'/name;files['close-failure/'+name]=p.read_bytes()
observed=json.loads(files['close-failure/test-results/tabs-profiles-observed.json'])
assert not observed['completed'] and len(observed['checks'])==7
assert observed['frontend_exit']==0xc0000005
assert observed['executable_sha256']=='d59a8d1e8e0094cc1bc2435d5a65de94659d881845a1cb3fd8fabf6ceb25a8d6'
files['controller.py']=Path(__file__).read_bytes()
archive=work/'research/kitty-unicode-evidence/cell-baseline-and-close-failure.tar.gz'
records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for record in records:assert sha(tar.extractfile(record['path']).read())==record['raw_sha256']
data=dict(baseline=dict(source=source,run=run['databaseId'],url=run['url'],compilers=summary,
    scope='Component clock() measurements only; different hosted compiler/runtime results are not a ranking'),
    close_failure=dict(source=failed['headSha'],run=failed['databaseId'],url=failed['url'],
        executable_sha256=observed['executable_sha256'],frontend_exit=observed['frontend_exit'],
        completed_checks=len(observed['checks']),original_image_retained=False,
        scope='Failure precedes index optimization; cause unknown, no fault stack or dump'),
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
        archive_sha256=sha(archive.read_bytes()),records=records))
(work/'research/kitty-cell-performance-validation.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(records=len(records),archive_bytes=archive.stat().st_size,baseline_run=run['databaseId'],failed_run=failed['databaseId'])))
