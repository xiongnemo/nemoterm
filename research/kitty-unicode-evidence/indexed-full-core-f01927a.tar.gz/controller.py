from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-relative-worktree'
base=root/'build/ci-kitty-cell-product-f01927a';directory=base/'core-evidence/test-results'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'core-run.json').read_text())
source='f01927ae12841fe7b657c5d86b3e637deb02b422'
assert run['headSha']==source and run['conclusion']=='success' and len(run['jobs'])==4
assert all(j['conclusion']=='success' for j in run['jobs'])
exe_sha=sha((base/'portable/nemoterm.exe').read_bytes());files={};memory=[];pixels=[];copies=[]
for p in base.glob('*'):
    if p.is_file():files[p.relative_to(base).as_posix()]=p.read_bytes()
for p in (base/'portable').iterdir():
    if p.is_file() and p.suffix.lower() not in ('.exe','.dll'):
        files[p.relative_to(base).as_posix()]=p.read_bytes()
for p in sorted(directory.glob('*workload-tabs-*-memory.json')):
    m=json.loads(p.read_text());op=p.with_name(p.name.replace('-memory','-observed'));o=json.loads(op.read_text())
    assert o['completed'] and o['memory_limit_passed'] and o['executable_sha256']==exe_sha
    assert not m['diagnostic_only'] and not m['injected'] and not m['errors']
    assert not o['owned_job_cleanup']['terminated_remaining']
    peak=m['peaks']['frontend']['private_ws'];limit=o['memory_limit_bytes']
    assert peak<=limit if o['memory_limit_inclusive'] else peak<limit
    record=dict(name=p.name,grid=o['actual_grid'],font=o['font'],renderer=o['renderer'],
        frontend=m['peaks']['frontend'],limit_bytes=limit,inclusive=o['memory_limit_inclusive'],
        samples=m['sample_count'],seconds=m['seconds'])
    if p.name.startswith('unicode-'):
        checks=o['post_memory_kitty_unicode'];assert len(checks)==4
        assert all(c['matched'] and c['after_memory_sampling'] and not c['injected'] and all(r['matched'] for r in c['rows']) for c in checks)
        record['post_memory_pixel_checks']=dict(records=4,rows=sum(len(c['rows']) for c in checks),
            cell_centers=sum(len(c['rows'])*(c['grid'][0]-2) for c in checks),
            active_and_inactive=True)
    memory.append(record)
    for path in (p,op):files[path.relative_to(base).as_posix()]=path.read_bytes()
assert len(memory)==12 and sum('post_memory_pixel_checks' in m for m in memory)==2
for p in directory.glob('unicode-kitty-workload-tabs-*-tab-*.png'):
    files[p.relative_to(base).as_posix()]=p.read_bytes()
for p in sorted(directory.glob('kitty-unicode-*-observed.json')):
    o=json.loads(p.read_text());assert o['completed'] and o['executable_sha256']==exe_sha
    if 'selection-' in p.name:
        assert len(o['checks'])==16 and all(c['matched'] and c['expected_utf8_hex']==c['shortcut_utf8_hex']==c['right_click_utf8_hex'] for c in o['checks'])
        copies.append(dict(name=p.name,cases=16,exact_copies=32,actual_renderer=o['actual_renderer']))
    else:
        phases=o['phases'] if 'phases' in o else o['checks']
        pixels.append(dict(name=p.name,phases=len(phases),actual_renderer=o['actual_renderer']))
    files[p.relative_to(base).as_posix()]=p.read_bytes()
assert len(copies)==3 and len(pixels)==6 and sum(p['phases'] for p in pixels)==153
files['controller.py']=Path(__file__).read_bytes()
archive=work/'research/kitty-unicode-evidence/indexed-full-core-f01927a.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for r in records:assert sha(tar.extractfile(r['path']).read())==r['raw_sha256']
data=dict(source=source,run=run['databaseId'],url=run['url'],conclusion='success',jobs=4,
    frontend_sha256=exe_sha,frontend_bytes=(base/'portable/nemoterm.exe').stat().st_size,
    runtime=[dict(name=p.name,bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in (base/'portable').iterdir() if p.suffix.lower() in ('.exe','.dll')],
    uninjected_memory=memory,unicode_pixels=pixels,unicode_clipboard=copies,
    scope='Ordinary CI with a MinGW frontend and sidecar source host. Remote Consolas grids; requested OpenGL falls back to GDI. Not a single-file artifact or local 160x48 Sarasa acceptance; no distribution promotion.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,archive_sha256=sha(archive.read_bytes()),records=records))
(work/'research/unicode-indexed-core-validation.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,memory_groups=len(memory),
    dense=[m for m in memory if 'post_memory_pixel_checks' in m])))
