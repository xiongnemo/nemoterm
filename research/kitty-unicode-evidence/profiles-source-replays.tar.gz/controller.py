from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-relative-worktree'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
files={};runs={}
for label,folder,source,outcome in (
    ('missing-git','ci-profiles-source-f01927a','f01927ae12841fe7b657c5d86b3e637deb02b422','failure'),
    ('replays','ci-profiles-source-8fe8a64','8fe8a64f8b157c6f2b0d5d7a5f622c05bb98c04d','success')):
    base=root/'build'/folder
    run=json.loads((base/'profiles-run.json').read_text())
    assert run['headSha']==source and run['status']=='completed' and run['conclusion']==outcome
    runs[label]=dict(source=source,run=run['databaseId'],url=run['url'],conclusion=outcome)
    for p in base.rglob('*'):
        if p.is_file():files[label+'/'+p.relative_to(base).as_posix()]=p.read_bytes()
base=root/'build/ci-profiles-source-8fe8a64/diagnostic'
identity=json.loads((base/'identity.json').read_text(encoding='utf-8-sig'))
assert identity['production_source']=='eae896846561f73fa1c444808ca3f7319707857a'
assert identity['fixture_source']==runs['replays']['source'] and not identity['exact_failed_image']
for item in identity['runtime_hashes']:
    name=item['Path'].replace('\\','/').split('/')[-1]
    assert sha((base/'runtime'/name).read_bytes())==item['Hash'].lower()
rebuilt=sha((base/'runtime/nemoterm.exe').read_bytes())
assert rebuilt=='dd71610cf78514e05d8e4d6f2daa2c2ea4c3eb2a13cbfc46de30871460bd8dd3'
results=[]
for p in sorted(base.glob('*-observed.json')):
    d=json.loads(p.read_text());assert d['completed'] and d['frontend_exit']==0
    assert len(d['checks'])==7 and d['executable_sha256']==rebuilt
    assert not d['owned_job_cleanup']['terminated_remaining']
    if p.name.startswith('debugger'):
        assert d['exception_observer']['exit_code']==0 and not d['exception_observer']['dumps']
    results.append(dict(name=p.name,checks=len(d['checks']),processes=d['owned_job_cleanup']['after']['total'],
                        debugger=p.name.startswith('debugger')))
assert len(results)==6 and sum(r['debugger'] for r in results)==3
events=[]
for p in sorted(base.glob('exception-profiles-*/events.jsonl')):
    data=[json.loads(line) for line in p.read_text().splitlines()]
    exceptions=[r for r in data if r['event']=='exception']
    assert len(exceptions)==1 and exceptions[0]['initial_attach_break'] and exceptions[0]['first_chance']
    assert data[-1]==dict(event='process_exit',code=0)
    events.append(dict(path=p.relative_to(base).as_posix(),records=len(data),initial_attach_breaks=1,
                       other_exceptions=0,exit_code=0))
assert len(events)==3
controls=json.loads((base/'exception-controls/controls/results.json').read_text())
assert len(controls)==4 and all(c['passed'] for c in controls)
files['controller.py']=Path(__file__).read_bytes()
archive=work/'research/kitty-unicode-evidence/profiles-source-replays.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for r in records:assert sha(tar.extractfile(r['path']).read())==r['raw_sha256']
data=dict(runs=runs,production_source=identity['production_source'],rebuilt_executable_sha256=rebuilt,
    original_failed_executable_sha256='d59a8d1e8e0094cc1bc2435d5a65de94659d881845a1cb3fd8fabf6ceb25a8d6',
    exact_failed_image=False,results=results,debugger_events=events,controls_passed=4,
    scope='Six finite rebuilt-source passes, three with debugger; no terminal fault reproduced. Does not establish original crash cause or product acceptance.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
                archive_sha256=sha(archive.read_bytes()),records=records))
(work/'research/unicode-profiles-close-validation.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(records=len(records),archive_bytes=archive.stat().st_size,replays=len(results),controls=4,
                     rebuilt_executable_sha256=rebuilt)))
