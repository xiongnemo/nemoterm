from pathlib import Path
import gzip, hashlib, io, json, tarfile

root = Path(__file__).resolve().parents[1]
work = root / 'build/kitty-relative-worktree'
base = root / 'build/ci-kitty-unicode-border-4095697'
source = '40956977be5a59585c53cd67b17db36c2823a179'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
files, runs = {}, {}
for kind in ('core', 'single', 'components'):
    run = json.loads((base / f'{kind}-run.json').read_text())
    assert run['headSha'] == source and run['status'] == 'completed'
    assert run['conclusion'] == 'success' and all(j['conclusion'] == 'success' for j in run['jobs'])
    runs[kind] = dict(run=run['databaseId'], url=run['url'], conclusion='success')
    for suffix in ('run.json', 'run.log', 'artifacts.json', 'observed-at.txt'):
        p = base / f'{kind}-{suffix}'
        files[p.relative_to(base).as_posix()] = p.read_bytes()
single = base / 'single-evidence/build/single-exe-check/research'
validation = single / 'single-exe-validation.json'
manifest = json.loads(validation.read_text())
exe = base / 'product/nemoterm.exe'
assert manifest['executable_sha256'] == sha(exe.read_bytes())
assert manifest['executable_bytes'] == exe.stat().st_size
assert len(manifest['passed_checks']) == 149
assert manifest['executable_directory_files'] == ['nemoterm.exe']
files[validation.relative_to(base).as_posix()] = validation.read_bytes()
memory, pixels = {}, {}
for label, directory in (('single', single), ('core', base / 'core-evidence/test-results')):
    memory[label], pixels[label] = [], []
    for p in sorted(directory.glob('*workload-tabs-*-memory.json')):
        data = json.loads(p.read_text())
        observation = p.with_name(p.name.replace('-memory.json', '-observed.json'))
        observed = json.loads(observation.read_text())
        assert observed['completed'] and observed['memory_limit_passed']
        assert not data['injected'] and not data['diagnostic_only'] and not data['errors']
        peak = data['peaks']['frontend']['private_ws']
        limit = observed['memory_limit_bytes']
        assert peak <= limit if observed['memory_limit_inclusive'] else peak < limit
        memory[label].append(dict(name=p.name, grid=observed['actual_grid'],
            font=observed['font'], renderer=observed['renderer'],
            frontend=data['peaks']['frontend'], limit_bytes=limit,
            inclusive=observed['memory_limit_inclusive'], samples=data['sample_count']))
        for record in (p, observation):
            files[record.relative_to(base).as_posix()] = record.read_bytes()
    assert len(memory[label]) == 10
    for p in sorted(directory.glob('kitty-unicode-*-observed.json')):
        data = json.loads(p.read_text())
        assert data['completed']
        if label == 'single':
            assert data['executable_sha256'] == manifest['executable_sha256']
        phases = data['phases'] if 'phases' in data else data['checks']
        renderer = data['renderer'] if 'renderer' in data else data['requested_renderer']
        pixels[label].append(dict(name=p.name, phases=len(phases),
                                 renderer=renderer, actual_renderer=data['actual_renderer']))
        files[p.relative_to(base).as_posix()] = p.read_bytes()
    assert len(pixels[label]) == 6 and sum(p['phases'] for p in pixels[label]) == 153
files['controller.py'] = Path(__file__).read_bytes()
archive = work / 'research/kitty-unicode-evidence/full-ci-4095697.tar.gz'
records = []
with archive.open('xb') as out, gzip.GzipFile(filename='', fileobj=out, mode='wb', mtime=0) as gz, tarfile.open(fileobj=gz, mode='w|') as tar:
    for name, raw in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        tar.addfile(info, io.BytesIO(raw))
        records.append(dict(path=name, raw_bytes=len(raw), raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for record in records:
        assert sha(tar.extractfile(record['path']).read()) == record['raw_sha256']
path = work / 'research/kitty-unicode-validation.json'
data = json.loads(path.read_text())
assert 'border_full_ci' not in data
data['border_full_ci'] = dict(source=source, runs=runs,
    single_executable_sha256=manifest['executable_sha256'],
    single_executable_bytes=manifest['executable_bytes'], passed_check_groups=149,
    unicode_pixels=pixels, uninjected_memory=memory,
    acceptance='Remote Consolas grids as recorded, not local 160x48 Sarasa acceptance. Predates capability advertisement, native copy fixture and dense Unicode memory fixture; downloaded but not promoted.')
data['bundles'].append(dict(path=archive.relative_to(work).as_posix(),
    archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()), records=records))
path.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps(dict(records=len(records), archive_bytes=archive.stat().st_size,
    source=source, groups=149, single_executable_sha256=manifest['executable_sha256'],
    grids=sorted(set(tuple(m['grid']) for group in memory.values() for m in group)))))
