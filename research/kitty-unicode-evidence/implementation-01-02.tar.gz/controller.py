from pathlib import Path
import gzip,hashlib,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-relative-worktree'
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def archive(name,files):
    path=work/'research/kitty-unicode-evidence'/name;records=[]
    with path.open('xb') as output,gzip.GzipFile(filename='',fileobj=output,mode='wb',mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w|') as tar:
        for name,p in sorted(files.items()):
            raw=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw)
            import io
            tar.addfile(info,io.BytesIO(raw));records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
    with tarfile.open(path) as tar:
        for r in records:assert sha(tar.extractfile(r['path']).read())==r['raw_sha256']
    return dict(path=path.relative_to(work).as_posix(),archive_bytes=path.stat().st_size,
                archive_sha256=sha(path.read_bytes()),records=records)

bundles=[];captures=[]
for suffix,run in [('33158e2',43675871329),('cd69cc7',43676070696)]:
    base=root/f'build/ci-unicode-text-{suffix}'
    data=json.loads((base/'run.json').read_text(encoding='utf-8-sig'))
    assert data['databaseId']==run and data['conclusion']=='success'
    observed=next((base/'artifacts').rglob('unicode-text-boundaries-xterm.json'))
    observation=json.loads(observed.read_text());assert len(observation['cases'])==(18 if suffix=='33158e2' else 26)
    files={p.relative_to(base).as_posix():p for p in base.rglob('*') if p.is_file()}
    bundles.append(archive('xterm-text-'+suffix+'.tar.gz',files))
    captures.append(dict(run=run,source=data['headSha'],observation_path=observed.relative_to(base).as_posix(),
        observation_sha256=sha(observed.read_bytes()),cases=len(observation['cases']),
        scope='REP with query observer effect' if suffix=='33158e2' else 'REP uninterrupted and query controls, alternate-screen cursors and ED2/ED3 cells'))

files={}
for iteration in ('01','02'):
    base=root/f'build/kitty-unicode-implementation-{iteration}'
    files.update({iteration+'/'+p.name:p for p in base.iterdir() if p.is_file()})
for name in ('kitty-unicode-placements-02.log','kitty-unicode-placements-strict-build.log','kitty-unicode-placements-strict-test.log'):
    files['strict/'+name]=root/'build'/name
for name in ('scripts/generate-kitty-diacritics.py','vendor/putty-0.85/terminal/nemo_kitty_diacritics.h'):
    files['new-source/'+name]=work/name
files['controller.py']=Path(__file__)
bundles.append(archive('implementation-01-02.tar.gz',files))
manifest=work/'research/kitty-unicode-validation.json';data=json.loads(manifest.read_text())
assert 'xterm_text_boundaries' not in data
data['xterm_text_boundaries']=captures
data['implementation_iterations']=[dict(iteration=1,failed_states=10,raw_matched_states=718),
    dict(iteration=2,failed_states=8,raw_matched_states=720,remaining='alternate-1047/1049 and ED3 text-policy differences confirmed independently with xterm')]
data['bundles']+=bundles
manifest.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'captures':captures,'bundles':[(b['path'],b['archive_bytes']) for b in bundles]}))
