from pathlib import Path
import gzip,hashlib,io,json,tarfile,winreg
root=Path(__file__).resolve().parents[1];work=root/'build/kitty-relative-worktree'
sha=lambda b:hashlib.sha256(b).hexdigest()
files={};runs=[]
def capture(name,report,log,complete):
    d=json.loads(report.read_text());folder=Path(d['folder'])
    assert d['completed']==complete and not d['global_input'] and d['clipboard_access']
    assert d['clipboard_restore_finished'] and not d['cleanup']['terminated_remaining']
    assert not d['cleanup']['remaining_processes']
    if complete:assert len(d['checks'])==16 and all(c['matched'] for c in d['checks'])
    profile=d['command'][d['command'].index('-load')+1]
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,'Software\\Nemo\\Nemoterm\\Sessions\\'+profile):
            raise AssertionError('Fixture profile still exists')
    except FileNotFoundError:pass
    prefix='native/'+name
    files[prefix+'/observed.json']=report.read_bytes()
    files[prefix+'/controller.log']=log.read_bytes()
    for p in folder.rglob('*'):
        if p.is_file():files[prefix+'/'+p.relative_to(folder).as_posix()]=p.read_bytes()
    runs.append(dict(name=name,completed=complete,matched_cases=sum(c['matched'] for c in d['checks']),
        clipboard_copies=len(d['checks'])*2 if complete else None,
        executable_sha256=d['executable_sha256'],font=d['font'],actual_renderer=d['actual_renderer'],
        capture=d['capture'],frida_version=d['frida_version'],profile_absence_rechecked=True,
        report=prefix+'/observed.json',cleanup=d['cleanup']))
for iteration in ('01','02'):
    capture('fixture-baseline-'+iteration,root/f'build/kitty-unicode-selection-native-baseline-{iteration}.json',
            root/f'build/kitty-unicode-selection-native-gdi-{iteration}.log',False)
    files[f'source/baseline-{iteration}.py']=(root/f'build/kitty-unicode-selection-native-baseline-{iteration}.py').read_bytes()
for font in ('sarasa','consolas'):
    for mode in ('gdi','opengl','directx','presented-gdi'):
        name=font+'-'+mode
        log='kitty-unicode-selection-native-gdi-03.log' if name=='sarasa-gdi' else f'kitty-unicode-selection-native-{name}.log'
        capture(name,root/f'build/kitty-unicode-selection-native-reports/{name}.json',root/'build'/log,True)
for name in ('kitty_unicode_selection_window_smoke.py','agent_key_probe.js','clipboard_test_utils.py',
             'protocol_oracle_window.py','owned_job.py','presented_window_capture.py'):
    files['source/'+name]=(work/'tests'/name).read_bytes()
for name in ('SOURCE-HOST.json','CONPTY-RUNTIME.json'):files['runtime/'+name]=(work/'build'/name).read_bytes()
files['controller.py']=Path(__file__).read_bytes()
path=work/'research/kitty-unicode-evidence/native-selection.tar.gz';records=[]
with path.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(path) as tar:
    for r in records:assert sha(tar.extractfile(r['path']).read())==r['raw_sha256']
manifest=work/'research/kitty-unicode-validation.json';data=json.loads(manifest.read_text())
data['native_selection']=dict(runs=runs,passed_copies=256,clipboard_restoration=True,
    fixture_corrections=['Cross-line linear selection includes the second-line leading space',
        'Rapid clicks at identical coordinates became word/line multi-clicks. Consecutive independent selections now start farther apart than the system double-click rectangle.'],
    scope='Exact Ctrl+Shift+C and default right-click copies, literal PUA/combining marks, main/alternate screens, app mouse, mode 2027, linear/rectangle and modifier release. Child input drained exactly.',
    pixel_scope='Red image coverage asserted before selection; selected screenshots are retained diagnostics, not a selected-image tint assertion.',
    visual_limit='Opaque images cover the underlying selection background, including an image-only rectangle; no separate image-selection overlay is implemented.',
    physical_input=False,memory_acceptance=False,
    runtime='Local MinGW frontend 0675072 plus unchanged source-built 3ee3235 headless host; not fresh combined-image acceptance')
data['bundles'].append(dict(path=path.relative_to(work).as_posix(),archive_bytes=path.stat().st_size,
    archive_sha256=sha(path.read_bytes()),records=records))
manifest.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(runs=len(runs),records=len(records),archive_bytes=path.stat().st_size,passed_copies=256)))
