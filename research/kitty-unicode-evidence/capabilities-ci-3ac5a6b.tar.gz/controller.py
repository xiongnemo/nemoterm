from pathlib import Path
import gzip, hashlib, io, json, tarfile

root = Path(__file__).resolve().parents[1]
work = root / 'build/kitty-relative-worktree'
base = root / 'build/ci-kitty-capabilities-3ac5a6b'
source = '3ac5a6b60882fc5c20f326ab01269b9e7e8d3c15'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
run = json.loads((base / 'components-run.json').read_text())
assert run['headSha'] == source and run['conclusion'] == 'success'
assert len(run['jobs']) == 3 and all(j['conclusion'] == 'success' for j in run['jobs'])
files = {p.relative_to(base).as_posix(): p.read_bytes()
         for p in base.rglob('*') if p.is_file()}
results = {}
for compiler in ('gcc', 'clang', 'msvc'):
    name = 'terminal-test.log' if compiler == 'msvc' else 'terminal-sanitizers.log'
    prefix = f'components/kitty-transport-{compiler}-{source}/'
    raw = files[prefix + name]
    for expected in (
        b'176 states (18 explicit capability subsets)',
        b'238 states; 0 failed states',
        b'728 states; 0 failed states; 8 explicit xterm text-policy states',
        b'32 exact core copies checked',
        b'Sixel terminal suite passed',
    ):
        assert expected in raw, (compiler, expected)
    results[compiler] = dict(log=prefix + name, sha256=sha(raw),
                             sanitizers=compiler != 'msvc')
files['controller.py'] = Path(__file__).read_bytes()
archive = work / 'research/kitty-unicode-evidence/capabilities-ci-3ac5a6b.tar.gz'
records = []
with archive.open('xb') as out, gzip.GzipFile(filename='', fileobj=out, mode='wb', mtime=0) as gz, tarfile.open(fileobj=gz, mode='w|') as tar:
    for name, raw in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        tar.addfile(info, io.BytesIO(raw))
        records.append(dict(path=name, raw_bytes=len(raw), raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for record in records:
        assert sha(tar.extractfile(record['path']).read()) == record['raw_sha256']
manifest = work / 'research/kitty-unicode-validation.json'
data = json.loads(manifest.read_text())
assert 'capabilities_ci' not in data
data['capabilities_ci'] = dict(source=source, run=run['databaseId'], url=run['url'],
    conclusion='success', compilers=results, feature_states=176,
    explicit_capability_subsets=18, relative_states=238, unicode_states=728,
    explicit_xterm_policy_states=8, exact_core_copies=32,
    acceptance='Component replay only. New native/full-product and dense-memory gates remain pending; accepted executable unchanged.')
data['bundles'].append(dict(path=archive.relative_to(work).as_posix(),
    archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()), records=records))
manifest.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps(dict(records=len(records), archive_bytes=archive.stat().st_size,
                     source=source, run=run['databaseId'], compilers=list(results))))
