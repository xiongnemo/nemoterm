from pathlib import Path
import gzip,hashlib,io,json,statistics,tarfile

root=Path(__file__).resolve().parents[1]; work=root/'build/kitty-relative-worktree'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
files={};runs={};summaries=[];external_binaries=[]
for label,folder,source,outcome in (
    ('missing-import','ci-unicode-resize-diagnostic-09dd518','09dd51894fcfd0d16ea95f415c1a2014681f61c0','failure'),
    ('indexed','ci-unicode-resize-diagnostic-84e6f80','84e6f80ef4eb631626fafd32ade9783547b112e8','success')):
    base=root/'build'/folder
    run=json.loads((base/'dense-run.json').read_text())
    assert run['headSha']==source and run['status']=='completed' and run['conclusion']==outcome
    runs[label]=dict(source=source,run=run['databaseId'],url=run['url'],conclusion=outcome)
    for p in base.rglob('*'):
        if not p.is_file():continue
        raw=p.read_bytes();name=label+'/'+p.relative_to(base).as_posix()
        if p.suffix.lower() in ('.exe','.dll','.obj','.lib','.pdb'):
            external_binaries.append(dict(path=name,bytes=len(raw),sha256=sha(raw)))
        else:files[name]=raw
    for arm in ('gdi','directx'):
        directory=base/arm
        identity=json.loads((directory/'identity.json').read_text(encoding='utf-8-sig'))
        assert identity['production_source']=='f01927ae12841fe7b657c5d86b3e637deb02b422'
        assert identity['fixture_source']==source and not identity['memory_acceptance']
        for item in identity['runtime_hashes']:
            name=item['Path'].replace('\\','/').split('/')[-1]
            assert sha((directory/'runtime'/name).read_bytes())==item['Hash'].lower()
        controls=json.loads((directory/'dump-controls/controls/results.json').read_text())
        assert len(controls)==3 and all(r['passed'] for r in controls)
        if label=='missing-import':
            assert "NameError: name 'faulthandler' is not defined" in (directory/'workload.log').read_text()
            continue
        observed_paths=list((directory/'observations').glob('*observed.json')); assert len(observed_paths)==1
        observed=json.loads(observed_paths[0].read_text())
        assert observed['diagnostic_completed'] and not observed['completed'] and not observed['memory_acceptance']
        assert observed['memory_limit_passed'] is None
        assert not observed['owned_job_cleanup']['terminated_remaining']
        memory_paths=list((directory/'observations').glob('*memory.json')); assert len(memory_paths)==1
        memory=json.loads(memory_paths[0].read_text())
        assert memory['diagnostic_only'] and memory['external_diagnostic'] and not memory['injected']
        assert not memory['errors']
        records=[json.loads(p.read_text()) for p in (directory/'observations').glob('resize-diagnostic-*/resize-*.json')]
        assert len(records)==24 and all(r['returned'] and not r['samples'] for r in records)
        assert not list((directory/'observations').rglob('*.dmp'))
        summaries.append(dict(renderer=arm,actual_grid=observed['actual_grid'],
            executable_sha256=observed['executable_sha256'],resize_calls=24,
            median_observed_seconds=statistics.median(r['seconds'] for r in records),
            max_observed_seconds=max(r['seconds'] for r in records),slow_snapshots=0,
            diagnostic_only=True,frontend_peaks=memory['peaks']['frontend'],
            owned_job_cleanup=observed['owned_job_cleanup']))
files['controller.py']=Path(__file__).read_bytes()
archive=work/'research/kitty-unicode-evidence/indexed-native-resize.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for record in records:assert sha(tar.extractfile(record['path']).read())==record['raw_sha256']
data=dict(runs=runs,production_source='f01927ae12841fe7b657c5d86b3e637deb02b422',results=summaries,
    timing_scope='MoveWindow plus external before/after thread snapshots, not frame latency. Different grids and hosted runners; not a renderer ranking.',
    acceptance='Source rebuild and diagnostic only; no exact failed image, dense-cell pixel verification or memory acceptance. Original timeout cause remains unproven.',
    external_binary_note='Downloaded binaries remain in local CI artifact folders and identified GitHub artifacts; they are hashed here, not embedded in this archive.',
    external_binaries=external_binaries,bundle=dict(path=archive.relative_to(work).as_posix(),
        archive_bytes=archive.stat().st_size,archive_sha256=sha(archive.read_bytes()),records=records))
(work/'research/unicode-resize-diagnostic-validation.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,external_binaries=len(external_binaries),results=summaries)))
