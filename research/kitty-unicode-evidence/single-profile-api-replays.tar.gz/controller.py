from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile

root=Path(__file__).resolve().parents[1]
work=root/'build/kitty-relative-worktree'
base=root/'build/ci-profile-api-exact-7146510'
directory=base/'diagnostic'
source='7146510bd45639dbf21eb08dfa379ace5a0049b4'
digest='992cabb4d424235e92f46586230c5282dab1ad3a92d1cef3bd7f1b63ff759115'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'tabs-run.json').read_text())
assert run['headSha']==source and run['databaseId']==43691454895 and run['conclusion']=='success'
job=next(j for j in run['jobs'] if j['name']=='diagnostic')
assert next(s for s in job['steps'] if s['name']=='Install fixture dependency')['conclusion']=='skipped'
identity=json.loads((directory/'identity.json').read_text(encoding='utf-8-sig'))
assert identity['executable_sha256']==digest and identity['repetitions']==12
assert identity['source_run']=='43687495119' and identity['capture_failure_dumps']
assert identity['fixture']=='profiles-api' and identity['profile_observer']=='automation' and identity['frida_version'] is None
reference_path=root/'build/ci-profile-exact-failure-af03e5a/diagnostic/replay-1-observed.json'
reference=json.loads(reference_path.read_text())
assert reference['executable_sha256']==digest and reference['completed']
results=[]
for p in sorted(directory.glob('replay-*-observed.json')):
    d=json.loads(p.read_text())
    assert d['completed'] and len(d['checks'])==7 and d['frontend_exit']==0
    assert d['executable_sha256']==digest and d['failure_dump_enabled']
    assert d['observer']=='automation' and d['automation_diagnostic']
    assert not d['memory_instrumented'] and not d['memory_acceptance']
    assert not d.get('failure_dump') and not d['owned_job_cleanup']['terminated_remaining']
    profiles=[]
    for actual,prior in zip(d['profiles'],reference['profiles'],strict=True):
        for key in ('requested_renderer','actual_renderer','cell','frame_sha256'):
            assert actual[key]==prior[key],(p.name,key,actual[key],prior[key])
        profiles.append({key:actual[key] for key in ('requested_renderer','actual_renderer','cell','frame_sha256')})
    results.append(dict(name=p.name,checks=7,exit_code=0,
        owned_processes=d['owned_job_cleanup']['after']['total'],profiles=profiles))
assert len(results)==12 and not list(directory.glob('profiles-failure-*'))
controls=json.loads((directory/'failure-dump-controls/controls/results.json').read_text())
assert len(controls)==3 and all(r['passed'] for r in controls)
files={p.relative_to(base).as_posix():p.read_bytes() for p in base.rglob('*') if p.is_file()}
files['controller.py']=Path(__file__).read_bytes()
files['comparison/frida-replay-1-observed.json']=reference_path.read_bytes()
for path in ('.github/workflows/tabs-close-replay.yml','tests/tabs_profiles_window_smoke.py',
             'tests/automation_capture.py','tools/nemoterm_debug.py'):
    files['fixture-source/'+path]=subprocess.check_output(['git','show',f'{source}:{path}'],cwd=work)
archive=work/'research/kitty-unicode-evidence/single-profile-api-replays.tar.gz'
records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(files.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for r in records:assert sha(tar.extractfile(r['path']).read())==r['raw_sha256']
data=dict(run=run['databaseId'],url=run['url'],fixture_source=source,conclusion='success',
    original_source=identity['source_commit'],original_run=int(identity['source_run']),
    executable_sha256=digest,observer='automation',frida_installed=False,
    results=results,controls_passed=3,terminal_dumps=0,
    comparison=dict(run=43690036549,record='replay-1-observed.json',
        raw_sha256=sha(reference_path.read_bytes()),identical_profile_frames=36),
    scope='Twelve finite uninjected exact-image diagnostic passes, with unchanged assertions and 15-second exit deadline. No timeout reproduced; no root cause, product or memory acceptance claim.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
        archive_sha256=sha(archive.read_bytes()),records=records))
(work/'research/unicode-single-profile-api-replays.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,replays=len(results),identical_profile_frames=36)))
