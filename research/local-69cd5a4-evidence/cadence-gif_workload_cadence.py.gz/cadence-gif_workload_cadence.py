"""Record every original GIF-workload API capture without changing its assertions."""
from pathlib import Path
import json
import runpy
import struct
import sys
import time

root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools'))
import nemoterm_debug as api
original=api.request
trace=[]
sessions={}


def traced(endpoint,operation='list',session=0,payload=b''):
    start=time.monotonic()
    result=original(endpoint,operation,session,payload)
    end=time.monotonic()
    if operation=='list':
        sessions.update({s['id']:s for s in result['sessions']})
    elif operation=='image':
        width,height=struct.unpack_from('<ii',result,18)
        s=sessions[session]
        cw,ch=(width-2)//s['cols'],(-height-2)//s['rows']
        x,y=1+2*cw+256,1+ch+144
        offset=54+(y*width+x)*4
        trace.append(dict(start=start,end=end,duration=end-start,session=session,
            bytes=len(result),bgr=result[offset:offset+3].hex(),patch=[x,y,8,8]))
    return result


api.request=traced
try:
    runpy.run_path(str(root/'tests/tabs_window_smoke.py'),run_name='__main__')
finally:
    (root/'research/gif-workload-cadence.json').write_text(json.dumps(dict(
        diagnostic_only=True,trace=trace,
        scope='Controller timestamps and unmodified response pixels; original 3-second assertion and PNG writes retained'),indent=2)+'\n')
