"""Diagnostic of large-image capture cadence; does not replace workload acceptance."""
import json
import struct
import time
from pathlib import Path
import sixel_palette_window_smoke as helper
from gif_fixture import gif, frame
from iterm_image_window_smoke import transfer

helper.COLS, helper.ROWS = 160, 48
original_request = helper.api.request
trace = []
start = time.monotonic()


def traced_request(endpoint, operation='list', session=0, payload=b''):
    begin = time.monotonic()
    value = original_request(endpoint, operation, session, payload)
    end = time.monotonic()
    if operation == 'image':
        width, height = struct.unpack_from('<ii', value, 18)
        cw, ch = (width-2)//helper.COLS, (-height-2)//helper.ROWS
        x, y = 1+2*cw+256, 1+ch+144
        offset = 54+(y*width+x)*4
        trace.append(dict(start=begin-start, end=end-start, duration=end-begin,
                          bytes=len(value), bgr=value[offset:offset+3].hex()))
    return value


def exercise(phase, block):
    data = gif(256, 144, [frame(256,144,colour=n,delay=10) for n in (1,2,3,0)], repeats=0)
    for iteration in range(3):
        for index, colour in enumerate(('red','green','blue')):
            sequence = helper.reset()+transfer(data,'width=512px;height=288px;preserveAspectRatio=0') if index == 0 else ''
            phase(f'large-{iteration}-{colour}', sequence,
                  [block(2,colour,left=256,top=144,count=8,height=8)])


helper.api.request = traced_request
try:
    helper.main(exercise, suite_name='gif-capture-diagnostic', font='SarasaTermSC Nerd Font Light')
finally:
    Path(helper.root/'research/gif-capture-timing.json').write_text(json.dumps(
        dict(diagnostic_only=True, trace=trace, frame_delay_ms=100,
             scope='Controller-side timing of unmodified API responses; not a trace of native animation ticks'), indent=2)+'\n')
