from pathlib import Path
p=Path('vendor/putty-0.85/terminal/terminal.c');source=p.read_text(encoding='utf-8')
# All noninteractive terminal writes are generated replies/transport framing,
# except the ENQ answerback conversion. Keep its text bytes untouched.
start=source.index('static void nemo_saved_title_free')
prefix=source[:start];tail=source[start:]
needle='ldisc_send(term->ldisc, '
cursor=0;changes=[]
while True:
    begin=tail.find(needle,cursor)
    if begin<0:break
    index=begin+len('ldisc_send(');depth=1;quote=None;escape=False
    while depth:
        char=tail[index]
        if quote:
            if escape:escape=False
            elif char=='\\':escape=True
            elif char==quote:quote=None
        elif char in ('"',"'"):quote=char
        elif char=='(':depth+=1
        elif char==')':depth-=1
        index+=1
    old=tail[begin:index];cursor=index
    if not old.rstrip().endswith('false)'):continue
    # Leave ENQ text and the comment explaining ordinary keyboard input alone.
    if 'term->answerback->' in tail[max(0,begin-100):begin]:continue
    body=old[len(needle):];last=body.rfind(',')
    new='nemo_protocol_send(term, '+body[:last]+')'
    changes.append((begin,index,new))
for begin,end,new in reversed(changes):tail=tail[:begin]+new+tail[end:]
source=prefix+tail
# These four formatters generate key sequences; arbitrary keyinput stays raw.
start=source.index('int format_arrow_key(');end=source.index('void term_keyinputw(',start)
part=source[start:end];assert part.count('return p - buf;')==4
source=source[:start]+part.replace('return p - buf;','return nemo_c1_key_sequence(term, buf, p - buf);')+source[end:]
p.write_text(source,encoding='utf-8')
print('Routed protocol writes:',len(changes))
