import datetime,gzip,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/ci-c1-43534154789'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
path=root/'research/c1-controls-validation.json';m=read(path)
source=m['source_commit'];files=[]
def retain(p,name):
    raw=p.read_bytes();packed=gzip.compress(raw,mtime=0)
    dest=root/'research/c1-controls-evidence'/(name+'.gz');assert not dest.exists(),dest
    dest.write_bytes(packed)
    files.append(dict(path=dest.relative_to(root).as_posix(),bytes=len(packed),sha256=sha(packed),
        raw_bytes=len(raw),raw_sha256=sha(raw),encoding='gzip'))
subprocess.run(['git','diff','--exit-code',source,'--','vendor','native','tests','scripts','tools'],cwd=root,check=True)
ci={}
for name in ('single','core'):
    run=read(base/(name+'-run.json'))
    expected='success' if name=='single' else 'cancelled'
    assert run['status']=='completed' and run['conclusion']==expected and run['headSha']==source
    if name=='single':assert all(j['conclusion']=='success' for j in run['jobs'])
    ci[name]=dict(id=run['databaseId'],url=run['url'],status=expected,
        jobs=[dict(name=j['name'],conclusion=j['conclusion']) for j in run['jobs']])
    for suffix in ('-run.json','-artifacts.json','-run.log'):retain(base/(name+suffix),'ci-'+name+suffix)
exe=(base/'product/nemoterm.exe').read_bytes();digest=sha(exe)
remote=base/'single-evidence/build/single-exe-check'
summary=read(remote/'research/single-exe-validation.json')
assert summary['executable_sha256']==digest and summary['executable_bytes']==len(exe)
assert summary['executable_directory_files']==['nemoterm.exe']
assert len(summary['passed_checks'])==len(set(summary['passed_checks']))==101
retain(remote/'research/single-exe-validation.json','ci-single-exe-validation.json')
artifact=next(a for a in read(base/'single-artifacts.json')['artifacts'] if a['name']=='nemoterm-single-exe-x64-'+source)
assert not artifact['expired']
ci['executable']=dict(bytes=len(exe),sha256=digest,artifact_id=artifact['id'],
    expires_at=artifact['expires_at'],archive_digest=artifact['digest'])
ci['passed_checks']=summary['passed_checks']
observed={}
for label,folder in [('ci_single',remote),('local_28591',base/'local-c1-28591'),('local_65001',base/'local-c1-65001')]:
    for cp in ((28591,65001) if label=='ci_single' else (int(label.split('_')[1]),)):
        p=folder/'research'/f'c1-controls-{cp}-observed.json';v=read(p)
        assert v['completed'] and v['executable_sha256']==digest and v['reference_case_count']==141
        assert len(v['exercise'])==5 and not v['cleanup']['terminated_remaining'] and not v['cleanup']['after']['active']
        observed[label+'-'+str(cp)]=dict(exact_reference_cases=141,exercise=list(v['exercise']),natural_cleanup=True)
        retain(p,label+'-'+p.name)
    if label!='ci_single':
        for relative in ('research/c1_controls-controller.json','c1_controls.log','controller.log'):
            retain(folder/relative,label+'-'+Path(relative).name)
for name in ('c1_controls.log','c1-controls-utf8.log'):retain(remote/'logs'/name,'ci-'+name)
local=base/'local-automation'
v=read(local/'research/automation-gdi-observed.json')
assert v['completed'] and len(v['checks'])==9 and v['exe_sha256']==digest
assert v['capture_differing_channels']==0 and not v['cleanup']['terminated_remaining']
observed['automation']=dict(checks=v['checks'],natural_cleanup=True,pixel_differing_channels=0)
for relative in ('research/automation-gdi-observed.json','research/automation-controller.json','automation.log','controller.log'):
    retain(local/relative,'ci-image-'+Path(relative).name)
for p in Path(v['folder']).glob('*.png'):retain(p,'ci-image-automation-'+p.name)
local=base/'local-workload-gdi'
v=read(local/'research/workload-tabs-gdi-top-observed.json')
memory=read(local/'research/workload-tabs-gdi-top-memory.json')
assert v['completed'] and v['memory_limit_passed'] and v['executable_sha256']==digest
assert len(v['checks'])==9 and v['actual_grid']==[160,48] and v['font']=='SarasaTermSC Nerd Font Light'
assert not v['memory_instrumented'] and not memory['injected'] and not memory['errors']
assert not v['owned_job_cleanup']['terminated_remaining']
observed['gdi_workload']=dict(font=v['font'],actual_grid=v['actual_grid'],functional_groups=9,
    actual_renderer=v['actual_renderer'],memory_instrumented=False,memory_limit_passed=True,
    peaks=memory['peaks'],samples=memory['sample_count'],seconds=memory['seconds'],natural_cleanup=True)
for relative in ('research/workload-tabs-gdi-top-observed.json','research/workload-tabs-gdi-top-memory.json',
    'research/tabs-controller.json','tabs.log','controller.log'):
    retain(local/relative,'ci-image-gdi-'+Path(relative).name)
for p in (base/'sanitizers').glob('terminal-*-sanitizers.log'):retain(p,'ci-'+p.name)
for p in (base/'core-evidence/test-results').glob('test_*.log'):retain(p,'ci-mingw-'+p.name)
for name in ('fetch-c1-ci.py','check-c1-ci-image.py','record-c1-partial-ci.py'):retain(root/'build'/name,name)
for p in (base/'initial-failure').glob('*'):
    if p.is_file():retain(p,'initial-core-'+p.name)
ci['core_followup']=dict(id=43537297417,source_commit='cb52a3c2ebf6d7da3c95facbedfc57d3684028cf',
    url='https://github.com/xiongnemo/nemoterm/actions/runs/43537297417',status='pending',
    reason='Initial Windows job hit its 20-minute overall deadline during the last memory step; new deadline 30 minutes',
    product_and_test_sources_unchanged=True)
ci['recorded_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
m.update(remote_ci='single passed; core followup pending',ci=ci,downloaded_image_checks=observed)
m['files']+=files
for f in m['files']:
    data=(root/f['path']).read_bytes()
    assert len(data)==f['bytes'] and sha(data)==f['sha256'] and sha(gzip.decompress(data))==f['raw_sha256']
path.write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(executable=ci['executable'],checks=observed,new_files=len(files))))
