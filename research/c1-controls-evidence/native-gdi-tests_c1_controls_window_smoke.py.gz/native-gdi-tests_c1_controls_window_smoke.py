"""Preserve exact 8-bit reply bytes through the native console host."""
from c1_controls_oracle_cases import CASES
from protocol_oracle_window import run

run('c1-controls',CASES,barrier=('\x1b[5n',b'\x1b[0n'),
    font='SarasaTermSC Nerd Font Light')
