import concurrent.futures,json,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
run=43537297417;source='cb52a3c2ebf6d7da3c95facbedfc57d3684028cf'
base=root/f'build/ci-c1-core-repeat-{run}-attempt2';base.mkdir(exist_ok=True)
deadline=time.monotonic()+2400;previous=None
while True:
    raw=subprocess.check_output(['gh','run','view',str(run),'--json',
        'databaseId,headSha,status,conclusion,jobs,url'],cwd=root,text=True,timeout=30)
    value=json.loads(raw);assert value['headSha']==source
    (base/'run.json').write_text(raw,encoding='utf-8')
    state=(value['status'],value['conclusion'])
    if state!=previous:print(state,flush=True);previous=state
    if value['status']=='completed':break
    assert time.monotonic()<deadline,'Observation deadline only; do not cancel or restart the workflow'
    time.sleep(15)
with (base/'run.log').open('wb') as output:
    subprocess.run(['gh','run','view',str(run),'--log'],cwd=root,stdout=output,check=True,timeout=120)
raw=subprocess.check_output(['gh','api',f'repos/xiongnemo/nemoterm/actions/runs/{run}/artifacts'],cwd=root,text=True,timeout=30)
(base/'artifacts.json').write_text(raw,encoding='utf-8');artifacts=json.loads(raw)['artifacts']
def download(item):
    prefix,folder=item
    match=[a for a in artifacts if a['name']==prefix+source and not a['expired']]
    if not match:return dict(folder=folder,missing=True)
    subprocess.run(['gh','run','download',str(run),'-n',prefix+source,'-D',str(base/folder)],
        cwd=root,check=True,timeout=180)
    return dict(folder=folder,artifact_id=match[0]['id'])
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    for result in pool.map(download,[('test-results-windows-','core-evidence'),
        ('test-results-sanitizers-','sanitizers'),('nemoterm-windows-x64-','portable')]):
        print(json.dumps(result),flush=True)
print('CI repeat evidence retained',flush=True)

