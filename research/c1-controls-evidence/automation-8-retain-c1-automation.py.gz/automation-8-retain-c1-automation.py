import gzip,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
path=root/'research/c1-controls-validation.json'
m=json.loads(path.read_text(encoding='utf-8'))
base=root/'build/native-c1-automation-gdi'
sha=lambda b:hashlib.sha256(b).hexdigest()
v=json.loads((base/'research/automation-gdi-observed.json').read_text())
c=json.loads((base/'research/automation-controller.json').read_text())
assert v['completed'] and len(v['checks'])==9 and c['completed']
assert v['exe_sha256']==c['executable_sha256']=='960f1ea3e8ed9691ddff355b32c2ee2f83138238986e457565745e114ef87d0a'
assert v['capture_differing_channels']==0
assert not v['cleanup']['terminated_remaining'] and not c['cleanup']['terminated_remaining']
sources=[base/'research/automation-gdi-observed.json',base/'research/automation-controller.json',
    base/'controller.log',base/'host-install.log',base/'dist/SOURCE-HOST.json',
    base/'tests/automation_window_smoke.py',base/'tools/nemoterm_debug.py',
    root/'build/check-c1-automation.py',Path(__file__).resolve()]
sources+=list(Path(v['folder']).glob('*'))
for index,source in enumerate(sources):
    raw=source.read_bytes();packed=gzip.compress(raw,mtime=0)
    dest=root/'research/c1-controls-evidence'/f'automation-{index}-{source.name}.gz'
    assert not dest.exists(),dest
    dest.write_bytes(packed)
    m['files'].append(dict(path=dest.relative_to(root).as_posix(),bytes=len(packed),sha256=sha(packed),
        raw_bytes=len(raw),raw_sha256=sha(raw),encoding='gzip'))
m['automation_recheck']=dict(executable_sha256=v['exe_sha256'],checks=v['checks'],
    actual_renderer=v['actual_renderer'],pixel_differing_channels=0,natural_cleanup=True,
    memory_acceptance=False,controller=c)
for f in m['files']:
    data=(root/f['path']).read_bytes()
    assert sha(data)==f['sha256'] and sha(gzip.decompress(data))==f['raw_sha256']
path.write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(files=len(m['files']),automation_checks=len(v['checks']))))
