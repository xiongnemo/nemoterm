import datetime,gzip,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
out=root/'research/c1-controls-evidence'
out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
files=[]
def retain(path,name):
    raw=path.read_bytes();data=gzip.compress(raw,mtime=0);dest=out/(name+'.gz')
    if dest.exists():assert dest.read_bytes()==data,str(dest)
    else:dest.write_bytes(data)
    files.append(dict(path=dest.relative_to(root).as_posix(),bytes=len(data),sha256=sha(data),
        raw_bytes=len(raw),raw_sha256=sha(raw),encoding='gzip'))
for path in sorted((root/'build').glob('*.log')):retain(path,path.name)
for path in sorted((root/'build').glob('check-c1-native*.py')):retain(path,path.name)
for name in ('run-sanitizers.py','route-protocol-replies.py','retain-c1.py'):
    retain(root/'build'/name,name)
native=[]
for base in sorted((root/'build').glob('native*')):
    if not base.is_dir():continue
    controller=base/'research/c1_controls-controller.json'
    if not controller.exists():continue
    c=read(controller)
    item=dict(directory=base.name,controller=c,observations=[])
    for path in sorted((base/'research').glob('*.json')):
        retain(path,base.name+'-'+path.name)
        if path!=controller:
            v=read(path)
            item['observations'].append(dict(name=path.name,completed=v['completed'],
                reference_cases=v['reference_case_count'],completed_queries=len(v['cases']),
                exercise=list(v.get('exercise',{})),cleanup=v.get('cleanup'),
                executable_sha256=v['executable_sha256']))
    for relative in ('controller.log','host-install.log','dist/SOURCE-HOST.json',
        'tests/c1_controls_window_smoke.py','tests/mouse_fixture.py',
        'tests/protocol_oracle_window.py','tests/protocol_wire_trace.py',
        'tests/c1_controls_oracle_cases.py','tests/owned_job.py'):
        p=base/relative
        if p.exists():retain(p,base.name+'-'+relative.replace('/','_'))
    native.append(item)
sources=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','517124f'],cwd=root,text=True).splitlines()
for p in sources:retain(root/p,'source-'+p.replace('/','_'))
for item in files:
    data=(root/item['path']).read_bytes()
    assert sha(data)==item['sha256'] and sha(gzip.decompress(data))==item['raw_sha256']
result=dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_commit='517124f30da646ff2d67b589226a5259002dd117',
    source_sha256={p:sha((root/p).read_bytes().replace(b'\r\n',b'\n')) for p in sources},
    source_hash_format='SHA-256 of UTF-8 checkout files with CRLF normalized to LF',
    native=native,independent_reference_cases=144,exact_reference_cases=141,
    excluded_reference_cases=['reply-palette-bel','reply-palette-st','reply-title'],
    local_core_suites=['queries','state_control','tcap','mouse','osc52','mok','win32_input','keyboard'],
    linux_asan_ubsan_suites=['queries','state_control','tcap','osc52','mok','win32_input','keyboard'],
    remote_ci='pending',memory_acceptance=False,accepted_distribution_replaced=False,
    full_goal_complete=False,files=files)
(root/'research/c1-controls-validation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(files=len(files),native_runs=len(native),compressed_bytes=sum(f['bytes'] for f in files))))
