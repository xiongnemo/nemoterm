import datetime,gzip,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
path=root/'research/c1-controls-validation.json';m=read(path);files=[]
base=root/'build/ci-c1-core-repeat-43537297417-attempt2'
failed=root/'build/ci-c1-core-repeat-43537297417'
run=read(base/'run.json');source='cb52a3c2ebf6d7da3c95facbedfc57d3684028cf'
assert run['status']=='completed' and run['conclusion']=='success' and run['headSha']==source
assert all(j['conclusion']=='success' for j in run['jobs'])
subprocess.run(['git','diff','--exit-code',m['source_commit'],source,'--','vendor','native','tests','scripts','tools'],cwd=root,check=True)
def retain(p,name):
    raw=p.read_bytes();packed=gzip.compress(raw,mtime=0)
    dest=root/'research/c1-controls-evidence'/(name+'.gz');assert not dest.exists(),dest
    dest.write_bytes(packed)
    files.append(dict(path=dest.relative_to(root).as_posix(),bytes=len(packed),sha256=sha(packed),
        raw_bytes=len(raw),raw_sha256=sha(raw),encoding='gzip'))
for folder,label in [(failed,'repeat-attempt1'),(base,'repeat-attempt2')]:
    for name in ('run.json','run.log','artifacts.json'):
        retain(folder/name,label+'-'+name)
retain(failed/'attempt-1-metadata.json','repeat-attempt1-metadata.json')
first=read(failed/'attempt-1-metadata.json')
assert first['run_attempt']==1 and first['conclusion']=='failure' and first['head_sha']==source
for p in (base/'core-evidence/test-results').glob('test_*.log'):retain(p,'repeat-mingw-'+p.name)
for p in (base/'sanitizers').glob('*.log'):retain(p,'repeat-sanitizer-'+p.name)
workloads={}
for renderer,side in [('gdi','top'),('directx','left')]:
    prefix=f'workload-tabs-{renderer}-{side}'
    p=base/'core-evidence/test-results'/(prefix+'-observed.json');v=read(p)
    assert v['completed'] and v['memory_limit_passed'] and len(v['checks'])==9
    assert not v['owned_job_cleanup']['terminated_remaining']
    workloads[renderer]=dict(font=v['font'],actual_grid=v['actual_grid'],actual_renderer=v['actual_renderer'],
        functional_groups=len(v['checks']),memory_limit_passed=True,natural_cleanup=True,
        local_machine_acceptance=False)
    for suffix in ('-observed.json','-memory.json','-preview.png'):
        retain(base/'core-evidence/test-results'/(prefix+suffix),'repeat-'+prefix+suffix)
followup=m['ci']['core_followup']
followup.update(status='success',jobs=[dict(name=j['name'],conclusion=j['conclusion']) for j in run['jobs']],
    attempts=[dict(attempt=1,status='failure',reason='MSYS2 mirror timeouts and invalid package database signature before product compilation'),
        dict(attempt=2,status='success',reason='Only the failed Windows job retried; signature verification unchanged')],
    workload_results=workloads)
m['remote_ci']='success';m['ci']['recorded_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
for name in ('watch-c1-core-repeat-02.py','record-c1-final-ci.py'):retain(root/'build'/name,'repeat-'+name)
m['files']+=files
for f in m['files']:
    b=(root/f['path']).read_bytes()
    assert len(b)==f['bytes'] and sha(b)==f['sha256'] and sha(gzip.decompress(b))==f['raw_sha256']
path.write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(new_records=len(files),total=len(m['files']),workloads=workloads),indent=2))
