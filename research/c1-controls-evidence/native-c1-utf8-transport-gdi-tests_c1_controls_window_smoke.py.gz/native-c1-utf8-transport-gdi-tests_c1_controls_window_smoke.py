"""Preserve exact 8-bit reply bytes through the native console host."""
from c1_controls_oracle_cases import CASES
from protocol_oracle_window import run
import argparse,os

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input-cp',type=int,choices=(28591,65001),default=28591)
args=parser.parse_args()
os.environ['NEMOTERM_TEST_INPUT_CP']=str(args.input_cp)
# Windows console byte reads encode Unicode using the application's input CP.
# ISO-8859-1 preserves the original octets; UTF-8 uses U+0080..U+009F scalars.
cases=CASES if args.input_cp==28591 else [(name,sequence,
    b''.join(chr(b).encode('utf-8') if 0x80<=b<=0x9f else bytes([b]) for b in reply))
    for name,sequence,reply in CASES]
run('c1-controls-'+str(args.input_cp),cases,barrier=('\x1b[5n',b'\x1b[0n'),
    font='SarasaTermSC Nerd Font Light')
