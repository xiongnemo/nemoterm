import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/ci-c1-43534154789'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
source='517124f30da646ff2d67b589226a5259002dd117'
r=read(base/'single-run.json')
assert r['conclusion']=='success' and r['headSha']==source and r['status']=='completed'
# The separate compiler suite hit its whole-job deadline and is rerunning with
# a larger CI budget. Its pending result is still a merge gate, not a reason to
# skip local checks of the already validated, hash-bound single image.
subprocess.run(['git','diff','--exit-code',source,'--','vendor','native','tests','scripts','tools'],cwd=root,check=True)
exe=base/'product/nemoterm.exe'
digest=hashlib.sha256(exe.read_bytes()).hexdigest()
v=read(base/'single-evidence/build/single-exe-check/research/single-exe-validation.json')
assert v['executable_sha256']==digest and v['executable_bytes']==exe.stat().st_size
assert v['executable_directory_files']==['nemoterm.exe'] and len(v['passed_checks'])==101
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
cases=[('c1-28591','c1_controls',[]),('c1-65001','c1_controls',['--input-cp','65001']),
    ('automation','automation',[]),('workload-gdi','tabs',['--renderer','gdi','--side','top',
        '--cols','160','--rows','48','--font','SarasaTermSC Nerd Font Light','--workload-memory'])]
for label,fixture,args in cases:
    dest=base/('local-'+label);assert not dest.exists(),dest
    for folder in ('research','build','tools','dist'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    shutil.copy2(exe,dest/'dist/nemoterm.exe')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        result=subprocess.run([sys.executable,str(controller),str(dest),fixture,*args],
            cwd=root,stdout=log,stderr=subprocess.STDOUT)
    print(json.dumps(dict(label=label,exit_code=result.returncode,executable_sha256=digest)),flush=True)
    if result.returncode:
        print((dest/'controller.log').read_text()[-5000:],flush=True)
        raise SystemExit(result.returncode)
