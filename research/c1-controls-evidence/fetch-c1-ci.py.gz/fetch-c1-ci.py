import concurrent.futures,json,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/ci-c1-43534154789';base.mkdir(exist_ok=True)
source='517124f30da646ff2d67b589226a5259002dd117'
runs={'single':43534154789,'core':43534154821}
deadline=time.monotonic()+1800;last={}
while True:
    done=True
    for name,run in runs.items():
        raw=subprocess.check_output(['gh','run','view',str(run),'--json',
            'databaseId,headSha,status,conclusion,jobs,url'],cwd=root,text=True,timeout=30)
        value=json.loads(raw);assert value['headSha']==source
        state=(value['status'],value['conclusion'])
        if last.get(name)!=state:print(name,state,flush=True);last[name]=state
        (base/(name+'-run.json')).write_text(raw,encoding='utf-8')
        done &= value['status']=='completed'
    if done:break
    assert time.monotonic()<deadline,'CI polling deadline reached; no workflow cancellation'
    time.sleep(15)
for name,run in runs.items():
    with (base/(name+'-run.log')).open('wb') as log:
        subprocess.run(['gh','run','view',str(run),'--log'],cwd=root,stdout=log,check=True,timeout=120)
    raw=subprocess.check_output(['gh','api',f'repos/xiongnemo/nemoterm/actions/runs/{run}/artifacts'],cwd=root,text=True,timeout=30)
    (base/(name+'-artifacts.json')).write_text(raw,encoding='utf-8')
downloads=[('single','nemoterm-single-exe-x64-','product'),('single','single-exe-evidence-','single-evidence'),
    ('core','test-results-windows-','core-evidence'),('core','test-results-sanitizers-','sanitizers')]
def download(item):
    name,prefix,folder=item
    artifacts=json.loads((base/(name+'-artifacts.json')).read_text())['artifacts']
    match=[a for a in artifacts if a['name']==prefix+source and not a['expired']]
    if not match:return dict(folder=folder,missing=True)
    subprocess.run(['gh','run','download',str(runs[name]),'-n',prefix+source,'-D',str(base/folder)],
        cwd=root,check=True,timeout=180)
    return dict(folder=folder,artifact_id=match[0]['id'])
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    for result in pool.map(download,downloads):print(json.dumps(result),flush=True)
print('Retained CI logs and available artifacts',flush=True)
