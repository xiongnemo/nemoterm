"""Check bounded requests on all tab sides and actual renderers, without screen changes."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
stage=root/'build/window-resize-clamp-matrix-01'
assert not stage.exists();stage.mkdir()
for folder in ('tests','tools'):shutil.copytree(work/folder,stage/folder,ignore=shutil.ignore_patterns('__pycache__'))
for folder in ('research','build','logs','case-evidence'):(stage/folder).mkdir()
shutil.copy2(__file__,stage/'controller.py')
image=root/'build/local-cli-profile-candidate-02/dist/nemoterm.exe'
def digest(p):
    with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert digest(image)=='a6c4c3b2d31db884ca22636e4d05bfd055df0fa8d50d64a2e9cba7cf8485b292'
env=dict(os.environ,NEMOTERM_TEST_EXE=str(image),NEMOTERM_TEST_FONT='Courier New',NEMOTERM_REQUIRE_OPENGL='1',NEMOTERM_REQUIRE_DIRECTX='1')
env.pop('CI',None);env.pop('GITHUB_ACTIONS',None)
results=[]
for number,renderer,side in [(0,'gdi','top'),(0,'gdi','bottom'),(0,'gdi','left'),(0,'gdi','right'),(1,'opengl','right'),(2,'directx','left')]:
    name=renderer+'-'+side;print('Starting',name,flush=True);started=time.monotonic()
    command=[sys.executable,'tests/window_resize_window_smoke.py','--renderer',str(number),'--tabs','--tab-side',side,'--font-size','24']
    with (stage/'logs'/(name+'.log')).open('w',encoding='utf-8') as log:
        result=subprocess.run(command,cwd=stage,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
    observations=[]
    for path in (stage/'research').iterdir():
        if not path.is_file():continue
        target=stage/'case-evidence'/name/'research'/path.name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
        observations.append(dict(path=target.relative_to(stage).as_posix(),sha256=digest(target),bytes=target.stat().st_size))
    data=json.loads((stage/'research/tabs-window-resize-observed.json').read_text())
    record=dict(name=name,exit_code=result.returncode,seconds=time.monotonic()-started,observations=observations,
                stages=sum(len(m['checks']) for m in data['modes']),clamps=sum(bool(c.get('expected_screen_clamp')) for m in data['modes'] for c in m['checks']))
    results.append(record);(stage/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    assert result.returncode==0 and record['stages']==58
    assert data['modes'][0]['active_renderer']==number+1
    assert all(m['host_class']=='NemotermHost' and not m['cleanup']['terminated_remaining'] and m['cleanup']['after']['active']==0 for m in data['modes'])
    assert record['clamps']>0
    print(json.dumps({k:v for k,v in record.items() if k!='observations'}),flush=True)
