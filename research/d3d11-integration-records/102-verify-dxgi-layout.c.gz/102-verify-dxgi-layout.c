#include <stddef.h>
#include <stdio.h>
#include <dxgi.h>
int main(void) { printf("DXGI_SWAP_CHAIN_DESC size=%zu OutputWindow=%zu\n", sizeof(DXGI_SWAP_CHAIN_DESC), offsetof(DXGI_SWAP_CHAIN_DESC,OutputWindow)); return sizeof(void*)!=8 || offsetof(DXGI_SWAP_CHAIN_DESC,OutputWindow)!=48; }
