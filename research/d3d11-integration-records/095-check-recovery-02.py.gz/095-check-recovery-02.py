import json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
controller=root.parent/'rtl-worktree/build/run-owned-check.py';results=[]
for label,name,args in [('recovery-02','gpu_lifecycle',[])]:
    dest=root/'build'/('native-'+label);assert not dest.exists()
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(root/'build/integrated-single/nemoterm.exe',dest/'dist')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),name,*args],
            cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    results.append(dict(label=label,exit_code=code));print(label,(dest/'controller.log').read_text(encoding='utf-8')[-2500:],flush=True)
    (root/'build/native-recovery-02-results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    if code:raise SystemExit(code)
