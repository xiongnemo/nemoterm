import json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
controller=root.parent/'rtl-worktree/build/run-owned-check.py';results=[]
for renderer,side in [('directx','left'),('gdi','top')]:
    dest=root/'build'/('workload-'+renderer);assert not dest.exists()
    for folder in ('dist','research','build'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(root/'build/integrated-single/nemoterm.exe',dest/'dist')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),'tabs','--renderer',renderer,
            '--side',side,'--cols','160','--rows','48','--workload-memory'],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    results.append(dict(renderer=renderer,exit_code=code));print(renderer,(dest/'controller.log').read_text(encoding='utf-8')[-2000:],flush=True)
(root/'build/workload-results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
assert all(r['exit_code']==0 for r in results),results
