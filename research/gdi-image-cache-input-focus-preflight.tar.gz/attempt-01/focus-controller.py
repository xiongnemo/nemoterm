"""Replay an unchanged owned input fixture with explicit real foreground focus."""
from pathlib import Path
import argparse,ctypes as c,ctypes.wintypes as w,hashlib,json,os,shutil,subprocess,sys,time,traceback

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--destination',type=Path,required=True)
parser.add_argument('--input-api',choices=['byte','wide'],required=True)
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
original=root/'build/local-gdi-single-product-12ee33b-01'
stage=args.destination.resolve();assert not stage.exists()
manifest=json.loads((root/'build/gdi-dense-memory-worktree/research/gdi-image-cache-product-gdi-validation.json').read_text())
identity=json.loads((original/'IDENTITY.json').read_text())
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(original/'dist/nemoterm.exe')==identity['executable_sha256']=='64195969a8f2e6653f854d598f169810107ee808d66eaa1088cf9e3ced6b259f'
stage.mkdir(parents=True)
for name in ['dist','tests','tools','build','research','logs']:(stage/name).mkdir()
for record in manifest['records']:
    name=record['path']
    if not name.startswith(('tests/','tools/')):continue
    assert digest(original/name)==record['sha256']
    target=stage/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(original/name,target)
shutil.copy2(original/'dist/nemoterm.exe',stage/'dist/nemoterm.exe')
shutil.copy2(Path(__file__),stage/'focus-controller.py')
(stage/'IDENTITY.json').write_text(json.dumps(dict(identity,scope='Unchanged fixture replay with actual foreground preparation; not a product rebuild'),indent=2)+'\n')
sys.path.insert(0,str(stage/'tests'))
from owned_job import OwnedJob,k
u=c.WinDLL('user32',use_last_error=True)
u.GetForegroundWindow.restype=w.HWND
u.SetForegroundWindow.argtypes=[w.HWND]
u.GetWindowThreadProcessId.argtypes=[w.HWND,c.POINTER(w.DWORD)]
u.GetClassNameW.argtypes=[w.HWND,w.LPWSTR,c.c_int]
u.IsWindowVisible.argtypes=[w.HWND]
callback_type=c.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
u.EnumWindows.argtypes=[callback_type,w.LPARAM]
evidence=dict(completed=False,fixture_source=identity['fixture_commit'],executable_sha256=identity['executable_sha256'],
              input_api=args.input_api,fixture_modified=False,foreground_preparation='SetForegroundWindow on the uniquely owned terminal host; no synthetic input or policy changes')
before=u.GetForegroundWindow();evidence['foreground_before']=before or 0
try:
    with OwnedJob() as job,(stage/'logs/input.log').open('w',encoding='utf-8') as log:
        command=[sys.executable,str(stage/'tests/input_method_window_smoke.py'),'--tabs','--input-api',args.input_api,
                 '--font','SarasaTermSC Nerd Font Light']
        env=dict(os.environ,NEMOTERM_TEST_EXE=str(stage/'dist/nemoterm.exe'))
        env.pop('CI',None);env.pop('GITHUB_ACTIONS',None)
        process=job.spawn(command,cwd=stage,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        evidence['controller_pid']=process.pid;evidence['command']=command
        deadline=time.monotonic()+20
        while True:
            if process.poll() is not None:raise RuntimeError(('Fixture exited before focus preparation',process.returncode))
            members={}
            for handle in job.member_handles():
                try:
                    path=c.create_unicode_buffer(32768);length=w.DWORD(len(path))
                    if k.QueryFullProcessImageNameW(handle,0,path,c.byref(length)) and Path(path.value)==stage/'dist/nemoterm.exe':
                        members[k.GetProcessId(handle)]=path.value
                finally:k.CloseHandle(handle)
            found=[]
            @callback_type
            def collect(hwnd,unused):
                pid=w.DWORD();u.GetWindowThreadProcessId(hwnd,c.byref(pid))
                if pid.value in members and u.IsWindowVisible(hwnd):
                    name=c.create_unicode_buffer(256);u.GetClassNameW(hwnd,name,len(name))
                    if name.value in ['Nemoterm','NemotermTabs']:found.append(dict(hwnd=hwnd,pid=pid.value,window_class=name.value))
                return True
            assert u.EnumWindows(collect,0)
            if found:
                assert len(found)==1,found
                target=found[0];break
            assert time.monotonic()<deadline,'Owned terminal host was not visible'
            time.sleep(.01)
        evidence['target']=target
        evidence['foreground_at_preparation']=u.GetForegroundWindow() or 0
        if evidence['foreground_at_preparation']!=target['hwnd']:
            c.set_last_error(0)
            evidence['set_foreground_result']=bool(u.SetForegroundWindow(target['hwnd']))
            evidence['set_foreground_error']=c.get_last_error()
        else:evidence['already_foreground']=True
        deadline=time.monotonic()+3
        while u.GetForegroundWindow()!=target['hwnd']:
            assert time.monotonic()<deadline,'Windows refused foreground preparation; no click or lock-policy workaround attempted'
            time.sleep(.01)
        evidence['foreground_after_preparation']=u.GetForegroundWindow()
        print('Prepared owned foreground:',json.dumps(target),flush=True)
        evidence['exit_code']=process.wait(timeout=120)
        evidence['cleanup']=job.finish()
        assert evidence['exit_code']==0,('Original fixture failed',evidence['exit_code'])
        assert not evidence['cleanup']['terminated_remaining'] and evidence['cleanup']['after']['active']==0
        observed=json.loads((stage/'research/tabs-input-method-observed.json').read_text())
        evidence['input_checks']=observed['checks'];evidence['dpi']=observed['dpi']
        assert len(observed['dpi'])==4
        evidence['completed']=True
except BaseException:
    evidence['error']=traceback.format_exc();raise
finally:
    evidence['foreground_after_cleanup']=u.GetForegroundWindow() or 0
    (stage/'research/focused-input-controller.json').write_text(json.dumps(evidence,indent=2)+'\n')
print('Unchanged focused input fixture passed:',args.input_api,len(evidence['input_checks']),'checks',flush=True)
