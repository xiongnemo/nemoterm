from protocol_oracle_window import run
from native_test_utils import root, json
from cursor_audit_cases import CASES
reference=json.loads((root/'research/xterm-reference.json').read_text())
differences=[]
def exercise(hwnd,phase,current):
    for name,sequence in CASES.items():
        expected=reference['cases'][name]
        assert expected['sequence']==sequence
        actual=phase(name,sequence,None)
        if actual.hex()!=expected['reply_hex']:
            differences.append(dict(name=name,actual=actual.hex(),expected=expected['reply_hex']))
    return dict(compared=len(CASES),differences=differences)
run('cursor-audit',[],exercise=exercise,profile={'WarnOnClose':0},source_reference=reference['version'])
path=root/'research/cursor-audit-observed.json'
value=json.loads(path.read_text())
value['transport_completed']=value['completed']
value['completed']=not differences
value['compatibility_passed']=not differences
path.write_text(json.dumps(value,indent=2)+'\n')
print('Cursor comparison:',len(CASES),'cases;',len(differences),'differences')
if differences:raise SystemExit(1)
