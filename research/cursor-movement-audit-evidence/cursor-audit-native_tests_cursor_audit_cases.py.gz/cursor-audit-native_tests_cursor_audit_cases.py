ESC,CSI='','['
RESET=CSI+'65;1"p'+ESC+'c'
Q=CSI+'6n'
CASES={}
contexts={
 'plain':'',
 'vertical':CSI+'4;17r',
 'horizontal':CSI+'?69h'+CSI+'8;67s',
 'both':CSI+'4;17r'+CSI+'?69h'+CSI+'8;67s',
 'origin':CSI+'4;17r'+CSI+'?69h'+CSI+'8;67s'+CSI+'?6h',
 'double':'',
 'wrap-disabled':CSI+'?7l',
}
for context,setup in contexts.items():
 for row,col in [(1,1),(7,13),(24,80),(2,3)]:
  for operation in ('E','F','a','e'):
   for count in ('','0','1','2','99999999'):
    name=f'{context}-{row}-{col}-{operation}-{count or "default"}'
    position=CSI+f'{row};{col}H'
    decoration=ESC+'#6' if context=='double' else ''
    CASES[name]=RESET+setup+position+decoration+Q+CSI+count+operation+Q+'Q'+Q
# A printable character at the right edge establishes pending wrap before movement.
for operation in ('E','F','a','e'):
 for mode in ('','?7l'):
  name=f'pending-wrap-{operation}-'+('disabled' if mode else 'enabled')
  CASES[name]=RESET+(CSI+mode if mode else '')+CSI+'5;80HX'+Q+CSI+operation+Q+'Y'+Q
