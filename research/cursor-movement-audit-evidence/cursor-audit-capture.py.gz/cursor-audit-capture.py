from pathlib import Path
import sys
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'tests'))
from xterm_state_oracle import run_cases
from cases import CASES
run_cases('/tmp/nemoterm-xterm-reference/xterm',str(Path(__file__).with_name('xterm.json')),CASES,
          ['-ti','vt520','-xrm','*allowWindowOps: true'],raw_replies=True)
