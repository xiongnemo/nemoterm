import shutil
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/cursor-boundary-audit'
assert not base.exists()
base.mkdir()
source='''ESC,CSI='\x1b','\x1b['
RESET=CSI+'65;1"p'+ESC+'c'
Q=CSI+'6n'
CASES={}
for origin in (False,True):
 setup=CSI+'4;17r'+CSI+'?69h'+CSI+'8;67s'+(CSI+'?6h' if origin else '')
 for row,col in [(16,66),(17,67),(18,68),(3,7)]:
  for operation in ('a','C','e','B','E','F'):
   for count in ('','0','1','2','3'):
    name=f'margins-origin-{int(origin)}-{row}-{col}-{operation}-{count or "default"}'
    CASES[name]=RESET+setup+CSI+f'{row};{col}H'+Q+CSI+count+operation+Q+'Q'+Q
for col in (38,39,40,41):
 for operation in ('a','C'):
  for count in ('','0','1','2','3'):
   name=f'double-{col}-{operation}-{count or "default"}'
   CASES[name]=RESET+CSI+'7;1H'+ESC+'#6'+CSI+f'7;{col}H'+Q+CSI+count+operation+Q+'Q'+Q
'''
(base/'cases.py').write_text(source,encoding='utf-8')
shutil.copy2(root/'build/cursor-audit/capture.py',base)
dest=base/'native'
for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
shutil.copytree(root/'tests',dest/'tests')
shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
shutil.copy2(root/'build/cursor-audit/native/dist/nemoterm.exe',dest/'dist')
(dest/'tests/cursor_audit_cases.py').write_text(source,encoding='utf-8')
shutil.copy2(root/'build/cursor-audit/native/tests/cursor_audit_window_smoke.py',dest/'tests')
print(base)
