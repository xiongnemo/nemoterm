import shutil
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/cursor-audit'
assert not base.exists()
base.mkdir()
case_source='''ESC,CSI='\x1b','\x1b['
RESET=CSI+'65;1"p'+ESC+'c'
Q=CSI+'6n'
CASES={}
contexts={
 'plain':'',
 'vertical':CSI+'4;17r',
 'horizontal':CSI+'?69h'+CSI+'8;67s',
 'both':CSI+'4;17r'+CSI+'?69h'+CSI+'8;67s',
 'origin':CSI+'4;17r'+CSI+'?69h'+CSI+'8;67s'+CSI+'?6h',
 'double':'',
 'wrap-disabled':CSI+'?7l',
}
for context,setup in contexts.items():
 for row,col in [(1,1),(7,13),(24,80),(2,3)]:
  for operation in ('E','F','a','e'):
   for count in ('','0','1','2','99999999'):
    name=f'{context}-{row}-{col}-{operation}-{count or "default"}'
    position=CSI+f'{row};{col}H'
    decoration=ESC+'#6' if context=='double' else ''
    CASES[name]=RESET+setup+position+decoration+Q+CSI+count+operation+Q+'Q'+Q
# A printable character at the right edge establishes pending wrap before movement.
for operation in ('E','F','a','e'):
 for mode in ('','?7l'):
  name=f'pending-wrap-{operation}-'+('disabled' if mode else 'enabled')
  CASES[name]=RESET+(CSI+mode if mode else '')+CSI+'5;80HX'+Q+CSI+operation+Q+'Y'+Q
'''
(base/'cases.py').write_text(case_source)
(base/'capture.py').write_text('''from pathlib import Path
import sys
root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root/'tests'))
from xterm_state_oracle import run_cases
from cases import CASES
run_cases('/tmp/nemoterm-xterm-reference/xterm',str(Path(__file__).with_name('xterm.json')),CASES,
          ['-ti','vt520','-xrm','*allowWindowOps: true'],raw_replies=True)
''')
dest=base/'native'
for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
shutil.copytree(root/'tests',dest/'tests')
shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
shutil.copy2(root.parent/'rtl-worktree/build/ci-underline-43508892024/product/nemoterm.exe',dest/'dist')
(dest/'tests/cursor_audit_cases.py').write_text(case_source)
(dest/'tests/cursor_audit_window_smoke.py').write_text('''from protocol_oracle_window import run
from native_test_utils import root, json
from cursor_audit_cases import CASES
reference=json.loads((root/'research/xterm-reference.json').read_text())
differences=[]
def exercise(hwnd,phase,current):
    for name,sequence in CASES.items():
        expected=reference['cases'][name]
        assert expected['sequence']==sequence
        actual=phase(name,sequence,None)
        if actual.hex()!=expected['reply_hex']:
            differences.append(dict(name=name,actual=actual.hex(),expected=expected['reply_hex']))
    return dict(compared=len(CASES),differences=differences)
run('cursor-audit',[],exercise=exercise,profile={'WarnOnClose':0},source_reference=reference['version'])
path=root/'research/cursor-audit-observed.json'
value=json.loads(path.read_text())
value['transport_completed']=value['completed']
value['completed']=not differences
value['compatibility_passed']=not differences
path.write_text(json.dumps(value,indent=2)+'\\n')
print('Cursor comparison:',len(CASES),'cases;',len(differences),'differences')
if differences:raise SystemExit(1)
''')
print(base)
