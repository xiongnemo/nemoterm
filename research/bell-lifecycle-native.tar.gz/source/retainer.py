"""Retain a passing window-lifetime fixture inside the original failed native job."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/bell-modes-worktree'
base=root/'build/ci-bell-native-f25294c';source='f25294c452e05fa45115cc46423ed647e95950ec'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'bell-window-run.json').read_bytes())
assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(43723767151,source,'completed','failure')
artifacts=json.loads((base/'bell-window-artifacts.json').read_bytes())['artifacts']
receipt=json.loads((base/'diagnostic-download.json').read_bytes())
artifact=next(a for a in artifacts if a['id']==receipt['artifact_id'])
assert artifact['name']=='bell-native-'+source and receipt['source']==source
b=base/'diagnostic';image=b/'build/single-exe-dist/nemoterm.exe';image_sha=sha(image.read_bytes())
assert image_sha=='bb407c52853e9e9003b9b853e418495940033182c15f714efabe31f9115b9955'
assert json.loads((b/'bell-image.json').read_text(encoding='utf-8-sig'))['Hash'].lower()==image_sha
states=json.loads((b/'research/bell-window-state-observed.json').read_bytes())
assert states['completed'] and states['executable_sha256']==image_sha and len(states['checks'])==30
assert len(states['cleanup'])==2 and all(not c['terminated_remaining'] and c['after']['active']==0 for c in states['cleanup'])
for renderer in (0,2):
    checks={x['name']:x for x in states['checks'] if x['renderer']==renderer};assert len(checks)==15
    assert any(e['api']=='FlashWindowEx' and e['flags']==0 for e in checks['notifying-background-close']['api'])
    assert not any(e['api']=='FlashWindowEx' and e['flags']==0 for e in checks['one-notice-owner-close-preserves-other']['api'])
    for check in checks.values():
        if 'before' in check:
            assert check['wire_hex']=='1b5b306e'
            for key in ('foreground','active','topmost','minimized'):assert check['before'][key]==check['after'][key]
assert "KeyError: 'hex'" in (b/'bell-bell_modes.log').read_text(encoding='utf-8-sig')
data=json.loads((b/'research/bell-modes-window-observed.json').read_bytes())
assert not data['completed'] and data['executable_sha256']==image_sha
with tarfile.open(work/'research/bell-modes-reference.tar.gz') as tar:
    reference=json.loads(tar.extractfile('reference/bell-modes-xterm.json').read())
streams=0
for name,steps in data['cases'].items():
    for i,step in enumerate(steps):
        for key in ('sequence_hex','reply_hex','wire_with_barrier_hex'):assert step[key]==reference['cases'][name]['steps'][i][key]
        streams+=1
assert streams==139
entries={'source/retainer.py':Path(__file__).read_bytes()}
for name in ('tests/bell_window_state_smoke.py','tests/bell_modes_window_smoke.py','tests/session_fixture.py',
             'tests/mouse_fixture.py','tests/native_test_utils.py','tests/fixture_io.py','tests/owned_job.py',
             'tests/protocol_oracle_window.py','tools/nemoterm_debug.py','vendor/putty-0.85/windows/window.c',
             '.github/workflows/ansi-conformance.yml'):
    entries['source/'+name]=subprocess.check_output(['git','show',source+':'+name],cwd=work)
for p in base.rglob('*'):
    if p.is_file():entries[p.relative_to(base).as_posix()]=p.read_bytes()
archive=work/'research/bell-lifecycle-native.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(entries.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path'] and sha(tar.extractfile(member).read())==record['raw_sha256']
manifest=dict(source=source,run=43723767151,conclusion='failure',artifact_id=artifact['id'],
    image=dict(bytes=image.stat().st_size,sha256=image_sha,accepted=False),
    window_states=dict(completed=True,checks=30,renderers=['gdi','directx'],natural_cleanup=True),
    protocol_fixture=dict(completed=False,preceding_exact_streams=139,failure='Transient empty mailbox read indexed hex directly; original KeyError preserved.'),
    scope='The original job failed. Its separate 30-state native fixture passes; these observations do not turn the job or product green. Active-tab closure while the host is unfocused remains a separate follow-up.',
    bundle=dict(path=archive.relative_to(work).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),records=records))
(work/'research/bell-lifecycle-native-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Retained',len(records),'records,',archive.stat().st_size,'bytes; 30 passing states and original protocol observer failure')
