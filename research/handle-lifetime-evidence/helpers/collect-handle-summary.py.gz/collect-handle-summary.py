import collections,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
results={}
for label in ('production','sequential','instant-sequential','trace-sequential','trace02-sequential'):
    folder=root/'build'/('terminal-handles-'+label)/'research'
    table=json.loads((folder/'handle-types.json').read_text(encoding='utf-8'))
    observed=json.loads((folder/'workload-tabs-directx-left-observed.json').read_text(encoding='utf-8'))
    controller=json.loads((folder/'tabs-controller.json').read_text(encoding='utf-8'))
    value=dict(executable_sha256=observed['executable_sha256'],grid=observed['actual_grid'],font=observed['font'],
        injected=observed['memory_instrumented'],memory_acceptance=False,checks=observed['checks'],
        controller=controller,inner_cleanup=observed['owned_job_cleanup'],
        baseline=table['snapshots'][0]['count'],post_close=[e['count'] for e in table['snapshots'][1:]],
        original_failure=table.get('original_failure'),settling_deltas=[e['delta']['type_deltas'] for e in table['settling']])
    if (folder/'handle-trace.json').exists():
        capture=json.loads((folder/'handle-trace.json').read_text(encoding='utf-8'));trace=capture['trace']
        events=trace['events'];mods=trace['initialModules']+trace['finalModules']
        def resolve(pc):
            v=int(pc,16)
            for mod in mods:
                b=int(mod['base'],16)
                if b<=v<b+mod['size']:return mod['name']+'+'+hex(v-b)
            return pc
        cycles=[]
        for index in range(12):
            begin=next(e['sequence'] for e in events if e.get('label')=='before-cycle-'+str(index))
            end=next(e['sequence'] for e in events if e.get('label')=='post-close-'+str(index))
            created=[e for e in events if begin<e['sequence']<end and e.get('api') in ('NtCreateEvent','NtCreateTimer','NtCreateSemaphore')]
            closes=[e for e in events if e['operation']=='close' and e.get('generation') in {x['sequence'] for x in created}]
            cycles.append(dict(index=index,counts=dict(collections.Counter(e['type'] for e in created)),
                creations=[dict(e,caller=resolve(e['caller']),frames=[resolve(x) for x in e['frames']]) for e in created],
                closes=[dict(e,caller=resolve(e['caller']),frames=[resolve(x) for x in e['frames']]) for e in closes]))
            assert len(created)==len(closes)==6
            assert all(begin<e['sequence']<end for e in closes)
        value['trace']=dict(completed=capture['completed'],detached=capture['detached'],
            event_count=len(events),overflow=trace['overflow'],cycles=cycles)
    results[label]=value
(root/'build/handle-lifetime-summary.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:{x:v[x] for x in ('baseline','post_close','injected','settling_deltas')} for k,v in results.items()},indent=2))
