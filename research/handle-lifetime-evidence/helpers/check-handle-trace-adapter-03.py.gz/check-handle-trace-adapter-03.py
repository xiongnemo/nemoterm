import json,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'tests'))
from owned_job import OwnedJob
dest=root/'build/handle-trace-adapter-03';assert not dest.exists();dest.mkdir(parents=True)
result=dict(completed=False);start=time.monotonic()
with OwnedJob() as job:
    try:
        with (dest/'native.log').open('w',encoding='utf-8') as log:
            child=job.spawn([sys.executable,str(root/'tests/handle_trace_native_test.py'),'--output',str(dest/'native.json')],
                cwd=root,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
            result['exit_code']=child.wait(timeout=60)
    finally:
        result['cleanup']=job.finish(grace=2);result['seconds']=time.monotonic()-start
        result['completed']=result.get('exit_code')==0 and not result['cleanup']['terminated_remaining']
        (dest/'controller.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print((dest/'native.log').read_text(encoding='utf-8'));print(json.dumps(result))
if not result['completed']:raise SystemExit(1)


