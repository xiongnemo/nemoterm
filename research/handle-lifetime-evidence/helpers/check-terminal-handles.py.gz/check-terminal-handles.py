import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
cases=[('production',root.parent/'cursor-worktree/build/ci-relative-43517911793/product/nemoterm.exe',
        '0db4c0d807e810a7d34c592c0920214d667bb45f8d5576d4fda9a42b38e566e5'),
       ('sequential',root.parent/'d3d11-worktree/build/sequential-single/nemoterm.exe',
        'bb73edd96408c84a8e00d6e321ff4f99fc54d894b91fcf5444a72b907760cd3c')]
results=[]
for label,exe,digest in cases:
    assert hashlib.sha256(exe.read_bytes()).hexdigest()==digest
    dest=root/'build'/('terminal-handles-'+label);assert not dest.exists()
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    shutil.copy2(exe,dest/'dist/nemoterm.exe')
    p=dest/'tests/tabs_window_smoke.py';original=p.read_text(encoding='utf-8');source=original
    def replace(a,b):
        global source
        assert source.count(a)==1,a
        source=source.replace(a,b)
    if label=='sequential':replace("3:'NemotermDirect2D'","3:'NemotermDirect3D11'")
    replace('            for i in range(12):',"""            from handle_snapshot import OwnedHandleSnapshot,compare
            handle_observer=OwnedHandleSnapshot(process,job)
            handle_evidence=dict(executable_sha256=evidence['executable_sha256'],injected=False,
                memory_acceptance=False,snapshots=[handle_observer.snapshot('baseline')],deltas=[],settling=[])
            handle_path=root/'research/handle-types.json'
            handle_path.write_text(json.dumps(handle_evidence,indent=2),encoding='utf-8')
            evidence['handle_type_diagnostic']=True
            evidence['memory_acceptance']=False
            for i in range(12):""")
    marker="                assert sample['handles']<=baseline['handles']+6,(baseline,sample)"
    replace(marker,"""                handle_evidence['snapshots'].append(handle_observer.snapshot('post-close-'+str(i)))
                handle_evidence['deltas'].append(compare(handle_evidence['snapshots'][0],handle_evidence['snapshots'][-1]))
                handle_evidence['original_samples']=evidence['cycles']
                if sample['handles']>baseline['handles']+6 or sample['gdi']>baseline['gdi']+3 or sample['user']>baseline['user']+2:
                    handle_evidence['original_failure']=dict(cycle=i,baseline=baseline,sample=sample)
                    for delay in (.1,.4,.5,1.):
                        time.sleep(delay)
                        snapshot=handle_observer.snapshot('after-failed-sample')
                        handle_evidence['settling'].append(dict(delay_seconds=delay,snapshot=snapshot,
                            delta=compare(handle_evidence['snapshots'][0],snapshot),resources=resources()))
                handle_path.write_text(json.dumps(handle_evidence,indent=2),encoding='utf-8')
"""+marker)
    marker="            evidence['checks'].append('12 create/close cycles retain one shared renderer without handle growth')"
    replace(marker,marker+"""
            u.PostMessageW(host,0x10,0,0);process.wait(timeout=15)
            assert process.returncode==0,process.returncode
            evidence['owned_job_cleanup']=job.finish(grace=5)
            assert not evidence['owned_job_cleanup']['terminated_remaining']
            evidence['diagnostic_completed']=True
            raise SystemExit(2)""")
    compile(source,str(p),'exec');p.write_text(source,encoding='utf-8')
    (dest/'research/diagnostic-fixture.json').write_text(json.dumps(dict(original_sha256=hashlib.sha256(original.encode()).hexdigest(),modified_sha256=hashlib.sha256(source.encode()).hexdigest(),
        purpose='Type metadata for owned frontend handles; preserve original assertions and failing samples; no full workload acceptance'),indent=2)+'\n',encoding='utf-8')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),'tabs','--renderer','directx','--side','left',
            '--cols','160','--rows','48','--workload-memory'],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    results.append(dict(label=label,controller_exit_code=code,controller=json.loads((dest/'research/tabs-controller.json').read_text(encoding='utf-8'))))
    (root/'build/terminal-handle-results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(results[-1]),flush=True)
