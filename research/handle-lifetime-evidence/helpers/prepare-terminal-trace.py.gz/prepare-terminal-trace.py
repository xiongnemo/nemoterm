from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=(root/'build/check-terminal-handles-instant.py').read_text(encoding='utf-8')
source=source.replace('terminal-handles-instant-','terminal-handles-trace-').replace('terminal-handle-instant-results','terminal-handle-trace-results')
source=source.replace("executable_sha256=evidence['executable_sha256'],injected=False", "executable_sha256=evidence['executable_sha256'],injected=True")
anchor="    compile(source,str(p),'exec');p.write_text(source,encoding='utf-8')"
assert source.count(anchor)==1
extra='''    replace("if args.workload_memory:args.dense_clusters=True", "if args.workload_memory:args.dense_clusters=True\\ninjected_observer=True  # Entire copied fixture is instrumented; never memory acceptance")
    replace('        immediate_samples=[]', '        immediate_samples=[];handle_trace=None')
    replace('        try:\\n            if args.workload_memory:', """        try:
            from handle_trace import OwnedHandleTrace
            handle_trace=OwnedHandleTrace(process,job,root/'research/handle-trace.json')
            evidence['handle_trace_diagnostic']=True
            evidence['memory_acceptance']=False
            if args.workload_memory:""")
    replace("            handle_path=root/'research/handle-types.json'", """            handle_evidence['baseline_marker']=handle_trace.mark('baseline')
            handle_path=root/'research/handle-types.json'""")
    replace('            for i in range(12):\\n                child=', "            for i in range(12):\\n                handle_trace.mark('before-cycle-'+str(i))\\n                child=")
    replace("                handle_evidence['snapshots'].append", "                handle_trace.mark('post-close-'+str(i))\\n                handle_evidence['snapshots'].append")
    replace("                handle_path.write_text(json.dumps(handle_evidence,indent=2),encoding='utf-8')", "                handle_trace.mark('post-observation-'+str(i))\\n                handle_path.write_text(json.dumps(handle_evidence,indent=2),encoding='utf-8')")
    replace("            evidence['checks'].append('12 create/close cycles retain one shared renderer without handle growth')", """            evidence['checks'].append('12 create/close cycles retain one shared renderer without handle growth')
            handle_trace.mark('settling-start');time.sleep(2)
            handle_evidence['final_snapshot']=handle_observer.snapshot('final-settled')
            handle_path.write_text(json.dumps(handle_evidence,indent=2),encoding='utf-8')
            result=handle_trace.close();handle_trace=None
            assert result['completed'] and result['detached'],result""")
    replace('                if census_observer:census_observer.close()', """                try:
                    if handle_trace:handle_trace.close()
                finally:
                    if census_observer:census_observer.close()""")
'''
source=source.replace(anchor,extra+anchor)
compile(source,'generated-terminal-trace','exec')
(root/'build/check-terminal-handles-trace.py').write_text(source,encoding='utf-8')
