import datetime,gzip,hashlib,json,shutil,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
out=root/'research/handle-lifetime-evidence';assert not out.exists();out.mkdir()
files=[]
def digest(data):return hashlib.sha256(data).hexdigest()
def retain(path,name):
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0)
    target=out/(name.replace('\\','/')+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(packed)
    files.append(dict(path=target.relative_to(root).as_posix(),bytes=len(packed),sha256=digest(packed),
        raw_bytes=len(raw),raw_sha256=digest(raw),encoding='gzip'))
def tree(folder,prefix):
    for path in sorted(folder.rglob('*')):
        if path.is_file():retain(path,prefix+'/'+path.relative_to(folder).as_posix())

# Preserve the source versions actually used by the earlier local attempts.
for name in ('handle_snapshot.py','handle_snapshot_native_test.py'):
    shutil.copy2(root/'tests'/name,root/'build/handle-adapter-03'/name)
for name in ('handle_trace.js','handle_trace.py','handle_trace_native_test.py'):
    shutil.copy2(root/'build/terminal-handles-trace02-sequential/tests'/name,root/'build/handle-trace-adapter-02'/name)
    shutil.copy2(root/'tests'/name,root/'build/handle-trace-adapter-03'/name)
for label in ('handle-adapter','handle-adapter-02','handle-adapter-03',
              'handle-trace-adapter','handle-trace-adapter-02','handle-trace-adapter-03'):
    tree(root/'build'/label,label)
for run in (43528837723,43530556414):tree(root/'build'/f'handle-ci-{run}',f'ci-{run}')
for label in ('production','sequential','instant-sequential','trace-sequential','trace02-sequential'):
    folder=root/'build'/('terminal-handles-'+label)
    tree(folder/'research',label+'/research')
    for name in ('tabs.log','controller.log'):retain(folder/name,label+'/'+name)
    for name in ('tabs_window_smoke.py','handle_snapshot.py','handle_snapshot_native_test.py','native_test_utils.py',
                 'session_fixture.py','tab_workload_memory.py','memory_limits.py','owned_job.py','frida_test_utils.py'):
        retain(folder/'tests'/name,label+'/tests/'+name)
    if label.startswith('trace'):
        for name in ('handle_trace.js','handle_trace.py','handle_trace_native_test.py'):
            retain(folder/'tests'/name,label+'/tests/'+name)
for name in ('check-handle-adapter.py','check-handle-adapter-02.py','check-handle-adapter-03.py',
             'check-handle-trace-adapter.py','check-handle-trace-adapter-02.py','check-handle-trace-adapter-03.py',
             'check-terminal-handles.py','check-terminal-handles-instant.py','check-terminal-handles-trace.py',
             'check-terminal-handles-trace02.py','prepare-terminal-trace.py',
             'analyze-handle-trace.py','analyze-handle-trace02.py','collect-handle-summary.py',
             'handle-lifetime-summary.json','handle-create-symbols.txt','symbolizer-version.txt',
             'terminal-handle-results.json','terminal-handle-instant-results.json',
             'terminal-handle-trace-results.json','terminal-handle-trace02-results.json','retain-handle-lifetime.py'):
    retain(root/'build'/name,'helpers/'+name)
retain(root.parent/'rtl-worktree/build/run-owned-check.py','helpers/run-owned-check.py')
images={}
for name,path in (('production',root.parent/'cursor-worktree/build/ci-relative-43517911793/product/nemoterm.exe'),
                  ('sequential',root.parent/'d3d11-worktree/build/sequential-single/nemoterm.exe'),
                  ('sequential-symbols',root.parent/'d3d11-worktree/build/sequential-single/nemoterm.pdb'),
                  ('accepted-distribution',root.parent.parent/'dist/nemoterm.exe')):
    raw=path.read_bytes();images[name]=dict(bytes=len(raw),sha256=digest(raw))
assert images['accepted-distribution']==dict(bytes=4371456,sha256='a108894f50f7d797f7d2c01558a71f268a1c812fe365270e5a6a7fb7868ca4ed')
ci={str(run):json.loads((root/'build'/f'handle-ci-{run}'/'run.json').read_text(encoding='utf-8-sig')) for run in (43528837723,43530556414)}
assert all(v['conclusion']=='success' for v in ci.values())
validation=json.loads((root/'build/handle-lifetime-summary.json').read_text(encoding='utf-8'))
manifest=dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    observer_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True,encoding='utf-8').strip(),
    production_source_commit='f079f80ade7b5ee73469ddb350ec1acad62042eb',
    experimental_source_commit='0382062763ffa8198c72fae155c7bd9c6f4796f6',
    images=images,ci=ci,runs=validation,memory_acceptance=False,product_change=False,files=files)
path=root/'research/handle-lifetime-validation.json';path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for item in files:
    packed=(root/item['path']).read_bytes();raw=gzip.decompress(packed)
    assert len(packed)==item['bytes'] and digest(packed)==item['sha256']
    assert len(raw)==item['raw_bytes'] and digest(raw)==item['raw_sha256']
print(json.dumps(dict(records=len(files),compressed_bytes=sum(e['bytes'] for e in files),images=images),indent=2))
