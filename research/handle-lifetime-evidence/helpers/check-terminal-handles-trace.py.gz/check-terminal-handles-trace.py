import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
cases=[('sequential',root.parent/'d3d11-worktree/build/sequential-single/nemoterm.exe',
        'bb73edd96408c84a8e00d6e321ff4f99fc54d894b91fcf5444a72b907760cd3c')]
results=[]
for label,exe,digest in cases:
    assert hashlib.sha256(exe.read_bytes()).hexdigest()==digest
    dest=root/'build'/('terminal-handles-trace-'+label);assert not dest.exists()
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    shutil.copy2(exe,dest/'dist/nemoterm.exe')
    p=dest/'tests/tabs_window_smoke.py';original=p.read_text(encoding='utf-8');source=original
    def replace(a,b):
        global source
        assert source.count(a)==1,a
        source=source.replace(a,b)
    if label=='sequential':replace("3:'NemotermDirect2D'","3:'NemotermDirect3D11'")
    replace('            for i in range(12):',"""            from handle_snapshot import OwnedHandleSnapshot,compare
            handle_observer=OwnedHandleSnapshot(process,job)
            handle_evidence=dict(executable_sha256=evidence['executable_sha256'],injected=True,
                memory_acceptance=False,snapshots=[handle_observer.snapshot('baseline')],deltas=[],settling=[])
            handle_path=root/'research/handle-types.json'
            handle_path.write_text(json.dumps(handle_evidence,indent=2),encoding='utf-8')
            evidence['handle_type_diagnostic']=True
            evidence['memory_acceptance']=False
            for i in range(12):""")
    marker="                assert sample['handles']<=baseline['handles']+6,(baseline,sample)"
    replace(marker,"""                handle_evidence['snapshots'].append(handle_observer.snapshot('post-close-'+str(i)))
                handle_evidence['deltas'].append(compare(handle_evidence['snapshots'][0],handle_evidence['snapshots'][-1]))
                handle_evidence['original_samples']=evidence['cycles']
                if sample['handles']>baseline['handles']+6 or sample['gdi']>baseline['gdi']+3 or sample['user']>baseline['user']+2:
                    handle_evidence['original_failure']=dict(cycle=i,baseline=baseline,sample=sample)
                    for delay in (.1,.4,.5,1.):
                        time.sleep(delay)
                        snapshot=handle_observer.snapshot('after-failed-sample')
                        handle_evidence['settling'].append(dict(delay_seconds=delay,snapshot=snapshot,
                            delta=compare(handle_evidence['snapshots'][0],snapshot),resources=resources()))
                handle_path.write_text(json.dumps(handle_evidence,indent=2),encoding='utf-8')
"""+marker)
    marker="            evidence['checks'].append('12 create/close cycles retain one shared renderer without handle growth')"
    replace(marker,marker+"""
            u.PostMessageW(host,0x10,0,0);process.wait(timeout=15)
            assert process.returncode==0,process.returncode
            evidence['owned_job_cleanup']=job.finish(grace=5)
            assert not evidence['owned_job_cleanup']['terminated_remaining']
            evidence['diagnostic_completed']=True
            raise SystemExit(2)""")
    replace("        handle=k.OpenProcess(0x410,False,process.pid)","""        handle=k.OpenProcess(0x410,False,process.pid)
        from handle_snapshot import OwnedHandleSnapshot,compare
        immediate_observer=OwnedHandleSnapshot(process,job)
        immediate_samples=[]""")
    replace("                count=w.DWORD();assert k.GetProcessHandleCount(handle,c.byref(count))", """                count=w.DWORD();assert k.GetProcessHandleCount(handle,c.byref(count))
                immediate_samples.append(dict(original_count=count.value,snapshot=immediate_observer.snapshot('inside-resources')))
                (root/'research/instant-handle-types.json').write_text(json.dumps(immediate_samples,indent=2),encoding='utf-8')""")
    replace("if args.workload_memory:args.dense_clusters=True", "if args.workload_memory:args.dense_clusters=True\ninjected_observer=True  # Entire copied fixture is instrumented; never memory acceptance")
    replace('        immediate_samples=[]', '        immediate_samples=[];handle_trace=None')
    replace('        try:\n            if args.workload_memory:', """        try:
            from handle_trace import OwnedHandleTrace
            handle_trace=OwnedHandleTrace(process,job,root/'research/handle-trace.json')
            evidence['handle_trace_diagnostic']=True
            evidence['memory_acceptance']=False
            if args.workload_memory:""")
    replace("            handle_path=root/'research/handle-types.json'", """            handle_evidence['baseline_marker']=handle_trace.mark('baseline')
            handle_path=root/'research/handle-types.json'""")
    replace('            for i in range(12):\n                child=', "            for i in range(12):\n                handle_trace.mark('before-cycle-'+str(i))\n                child=")
    replace("                handle_evidence['snapshots'].append", "                handle_trace.mark('post-close-'+str(i))\n                handle_evidence['snapshots'].append")
    replace("                handle_path.write_text(json.dumps(handle_evidence,indent=2),encoding='utf-8')", "                handle_trace.mark('post-observation-'+str(i))\n                handle_path.write_text(json.dumps(handle_evidence,indent=2),encoding='utf-8')")
    replace("            evidence['checks'].append('12 create/close cycles retain one shared renderer without handle growth')", """            evidence['checks'].append('12 create/close cycles retain one shared renderer without handle growth')
            handle_trace.mark('settling-start');time.sleep(2)
            handle_evidence['final_snapshot']=handle_observer.snapshot('final-settled')
            handle_path.write_text(json.dumps(handle_evidence,indent=2),encoding='utf-8')
            result=handle_trace.close();handle_trace=None
            assert result['completed'] and result['detached'],result""")
    replace('                if census_observer:census_observer.close()', """                try:
                    if handle_trace:handle_trace.close()
                finally:
                    if census_observer:census_observer.close()""")
    compile(source,str(p),'exec');p.write_text(source,encoding='utf-8')
    (dest/'research/diagnostic-fixture.json').write_text(json.dumps(dict(original_sha256=hashlib.sha256(original.encode()).hexdigest(),modified_sha256=hashlib.sha256(source.encode()).hexdigest(),
        purpose='Type metadata for owned frontend handles; preserve original assertions and failing samples; no full workload acceptance'),indent=2)+'\n',encoding='utf-8')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),'tabs','--renderer','directx','--side','left',
            '--cols','160','--rows','48','--workload-memory'],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    results.append(dict(label=label,controller_exit_code=code,controller=json.loads((dest/'research/tabs-controller.json').read_text(encoding='utf-8'))))
    (root/'build/terminal-handle-trace-results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(results[-1]),flush=True)
