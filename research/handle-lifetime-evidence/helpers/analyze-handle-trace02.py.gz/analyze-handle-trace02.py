import collections,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
folder=root/'build/terminal-handles-trace02-sequential/research'
capture=json.loads((folder/'handle-trace.json').read_text(encoding='utf-8'))
trace=capture['trace'];events=trace['events'];mods=trace['initialModules']+trace['finalModules']
def resolve(pc):
    value=int(pc,16)
    for mod in mods:
        base=int(mod['base'],16)
        if base<=value<base+mod['size']:return mod['name']+'+'+hex(value-base)
    return pc
def decoded(event):
    return dict(event,caller=resolve(event.get('caller','0x0')),frames=[resolve(x) for x in event.get('frames',[])])
metadata=json.loads((folder/'handle-types.json').read_text(encoding='utf-8'))
baseline={e['handle']:e for e in metadata['snapshots'][0]['entries']}
last=metadata.get('final_snapshot',metadata['settling'][-1]['snapshot'] if metadata['settling'] else metadata['snapshots'][-1])
added=[e for e in last['entries'] if e['handle'] not in baseline]
lastgen={int(e['handle'],16):e for e in events if e['operation']=='create'}
correlations=[]
for e in added:
    created=lastgen.get(e['handle']);generation=created['sequence'] if created else None
    closes=[decoded(x) for x in events if x['operation'].startswith('close') and x['generation']==generation]
    compatible=bool(created and created['type']==e['type'] and not any(x['operation']=='close' for x in closes))
    correlations.append(dict(snapshot=e,compatible_unclosed_generation=compatible,
        last_creation_at_same_value=decoded(created) if created else None,closes=closes,
        interpretation='Candidate only; value and type do not prove object identity' if compatible else
            'Unattributed; no compatible unclosed creation observed at this value'))
counts=collections.Counter((e['type'],resolve(e['caller'])) for e in events if e['operation']=='create')
selected=[]
for key,count in counts.items():
    sample=next(e for e in events if e['operation']=='create' and (e['type'],resolve(e['caller']))==key)
    selected.append(dict(type=key[0],caller=key[1],count=count,sample=decoded(sample)))
result=dict(completed=capture['completed'],detached=capture['detached'],messages=capture['messages'],
    overflow=trace['overflow'],stop=trace['stopReason'],event_count=len(events),
    original_failure=metadata.get('original_failure'),baseline_count=len(baseline),last_count=last['count'],
    persistent_correlations=correlations,creation_groups=selected,
    markers=[e for e in events if e['operation']=='mark'],outstanding=trace['outstanding'])
(folder/'trace-analysis.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k not in ('markers','outstanding','creation_groups')},indent=2))

