from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
stage=root/'build/extended-key-resources-checks-01/mingw'
stage.mkdir(parents=True,exist_ok=False)
targets=['test_mok','test_keyboard','test_udk_terminal','test_queries','test_state_control','test_win32_input']
with (stage/'build.log').open('w') as log:
    subprocess.run([str(root/'tools/python/cmake/data/bin/cmake.exe'),'--build',str(root/'build/gdi-dense-memory-build'),
        '--target','pterm',*targets,'--parallel','4'],stdout=log,stderr=subprocess.STDOUT,check=True)
results=[]
for target in targets:
    exe=root/'build/gdi-dense-memory-build'/(target+'.exe')
    with (stage/(target+'.log')).open('w') as log:
        subprocess.run([str(exe)],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    results.append(dict(target=target,sha256=hashlib.sha256(exe.read_bytes()).hexdigest()))
    print(target,'passed',flush=True)
(stage/'results.json').write_text(json.dumps(results,indent=2)+'\n')
sources={p.relative_to(work).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in [
    work/'vendor/putty-0.85/terminal/terminal.c',work/'vendor/putty-0.85/terminal/terminal.h',
    work/'vendor/putty-0.85/windows/nemo_key_input.c',work/'vendor/putty-0.85/test/test_mok.c',
    work/'vendor/putty-0.85/test/test_mok_win.c',work/'tests/special_keys_reference.h',work/'tests/extended_keys_reference.h',work/'vendor/putty-0.85/putty.h']}
(stage/'source-hashes.json').write_text(json.dumps(sources,indent=2)+'\n')
