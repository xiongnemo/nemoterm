from pathlib import Path
from collections import Counter
import hashlib,json,tarfile
root=Path(__file__).resolve().parents[1]
work=root/'build/tab-callback-diagnostic-worktree'
base=root/'build/ci-tab-callback-8c2d004';evidence=base/'diagnostic'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
run=load(base/'tabs-run.json');assert run['databaseId']==43758602960 and run['conclusion']=='success'
assert run['headSha']=='8c2d00484548e86351d2aa063fb67c57570458bd'
identity=load(evidence/'identity.json')
assert identity['source_commit']=='23c90fe3eb54d21b0d8c128c2d2a41090095b6d4'
assert identity['executable_sha256']=='75c88c5236b53853ea7c992c870fef322822939592b07476d99730a88543663d'
assert identity['fixture_commit']==run['headSha'] and identity['frida_version']=='17.24.3' and identity['repetitions']==12
local=load(root/'build/tab-callback-23c90fe-local-02/IDENTITY.json')
for entry in identity['runtime_hashes']:
    assert local['package_hashes'][Path(entry['Path']).name]==entry['Hash'].lower()
assert len(list(evidence.glob('replay-*-observed.json')))==12
exceptions=Counter()
for i in range(1,13):
    observed=load(evidence/f'replay-{i}-observed.json')
    assert observed['completed'] and observed['actual_renderer']==1 and len(observed['checks'])==9
    assert observed['executable_sha256']==identity['executable_sha256']
    assert observed['requested_grid']==[160,48]
    assert observed['owned_job_cleanup']['after']==dict(total=54,active=0,terminated=0)
    assert not observed['owned_job_cleanup']['terminated_remaining']
    boundary=observed['probe_boundaries']
    assert [b['matches_initial_entry'] for b in boundary]==[False,False,True,True]
    assert all(b['exit_code'] is None and b['exit_code_after_observation'] is None for b in boundary)
    observer=observed['exception_observer'];assert observer['exit_code']==0 and observer['dumps']==[]
    events=evidence/Path(observer['events_file']).parent.name/'events.jsonl'
    for event in map(json.loads,events.read_text().splitlines()):
        assert event['event']!='observer_error'
        if event['event']=='exception' and not event['initial_attach_break']:
            assert event['first_chance']
            exceptions[hex(event['code'])]+=1
controls=load(evidence/'exception-controls/controls/results.json');assert len(controls)==4
files=[]
def add(p,n):files.append(dict(path=n,source=p,bytes=p.stat().st_size,sha256=sha(p)))
for p in evidence.rglob('*'):
    if p.is_file():add(p,'diagnostic/'+p.relative_to(evidence).as_posix())
for name in ('tabs-run.json','tabs-run.log','tabs-artifacts.json','diagnostic-download.json'):add(base/name,name)
add(Path(__file__),'controller/retain-tab-callback-hosted.py')
archive=work/'research/tab-callback-portable-hosted.tar.gz';assert not archive.exists()
with tarfile.open(archive,'x:gz') as tar:
    for f in files:tar.add(f['source'],arcname=f['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for f in files:assert hashlib.sha256(tar.extractfile(f['path']).read()).hexdigest()==f['sha256']
result=dict(scope='Exact-image hosted diagnosis; successful finite replays do not explain or resolve the original callback exception.',
    source_commit=identity['source_commit'],fixture_commit=identity['fixture_commit'],run_id=run['databaseId'],
    artifact_id=load(base/'diagnostic-download.json')['artifact_id'],executable_sha256=identity['executable_sha256'],
    replays=12,actual_renderer='GDI',groups_per_replay=9,naturally_drained_processes=648,
    external_observer_controls=4,first_chance_exceptions=dict(exceptions),second_chance_exceptions=0,
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),
    files=[{k:v for k,v in f.items() if k!='source'} for f in files])
(work/'research/tab-callback-portable-hosted-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))
