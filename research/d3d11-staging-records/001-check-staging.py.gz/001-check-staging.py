from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];base=root/'build/staging-comparison';base.mkdir()
old=root.parent/'gif-animation-worktree/build/gif-single-02/nemoterm.exe'
new=root/'build/staging-single-01/nemoterm.exe'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='c83b8f54000b017116069419eedb7f6cfbaacd1fd8b7d69d134f4d1a5f734299'
assert hashlib.sha256(new.read_bytes()).hexdigest()=='9300a9cd87fc9f9fc4dff39408c07221addce0febc70e0b7b7fa2f7a3fee42c0'
memory=['--renderer','directx','--side','left','--cols','160','--rows','48','--workload-memory']
cases=[('before-directx-images','tabs',memory+['--inline-images'],old),
       ('after-renderer','renderer',[],new),
       ('after-static-images','iterm_image',['--renderer','directx'],new),
       ('after-gif-animation','gif_animation',['--renderer','directx'],new),
       ('after-directx','tabs',memory,new),
       ('after-directx-images','tabs',memory+['--inline-images'],new),
       ('after-gdi-images','tabs',['--renderer','gdi','--side','top','--cols','160','--rows','48','--workload-memory','--inline-images'],new)]
results=[]
for name,test,args,exe in cases:
    dest=base/name
    for directory in ('dist','research','build','tools'):(dest/directory).mkdir(parents=True)
    shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(exe,dest/'dist/nemoterm.exe')
    with (dest/'controller.log').open('w') as log:
        run=subprocess.run([sys.executable,str(root.parent/'rtl-worktree/build/run-owned-check.py'),str(dest),test,*args],stdout=log,stderr=subprocess.STDOUT)
    record=dict(name=name,exit_code=run.returncode)
    for p in (dest/'research').glob('*-memory.json'):
        d=json.loads(p.read_text());record.update(samples=d['sample_count'],peaks=d['peaks']['frontend'])
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps(record),flush=True)
    if run.returncode:print((dest/'controller.log').read_text()[-2600:],flush=True)
if any(r['exit_code'] for r in results if r['name'].startswith('after-')):raise SystemExit(1)
