"""Retain the completed three-compiler component run without accepting product CI."""
from pathlib import Path
import hashlib,json,tarfile
root=Path(__file__).resolve().parents[1]
base=root/'build/ci-osc-colour-sequence-31747b9'
research=root/'build/gdi-dense-memory-worktree/research'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source='31747b9aba2199ddf896f06f87a05c829a223d69'
run=load(base/'ansi-components-run.json')
assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(43765300885,source,'completed','success')
jobs={j['name']:j['conclusion'] for j in run['jobs']}
assert jobs['linux (gcc)']==jobs['linux (clang)']==jobs['msvc']=='success'
artifacts={}
for compiler in ('gcc','clang','msvc'):
    folder=base/'ansi-components'/compiler
    assert (folder/'test_osc_colour.log').read_text(encoding='utf-8-sig').strip()=='OSC colour suite passed'
    receipt=load(base/'ansi-components'/(compiler+'-download.json'))
    assert receipt['source']==source and receipt['run_id']==43765300885
    for item in receipt['files']:
        path=folder/item['path'];assert path.stat().st_size==item['bytes'] and digest(path)==item['sha256']
    artifacts[compiler]=receipt['artifact_id']
paths={p:p.relative_to(base).as_posix() for p in (base/'ansi-components').rglob('*') if p.is_file()}
for name in ('ansi-components-run.json','ansi-components-run.log','ansi-components-artifacts.json'):
    paths[base/name]=name
paths[Path(__file__)]='retainer.py'
archive=research/'osc-colour-sequence-ci.tar.gz';records=[]
with archive.open('xb') as raw,tarfile.open(fileobj=raw,mode='w:gz') as tar:
    for path,name in sorted(paths.items(),key=lambda pair:pair[1]):
        records.append(dict(path=name,bytes=path.stat().st_size,sha256=digest(path)))
        tar.add(path,arcname=name,recursive=False)
with tarfile.open(archive) as tar:
    assert len(set(tar.getnames()))==len(tar.getnames())==len(records)
    for item in records:
        raw=tar.extractfile(item['path']).read()
        assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
record=dict(source=source,run_id=43765300885,conclusion='success',artifacts=artifacts,
    reference_streams=64,replay_modes=['whole','bytewise'],
    scope='Component GCC/Clang ASan/UBSan and MSVC. Full product workflows and native replay remain separate.',
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=digest(archive)),records=records)
with (research/'osc-colour-sequence-ci-validation.json').open('x',encoding='utf-8') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps({k:v for k,v in record.items() if k!='records'},indent=2))
