"""Preserve the original full-CI SUB assertion failures and all completed jobs."""
from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile
root=Path(__file__).resolve().parents[1]
work=root/'build/cancellation-worktree'
base=root/'build/ci-cancellation-complete-73ed664'
source='73ed664ceefaba24ff7900af9254fc25fa1d2f76'
run=json.loads((base/'ordinary-run.json').read_text(encoding='utf-8'))
assert (run['headSha'],run['databaseId'],run['status'],run['conclusion']) == (source,43709232412,'completed','failure')
assert sorted(j['conclusion'] for j in run['jobs']) == ['failure','failure','success','success']
entries={'controller.py':Path(__file__)}
for p in base.glob('ordinary-*'):
    if p.is_file(): entries[p.name]=p
for folder,artifact in [('core-evidence',14159734610),('sanitizers',14159961543),('ordinary-msvc',14159359998)]:
    p=base/(folder+'-download.json')
    receipt=json.loads(p.read_text(encoding='utf-8'))
    assert receipt['artifact_id']==artifact and receipt['source']==source
    entries[p.name]=p
    for p in (base/folder).rglob('*'):
        if p.is_file():entries[p.relative_to(base).as_posix()]=p
for name in ('.github/workflows/ci.yml','vendor/putty-0.85/test/test_selective_erase.c',
             'vendor/putty-0.85/test/test_sgr.c','vendor/putty-0.85/test/test_tcap.c',
             'vendor/putty-0.85/terminal/terminal.c'):
    entries['source/'+name]=subprocess.check_output(['git','show',f'{source}:{name}'],cwd=work)
assert '38 != 74' in (base/'sanitizers/terminal-selective-erase-sanitizers.log').read_text(encoding='utf-8')
assert '38 != 87' in (base/'ordinary-run.log').read_text(encoding='utf-8')
def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
archive=work/'research/control-cancellation-ordinary-failure.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,value in sorted(entries.items()):
        info=tarfile.TarInfo(name)
        if isinstance(value,bytes):
            info.size=len(value);checksum=hashlib.sha256(value).hexdigest();tar.addfile(info,io.BytesIO(value))
        else:
            info.size=value.stat().st_size;checksum=digest(value)
            with value.open('rb') as f:tar.addfile(info,f)
        records.append(dict(path=name,raw_bytes=info.size,raw_sha256=checksum))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path']
        assert hashlib.file_digest(tar.extractfile(member),'sha256').hexdigest()==record['raw_sha256']
manifest=dict(source=source,run=43709232412,conclusion='failure',
    findings=['Sanitizer selective-erase test assumed SUB prints no error character.',
              'Windows SGR test assumed SUB prints no error character.'],
    correction_source='069d220e0f53b732caab9748a66a5413c2a8c6fc',
    correction_scope='Existing selective-erase, SGR and XTGETTCAP assertions updated; no production change.',
    limits='Original failed CI; not a successful full-product checkpoint. Complete rerun remains separate.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
                archive_sha256=digest(archive),records=records))
(work/'research/control-cancellation-ordinary-failure-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size)))
