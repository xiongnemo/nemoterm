import json,runpy
from pathlib import Path
import native_test_utils as native
import clipboard_test_utils as clipboard
original_read=native.read_snapshot
original_clip=clipboard.clipboard_text
state=dict(pending=0,injected=0)
def read(path):
    if state['pending']:
        state['pending']-=1;state['injected']+=1
        return {}
    return original_read(path)
def copied(hwnd):
    value=original_clip(hwnd)
    state['pending']+=1
    return value
native.read_snapshot=read
clipboard.clipboard_text=copied
try:
    runpy.run_path(str(Path(__file__).with_name('bindings_window_smoke.py')),run_name='__main__')
finally:
    (native.root/'research/bindings-read-fault.json').write_text(json.dumps(state,indent=2))
