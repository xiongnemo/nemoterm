import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/bindings-observation';base.mkdir(exist_ok=False)
exe=root.parents[1]/'build/ci-main-57171fa/unverified-product/nemoterm.exe'
sha='16d15ab4928b421e3ef281153ec54c9e35ad8e4694213ab89c0066bb40738f21'
assert hashlib.sha256(exe.read_bytes()).hexdigest()==sha
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
old=subprocess.check_output(['git','show','HEAD:tests/bindings_window_smoke.py'],cwd=root)
fault='''import json,runpy
from pathlib import Path
import native_test_utils as native
import clipboard_test_utils as clipboard
original_read=native.read_snapshot
original_clip=clipboard.clipboard_text
state=dict(pending=0,injected=0)
def read(path):
    if state['pending']:
        state['pending']-=1;state['injected']+=1
        return {}
    return original_read(path)
def copied(hwnd):
    value=original_clip(hwnd)
    state['pending']+=1
    return value
native.read_snapshot=read
clipboard.clipboard_text=copied
try:
    runpy.run_path(str(Path(__file__).with_name('bindings_window_smoke.py')),run_name='__main__')
finally:
    (native.root/'research/bindings-read-fault.json').write_text(json.dumps(state,indent=2))
'''
records=[]
for label,original,injected in [('before-fault',True,True),('fixed-normal',False,False),('fixed-fault',False,True)]:
    dest=base/label
    for folder in ['dist','research','build','tools']:(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    if original:(dest/'tests/bindings_window_smoke.py').write_bytes(old)
    (dest/'tests/bindings_fault_window_smoke.py').write_text(fault,encoding='utf-8')
    name='bindings_fault' if injected else 'bindings'
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        result=subprocess.run([sys.executable,str(controller),str(dest),name],cwd=root,stdout=log,stderr=subprocess.STDOUT)
    observed=json.loads((dest/'research'/f'{name}-controller.json').read_text())
    assert not observed['cleanup']['terminated_remaining'] and not observed['cleanup']['remaining_processes'],observed
    assert result.returncode==(1 if original else 0),observed
    item=dict(label=label,expected_failure=original,controller=observed)
    if injected:
        item['fault']=json.loads((dest/'research/bindings-read-fault.json').read_text())
        assert item['fault']['injected']==(1 if original else 2),item
    if original:
        assert "KeyError: 'hex'" in (dest/'controller.log').read_text()
    else:
        data=json.loads((dest/'research/bindings-observed.json').read_text())
        assert len(data['checks'])==5,data
        assert all(x['input_checkpoint']['hex']=='1b5b306e1b5b306e' for x in data['checks'][:2])
    records.append(item);(base/'results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label,'expected failure' if original else 'passed',flush=True)
