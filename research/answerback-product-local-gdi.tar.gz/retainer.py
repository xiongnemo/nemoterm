"""Retain the first thirteen exact-image cases without accepting the full candidate."""
from pathlib import Path
from collections import Counter
import hashlib, io, json, subprocess, tarfile
from PIL import Image

root = Path(__file__).resolve().parents[1]
stage = root/'build/local-answerback-product-253855b-01'
work = root/'build/gdi-dense-memory-worktree'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
source = '253855b481b2ccd6a13dae5490c42f19c8b9dd64'
sha = 'f086fde1d97b33d231281a939dcf855150b2270726e672d99b68fca631e32107'

def digest(p):
    with p.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

identity = load(stage/'IDENTITY.json')
assert identity['source_commit'] == identity['fixture_commit'] == source
assert identity['source_run'] == 43757506287 and identity['artifact_id'] == 14181225772
assert identity['executable_sha256'] == digest(stage/'dist/nemoterm.exe') == sha
assert identity['executable_bytes'] == (stage/'dist/nemoterm.exe').stat().st_size == 4544512
assert [p.name for p in (stage/'dist').iterdir()] == ['nemoterm.exe']
names = [name for name, _ in load(stage/'cases.json')][:13]
assert names == ['command-line-profile', 'hosted-geometry-gdi', 'hosted-geometry-opengl',
    'hosted-geometry-directx', 'hosted-resize-top', 'hosted-resize-bottom',
    'hosted-resize-left', 'hosted-resize-right', 'legacy-parameter', 'answerback-config',
    'shutdown', 'startup-size', 'unicode-kitty-memory-gdi']
results = load(stage/'logs/results.json')[:13]
assert [r['name'] for r in results] == names and all(r.get('exit_code') == 0 for r in results)
paths = {}
for result in results:
    assert result['observations'] and not result.get('controller_timeout')
    for record in result['observations']:
        path = (stage/record['path']).resolve()
        path.relative_to(stage)
        assert path.stat().st_size == record['bytes'] and digest(path) == record['sha256']
        paths[path] = record['path']
    paths[stage/'logs'/f"{result['name']}.log"] = f"logs/{result['name']}.log"

# Match the complete fixture set to Git, not only to the runner's own manifest.
archive = subprocess.check_output(['git', 'archive', source, 'tests', 'tools/nemoterm_debug.py'], cwd=work)
with tarfile.open(fileobj=io.BytesIO(archive)) as bundle:
    for entry in bundle:
        if not entry.isfile():
            continue
        path = stage/entry.name
        expected = hashlib.sha256(bundle.extractfile(entry).read()).hexdigest()
        assert digest(path) == identity['fixtures'][entry.name] == expected
        paths[path] = entry.name

def report(case, name):
    path = stage/'case-evidence'/case/'research'/name
    value = load(path)
    assert value.get('executable_sha256', value.get('exe_sha256')) == sha
    assert value.get('completed', True) and not value.get('error')
    return value

cli = report('command-line-profile', 'command-line-profile-observed.json')
assert len(cli['checks']) == 5 and all(c['matched'] for c in cli['checks'])
for cleanup in cli['cleanup']:
    assert not cleanup['terminated_remaining'] and cleanup['after']['active'] == 0
geometry = []
for renderer, number in [('gdi', 0), ('opengl', 1), ('directx', 2)]:
    value = report('hosted-geometry-'+renderer, 'tabs-geometry-window-observed.json')
    assert value['tab_host'] and value['tab_side'] == 'bottom' and len(value['modes']) == 1
    mode = value['modes'][0]
    assert mode['host_class'] == 'NemotermHost' and mode['active_renderer'] == number+1
    assert len(mode['checks']) == 7 and mode['exit_code'] == 0 and mode['output_while_minimized_preserved']
    assert not mode['cleanup']['terminated_remaining'] and mode['cleanup']['after']['active'] == 0
    geometry.append(dict(renderer=renderer, stages=len(mode['checks'])))
resize = []
for side in ('top', 'bottom', 'left', 'right'):
    value = report('hosted-resize-'+side, 'tabs-window-resize-observed.json')
    assert value['tab_host'] and value['tab_side'] == side
    assert [(m['policy'], m['requested_renderer'], len(m['checks'])) for m in value['modes']] == [
        ('normal', 0, 42), ('normal', 1, 42), ('normal', 2, 42),
        ('remote-denied', 0, 5), ('locked-window', 0, 5), ('font-resize', 0, 6)]
    for mode in value['modes']:
        assert mode['host_class'] == 'NemotermHost' and mode['active_renderer'] == mode['requested_renderer']+1
        assert mode['exit_code'] == 0 and not mode['cleanup']['terminated_remaining']
        assert mode['cleanup']['after']['active'] == 0
        for check in mode['checks']:
            if 'requested_client' in check:
                expected = [min(a, b) for a, b in zip(check['requested_client'], check['monitor_client_limit'])]
                assert check['client'] == check['expected_client'] == expected
                assert check['expected_screen_clamp'] == (expected != check['requested_client'])
    resize.append(dict(side=side, stages=sum(len(m['checks']) for m in value['modes'])))

reference = load(stage/'tests/legacy_parameter_reference.json')
assert len(reference['cases']) == 136
for cp in (28591, 65001):
    value = report('legacy-parameter', f'legacy-parameter-{cp}-observed.json')
    assert value['exercise']['input_cp'] == cp and len(value['cases']) == 136
    for case in reference['cases']:
        expected = bytes.fromhex(case['reply_hex'])
        if cp == 65001:
            expected = b''.join(chr(b).encode() if 0x80 <= b <= 0x9f else bytes([b]) for b in expected)
        assert bytes.fromhex(value['cases'][case['name']]) == expected+b'\x1b[0n'
    for label, reply in [('literal', b'LEFT^!^0^ ^:^/RIGHT^END'), ('controls', b'\r\n\0\x1b\x7f^'),
                         ('numeric', b'\r\r\r\0'), ('empty', b'')]:
        value = report('answerback-config', f'answerback-config-{label}-{cp}-observed.json')
        assert value['exercise']['input_cp'] == cp and len(value['cases']) == 20
        for name, wire in value['cases'].items():
            expected = b'' if name == 'within-osc' else reply+b'\x1b[1;1R' if name == 'within-csi' else reply
            assert bytes.fromhex(wire) == expected+b'\x1b[0n'

shutdown = report('shutdown', 'shutdown-window-observed.json')
assert shutdown['frida_version'] == '17.23.3' and len(shutdown['cases']) == 12
assert Counter(c['observer'] for c in shutdown['cases']) == {'none': 6, 'lifetime': 6}
for case in shutdown['cases']:
    assert case['exit_code'] == 0 and not case['cleanup']['terminated_remaining']
    assert case['active_renderer'] == {'gdi': 1, 'opengl': 2, 'directx': 3}[case['renderer']]
    if case['observer'] == 'none':
        assert not case['injected']
        continue
    events = case['events']
    freed = [e for e in events if e.get('event') == 'seat-free']
    returned = [e for e in events if e.get('event') == 'com-uninitialize-return']
    assert len(freed) == len(returned) == 1 and freed[0]['success'] and not freed[0]['window_alive']
    assert returned[0]['seat_freed'] and not returned[0]['window_alive']
    assert sorted(returned[0]['detached_observers']) == ['com', 'heap', 'window']
    assert not any(e.get('event') == 'callback-after-seat-free' or e.get('type') == 'error' for e in events)
assert len(report('startup-size', 'startup-size-observed.json')['checks']) == 2

case = 'unicode-kitty-memory-gdi'
name = 'unicode-kitty-workload-tabs-gdi-top-observed.json'
value = report(case, name)
samples = load(stage/'case-evidence'/case/'research'/name.replace('-observed', '-memory'))
assert value['actual_renderer'] == 1 and value['actual_grid'] == [160, 48]
assert value['font'] == 'SarasaTermSC Nerd Font Light' and not value['memory_instrumented']
assert not samples['injected'] and not samples['errors'] and not samples['exited_during_sample']
assert samples['sample_count'] == len(samples['samples']) == 3966
assert value['process_tree_memory']['peaks'] == samples['peaks']
for key in ('private_ws', 'total_ws', 'private_commit'):
    assert samples['peaks']['frontend'][key] == max(s['groups']['frontend'][key] for s in samples['samples'])
assert samples['peaks']['frontend']['private_ws'] == value['peak_private_ws'] == 19197952
assert value['memory_limit_required'] and value['memory_limit_passed'] and value['memory_limit_bytes'] == 20000000
assert not value['memory_limit_inclusive'] and value['peak_private_ws'] < 20000000
assert len(value['checks']) == 10 and value['host_close']['exit_code'] == 0
cleanup = value['owned_job_cleanup']
assert not cleanup['terminated_remaining'] and cleanup['after'] == {'total': 56, 'active': 0, 'terminated': 0}
captures = value['post_memory_kitty_unicode']
assert len(captures) == 4 and sum(c['cells_verified'] for c in captures) == 29072
images = 0
for capture in captures:
    assert capture['matched'] and capture['after_memory_sampling'] and not capture['injected']
    assert capture['grid'] == [160, 48] and len(capture['rows']) == 46
    for row in capture['rows']:
        assert row['matched']
        if 'image' not in row:
            continue
        with Image.open(stage/'case-evidence'/case/'research'/row['image']) as picture:
            assert picture.size == (row['patch'][2], 1)
            assert all(pixel == (0, 0, 255) for pixel in picture.convert('RGB').getdata())
        images += 1
assert images == 12

for name in ('IDENTITY.json', 'all-cases.json', 'cases.json', 'controller.py'):
    paths[stage/name] = name
paths[Path(__file__)] = 'retainer.py'
target = work/'research/answerback-product-local-gdi.tar.gz'
records = []
with target.open('xb') as raw, tarfile.open(fileobj=raw, mode='w:gz') as bundle:
    for path, name in sorted(paths.items(), key=lambda pair: pair[1]):
        records.append(dict(path=name, bytes=path.stat().st_size, sha256=digest(path)))
        bundle.add(path, arcname=name, recursive=False)
    # The parent runner is still writing its results; retain a stable prefix.
    data = (json.dumps(results, indent=2)+'\n').encode()
    entry = tarfile.TarInfo('logs/results-prefix.json'); entry.size = len(data)
    bundle.addfile(entry, io.BytesIO(data))
    records.append(dict(path=entry.name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
summary = dict(source=source, executable_sha256=sha, executable_bytes=4544512,
    accepted_candidate=False, reviewed_groups=names, planned_groups=49,
    scope='First thirteen completed local groups only; other background, desktop and full protocol requirements remain open.',
    geometry=geometry, resize=resize, legacy_parameter_streams=272, answerback_streams=160,
    shutdown_cases=12, memory=dict(peaks=samples['peaks'], samples=samples['sample_count'],
        seconds=samples['seconds'], verified_image_cells=29072, retained_pixel_strips=images,
        lifecycle_checks=value['checks'], cleanup=cleanup),
    archive=dict(path=target.name, bytes=target.stat().st_size, sha256=digest(target)), records=records)
with (work/'research/answerback-product-local-gdi-validation.json').open('x', encoding='utf-8') as stream:
    json.dump(summary, stream, indent=2); stream.write('\n')
print(json.dumps({k:summary[k] for k in ('accepted_candidate', 'reviewed_groups', 'archive')}, indent=2))
