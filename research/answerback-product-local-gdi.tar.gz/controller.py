"""Accept the exact 253855b CI image in fresh, explicitly scoped local stages."""
from pathlib import Path
import argparse,hashlib,io,json,os,shutil,subprocess,sys,tarfile,time

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--destination',type=Path,required=True)
p.add_argument('--scope',choices=('background','interactive','all'),default='background')
p.add_argument('--desktop-ready',action='store_true')
p.add_argument('--only-case',action='append')
p.add_argument('--prepare-only',action='store_true')
a=p.parse_args()
root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
base=root/'build/ci-answerback-nul-253855b'
source='253855b481b2ccd6a13dae5490c42f19c8b9dd64'
fixture=source
load=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

for kind,run_id,count in [('ordinary',43757506311,4),('single',43757506287,1)]:
    run=load(base/(kind+'-run.json'))
    assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(run_id,source,'completed','success'),kind
    assert len(run['jobs'])==count and all(job['conclusion']=='success' for job in run['jobs'])
receipt=load(base/'product-download.json')
assert receipt['source']==source and receipt['run_id']==43757506287
artifact=next(item for item in load(base/'single-artifacts.json')['artifacts'] if item['id']==receipt['artifact_id'])
assert artifact['name']=='nemoterm-single-exe-x64-'+source and not artifact['expired']
image=base/'product/nemoterm.exe';image_sha=digest(image)
validation=load(base/'single-evidence/build/single-exe-check/research/single-exe-validation.json')
assert validation['executable_sha256']==image_sha and validation['executable_bytes']==image.stat().st_size
assert validation['executable_directory_files']==['nemoterm.exe']
assert len(validation['passed_checks'])==len(set(validation['passed_checks']))==163
assert {'command_line_profile','tabs-regressions','codex-tabs-default','codex-tabs-inline','legacy_parameter','answerback_config'}<=set(validation['passed_checks'])
subprocess.run(['git','diff','--exit-code',source,fixture,'--','vendor/putty-0.85','native','scripts','CMakeLists.txt'],cwd=work,check=True)

original=load(root/'build/local-gdi-single-product-12ee33b-01/cases.json')
assert len(original)==39 and len({name for name,_ in original})==39
cases=[(name,list(command)) for name,command in original]
for name,command in cases:
    if name in ('input-byte','input-wide'):command.append('--foreground')
cases.append(('command-line-profile',['tests/command_line_profile_window_smoke.py']))
for renderer,number in [('gdi','0'),('opengl','1'),('directx','2')]:
    cases.append(('hosted-geometry-'+renderer,['tests/geometry_window_smoke.py','--tabs','--tab-side','bottom','--renderer',number]))
for side in ('top','bottom','left','right'):
    cases.append(('hosted-resize-'+side,['tests/window_resize_window_smoke.py','--tabs','--tab-side',side]))
cases.append(('legacy-parameter',['tests/legacy_parameter_window_smoke.py']))
cases.append(('answerback-config',['tests/answerback_config_window_smoke.py']))
assert len(cases)==49 and len({name for name,_ in cases})==49
# Verify the changed host/resize, parameter-query and answerback paths before the longer unchanged workloads.
cases=cases[-10:]+cases[:-10]
interactive={'input-byte','input-wide','bindings','drop-gdi','drop-directx','selection-gdi','selection-directx','unicode-presented-gdi'}
selected=[case for case in cases if a.scope=='all' or (case[0] in interactive)==(a.scope=='interactive')]
if a.only_case:
    names=set(a.only_case)
    assert len(names)==len(a.only_case) and names<={name for name,_ in selected}
    selected=[case for case in selected if case[0] in names]
if any(name in interactive for name,_ in selected):assert a.desktop_ready,'Foreground and clipboard cases require an available desktop'
assert selected
shutdown=root/'build/shutdown-python-17233-validation/Scripts/python.exe'
subprocess.run([str(shutdown),'-c',"import frida; assert frida.__version__=='17.23.3'"],check=True)
import frida
assert frida.__version__=='17.24.3'
font_map=root/'build/answerback-product-font-map-253855b.json'
font=load(font_map)
assert font['resolved_font']=='SarasaTermSC Nerd Font Light' and font['native_cjk_glyph']

stage=a.destination.resolve();assert not stage.exists(),'Choose a fresh stage; preserve all earlier failures'
stage.mkdir(parents=True)
for folder in ('dist','logs','research','build','case-evidence'):(stage/folder).mkdir()
archive=subprocess.check_output(['git','archive',fixture,'tests','tools/nemoterm_debug.py'],cwd=work)
fixtures={}
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    for entry in tar:
        if entry.isdir():continue
        assert entry.isfile(),entry.name
        target=(stage/entry.name).resolve();assert target.is_relative_to(stage)
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(tar.extractfile(entry).read());fixtures[entry.name]=digest(target)
shutil.copy2(image,stage/'dist/nemoterm.exe')
shutil.copy2(font_map,stage/'research/font-mapper-preflight.json')
shutil.copy2(__file__,stage/'controller.py')
identity=dict(source_commit=source,fixture_commit=fixture,source_run=43757506287,
    artifact_id=receipt['artifact_id'],executable_sha256=image_sha,executable_bytes=image.stat().st_size,
    ci_groups=163,shutdown_frida='17.23.3',other_frida=frida.__version__,fixtures=fixtures,
    fixture_changes='Uses exact source-matched 253855b fixtures, including host guards, screen bounds, parameter queries, answerback escapes and configured topmost fixtures.',
    planned_groups=len(cases),selected_groups=len(selected),scope=a.scope,desktop_ready=a.desktop_ready,
    remaining_groups=[name for name,_ in cases if name not in dict(selected)],
    acceptance_scope='Exact-image bounded regression; all original protocol and physical/application requirements remain separate. No promotion.')
(stage/'IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n')
(stage/'all-cases.json').write_text(json.dumps(cases,indent=2)+'\n')
(stage/'cases.json').write_text(json.dumps(selected,indent=2)+'\n')
if a.prepare_only:
    print('Prepared without running:',stage);raise SystemExit(0)
env=dict(os.environ,NEMOTERM_TEST_EXE=str(stage/'dist/nemoterm.exe'),NEMOTERM_REQUIRE_OPENGL='1',NEMOTERM_REQUIRE_DIRECTX='1',
    NEMOTERM_TEST_FONT=font['resolved_font'],NEMOTERM_SHUTDOWN_DEADLINE_SECONDS='120',NEMOTERM_TEST_TRACEBACK_SECONDS='60')
env.pop('CI',None);env.pop('GITHUB_ACTIONS',None)
def observations():
    return {path.relative_to(stage):digest(path) for folder in ('research','build') for path in (stage/folder).rglob('*') if path.is_file()}
results=[]
for name,arguments in selected:
    print('Starting exact-product case:',name,flush=True)
    before=observations();started=time.monotonic()
    with (stage/'logs'/(name+'.log')).open('w',encoding='utf-8') as log:
        try:
            result=subprocess.run([str(shutdown) if name=='shutdown' else sys.executable,*arguments],cwd=stage,env=env,
                stdout=log,stderr=subprocess.STDOUT,timeout=1800 if '-memory-' in name else 300)
            record=dict(name=name,exit_code=result.returncode,seconds=time.monotonic()-started)
        except subprocess.TimeoutExpired:record=dict(name=name,controller_timeout=True,seconds=time.monotonic()-started)
    record['observations']=[]
    for relative,checksum in observations().items():
        if before.get(relative)==checksum:continue
        target=stage/'case-evidence'/name/relative
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(stage/relative,target)
        record['observations'].append(dict(path=target.relative_to(stage).as_posix(),bytes=target.stat().st_size,sha256=checksum))
    results.append(record);(stage/'logs/results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps({key:value for key,value in record.items() if key!='observations'}),flush=True)
    if record.get('exit_code')!=0:raise SystemExit(1)
assert [path.name for path in (stage/'dist').iterdir()]==['nemoterm.exe']
assert digest(stage/'dist/nemoterm.exe')==image_sha
print(len(selected),'selected groups passed; review original evidence and remaining groups separately. No promotion.',flush=True)
