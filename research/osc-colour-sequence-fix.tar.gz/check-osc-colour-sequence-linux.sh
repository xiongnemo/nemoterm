#!/bin/sh
set -eu
compiler=$1
case "$compiler" in gcc|clang) ;; *) exit 2;; esac
root=/mnt/c/Users/nemo/Documents/Projects/nemoterm
source="$root/build/gdi-dense-memory-worktree"
evidence="$root/build/osc-colour-sequence-01/patched-$compiler"
mkdir "$evidence"
build=$(cat "$root/build/answerback-nul-linux-$compiler-03/build-directory.txt")
printf '%s\n' "$build" > "$evidence/build-directory.txt"
GIT_DIR="$root/.git/worktrees/gdi-dense-memory-worktree"
GIT_WORK_TREE="$source"
export GIT_DIR GIT_WORK_TREE
"$compiler" --version > "$evidence/compiler.txt"
sha256sum "$source/vendor/putty-0.85/terminal/terminal.c" "$source/vendor/putty-0.85/test/test_osc_colour.c" "$source/tests/osc_colour_sequence_reference.h" > "$evidence/sources.sha256"
cmake --build "$build" --target test_osc_colour test_colour test_queries test_sgr test_state_control --parallel 2 > "$evidence/build.log" 2>&1
for target in test_colour test_osc_colour test_queries test_sgr test_state_control; do
    ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1 timeout 120 "$build/$target" > "$evidence/$target.log" 2>&1
    printf '%s %s passed\n' "$compiler" "$target"
done
