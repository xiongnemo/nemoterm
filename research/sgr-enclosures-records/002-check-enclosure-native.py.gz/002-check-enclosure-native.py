import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];results=[]
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
base=root/'build/enclosure-native';base.mkdir(exist_ok=False)
before=root.parents[1]/'dist/nemoterm.exe'
after=root/'build/enclosure-single/nemoterm.exe'
assert hashlib.sha256(before.read_bytes()).hexdigest()=='ebd2d24edcf9ba10f0435597e15ad8aff44320fad1a707b6e4cbc10654345a63'
for label,exe,expected in [('before',before,1),('after',after,0)]:
    dest=base/label
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),'renderer'],
            cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    record=dict(label=label,exit_code=code,expected_exit_code=expected)
    report=dest/'research/renderer-observed.json'
    if report.exists():
        data=json.loads(report.read_text());record.update(completed=data['completed'],
            modes=[dict(active=m['active'],checks=len(m['checks']),enclosure=m.get('enclosure_pixels_checked')) for m in data['modes']])
        if expected:
            assert len(data['modes'])==1 and data['modes'][0]['checks'][-1]['scene']=='enclosures'
            assert 'AssertionError: (1, 1, 0, 0)' in (dest/'renderer.log').read_text()
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(record,flush=True)
    if code!=expected:
        print((dest/'controller.log').read_text()[-3500:]);raise SystemExit(1)
