import gzip,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
dest=root/'research/sgr-enclosures-records';dest.mkdir(exist_ok=False)
files=list((root/'build/enclosure-evidence').glob('*'))
reference=root.parents[1]/'build/sgr-enclosure-reference/source.json'
files.append(reference)
for folder in ('enclosure-native','enclosure-wire','enclosure-memory-gdi','enclosure-memory-directx','enclosure-resources'):
    base=root/'build'/folder
    for p in base.rglob('*'):
        if not p.is_file():continue
        parts=p.relative_to(base).parts
        if any(n in parts for n in ['dist','tools','__pycache__']):continue
        if 'tests' in parts:
            if folder!='enclosure-resources' or p.name not in ['tabs_window_smoke.py','dll_window_catalogue.py']:continue
        if p.suffix in ['.json','.log','.png','.bmp','.py']:files.append(p)
for name in ('link-enclosure-image.py','check-enclosure-native.py','check-enclosure-memory.py','check-enclosure-resources.py','enclosure-memory-results.json'):
    files.append(root/'build'/name)
for name in ('image.json','link.rsp','link.log'):files.append(root/'build/enclosure-single'/name)
files.append(Path(__file__))
records=[]
for p in sorted(set(files)):
    data=p.read_bytes();archive=dest/f'{len(records):03d}-{p.name}.gz';archive.write_bytes(gzip.compress(data,mtime=0))
    name=str(p.relative_to(root)) if p.is_relative_to(root) else 'reference/'+p.name
    records.append(dict(path=name.replace('\\','/'),archive=str(archive.relative_to(root)).replace('\\','/'),
                        bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
manifest=dict(kind='Local owned Win32 and Linux observations, not REA-server Evidence',
    product_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    image_sha256='2f65d99323df10e1f381662a652782d8033c5938d6c3b4eefcb77a3d83bb8c9a',
    records=records)
(root/'research/sgr-enclosures-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
for r in records:
    data=gzip.decompress((root/r['archive']).read_bytes())
    assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
print('Verified',len(records),'records;',sum((root/r['archive']).stat().st_size for r in records),'compressed bytes')
