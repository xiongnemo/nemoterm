import json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];results=[]
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
for mode,side in [('gdi','top'),('directx','left')]:
    dest=root/'build'/('enclosure-memory-'+mode);assert not dest.exists()
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(root/'build/enclosure-single/nemoterm.exe',dest/'dist')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),'tabs','--renderer',mode,
            '--side',side,'--cols','160','--rows','48','--workload-memory'],cwd=root,
            stdout=log,stderr=subprocess.STDOUT).returncode
    record=dict(label=mode,exit_code=code)
    memory=list((dest/'research').glob('*-memory.json'))
    if memory:
        data=json.loads(memory[0].read_text());record.update(peaks=data['peaks']['frontend'],samples=data['sample_count'])
    results.append(record);(root/'build/enclosure-memory-results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(record,flush=True)
    if code:
        print((dest/'controller.log').read_text()[-2300:]);raise SystemExit(code)
