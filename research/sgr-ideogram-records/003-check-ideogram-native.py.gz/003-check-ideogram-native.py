import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/ideogram-native';base.mkdir(exist_ok=False)
exe=root/'build/ideogram-single/nemoterm.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='7f3a9933200be5f50a25a7e8fe69683fb04db56621455ed5b57195308a6b06b8'
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
cases=[('renderer','renderer',[]),('wire','sgr_stack',[])]
cases += [('memory-'+renderer,'tabs',['--renderer',renderer,'--side',side,'--cols','160','--rows','48','--workload-memory'])
    for renderer,side in [('gdi','top'),('directx','left')]]
results=[]
for label,test,arguments in cases:
    dest=base/label
    for folder in ['dist','research','build','tools']:(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        result=subprocess.run([sys.executable,str(controller),str(dest),test,*arguments],cwd=root,stdout=log,stderr=subprocess.STDOUT)
    record=dict(label=label,exit_code=result.returncode)
    for p in (dest/'research').glob('*-memory.json'):
        d=json.loads(p.read_text());record.update(samples=d['sample_count'],peaks=d['peaks']['frontend'])
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(record,flush=True)
    if result.returncode:
        print((dest/'controller.log').read_text()[-2800:],flush=True);raise SystemExit(result.returncode)
