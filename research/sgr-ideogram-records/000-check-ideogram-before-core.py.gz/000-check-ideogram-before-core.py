import json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1];dest=root/'build/ideogram-before-core';dest.mkdir(exist_ok=False)
source='/mnt/c/'+root.as_posix()[3:];build='/tmp/nemoterm-ideogram-normal-20261114'
prefix=['wsl','-d','Debian','--'];commands=[]
for label,args in [
    ('configure',prefix+['cmake','-S',source+'/vendor/putty-0.85','-B',build,'-G','Ninja','-DPUTTY_GTK_VERSION=NONE','-DPUTTY_GSSAPI=OFF','-DCMAKE_C_FLAGS=-O1']),
    ('build',prefix+['cmake','--build',build,'--target','test_queries','--parallel','4']),
    ('queries',prefix+[build+'/test_queries'])]:
    with (dest/(label+'.log')).open('wb') as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
    commands.append(dict(label=label,argv=args,exit_code=r.returncode));(dest/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(label,r.returncode,flush=True)
    assert (r.returncode!=0 if label=='queries' else r.returncode==0),(label,r.returncode)
print('The old parser rejects the new ideogram reply expectations',flush=True)
