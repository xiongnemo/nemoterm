$ErrorActionPreference='Stop'
. ../rtl-worktree/build/local-msvc/env.ps1
$taskRoot=(Get-Location).Path
$evidence=Join-Path $taskRoot 'build/ideogram-build'
New-Item -ItemType Directory -Path $evidence -Force | Out-Null
& ../../tools/python/cmake/data/bin/cmake.exe -S vendor/putty-0.85 -B build/frontend-single -G Ninja -DCMAKE_C_COMPILER=cl -DCMAKE_CXX_COMPILER=cl -DCMAKE_BUILD_TYPE=MinSizeRel '-DCMAKE_C_FLAGS=/std:c11 /utf-8' '-DCMAKE_C_FLAGS_MINSIZEREL=/O1 /Ob1 /Gy /Gw' -DCMAKE_POLICY_DEFAULT_CMP0091=NEW -DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded "-DCMAKE_ARCHIVE_OUTPUT_DIRECTORY=$taskRoot/build/frontend-single" -DPUTTY_GSSAPI=OFF -DNEMOTERM_SINGLE_EXE=ON "-DCMAKE_MAKE_PROGRAM=$taskRoot/../../tools/python/bin/ninja.exe" *> "$evidence/configure.log"
if ($LASTEXITCODE) { Get-Content "$evidence/configure.log" -Tail 30; exit $LASTEXITCODE }
& ../../tools/python/cmake/data/bin/cmake.exe --build build/frontend-single --target pterm test_sixel test_sixel_terminal test_sgr test_queries test_state_control test_rectangle --parallel 4 *> "$evidence/build.log"
if ($LASTEXITCODE) { Get-Content "$evidence/build.log" -Tail 40; exit $LASTEXITCODE }
foreach ($test in @('test_sixel','test_sixel_terminal','test_sgr','test_queries','test_state_control','test_rectangle')) {
    & "./build/frontend-single/$test.exe" *> "$evidence/$test.log"
    if ($LASTEXITCODE) { Get-Content "$evidence/$test.log" -Tail 30; exit $LASTEXITCODE }
}
python build/link-ideogram-image.py
exit $LASTEXITCODE
