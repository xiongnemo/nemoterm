import json,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
source='/mnt/c/'+root.as_posix()[3:]
dest=root/'build/ideogram-core';dest.mkdir(exist_ok=False)
tests=['test_sixel','test_sixel_terminal','test_sgr','test_queries','test_state_control','test_rectangle']
commands=[]
def run(label,argv):
    with (dest/(label+'.log')).open('wb') as log:
        result=subprocess.run(argv,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    commands.append(dict(label=label,argv=argv,exit_code=result.returncode))
    (dest/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    print(label,result.returncode,flush=True)
    if result.returncode:
        print((dest/(label+'.log')).read_text(errors='replace')[-3000:]);raise SystemExit(result.returncode)
run('generated-sgr',[sys.executable,'tests/generate_sgr_stack_oracle.py','--check'])
run('resource-settle-unit',[sys.executable,'tests/resource_settle_test.py'])
prefix=['wsl','-d','Debian','--']
for kind,flags in [('normal','-O1'),('sanitizer','-g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer')]:
    build='/tmp/nemoterm-ideogram-'+kind+'-20261114'
    configure=prefix+['cmake','-S',source+'/vendor/putty-0.85','-B',build,'-G','Ninja',
        '-DPUTTY_GTK_VERSION=NONE','-DPUTTY_GSSAPI=OFF','-DCMAKE_C_FLAGS='+flags]
    if kind=='sanitizer':configure+=['-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined']
    run(kind+'-configure',configure)
    run(kind+'-build',prefix+['cmake','--build',build,'--target',*tests,'--parallel','4'])
    for test in tests:
        argv=prefix+(['env','ASAN_OPTIONS=detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS=halt_on_error=1'] if kind=='sanitizer' else [])+[build+'/'+test]
        run(kind+'-'+test,argv)
strict='/tmp/nemoterm-ideogram-strict-20261114'
run('strict-build',prefix+['cc','-std=c99','-Wall','-Wextra','-Werror','-pedantic','-I'+source+'/vendor/putty-0.85/terminal',source+'/tests/test_sixel.c',
    source+'/vendor/putty-0.85/terminal/nemo_sixel.c','-lm','-o',strict])
run('strict-sixel',prefix+[strict])
