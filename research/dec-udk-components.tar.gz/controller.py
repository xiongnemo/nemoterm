from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile
root = Path(__file__).resolve().parents[1]
work = root/'build/udk-worktree'
sha = lambda data: hashlib.sha256(data).hexdigest()
entries = {'controller.py':Path(__file__).read_bytes()}
summaries = []
for source,number,conclusion in [
    ('2a6a1639f3d98d7182a473e924eff9a139ad142b',43717684952,'failure'),
    ('f8a20d3872d203023d79dc80d3d4d555840dba0b',43717926965,'success')]:
    prefix = source[:7]
    base = root/f'build/ci-udk-components-{prefix}'
    run = json.loads((base/'ansi-components-run.json').read_bytes())
    assert (run['headSha'],run['databaseId'],run['status'],run['conclusion']) == (source,number,'completed',conclusion)
    jobs = [j for j in run['jobs'] if j['conclusion'] != 'skipped']
    assert len(jobs) == 3
    artifacts = json.loads((base/'ansi-components-artifacts.json').read_bytes())['artifacts']
    matches, receipts = [], []
    def blob(name):
        key = prefix+'/source/'+name
        if key not in entries:
            entries[key] = subprocess.check_output(['git','show',source+':'+name],cwd=work)
        return entries[key]
    for compiler in ('gcc','clang','msvc'):
        receipt = json.loads((base/(compiler+'-download.json')).read_bytes())
        artifact = next(a for a in artifacts if a['id'] == receipt['artifact_id'])
        assert artifact['name'] == f'ansi-conformance-{compiler}-{source}' and receipt['source'] == source
        receipts.append(dict(compiler=compiler,id=artifact['id']))
        if compiler == 'msvc':
            hashes = [(item['Path'].replace('\\','/').split('/vendor/',1),item['Hash'].lower())
                      for item in json.loads((base/compiler/'sources.json').read_text(encoding='utf-8-sig'))]
            pairs = []
            for parts,digest in hashes:
                name = 'vendor/'+parts[1] if len(parts) == 2 else 'tests/'+parts[0].split('/tests/',1)[1]
                pairs.append((name,digest))
        else:
            pairs = [(name,digest) for digest,name in
                     (line.split(None,1) for line in (base/compiler/'sources.sha256').read_text().splitlines())]
        for name,digest in pairs:
            raw = blob(name)
            assert digest in (sha(raw),sha(raw.replace(b'\n',b'\r\n'))),name
            matches.append(dict(compiler=compiler,path=name,sha256=digest))
        log = (base/compiler/'test_udk_terminal.log').read_text(encoding='utf-8-sig')
        passes = conclusion == 'success' or compiler == 'msvc'
        assert ('UDK terminal: passed' if passes else 'UDK terminal: FAILED') in log
        if passes:
            assert 'reply mismatch' not in log
            for mode in ('whole','bytewise'): assert f'UDK {mode}: 238 unchanged reference replies' in log
            assert '64 reset cycles checked' in log
        else:
            assert log.count('reply mismatch') == 2 and log.count('eight-bit-dcs/0') == 2
        for test in ('locator_terminal','cancellation_terminal','ansi_terminal','queries','state_control',
                     'keyboard','pointer_terminal','osc52','sixel_terminal','selective_erase','sgr','tcap'):
            text = (base/compiler/f'test_{test}.log').read_text(encoding='utf-8-sig')
            assert 'passed' in text or '0 failures' in text,test
    for name in ('scripts/generate-udk-reference.py','tests/generate_dec_status_oracle.py',
                 'tests/dec_status_oracle_cases.h','tests/dec_status_window_smoke.py',
                 'vendor/putty-0.85/test/test_queries.c','.github/workflows/ansi-conformance.yml',
                 'vendor/putty-0.85/unix/CMakeLists.txt','vendor/putty-0.85/windows/CMakeLists.txt'):
        blob(name)
    for p in base.rglob('*'):
        if p.is_file(): entries[prefix+'/'+p.relative_to(base).as_posix()] = p.read_bytes()
    summaries.append(dict(source=source,run=number,conclusion=conclusion,
                          jobs=[dict(name=j['name'],conclusion=j['conclusion']) for j in jobs],
                          artifacts=receipts,source_matches=matches))
subprocess.run(['git','diff','--exit-code','2a6a163','f8a20d3','--','vendor/putty-0.85/terminal',
                'vendor/putty-0.85/windows','vendor/putty-0.85/putty.h','vendor/putty-0.85/config.c',
                'vendor/putty-0.85/conf-enums.h'],cwd=work,check=True)
archive = work/'research/dec-udk-components.tar.gz'
records = []
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(entries.items()):
        info = tarfile.TarInfo(name); info.size = len(raw); tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name == record['path'] and sha(tar.extractfile(member).read()) == record['raw_sha256']
manifest = dict(runs=summaries,reference_sha256='b6917d91165d635fc7d202be432028faa27104fc62e947ddc4d48c046c2dada3',
    cases=91,steps_per_mode=238,modes=['whole','bytewise'],reset_cycles=64,
    limits=dict(input_bytes=65536,decoded_storage_bytes=1048576),
    scope='Component replay and allocation/cancellation checks. Initial Linux fixture had stale charset tables; the corrected fixture preserves every input and expected reply. Production code is identical between these two runs. Native and product acceptance remain separate.',
    bundle=dict(path=archive.relative_to(work).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),records=records))
(work/'research/dec-udk-components-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Retained',len(records),'records',archive.stat().st_size,'bytes;',sum(len(s['source_matches']) for s in summaries),'source hash matches')
