"""Repeat existing PNG/GIF pixels after all memory sampling has completed."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
stage=Path(sys.argv[1]).resolve()
identity=json.loads((stage/'IDENTITY.json').read_text())
assert identity['source_commit']=='b3e03bb3a3a1f75e3403b7dd5a9e0d14065c46ac'
assert hashlib.sha256((stage/'dist/nemoterm.exe').read_bytes()).hexdigest()==identity['executable_sha256']
prior=json.loads((stage/'logs/results.json').read_text())
assert len(prior)==23 and all(x.get('exit_code')==0 for x in prior)
assert not (stage/'logs/image-regressions.json').exists(),'Preserve earlier observations'
cases=[]
for family,fixture in [('inline','iterm_image_window_smoke.py'),('gif','gif_animation_window_smoke.py')]:
 for renderer in ('gdi','opengl','directx'):
  cases.append((family+'-'+renderer,['tests/'+fixture,'--renderer',renderer]))
 cases.append((family+'-presented-gdi',['tests/'+fixture,'--renderer','gdi','--presented-gdi']))
env=dict(os.environ,NEMOTERM_TEST_EXE=str(stage/'dist/nemoterm.exe'),NEMOTERM_REQUIRE_OPENGL='1',NEMOTERM_REQUIRE_DIRECTX='1',NEMOTERM_TEST_FONT='SarasaTermSC Nerd Font Light')
env.pop('CI',None)
results=[]
for name,arguments in cases:
 start=time.monotonic()
 with (stage/'logs'/('regression-'+name+'.log')).open('w') as output:
  try:
   result=subprocess.run([sys.executable,*arguments],cwd=stage,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=240)
   item=dict(name=name,exit_code=result.returncode,seconds=time.monotonic()-start)
  except subprocess.TimeoutExpired:
   item=dict(name=name,controller_timeout=True,seconds=time.monotonic()-start)
 results.append(item);(stage/'logs/image-regressions.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(item),flush=True)
 if item.get('exit_code')!=0:sys.exit(1)
print('Existing image-protocol pixel regressions passed',flush=True)
