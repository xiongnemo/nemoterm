"""Review exact-product pixels, uninjected memory and natural process cleanup."""
from pathlib import Path
import hashlib,json,sys
stage=Path(sys.argv[1]).resolve()
identity=json.loads((stage/'IDENTITY.json').read_text())
digest=hashlib.sha256((stage/'dist/nemoterm.exe').read_bytes()).hexdigest();assert digest==identity['executable_sha256']
results=json.loads((stage/'logs/results.json').read_text())
assert len(results)==23 and all(r.get('exit_code')==0 for r in results),results
shutdown=json.loads((stage/'research/shutdown-window-observed.json').read_text())
assert shutdown['completed'] and shutdown['executable_sha256']==digest and len(shutdown['cases'])==12
for case in shutdown['cases']:
 assert case['exit_code']==0 and not case['cleanup']['terminated_remaining'],case
 assert case['active_renderer']=={'gdi':1,'opengl':2,'directx':3}[case['renderer']],case
pixel_records=[];memory_records=[]
for p in sorted((stage/'research').glob('*observed.json')):
 j=json.loads(p.read_text(encoding='utf-8-sig'))
 if p.name.startswith(('kitty-image-','kitty-geometry-','kitty-compression-','iterm-images-','gif-animation-')):
  assert j['completed'] and j['executable_sha256']==digest,p
  renderer=j.get('requested_renderer',j.get('renderer'))
  assert j['actual_renderer']=={'gdi':0,'opengl':1,'directx':2}[renderer],p
  assert not j['cleanup']['terminated_remaining'],p
  pixel_records.append({'name':p.name,'checks':len(j.get('checks',j.get('phases',[]))),'capture':j.get('capture'),'actual_renderer':j['actual_renderer']})
 if p.name.startswith(('workload-tabs-','inline-workload-tabs-','animated-workload-tabs-','kitty-workload-tabs-','compressed-kitty-workload-tabs-')):
  assert j['executable_sha256']==digest and j['font']=='SarasaTermSC Nerd Font Light',p
  assert j['actual_renderer']=={'gdi':1,'directx':3}[j['renderer']],p
  assert j['completed'] and j['memory_limit_passed'] and not j['memory_instrumented'],p
  assert j['actual_grid']==[160,48] and not j['process_tree_memory']['injected'],p
  assert not j['owned_job_cleanup']['terminated_remaining'],p
  memory_records.append({'name':p.name,'grid':j['actual_grid'],'font':j.get('font'),'samples':j['process_tree_memory']['sample_count'],'peaks':j['process_tree_memory']['peaks'],'limit_bytes':j['memory_limit_bytes'],'limit_inclusive':j['memory_limit_inclusive']})
assert len(pixel_records)==20,pixel_records
extra=json.loads((stage/'logs/image-regressions.json').read_text())
assert len(extra)==8 and all(x.get('exit_code')==0 for x in extra)
assert len(memory_records)==10,memory_records
print(json.dumps({'identity':identity,'pixels':pixel_records,'memory':memory_records},indent=2))
