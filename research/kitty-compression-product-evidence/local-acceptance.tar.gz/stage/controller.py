"""Accept only the successful formal product; never promote or overwrite dist."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,time
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--evidence',type=Path,required=True)
parser.add_argument('--destination',type=Path,required=True)
args=parser.parse_args()
repo=Path(__file__).resolve().parents[1]
base=args.evidence.resolve(); stage=args.destination.resolve()
source='b3e03bb3a3a1f75e3403b7dd5a9e0d14065c46ac'
run=json.loads((base/'single-run.json').read_text())
assert run['headSha']==source and run['status']=='completed' and run['conclusion']=='success',run
assert run['databaseId']==43646925393
receipt=json.loads((base/'product-download.json').read_text());assert receipt['source']==source
exe=base/'product/nemoterm.exe';digest=hashlib.sha256(exe.read_bytes()).hexdigest()
observed=json.loads((base/'single-evidence/build/single-exe-check/research/single-exe-validation.json').read_text(encoding='utf-8-sig'))
assert observed['executable_sha256']==digest and observed['executable_bytes']==exe.stat().st_size
assert observed['executable_directory_files']==['nemoterm.exe']
assert {'kitty_compression','kitty_compression-opengl','kitty_compression-directx','compressed-kitty-workload-tabs-gdi-top','compressed-kitty-workload-tabs-directx-left'} <= set(observed['passed_checks'])
assert not stage.exists(),'Use a fresh staging directory; do not overwrite previous evidence'
stage.mkdir(parents=True)
for folder in ('dist','tests','tools','logs','research'):(stage/folder).mkdir()
work=repo/'build/kitty-placement-worktree'
# Copy the committed fixture snapshot, preserving tracked bytes and source identity.
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',source,'--','tests','tools/nemoterm_debug.py'],cwd=work,text=True).splitlines()
for name in paths:
 target=stage/name;target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(subprocess.check_output(['git','show',source+':'+name],cwd=work))
shutil.copy2(exe,stage/'dist/nemoterm.exe')
font_map=json.loads((repo/'build/compression-font-map.json').read_text(encoding='utf-8'))
assert font_map['resolved_font']=='SarasaTermSC Nerd Font Light' and font_map['native_cjk_glyph']
shutil.copy2(repo/'build/compression-font-map.json',stage/'research/font-mapper-preflight.json')
identity=dict(source_commit=source,product_source_commit='48a02634323302fddd955b9bc25f2bd90ca7a6d3',source_run=run['databaseId'],artifact_id=receipt['artifact_id'],executable_sha256=digest,executable_bytes=exe.stat().st_size,fixture_source_commit=source,ci_checks=len(observed['passed_checks']),scope='Local formal-product acceptance; no promotion by this controller')
(stage/'IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n')
shutil.copy2(Path(__file__),stage/'controller.py')
cases=[('shutdown',['tests/shutdown_window_smoke.py'])]
for family,script in [('kitty','kitty_image_window_smoke.py'),('geometry','kitty_geometry_window_smoke.py'),('compression','kitty_compression_window_smoke.py')]:
 for renderer in ('gdi','opengl','directx'):
  cases.append((family+'-'+renderer,['tests/'+script,'--renderer',renderer]))
 cases.append((family+'-presented-gdi',['tests/'+script,'--renderer','gdi','--presented-gdi']))
for family,extra in [('sixel',[]),('inline',['--inline-images']),('animated',['--animated-images']),('kitty',['--kitty-images']),('compressed-kitty',['--kitty-images','--kitty-compression'])]:
 for renderer,side in [('gdi','top'),('directx','left')]:
  cases.append((family+'-memory-'+renderer,['tests/tabs_window_smoke.py','--renderer',renderer,'--side',side,'--workload-memory','--cols','160','--rows','48','--font','SarasaTermSC Nerd Font Light',*extra]))
env=dict(os.environ,NEMOTERM_TEST_EXE=str(stage/'dist/nemoterm.exe'),NEMOTERM_REQUIRE_OPENGL='1',NEMOTERM_REQUIRE_DIRECTX='1',NEMOTERM_TEST_FONT='SarasaTermSC Nerd Font Light',NEMOTERM_SHUTDOWN_DEADLINE_SECONDS='120')
env.pop('CI',None)
results=[]
for name,arguments in cases:
 started=time.monotonic()
 with (stage/'logs'/f'{name}.log').open('w',encoding='utf-8') as log:
  try:
   result=subprocess.run([sys.executable,*arguments],cwd=stage,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
   item=dict(name=name,exit_code=result.returncode,seconds=time.monotonic()-started)
  except subprocess.TimeoutExpired:
   item=dict(name=name,controller_timeout=True,seconds=time.monotonic()-started)
 results.append(item);(stage/'logs/results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(item),flush=True)
 if item.get('exit_code')!=0:sys.exit(1)
assert [p.name for p in (stage/'dist').iterdir()]==['nemoterm.exe']
assert hashlib.sha256((stage/'dist/nemoterm.exe').read_bytes()).hexdigest()==digest
print('All local acceptance commands passed; retained observations still require review',flush=True)
