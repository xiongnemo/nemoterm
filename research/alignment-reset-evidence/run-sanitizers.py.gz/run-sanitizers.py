import os, subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
dest=Path('/tmp/nemoterm-alignment-asan-20261114')
def command(name,args,env=None):
    with (root/'build'/name).open('w') as output:
        result=subprocess.run(args,stdout=output,stderr=subprocess.STDOUT,env=env,timeout=300)
    if result.returncode:
        print((root/'build'/name).read_text()[-5000:],flush=True)
        raise SystemExit(result.returncode)
    print(name+': passed',flush=True)
command('asan-configure.log',['cmake','-S',str(root/'vendor/putty-0.85'),'-B',str(dest),'-G','Ninja',
    '-DPUTTY_GTK_VERSION=NONE','-DPUTTY_GSSAPI=OFF',
    '-DCMAKE_C_FLAGS=-g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer',
    '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined'])
names=['test_state_control','test_sixel_terminal','test_hyperlink']
command('asan-build.log',['cmake','--build',str(dest),'--target',*names,'--parallel','4'])
for name in names:
    command('asan-'+name+'.log',[str(dest/name)],
            env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1',UBSAN_OPTIONS='halt_on_error=1'))
