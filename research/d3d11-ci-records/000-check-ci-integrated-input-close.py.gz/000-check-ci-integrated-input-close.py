import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/ci-input-close-local';base.mkdir(exist_ok=False)
exe=root/'build/ci-integrated-input-close-9c22311/product/nemoterm.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='ebd2d24edcf9ba10f0435597e15ad8aff44320fad1a707b6e4cbc10654345a63'
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
results=[]
for label,name,args in [('startup','startup_visibility',[]),
    ('automation','automation',['--renderer','directx']),
    ('gdi','tabs',['--renderer','gdi','--side','top','--cols','160','--rows','48','--workload-memory']),
    ('directx','tabs',['--renderer','directx','--side','left','--cols','160','--rows','48','--workload-memory'])]:
    dest=base/label
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),name,*args],
            cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    record=dict(label=label,exit_code=code)
    memory=list((dest/'research').glob('*-memory.json'))
    if memory:
        data=json.loads(memory[0].read_text());record.update(peaks=data['peaks']['frontend'],samples=data['sample_count'])
    results.append(record);print(record,flush=True)
    (base/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    if code:
        print((dest/'controller.log').read_text()[-2500:]);raise SystemExit(code)
