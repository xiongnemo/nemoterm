set -euo pipefail
cd -- "$(dirname -- "$0")"
exec 2>producer.stderr
trap 'echo "$?" > producer.exit' EXIT
await() { for ((i=0;i<600;i++)); do [[ ! -f stop ]] || exit 23; [[ ! -f "$1" ]] || return 0; sleep .1; done; return 22; }
{ printf 'TERM=%s\n' "$TERM"; dpkg-query -W libsixel-bin; command -v img2sixel sixel2png; sha256sum "$(command -v img2sixel)" "$(command -v sixel2png)"; } > tools.txt
printf '\033[?25l\033[?80l\033[?1070h\033[0m\033]11;rgb:0/0/0\007\033[2J\033[9;1HSIXEL_BEFORE'
await draw
printf '\033[2;3H'
img2sixel -7 source.png | tee encoded.six
sixel2png -i encoded.six -o decoded.png
printf '\033[9;1HSIXEL_DRAWN '
await erase
printf '\033[2J\033[9;1HSIXEL_ERASED'
await finish
