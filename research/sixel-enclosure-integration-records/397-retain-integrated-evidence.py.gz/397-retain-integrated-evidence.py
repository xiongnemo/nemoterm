import gzip,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
files=[]
for name in ['integrated-core','integrated-build','integrated-native']:
    folder=root/'build'/name
    for p in folder.rglob('*'):
        if not p.is_file() or any(n in p.relative_to(folder).parts for n in ['dist','tests','tools','__pycache__']):continue
        if p.suffix in ['.json','.log','.png','.bmp']:files.append(p)
files += list((root/'build').glob('*integrated*.py'))+list((root/'build').glob('*integrated*.ps1'))
files += [root/'build/integrated-single'/n for n in ['image.json','link.rsp','link.log']]
dest=root/'research/sixel-enclosure-integration-records';dest.mkdir(exist_ok=True);records=[]
for p in sorted(set(files)):
    data=p.read_bytes();archive=dest/f'{len(records):03d}-{p.name}.gz'
    if archive.exists():assert gzip.decompress(archive.read_bytes())==data,archive
    else:archive.write_bytes(gzip.compress(data,mtime=0))
    records.append(dict(path=p.relative_to(root).as_posix(),archive=archive.relative_to(root).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
paths=subprocess.check_output(['git','diff','--name-only','420363b','--','vendor','tests','scripts','.github'],cwd=root,text=True).splitlines()
sources=[dict(path=p,sha256=hashlib.sha256((root/p).read_bytes()).hexdigest()) for p in paths if (root/p).is_file()]
manifest=dict(source='4e4bbc7',image=json.loads((root/'build/integrated-single/image.json').read_text()),
    kind='Local native and compiler observations, not REA-server Evidence',sources=sources,records=records)
(root/'research/sixel-enclosure-integration-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
for r in records:
    data=gzip.decompress((root/r['archive']).read_bytes());assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
print('Verified',len(records),'records;',sum((root/r['archive']).stat().st_size for r in records),'compressed bytes')
