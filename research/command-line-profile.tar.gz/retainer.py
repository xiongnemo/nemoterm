"""Retain the CLI regression and corrected portable image without promotion."""
from pathlib import Path
import hashlib,json,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/gdi-dense-memory-worktree';research=work/'research'
runtime=root/'build/local-cli-profile-candidate-01/dist'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before=load(research/'command-line-profile-baseline-observed.json')
after=load(research/'command-line-profile-candidate-observed.json')
assert not before['completed'] and [c['matched'] for c in before['checks']]==[True,True,False,False,False]
assert before['executable_sha256']=='64195969a8f2e6653f854d598f169810107ee808d66eaa1088cf9e3ced6b259f'
assert after['completed'] and len(after['checks'])==5 and all(c['matched'] for c in after['checks'])
assert after['executable_sha256']==digest(runtime/'nemoterm.exe')
assert all(not c['terminated_remaining'] and c['after']['active']==0 for d in (before,after) for c in d['cleanup'])
assert 'LockScreenBackstopFrame' not in (work/'build/input-method-focus-diagnostic.log').read_text() # class was queried separately below
paths={research/'command-line-profile-baseline-observed.json':'baseline-observed.json',
       research/'command-line-profile-candidate-observed.json':'candidate-observed.json',
       research/'command-line-profile-ime-foreground-failure.json':'first-local-foreground-failure.json',
       work/'build/input-method-failure.json':'local-foreground-diagnostic-failure.json',
       work/'build/input-method-focus-diagnostic.log':'local-foreground-diagnostic.log'}
for name in ('tests/command_line_profile_window_smoke.py','tests/input_method_window_smoke.py',
             'tests/selection_window_smoke.py','tests/owned_window_focus.py','vendor/putty-0.85/windows/pterm.c',
             'scripts/test-single-exe.ps1','.github/workflows/ci.yml'):
    paths[work/name]='source/'+name
for path in runtime.iterdir():paths[path]='runtime/'+path.name
earlier=root/'build/local-gdi-single-ime-byte-focused-12ee33b-03'
for name in ('IDENTITY.json','focus-controller.py','logs/input.log','research/focused-input-controller.json','build/input-method-failure.json'):
    paths[earlier/name]='earlier-host-preparation/'+name
identity=dict(scope='CLI product fix and local portable regression; no single-image or IME acceptance.',
    base_commit='90024c4',source_file_sha256=digest(work/'vendor/putty-0.85/windows/pterm.c'),
    runtime={path.name:dict(bytes=path.stat().st_size,sha256=digest(path)) for path in runtime.iterdir()},
    old_cases=[c['matched'] for c in before['checks']],new_cases=[c['matched'] for c in after['checks']],
    foreground_observation=dict(source='Separate read-only Win32 query of the HWND returned by WindowFromPoint in the retained diagnostic',
        window=36504652,pid=23032,window_class='LockScreenBackstopFrame',root=36504652,exstyle=134217736,
        caption_click_sent=False),ci='Pending for this source change')
checkpoint=root/'build/command-line-profile-retained-identity.json'
with checkpoint.open('x',encoding='utf-8') as stream:json.dump(identity,stream,indent=2);stream.write('\n')
paths[checkpoint]='identity.json';paths[Path(__file__)]='retainer.py'
archive=research/'command-line-profile.tar.gz';records=[]
with archive.open('xb') as raw,tarfile.open(fileobj=raw,mode='w:gz') as bundle:
    for path,name in sorted(paths.items(),key=lambda pair:pair[1]):
        records.append(dict(path=name,bytes=path.stat().st_size,sha256=digest(path)));bundle.add(path,arcname=name,recursive=False)
identity.update(archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=digest(archive)),records=records)
with (research/'command-line-profile-validation.json').open('x',encoding='utf-8') as stream:json.dump(identity,stream,indent=2);stream.write('\n')
print(json.dumps(dict(archive=identity['archive'],runtime=identity['runtime'],records=len(records)),indent=2))
