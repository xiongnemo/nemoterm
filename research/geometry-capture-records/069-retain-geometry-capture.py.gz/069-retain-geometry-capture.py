from pathlib import Path
import gzip,hashlib,json
root=Path(__file__).resolve().parents[1];base=root/'build/geometry-capture-comparison'
dest=root/'research/geometry-capture-records';dest.mkdir()
paths=[p for p in base.rglob('*') if p.is_file() and p.suffix in ('.json','.log','.png') and not any(s in p.parts for s in ('dist','tests','tools'))]
paths += [root/'build/check-geometry-capture.py',Path(__file__)]
for name in ('geometry_window_smoke.py','window_resize_window_smoke.py','shutdown_window_smoke.py','owned_failure_state.py','thread_snapshot.py','handle_snapshot.py','automation_capture.py','owned_job.py','frida_test_utils.py'):
 paths.append(root/'tests'/name)
for name,test in [('resize-original','window_resize'),('shutdown-original','shutdown'),('startup-diagnostic-canary','shutdown')]:
 paths.append(base/name/'tests'/f'{test}_window_smoke.py')
ci=[(root/'build/ci-owned-e1261e2','single',43575722079,False),
    (root.parent/'iterm-images-worktree/build/ci-iterm-a6c94cc','single',43575726430,False),
    (root.parent/'gif-animation-worktree/build/ci-gif-3d10a85','core',43576229677,False)]
for folder,kind,run,passed in ci:
 for suffix in ('run.json','run.log','artifacts.json'):paths.append(folder/f'{kind}-{suffix}')
 if kind=='single':
  paths += [folder/'single-evidence/build/native-crashes/application-errors.json']
  research=folder/'single-evidence/build/single-exe-check/research'
  for pattern in ('tabs-window-resize*','shutdown-window-observed.json'):
   paths += list(research.glob(pattern))
 else:
  paths += list((folder/'core-evidence/test-results').glob('tabs-geometry*'))
manifest=dict(scope='API captures retain geometry and resize assertions; diagnose owned lifecycle failures without changing deadlines',
 ci=[dict(run=run,conclusion='failure') for _,_,run,_ in ci],results=json.loads((base/'results.json').read_text()),records=[])
for i,p in enumerate(sorted(set(paths))):
 assert p.is_file(),p
 data=p.read_bytes();archive=dest/f'{i:03d}-{p.name}.gz';archive.write_bytes(gzip.compress(data,mtime=0))
 assert gzip.decompress(archive.read_bytes())==data
 manifest['records'].append(dict(path=str(p),archive=archive.relative_to(root).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(root/'research/geometry-capture-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(dict(records=len(manifest['records']),compressed_bytes=sum(p.stat().st_size for p in dest.iterdir())))
