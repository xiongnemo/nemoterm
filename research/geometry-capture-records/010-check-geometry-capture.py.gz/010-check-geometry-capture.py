from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];project=root.parents[1]
base=root/'build/geometry-capture-comparison';base.mkdir()
resize=root/'build/ci-owned-e1261e2/unverified-product/nemoterm.exe'
gif=project/'build/gif-animation-worktree/build/ci-gif-3d10a85/product/nemoterm.exe'
startup=project/'build/iterm-images-worktree/build/ci-iterm-a6c94cc/unverified-product/nemoterm.exe'
accepted=project/'dist/nemoterm.exe'
assert hashlib.sha256(resize.read_bytes()).hexdigest()=='3ee59aa8ef2c08e5af3e306a4b8321e04f63b101e38858494f3f41170874f78f'
assert hashlib.sha256(startup.read_bytes()).hexdigest()=='200f0025d3266e865ce81877bcb35bf93b9db8146edf061b21d341b4e54fe873'
assert hashlib.sha256(accepted.read_bytes()).hexdigest()=='c110843b1fd5a551d654df094fa716c1ea1c48383d90e642b964d7dfb3d15e26'
cases=[
 ('resize-original',resize,'window_resize',['--tabs','--tab-side','left'],'old'),
 ('resize-api',resize,'window_resize',['--tabs','--tab-side','left'],'new'),
 ('geometry-api-tabs',gif,'geometry',['--tabs','--tab-side','bottom'],'new'),
 ('geometry-api-single',accepted,'geometry',[],'new'),
 ('resize-api-single',accepted,'window_resize',[],'new'),
 ('shutdown-original',startup,'shutdown',[],'old'),
 ('shutdown-diagnostics',startup,'shutdown',[],'new'),
 ('startup-diagnostic-canary',startup,'shutdown',['--renderer','gdi'],'canary')]
for name,exe,fixture,args,variant in cases:
 dest=base/name
 for directory in ('dist','research','build','tools'):(dest/directory).mkdir(parents=True)
 shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
 target=dest/'tests'/f'{fixture}_window_smoke.py'
 if variant=='old':
  target.write_bytes(subprocess.check_output(['git','show',f'HEAD:tests/{fixture}_window_smoke.py'],cwd=root))
 if variant=='canary':
  source=target.read_text();needle='hwnd = wait_for(lambda: find_window(process.pid))'
  assert source.count(needle)==1
  target.write_text(source.replace(needle,'hwnd = wait_for(lambda: None)  # Deliberately withhold readiness from this fixture.'),encoding='utf-8')
 shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(exe,dest/'dist/nemoterm.exe')
results=[]
for name,exe,fixture,args,variant in cases:
 dest=base/name
 with (dest/'controller.log').open('w') as log:
  run=subprocess.run([sys.executable,str(project/'build/rtl-worktree/build/run-owned-check.py'),str(dest),fixture,*args],stdout=log,stderr=subprocess.STDOUT)
 filename={'geometry':('tabs-' if '--tabs' in args else '')+'geometry-window-observed.json',
           'window_resize':('tabs-' if '--tabs' in args else '')+'window-resize-observed.json',
           'shutdown':'shutdown-window-observed.json'}[fixture]
 observed=dest/'research'/filename;d=json.loads(observed.read_text()) if observed.exists() else {}
 record=dict(name=name,variant=variant,executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),exit_code=run.returncode,completed=d.get('completed'),error=d.get('error'))
 record['modes']=[dict(requested=m.get('requested_renderer'),active=m.get('active_renderer'),checks=len(m.get('checks',[])),exit_code=m.get('exit_code'),close_seconds=m.get('close_seconds'),cleanup=m.get('cleanup')) for m in d.get('modes',[])]
 record['shutdown_cases']=[dict(renderer=v['renderer'],close=v['close'],failed_phase=v.get('failed_phase'),exit_code=v.get('exit_code'),cleanup=v.get('cleanup')) for v in d.get('cases',[])]
 if variant=='canary':
  case=d.get('cases',[{}])[0];state=case.get('process_before_cleanup',{})
  record['expected_failure_observed']=(run.returncode!=0 and case.get('failed_phase')=='window-ready' and state.get('exit_code','missing') is None and bool(state.get('threads')) and any(v['kind']=='Nemoterm' for v in state.get('windows',[])) and case.get('cleanup',{}).get('terminated_remaining') is True)
 results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps(record),flush=True)
 if run.returncode:print((dest/'controller.log').read_text()[-1600:],flush=True)
assert all(r['exit_code']==0 for r in results if r['variant']=='new'),results
assert all(r.get('expected_failure_observed') for r in results if r['variant']=='canary'),results
