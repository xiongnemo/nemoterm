"""Independently verify the retained exact-product local acceptance records."""
from pathlib import Path
import hashlib,json,sys
from collections import Counter
from PIL import Image
stage=Path(sys.argv[1]).resolve()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=load(stage/'IDENTITY.json');digest=sha(stage/'dist/nemoterm.exe')
assert digest==identity['executable_sha256'] and identity['ci_checks']==140
assert [p.name for p in (stage/'dist').iterdir()]==['nemoterm.exe']
results=load(stage/'logs/results.json')
assert len(results)==35 and all(r.get('exit_code')==0 for r in results),results
shutdown=load(stage/'research/shutdown-window-observed.json')
assert shutdown['completed'] and shutdown['executable_sha256']==digest and len(shutdown['cases'])==12
for case in shutdown['cases']:
 assert case['exit_code']==0 and not case['cleanup']['terminated_remaining'],case
 assert case['active_renderer']=={'gdi':1,'opengl':2,'directx':3}[case['renderer']],case
pixels=[];memory=[];api=presented=0
for p in sorted((stage/'research').glob('*observed.json')):
 d=load(p)
 if p.name.startswith(('kitty-image-','kitty-geometry-','kitty-compression-','kitty-features-','iterm-images-','gif-animation-')):
  assert d['completed'] and d['executable_sha256']==digest,p
  renderer=d.get('requested_renderer',d.get('renderer'))
  assert d['actual_renderer']=={'gdi':0,'opengl':1,'directx':2}[renderer],p
  assert not d['cleanup']['terminated_remaining'] and d['cleanup']['after']['active']==0,p
  checks=d['checks'] if 'checks' in d else d['phases']
  for check in checks:
   assert check['matched'],(p,check['name'])
   if 'expected_reply_hex' in check:assert check['reply_hex']==check['expected_reply_hex'],(p,check['name'])
   if 'bmp' in check:
    bmp=Path(d['folder'])/check['bmp'];bmp.resolve().relative_to(stage)
    assert sha(bmp)==check['bmp_sha256'],bmp
   else:
    # Geometry fixtures retain PNG and the original BMP's capture-time digest.
    # Recheck retained pixels, without pretending the original BMP is available.
    folders=[q for q in (stage/'research').glob(p.name.removesuffix('-observed.json')+'-*') if q.is_dir()]
    assert len(folders)==1,folders
    image=Image.open(folders[0]/check['image']).convert('RGB')
    assert image.size==(check['geometry']['width'],check['geometry']['height'])
    counts=Counter(image.get_flattened_data())
    for name,rgb in [('red',(255,0,0)),('blue',(0,0,255))]:
     record=check['counts'][name]
     assert counts[rgb]==record['actual']==record['expected'] and not record['missing'] and not record['unexpected']
  count=len(checks)
  if '-presented-gdi-' in p.name:presented+=count
  else:api+=count
  pixels.append(dict(name=p.name,stages=count,actual_renderer=d['actual_renderer'],capture=d['capture'],cleanup=d['cleanup']))
 if p.name.startswith(('workload-tabs-','inline-workload-tabs-','animated-workload-tabs-','kitty-workload-tabs-','compressed-kitty-workload-tabs-')):
  assert d['executable_sha256']==digest and d['font']=='SarasaTermSC Nerd Font Light',p
  assert d['actual_renderer']=={'gdi':1,'directx':3}[d['renderer']],p
  assert d['completed'] and d['memory_limit_passed'] and not d['memory_instrumented'],p
  assert d['actual_grid']==[160,48] and not d['process_tree_memory']['injected'],p
  assert not d['process_tree_memory']['diagnostic_only'] and not d['process_tree_memory']['errors'],p
  assert not d['owned_job_cleanup']['terminated_remaining'] and d['owned_job_cleanup']['after']['active']==0,p
  limit=20000000 if d['renderer']=='gdi' else 25000000
  peak=d['process_tree_memory']['peaks']['frontend']['private_ws']
  assert d['memory_limit_bytes']==limit and d['memory_limit_inclusive']==(d['renderer']=='directx')
  assert peak<limit if d['renderer']=='gdi' else peak<=limit
  memory.append(dict(name=p.name,renderer=d['renderer'],grid=d['actual_grid'],font=d['font'],
   samples=d['process_tree_memory']['sample_count'],peaks=d['process_tree_memory']['peaks'],
   limit_bytes=limit,limit_inclusive=d['memory_limit_inclusive'],cleanup=d['owned_job_cleanup']))
assert len(pixels)==24 and len(memory)==10,(len(pixels),len(memory))
assert (api,presented)==(927,309),(api,presented)
summary=dict(identity=identity,groups=35,shutdown_cases=12,api_stages=api,presented_gdi_stages=presented,
 pixels=pixels,memory=memory,frontend_peaks={renderer:{key:max(r['peaks']['frontend'][key] for r in memory if r['renderer']==renderer)
  for key in ('private_ws','total_ws','private_commit')} for renderer in ('gdi','directx')})
(stage.parent/'review.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({key:summary[key] for key in ('identity','groups','api_stages','presented_gdi_stages','frontend_peaks')},indent=2))
