"""Promote only a reviewed exact product, retain its predecessor and all evidence."""
from pathlib import Path
import datetime,gzip,hashlib,io,json,os,shutil,subprocess,tarfile
root=Path(__file__).resolve().parent.parent
work=root/'build/kitty-features-worktree';base=root/'build/ci-kitty-features-6e05bd1'
stage=root/'build/feature-query-product-6e05bd1/stage'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
subprocess.run(['python',str(root/'build/review-feature-product.py'),str(stage)],check=True,cwd=root)
review=load(stage.parent/'review.json');identity=review['identity'];digest=identity['executable_sha256']
subprocess.run(['git','diff','--quiet',identity['source_commit'],'HEAD','--','vendor','native','scripts/build.ps1','scripts/build-single-exe.ps1','scripts/prepare-single-exe.py'],cwd=work,check=True)
manifest_path=work/'research/kitty-feature-product-validation.json';manifest=load(manifest_path)
assert manifest['local_acceptance']=='pending'
assert manifest['single_executable_sha256']==digest and manifest['passed_single_checks']==140
artifact=next(a for a in load(base/'single-artifacts.json')['artifacts'] if a['id']==identity['artifact_id'])
expiry=artifact['expires_at']
old=root/'dist/nemoterm.exe';old_sha=sha(old.read_bytes())
assert old_sha=='65145ffb30d8a75199161f526b690794b66f6d593deab6f88cfd078ce5a795a0'
assert [p.name for p in old.parent.iterdir()]==['nemoterm.exe']
backup=root/'build/accepted-before-feature-queries-b3e03bb.exe'
assert not backup.exists()
shutil.copy2(old,backup);assert sha(backup.read_bytes())==old_sha
temporary=root/'dist/nemoterm.next.exe';assert not temporary.exists()
shutil.copy2(stage/'dist/nemoterm.exe',temporary)
assert sha(temporary.read_bytes())==digest
os.replace(temporary,old)
assert sha(old.read_bytes())==digest and [p.name for p in old.parent.iterdir()]==['nemoterm.exe']
promotion=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_commit=identity['source_commit'],
 executable_sha256=digest,executable_bytes=old.stat().st_size,artifact_id=identity['artifact_id'],
 previous_sha256=old_sha,backup=str(backup),groups=35,dist_files=['nemoterm.exe'])
(stage.parent/'promotion.json').write_text(json.dumps(promotion,indent=2)+'\n')
files={}
for folder in ('research','logs'):
 for p in (stage/folder).rglob('*'):
  if p.is_file():files[p.relative_to(stage).as_posix()]=p.read_bytes()
for name in ('IDENTITY.json','controller.py'):files[name]=(stage/name).read_bytes()
for name in ('review.json','promotion.json'):files[name]=(stage.parent/name).read_bytes()
files['review-controller.py']=(root/'build/review-feature-product.py').read_bytes()
files['promotion-controller.py']=Path(__file__).read_bytes()
buffer=io.BytesIO();rows=[]
with tarfile.open(fileobj=buffer,mode='w') as tar:
 for name,raw in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
  rows.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
data=gzip.compress(buffer.getvalue(),mtime=0)
path='research/kitty-feature-product-evidence/local-acceptance.tar.gz';(work/path).write_bytes(data)
with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as tar:
 for row in rows:assert sha(tar.extractfile(row['path']).read())==row['raw_sha256']
fixture={p.relative_to(stage).as_posix():sha(p.read_bytes()) for name in ('tests','tools')
 for p in (stage/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts}
for name,d in fixture.items():
 raw=subprocess.check_output(['git','show',identity['fixture_source_commit']+':'+name],cwd=work)
 assert sha(raw)==d,name
manifest.update(local_acceptance=review,promotion=promotion,fixture_snapshot_sha256=fixture,artifact_expires=expiry)
manifest['bundles'].append(dict(path=path,archive_bytes=len(data),archive_sha256=sha(data),records=rows))
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
g=review['frontend_peaks']['gdi'];d=review['frontend_peaks']['directx']
memory_table='\n'.join('| '+r['name']+' | '+str(r['samples'])+' | '+' | '.join(f"{r['peaks']['frontend'][k]:,}" for k in ('private_ws','total_ws','private_commit'))+' |' for r in review['memory'])
article=f'''# Accepted feature-query single executable

The accepted local `dist/nemoterm.exe` is the formal CI product from
`{identity['source_commit']}`: **{identity['executable_bytes']:,} bytes**, SHA256
`{digest}`. Its runtime directory contains only this executable; the source-built
console host uses the same image. The prior accepted compression image is kept
locally at `build/accepted-before-feature-queries-b3e03bb.exe`.

[Ordinary CI 43653882910](https://github.com/xiongnemo/nemoterm/actions/runs/43653882910)
passed all four jobs and [single-image CI 43653882888](https://github.com/xiongnemo/nemoterm/actions/runs/43653882888)
passed **140 groups** at that exact source. [Download artifact 14138801522](https://github.com/xiongnemo/nemoterm/actions/runs/43653882888/artifacts/14138801522)
expires at `{expiry}`. The strict GCC/Clang/MSVC component run also passed.
The [implementation record](kitty-feature-implementation.md) explains the
independent 84-case/176-state reference, supported-key projection and limits.

## Downloaded product validation

All **35 local groups** pass: 12 shutdown cases, 24 native image suites and ten
memory workloads. The image suites use SarasaTermSC Nerd Font Light and require
actual GDI, OpenGL and DirectX backends. GPU fallback cannot satisfy these runs.
The retained OS font-mapper preflight is independent of the terminal process.

| Fixture | Stages per actual renderer | Separate presented GDI stages |
| --- | ---: | ---: |
| Kitty image placement and lifecycle | 24 | 24 |
| Kitty font/window geometry | 12 | 12 |
| Compressed Kitty RGB/RGBA/PNG | 29 | 29 |
| Kitty feature-query state/reply replay | 176 | 176 |
| OSC 1337 static images | 32 | 32 |
| GIF animation | 36 | 36 |

All **927 API stages** and **309 direct GDI client-DC stages** pass. Feature-query
stages check exact wire replies with an input barrier, retained seed pixels and
completion of interleaved uploads. Every stored BMP is rehashed during review.
All test-owned jobs drain naturally, including each shutdown path.

## Ten uninjected memory workloads

Every workload uses an actual **160 x 48** Sarasa grid and two tabs. Sequential
sampling includes startup and resource settling with no working-set trimming.
GDI remains strictly below 20,000,000 private working-set bytes and DirectX at or
below 25,000,000. The additional external crash debugger is absent from all these
product acceptance runs.

| Workload record | Samples | Peak private WS (B) | Peak total WS (B) | Peak private commit (B) |
| --- | ---: | ---: | ---: | ---: |
{memory_table}

The maximum frontend private working sets are **{g['private_ws']:,} bytes for GDI**
and **{d['private_ws']:,} for DirectX**. Total WS peaks are {g['total_ws']:,} and
{d['total_ws']:,}; DirectX still exceeds the approximate 50 MB total target.
Private commit is recorded separately. Host, application and whole-tree samples
remain in the raw evidence; finite workloads do not prove arbitrary-load bounds.

## Retention and scope

`kitty-feature-product-validation.json` indexes all raw ordinary/single-image CI
records and **{len(rows):,} local records**, including a byte-verified promotion
receipt and {len(fixture)} committed fixture hashes. The local acceptance and CI
archives have separately checked SHA256 hashes for every record.

Feature discovery reports the implemented bounded subset. File/shared-memory
transport, Unicode placeholders, relative placements and Kitty animation remain
open. Physical keyboard/wheel input, live IME candidate selection, cross-monitor
DPI and long-running real-application coverage are not established by these
deterministic native fixtures. The earlier audible-bell listening confirmation
retains its original executable identity in [the bell record](font-zoom-and-bell.md).
The [unresolved historical tab crash](tab-probe-detach.md) and shutdown failures
are preserved; successful replays and the new diagnostic observer do not prove
their causes. The original full-goal scope remains active.
'''
(work/'research/kitty-feature-product.md').write_text(article,encoding='utf-8')

def edit(name,old_text,new_text):
 p=work/name;text=p.read_text(encoding='utf-8');assert text.count(old_text)==1,(name,old_text)
 p.write_text(text.replace(old_text,new_text),encoding='utf-8')

edit('README.md','下方单 EXE 在本机 GDI、OpenGL、DirectX 共通过 399 个 Kitty、缩放、静态图片和 GIF 检查，\n另通过 133 个直接读取 GDI 窗口客户区的检查。',
 '下方单 EXE 已支持功能查询，在本机 GDI、OpenGL、DirectX 共通过 927 个像素与回包阶段，\n另通过 309 个直接读取 GDI 窗口客户区的阶段；包含既有图片、缩放、GIF 和新增功能查询。')
edit('README.md','[下载 `b3e03bb` 单文件产物](https://github.com/xiongnemo/nemoterm/actions/runs/43646925393/artifacts/14135728448)',
 '[下载 `6e05bd1` 单文件产物](https://github.com/xiongnemo/nemoterm/actions/runs/43653882888/artifacts/14138801522)')
edit('README.md','单文件 CI 共 137 组检查','单文件 CI 共 140 组检查')
edit('README.md','Kitty 压缩图片子集、字号缩放与响铃。EXE 为 **4,515,328 字节**。','Kitty 压缩图片与功能查询子集、字号缩放与响铃。EXE 为 **4,515,840 字节**。')
edit('README.md','2026-12-14 22:51 UTC',datetime.datetime.fromisoformat(expiry.replace('Z','+00:00')).strftime('%Y-%m-%d %H:%M UTC'))
edit('README.md','下载的 `b3e03bb` 在本机','下载的 `6e05bd1` 在本机')
edit('README.md','GDI 私有工作集最高 **16.82 MB**，DX 最高 **24.25 MB**。',f"GDI 私有工作集最高 **{g['private_ws']/1e6:.2f} MB**，DX 最高 **{d['private_ws']/1e6:.2f} MB**。")
edit('README.md','GDI 总工作集最高 **39.49 MB**，DX 最高 **59.81 MB**；',f"GDI 总工作集最高 **{g['total_ws']/1e6:.2f} MB**，DX 最高 **{d['total_ws']/1e6:.2f} MB**；")
p=work/'README.md';p.write_text(p.read_text().replace('research/kitty-compression-product.md','research/kitty-feature-product.md'),encoding='utf-8')
p=work/'docs/PROTOCOLS.md';text=p.read_text();line=next(x for x in text.splitlines() if x.startswith('| kitty graphics：'))
replacement='| kitty graphics：`APC G control;payload ST` | 已证（有限子集） | 直接 RGB/RGBA/PNG、`o=z` 压缩、分块、图像及功能查询、放置/删除、裁剪缩放、三层叠放、滚动与主备屏生命周期已接入。已验收 `6e05bd1` 单 EXE 在实际 GDI/GL/DX 各通过 24 项图像、12 项几何、29 项压缩及 176 个功能查询阶段，独立 GDI 客户区捕获和 GDI/DX 大窗口内存负载也通过。功能查询依据上游 84 场景/176 状态，只报告实际实现的能力；文件/共享内存、Kitty 动画、相对放置及 Unicode 占位等仍未实现。见[功能查询实现](../research/kitty-feature-implementation.md)、[压缩实现](../research/kitty-compression.md)及[成品验证](../research/kitty-feature-product.md)。 |'
p.write_text(text.replace(line,replacement),encoding='utf-8')
p=work/'docs/REQUIREMENTS.md';text=p.read_text();old_header='## Current accepted artifact (2026-11-15 Sydney)'
assert text.count(old_header)==1
new_header=f'''## Current accepted artifact (2026-11-15 Sydney)

The sole local distribution file is the accepted `nemoterm.exe` from
`{identity['source_commit']}`, {identity['executable_bytes']:,} bytes, SHA256
`{digest}`. The [exact-product record](../research/kitty-feature-product.md)
links all four successful ordinary CI jobs, 140 single-image CI groups, 35 local
groups, 927 API stages, 309 presented GDI stages and ten uninjected memory runs.
The prior compression image remains backed up locally.

Actual 160x48 Sarasa two-tab Sixel/PNG/GIF/Kitty/compressed-Kitty workloads peak at
{g['private_ws']:,} private-WS bytes for GDI and {d['private_ws']:,} for DirectX,
passing the strict 20 MB / inclusive 25 MB gates. Total WS peaks are
{g['total_ws']:,} and {d['total_ws']:,}; DX still exceeds the approximate 50 MB goal.
All owned jobs drain naturally. Feature queries report the bounded implemented
subset without allocating image owners or disturbing pending uploads.

An [optional external exception observer](../research/native-exception-observer.md)
passes its four native controls on MinGW/MSVC and captures unhandled fault context
and dumps. Three hosted exact-image replays pass while it is attached. It is not
used in these product memory runs; the historical tab access violation and
shutdown/resource incidents remain unresolved. The full protocol, graphics,
physical-input, real-application and long-session scope remains open.

## Earlier compression artifact (2026-11-15 Sydney)'''
p.write_text(text.replace(old_header,new_header),encoding='utf-8')
edit('research/kitty-feature-implementation.md','The development branch now answers `a=q,e=<action>` without loading an image,\nchanging placements or advancing the cursor. The accepted `b3e03bb` single EXE\nstill predates this change and remains in `dist`; new single-image CI and local\nproduct acceptance are required before replacing it.',
 'The implementation answers `a=q,e=<action>` without loading an image, changing\nplacements or advancing the cursor. The formal `6e05bd1` single EXE now passes\nfull CI and downloaded-product local acceptance, and replaces the earlier\ncompression image in `dist`. See [the exact product record](kitty-feature-product.md).\nThe development-sidecar observations below remain a separate earlier checkpoint.')
edit('research/kitty-feature-implementation.md','in the validation manifest. Full ordinary/single-image CI is still running.',
 'in the validation manifest. Full ordinary/single-image CI now passes all four\nordinary jobs and 140 single-image groups; their raw records and subsequent\nlocal acceptance are retained in [the product checkpoint](kitty-feature-product.md).')
edit('research/kitty-feature-queries.md','now passes core/native replay; the accepted `b3e03bb` product still predates it.',
 'passes core/native replay and the accepted `6e05bd1` single-image\n[product checkpoint](kitty-feature-product.md).')
p=work/'research/kitty-compression-product.md';text=p.read_text()
p.write_text(text.replace('# Accepted compressed-image single executable','# Earlier accepted compressed-image single executable',1).replace('\n\nThe accepted local',
 '\n\nThis is a historical checkpoint, superseded by the accepted [feature-query\nproduct](kitty-feature-product.md). Its measurements and failures remain unchanged.\n\nThe then-accepted local',1),encoding='utf-8')
print(json.dumps(dict(promoted=digest,local_records=len(rows),fixture_files=len(fixture),artifact_expires=expiry)))
