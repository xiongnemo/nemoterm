import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];results=[]
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
base=root/'build/menu-before';base.mkdir(exist_ok=False)
before=root.parents[1]/'dist/nemoterm.exe'
after=None
assert hashlib.sha256(before.read_bytes()).hexdigest()=='aa11c5398c102feef624764dda1a09ba96afadc33151358166c02e1eaf998bba'
for label,exe,expected in [('before',before,1)]:
    dest=base/label
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),'tabs','--renderer','gdi',
            '--side','top','--cols','80','--rows','24'],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    assert code==expected
    assert 'Tab switch recreated the host system menu' in (dest/'tabs.log').read_text()
    print('Old artifact fails the menu-identity assertion as expected',flush=True)
