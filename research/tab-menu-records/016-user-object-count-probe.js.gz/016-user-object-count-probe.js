// Diagnostic hooks only; no return values, input state or target data are changed.
const modules = ['win32u.dll','user32.dll'];
const count = new NativeFunction(Process.getModuleByName('user32.dll').getExportByName('GetGuiResources'),'uint',['pointer','uint']);
const self = ptr(-1);
const hooks = [], failures = [];
let emitted = 0, truncated = false;
function frame(address) {
  const m = Process.findModuleByAddress(address);
  return m ? {module:m.name,rva:address.sub(m.base).toString()} : {address:address.toString()};
}
for (const name of modules) {
  const m = Process.findModuleByName(name);
  if (!m) { failures.push({module:name,error:'not loaded'});continue; }
  const exports = m.enumerateExports().filter(e => e.type === 'function' &&
    ((/^NtUser(Create|Destroy)/.test(e.name) && /(Menu|Window|Cursor|InputContext|Accelerator)/.test(e.name)) || ['CreateMenu','CreatePopupMenu','LoadMenuW','DestroyMenu','DestroyWindow','DestroyIcon'].includes(e.name)));
  for (const e of exports) {
    try {
      Interceptor.attach(e.address, {
        onEnter(args) {
          this.args0 = args[0].toString();this.tid = Process.getCurrentThreadId();
          this.started = Date.now();this.before = count(self,1);
          this.stack = Thread.backtrace(this.context, Backtracer.ACCURATE).slice(0,10).map(frame);
        },
        onLeave(result) {
          if (emitted >= 4096) {
            if (!truncated) {truncated=true;send({kind:'truncated',limit:4096});}
            return;
          }
          send({kind:'user-call',index:emitted++,name:e.name,thread:this.tid,
            started_ms:this.started,finished_ms:Date.now(),argument0:this.args0,
            result:result.toString(),before_user:this.before,after_user:count(self,1),stack:this.stack});
        }
      });
      hooks.push({name:e.name,module:m.name,rva:e.address.sub(m.base).toString()});
    } catch (error) {failures.push({name:e.name,error:String(error)});}
  }
}
send({kind:'ready',pid:Process.id,hooks,failures,bound:4096,
      caveat:'Injected trace; pre-attach objects and unhooked paths are unobserved; names alone do not identify handle ownership'});
