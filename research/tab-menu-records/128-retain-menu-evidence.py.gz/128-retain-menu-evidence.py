import gzip,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
old=root.parent/'sgr-enclosure-worktree'
files=[]
folders=[root/'build'/name for name in ['menu-before','menu-after','menu-remaining','menu-quiescence','menu-resource-trace','menu-hook-trace','menu-timer-trace','menu-evidence']]
folders += [old/'build'/name for name in ['enclosure-quiescence','user-object-trace','user-object-count-trace']]
for folder in folders:
    for p in folder.rglob('*'):
        if not p.is_file() or any(n in p.relative_to(folder).parts for n in ['dist','tests','tools','__pycache__']):continue
        if p.suffix in ['.json','.log','.png','.bmp']:files.append(p)
files += list((root/'build').glob('*menu*.py'))+list((root/'build').glob('menu-*-probe.js'))
files += [root/'build/menu-single/image.json',root/'build/menu-single/link.rsp',root/'build/menu-single/link.log',Path(__file__)]
files += [old/'build'/n for n in ['check-enclosure-quiescence.py','run-user-object-trace.py','run-user-object-count-trace.py','user-object-trace-probe.js','user-object-count-probe.js']]
files += [root/n for n in ['vendor/putty-0.85/windows/nemo_tabs_host.h','vendor/putty-0.85/windows/nemo_tabs_host.inc','tests/tabs_window_smoke.py','tests/tab_menu_checks.py']]
dest=root/'research/tab-menu-records';dest.mkdir(exist_ok=True);records=[]
for p in sorted(set(files)):
    assert p.is_file(),p
    data=p.read_bytes();archive=dest/f'{len(records):03d}-{p.name}.gz'
    if archive.exists():assert gzip.decompress(archive.read_bytes())==data,archive
    else:archive.write_bytes(gzip.compress(data,mtime=0))
    label=p.relative_to(root).as_posix() if p.is_relative_to(root) else '../sgr-enclosure-worktree/'+p.relative_to(old).as_posix()
    records.append(dict(path=label,archive=archive.relative_to(root).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
manifest=dict(base='420363b297d059f62ebf59504449ceebf2de1cab',image=json.loads((root/'build/menu-single/image.json').read_text()),
    scope='Menu reuse candidate, failed resource checks, local diagnostics and complete REA wrappers; not accepted or merged',records=records)
(root/'research/tab-menu-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
for r in records:
    data=gzip.decompress((root/r['archive']).read_bytes());assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
print('Verified',len(records),'records;',sum((root/r['archive']).stat().st_size for r in records),'compressed bytes')
