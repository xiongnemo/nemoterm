import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];base=root/'build/menu-after';base.mkdir(exist_ok=False)
exe=root/'build/menu-single/nemoterm.exe'
controller=root.parent/'rtl-worktree/build/run-owned-check.py';results=[]
cases=[('gdi-top','tabs',['--renderer','gdi','--side','top','--cols','160','--rows','48','--workload-memory']),
       ('directx-left','tabs',['--renderer','directx','--side','left','--cols','160','--rows','48','--workload-memory']),
       ('opengl-bottom','tabs',['--renderer','opengl','--side','bottom','--cols','80','--rows','24']),
       ('gdi-right','tabs',['--renderer','gdi','--side','right','--cols','80','--rows','24']),
       ('profiles','tabs_profiles',[])]
for label,test,args in cases:
    dest=base/label
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),test,*args],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    record=dict(label=label,exit_code=code)
    memory=list((dest/'research').glob('*-memory.json'))
    if memory:
        d=json.loads(memory[0].read_text());record.update(peaks=d['peaks']['frontend'],samples=d['sample_count'])
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(record,flush=True)
    if code:
        print((dest/'controller.log').read_text()[-2800:]);raise SystemExit(code)
