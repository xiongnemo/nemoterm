"""Owned-process metadata after a failed acceptance run; never acceptance."""
import ast,hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/enclosure-quiescence';base.mkdir(exist_ok=False)
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
old_script=root.parent/'dx-integration-worktree/build/check-delay-dx-catalogue.py'
helper=next(ast.literal_eval(n.value) for n in ast.parse(old_script.read_text()).body
            if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='helper' for t in n.targets))
results=[]
for label,exe in [('accepted',root.parents[1]/'dist/nemoterm.exe'),
                  ('enclosures',root/'build/enclosure-single/nemoterm.exe')]:
    dest=base/label
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    (dest/'tests/dll_window_catalogue.py').write_text(helper)
    p=dest/'tests/tabs_window_smoke.py';code=p.read_text()
    anchor="""                return dict(handles=count.value,gdi=u.GetGuiResources(handle,0),user=u.GetGuiResources(handle,1),
                            injected=injected_observer,**memory_sample(handle))"""
    replacement="""                result=dict(handles=count.value,gdi=u.GetGuiResources(handle,0),user=u.GetGuiResources(handle,1),
                            injected=injected_observer,**memory_sample(handle))
                from dll_window_catalogue import catalogue
                index=len(evidence.setdefault('resource_catalogues',[]))
                evidence['resource_catalogues'].append(dict(sample=result,
                    phase=memory_sampler.phase if memory_sampler else 'after-memory',
                    **catalogue(thread_observer.owner),
                    handles=thread_observer.owner.snapshot(str(index)),
                    threads=thread_observer.snapshot(str(index))))
                return result"""
    assert code.count(anchor)==1;code=code.replace(anchor,replacement)
    anchor="                assert sample['handles']<=baseline['handles']+6,(baseline,sample)"
    replacement="""                if (sample['handles']>baseline['handles']+6 or
                    sample['gdi']>baseline['gdi']+3 or sample['user']>baseline['user']+2):
                    history=[];evidence['post_failure_resources']=history
                    started=time.monotonic()
                    for _ in range(20):
                        time.sleep(.1)
                        history.append(dict(seconds=time.monotonic()-started,**resources()))
                assert sample['handles']<=baseline['handles']+6,(baseline,sample)"""
    assert code.count(anchor)==1;code=code.replace(anchor,replacement)
    anchor="            evidence['completed']=True"
    assert code.count(anchor)==1
    code=code.replace(anchor,"            evidence.update(diagnostic_completed=True,completed=False,memory_acceptance=False)")
    anchor="            baseline=resources();evidence['initial']=initial;evidence['two_tabs']=baseline;evidence['cycles']=[]"
    replacement="""            # Diagnostic hypothesis: settle one startup baseline, then retain
            # every original cycle assertion and all startup memory samples.
            startup=[];evidence['startup_resource_stability']=startup
            started=time.monotonic();quiet_since=started;previous=None
            while True:
                baseline=resources();now=time.monotonic()
                signature=tuple(baseline[k] for k in ('handles','gdi','user'))
                if signature!=previous:quiet_since=now;previous=signature
                startup.append(dict(seconds=now-started,quiet_seconds=now-quiet_since,**baseline))
                if now-started>=3 and now-quiet_since>=2:break
                assert now-started<10,'Startup resources did not stabilize within ten seconds'
                time.sleep(.1)
            evidence['initial']=initial;evidence['two_tabs']=baseline;evidence['cycles']=[]"""
    assert code.count(anchor)==1;code=code.replace(anchor,replacement)
    p.write_text(code)
    (dest/'diagnostic-fixture.json').write_text(json.dumps(dict(
        scope='Diagnostic startup baseline: min 3s, unchanged handle/GDI/USER tuple for 2s, max 10s; original cycle assertions and memory samples retained; metadata may change timing',
        acceptance=False,executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),
        original_fixture_sha256=hashlib.sha256((root/'tests/tabs_window_smoke.py').read_bytes()).hexdigest(),
        fixture_sha256=hashlib.sha256(p.read_bytes()).hexdigest()),indent=2)+'\n')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),'tabs',
            '--renderer','directx','--side','left','--cols','160','--rows','48','--workload-memory'],
            cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    record=dict(label=label,exit_code=code,acceptance=False)
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(record,flush=True)
    if code:print((dest/'controller.log').read_text()[-2200:],flush=True)
