import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=root.parent/'sgr-enclosure-worktree/build/enclosure-quiescence/accepted'
dest=root/'build/menu-resource-trace';dest.mkdir(exist_ok=False)
for folder in ('tests','tools'):shutil.copytree(source/folder,dest/folder)
for folder in ('dist','research','build'):(dest/folder).mkdir()
exe=root/'build/menu-single/nemoterm.exe';shutil.copy2(exe,dest/'dist')
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='18d20efbc85257fb8a04822debf2bc8a0a9a49d6a8e7c86a6871c10eb10eae6c'
p=dest/'tests/tabs_window_smoke.py';code=p.read_text()
anchor='diagnostic=injected_observer or args.etw_memory_trace'
assert code.count(anchor)==1;code=code.replace(anchor,anchor+'\ninjected_observer=True # REA attaches before the measured cycles; no memory acceptance')
anchor='            first=new_child([])'
replacement=anchor+"""
            thread_observer.owner._validate_owner()
            write_snapshot(root/'research/attach-ready.json',dict(pid=process.pid,executable=str(exe),sha256=evidence['executable_sha256']))
            wait_for(lambda:(root/'research/trace-go').exists(),timeout=90)"""
assert code.count(anchor)==1;code=code.replace(anchor,replacement)
assert code.count('for i in range(12):')==1;code=code.replace('for i in range(12):','for i in range(3):')
anchor="            evidence['checks'].append('12 create/close cycles retain one shared renderer without handle growth')"
replacement="""            evidence.update(diagnostic_completed=True,completed=False,memory_acceptance=False)
            raise SystemExit(2) # Three observed cycles; never run/claim memory acceptance."""
assert code.count(anchor)==1;code=code.replace(anchor,replacement)
anchor="""        finally:
            try:
                if census_observer:census_observer.close()"""
replacement="""        finally:
            failure=sys.exc_info()[1]
            write_snapshot(root/'research/trace-done.json',dict(pid=process.pid,error=repr(failure),active=process.poll() is None))
            wait_for(lambda:(root/'research/trace-release').exists(),timeout=40)
            if process.poll() is None:
                u.PostMessageW(host,0x10,0,0)
                process.wait(timeout=15)
            try:
                if census_observer:census_observer.close()"""
assert code.count(anchor)==1;code=code.replace(anchor,replacement);code=code.replace('result=dict(handles=count.value,','result=dict(observed_unix_ms=int(time.time()*1000),handles=count.value,');p.write_text(code)
(dest/'diagnostic-fixture.json').write_text(json.dumps(dict(acceptance=False,scope='Injected USER create/destroy trace; three bounded cycles; original resource checks; no memory acceptance',
    image_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),fixture_sha256=hashlib.sha256(p.read_bytes()).hexdigest()),indent=2)+'\n')
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
with (dest/'controller.log').open('w',encoding='utf-8') as log:
    result=subprocess.run([sys.executable,str(controller),str(dest),'tabs','--renderer','directx','--side','left','--cols','160','--rows','48','--workload-memory'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
print((dest/'controller.log').read_text()[-2200:]);raise SystemExit(result.returncode)
