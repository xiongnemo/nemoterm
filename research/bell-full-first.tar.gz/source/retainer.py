"""Retain original incomplete checkpoints; no failed image becomes accepted."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1]
work=root/'build/bell-modes-worktree'
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def bundle(name,base,source,runs,summary,sources):
    for kind,number,conclusion in runs:
        run=json.loads((base/(kind+'-run.json')).read_bytes())
        assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(number,source,'completed',conclusion)
        artifacts=json.loads((base/(kind+'-artifacts.json')).read_bytes())['artifacts']
        for receipt_path in base.glob('*-download.json'):
            receipt=json.loads(receipt_path.read_bytes())
            assert receipt['source']==source
            # A combined collector contains receipts from both workflows.
            matches=[a for a in artifacts if a['id']==receipt['artifact_id']]
            if matches:assert matches[0]['name'].endswith(source)
    entries={'source/retainer.py':Path(__file__).read_bytes()}
    for path in sources:
        entries['source/'+path]=subprocess.check_output(['git','show',source+':'+path],cwd=work)
    for p in base.rglob('*'):
        if p.is_file():entries[p.relative_to(base).as_posix()]=p.read_bytes()
    archive=work/'research'/f'{name}.tar.gz';records=[]
    with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
        for path,raw in sorted(entries.items()):
            info=tarfile.TarInfo(path);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
            records.append(dict(path=path,raw_bytes=len(raw),raw_sha256=sha(raw)))
    with tarfile.open(archive,'r|gz') as tar:
        for member,record in zip(tar,records,strict=True):
            assert member.name==record['path'] and sha(tar.extractfile(member).read())==record['raw_sha256']
    manifest=dict(source=source,runs=[dict(kind=k,run=n,conclusion=c) for k,n,c in runs],accepted=False,
        summary=summary,bundle=dict(path=archive.relative_to(work).as_posix(),bytes=archive.stat().st_size,
            sha256=sha(archive.read_bytes()),records=records))
    (work/'research'/f'{name}-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    print(name,len(records),'records',archive.stat().st_size,'bytes',flush=True)

common=['tests/native_test_utils.py','tests/fixture_io.py','tests/owned_job.py','tests/mouse_fixture.py',
    'tests/protocol_oracle_window.py','vendor/putty-0.85/windows/window.c','vendor/putty-0.85/windows/nemo_tabs_host.inc']

base=root/'build/ci-bell-complete-ea141fe';source='ea141fefc3e105aad6c1fcd49e0e0f161745ab53'
images=[]
for kind,folder,evidence in [('ordinary','unverified-mingw','core-evidence/test-results'),
                             ('single','unverified-product','single-evidence/build/single-exe-check/research')]:
    image=base/folder/'nemoterm.exe';digest=sha(image.read_bytes())
    data=json.loads((base/evidence/'bell-modes-window-observed.json').read_bytes())
    assert not data['completed'] and data['cases']=={} and data['executable_sha256']==digest
    log=(base/(kind+'-run.log')).read_text()
    assert 'assert u.SetForegroundWindow(window)' in log and 'AssertionError' in log
    udk=json.loads((base/evidence/'udk-window-observed.json').read_bytes())
    assert udk['completed'] and len(udk['cases'])==89 and sum(map(len,udk['cases'].values()))==232
    assert udk['executable_sha256']==digest
    images.append(dict(kind=kind,bytes=image.stat().st_size,sha256=digest,udk_exact_streams=232,bell_cases=0))
bundle('bell-full-first',base,source,[('ordinary',43722555463,'failure'),('single',43722558224,'failure')],
    dict(failure='Both full jobs stop before the first bell case because SetForegroundWindow refuses the fixture focus preparation.',
         images=images,scope='Earlier core, MSVC and sanitizer results remain in their original run metadata. Neither full product passes; downstream tests were not reached.'),
    common+['tests/bell_modes_window_smoke.py','tests/udk_window_smoke.py','scripts/test-single-exe.ps1','.github/workflows/ci.yml','.github/workflows/single-exe.yml'])

base=root/'build/ci-bell-native-0284fcf';source='0284fcf0855c86d528f6f6e490aea143ce3eb7c9'
b=base/'diagnostic';image=b/'build/single-exe-dist/nemoterm.exe';digest=sha(image.read_bytes())
data=json.loads((b/'research/bell-window-state-observed.json').read_bytes())
assert not data['completed'] and len(data['checks'])==19 and data['executable_sha256']==digest
assert data['checks'][-2]['name']=='inactive-host-active-tab-close' and data['checks'][-2]['focus_input_hex']=='1b5b306e'
assert data['checks'][-1]['name']=='new-active-notice-clears-on-foreground' and data['checks'][-1]['api']==[]
replay=json.loads((b/'research/bell-modes-window-observed.json').read_bytes())
assert replay['completed'] and len(replay['cases'])==112 and sum(map(len,replay['cases'].values()))==192
assert replay['executable_sha256']==digest
with tarfile.open(work/'research/bell-modes-reference.tar.gz') as tar:
    reference=json.loads(tar.extractfile('reference/bell-modes-xterm.json').read())
for name,steps in replay['cases'].items():
    for i,step in enumerate(steps):
        for key in ('sequence_hex','reply_hex','wire_with_barrier_hex'):assert step[key]==reference['cases'][name]['steps'][i][key]
bundle('bell-reactivation-first',base,source,[('bell-window',43724828019,'failure')],
    dict(failure='The GDI host preserves notice and suppresses false focus when the selected background tab closes, but actual reactivation does not acknowledge the notice.',
         image=dict(bytes=image.stat().st_size,sha256=digest),exact_bell_replies=192,
         scope='The standalone replay passes. The new state fixture stops at the nineteenth GDI check; DirectX is not reached.'),
    common+['tests/bell_modes_window_smoke.py','tests/bell_window_state_smoke.py','tests/session_fixture.py','.github/workflows/ansi-conformance.yml'])

base=root/'build/ci-udk-single-23615de';source='23615deb5130c16953cddd5a2b899c67814e8f6c'
log=(base/'single-run.log').read_text()
assert '##[error]The operation was canceled.' in log and 'Unicode workload: frame-13 after-window-resize' in log
run=json.loads((base/'single-run.json').read_bytes())
step=next(s for s in run['jobs'][0]['steps'] if s['name']=='Verify isolated executable with native protocol and pixel tests')
assert step['conclusion']=='cancelled'
image=base/'unverified-product/nemoterm.exe';digest=sha(image.read_bytes())
udk=json.loads((base/'single-evidence/build/single-exe-check/research/udk-window-observed.json').read_bytes())
assert udk['completed'] and len(udk['cases'])==89 and sum(map(len,udk['cases'].values()))==232
assert udk['executable_sha256']==digest
bundle('dec-udk-single-timeout',base,source,[('single',43721295539,'cancelled')],
    dict(failure='The 45-minute workflow deadline interrupts a progressing dense Unicode workload; no complete single-image acceptance exists.',
         image=dict(bytes=image.stat().st_size,sha256=digest),udk_exact_streams=232,
         scope='Retains the cancellation and incomplete downstream evidence. The next single-image workflow gets a 60-minute overall budget; per-fixture checks and shutdown deadlines stay unchanged.'),
    common+['tests/udk_window_smoke.py','tests/tab_workload_memory.py','scripts/test-single-exe.ps1','.github/workflows/single-exe.yml'])
