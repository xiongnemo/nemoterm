"""Retain original failed and passed ANSI replay artifacts with source identities."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

root = Path(__file__).resolve().parents[1]
work = root / 'build/ansi-conformance-worktree'
runs = [
    ('2650746dcd77ebfe247a963c6880bd1883d69d2f', 43705252556, 'failure'),
    ('7f449c0d4eb3a487f5ab2ccbb55faa478d7343c8', 43705465047, 'failure'),
    ('889c9419bf672fad05d551910e1769609f88320f', 43705674015, 'success'),
]
source_paths = [
    '.github/workflows/ansi-conformance.yml', 'scripts/generate-ansi-reference.py',
    'tests/ansi_conformance_reference.h', 'vendor/putty-0.85/test/test_ansi_terminal.c',
    'vendor/putty-0.85/terminal/terminal.c', 'vendor/putty-0.85/terminal/terminal.h',
    'vendor/putty-0.85/unix/CMakeLists.txt', 'vendor/putty-0.85/windows/CMakeLists.txt',
]
sha = lambda data: hashlib.sha256(data).hexdigest()
entries = {'controller.py': Path(__file__).read_bytes()}
summaries = []
for source, run_id, conclusion in runs:
    prefix = source[:7]
    base = root / ('build/ci-ansi-component-' + prefix)
    run = json.loads((base / 'ansi-components-run.json').read_text())
    assert (run['headSha'], run['databaseId'], run['status'], run['conclusion']) == (
        source, run_id, 'completed', conclusion)
    assert len(run['jobs']) == 3
    blobs = {name: subprocess.check_output(['git', 'show', f'{source}:{name}'], cwd=work)
             for name in source_paths}
    verified = []
    for compiler in ('gcc', 'clang', 'msvc'):
        if compiler == 'msvc':
            records = json.loads((base/compiler/'sources.json').read_text(encoding='utf-8-sig'))
            for record in records:
                path = record['Path'].replace('\\', '/')
                name = next(n for n in source_paths if path.endswith('/' + n))
                # Checkout line endings depend on the repository attributes.
                actual = record['Hash'].lower()
                encoding = 'Git LF' if actual == sha(blobs[name]) else 'CRLF'
                assert actual in (sha(blobs[name]), sha(blobs[name].replace(b'\n', b'\r\n')))
                verified.append({'compiler': compiler, 'path': name, 'encoding': encoding})
        else:
            for line in (base/compiler/'sources.sha256').read_text().splitlines():
                digest, name = line.split(maxsplit=1)
                assert digest == sha(blobs[name])
                verified.append({'compiler': compiler, 'path': name, 'encoding': 'Git LF'})
        if conclusion == 'success':
            log = (base/compiler/'test_ansi_terminal.log').read_text(encoding='utf-8-sig')
            for mode in ('whole', 'bytewise'):
                assert (f'ANSI {mode}: 243 streams, 240 exact XTerm replies, '
                        '3 explicit SUB policies, 0 failures') in log
            for suite in ('queries', 'state_control', 'keyboard', 'pointer_terminal'):
                assert 'passed' in (base/compiler/f'test_{suite}.log').read_text(encoding='utf-8-sig')
    for path in base.rglob('*'):
        if path.is_file():
            entries[prefix + '/' + path.relative_to(base).as_posix()] = path.read_bytes()
    for name, blob in blobs.items():
        entries[prefix + '/source/' + name] = blob
    summaries.append({'source': source, 'run': run_id, 'conclusion': conclusion,
                      'source_matches': verified})

registration = []
for run_id in (43705252567, 43705252529):
    raw = subprocess.check_output(['gh', 'run', 'view', str(run_id), '--json',
                                  'databaseId,headSha,status,conclusion,jobs,url'], cwd=root)
    data = json.loads(raw)
    assert data['headSha'] == runs[0][0] and data['conclusion'] == 'cancelled'
    entries[f'registration/cancelled-{run_id}.json'] = raw
    registration.append({'run': run_id, 'conclusion': 'cancelled',
                         'reason': 'Intentional cancellation of broad workflows after registering the new focused workflow.'})

archive = work / 'research/ansi-conformance-components.tar.gz'
records = []
with archive.open('xb') as out, gzip.GzipFile(filename='', fileobj=out, mode='wb', mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w|') as tar:
        for name, raw in sorted(entries.items()):
            info = tarfile.TarInfo(name); info.size = len(raw)
            tar.addfile(info, io.BytesIO(raw))
            records.append({'path': name, 'raw_bytes': len(raw), 'raw_sha256': sha(raw)})
with tarfile.open(archive, 'r|gz') as tar:
    for member, record in zip(tar, records, strict=True):
        assert member.name == record['path']
        assert sha(tar.extractfile(member).read()) == record['raw_sha256']
manifest = {
    'runs': summaries, 'registration': registration,
    'reference_observations_sha256': '098028b29c4cbfe4ea66a447e576ddd3750baa9acafe270697ab9194d4c23506',
    'cases_per_mode': 243, 'fragmentation_modes': ['whole', 'bytewise'],
    'exact_xterm_cases_per_mode': 240,
    'explicit_policy_cases': ['ansiL-cancel-sub', 'ansiM-cancel-sub', 'ansiN-cancel-sub'],
    'scope': 'Core parser replay only; not complete product, native ConPTY, local Sarasa, or memory acceptance.',
    'bundle': {'path': archive.relative_to(work).as_posix(), 'archive_bytes': archive.stat().st_size,
               'archive_sha256': sha(archive.read_bytes()), 'records': records},
}
(work/'research/ansi-conformance-component-validation.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps({'runs': len(runs), 'records': len(records), 'bytes': archive.stat().st_size,
                  'source_matches': sum(len(r['source_matches']) for r in summaries)}))
