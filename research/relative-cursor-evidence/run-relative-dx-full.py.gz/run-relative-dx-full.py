import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/ci-relative-43517911793'
dest=base/'local-workload-directx-full-followup'
assert not dest.exists(),dest
subprocess.run(['git','diff','--exit-code','f079f80ade7b5ee73469ddb350ec1acad62042eb','--','vendor','native','tests','scripts','.github','tools'],cwd=root,check=True)
exe=base/'product/nemoterm.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='0db4c0d807e810a7d34c592c0920214d667bb45f8d5576d4fda9a42b38e566e5'
for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
shutil.copytree(root/'tests',dest/'tests')
shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
shutil.copy2(exe,dest/'dist/nemoterm.exe')
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
with (dest/'controller.log').open('w',encoding='utf-8') as log:
    code=subprocess.run([sys.executable,str(controller),str(dest),'tabs','--renderer','directx','--side','left','--cols','160','--rows','48','--workload-memory'],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
print(json.dumps(dict(controller_exit_code=code,result=str(dest/'research/workload-tabs-directx-left-observed.json'))),flush=True)
raise SystemExit(code)
