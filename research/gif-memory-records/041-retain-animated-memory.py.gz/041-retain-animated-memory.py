from pathlib import Path
import gzip,hashlib,json
root=Path(__file__).resolve().parents[1]
folders=[root/'build/animated-memory-01',root/'build/animated-memory-canary']
dest=root/'research/gif-memory-records';dest.mkdir()
paths=[p for folder in folders for p in folder.rglob('*') if p.is_file() and p.suffix in ('.json','.log','.png') and not any(s in p.parts for s in ('dist','tests','tools'))]
paths += [root/'build/check-animated-memory.py',root/'build/check-animated-canary.py',Path(__file__)]
for name in ('tab_workload_memory.py','tabs_window_smoke.py','gif_fixture.py','owned_job.py','memory_limits.py'):
 paths.append(root/'tests'/name)
for folder in (folders[0]/'gdi',folders[0]/'directx',folders[1]):
 for name in ('tab_workload_memory.py','tabs_window_smoke.py'):paths.append(folder/'tests'/name)
paths += [root/'scripts/test-single-exe.ps1',root/'.github/workflows/ci.yml']
manifest=dict(executable_sha256='9300a9cd87fc9f9fc4dff39408c07221addce0febc70e0b7b7fa2f7a3fee42c0',
 scope='Local 160x48 Sarasa two-tab GIF workloads; pre-capture uninstrumented memory and post-memory animation pixels',
 results=json.loads((folders[0]/'results.json').read_text()),canary=json.loads((folders[1]/'results.json').read_text()),records=[])
for i,p in enumerate(sorted(set(paths))):
 data=p.read_bytes();archive=dest/f'{i:03d}-{p.name}.gz';archive.write_bytes(gzip.compress(data,mtime=0))
 assert gzip.decompress(archive.read_bytes())==data
 manifest['records'].append(dict(path=str(p),archive=archive.relative_to(root).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(root/'research/gif-memory-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(dict(records=len(manifest['records']),compressed_bytes=sum(p.stat().st_size for p in dest.iterdir())))
