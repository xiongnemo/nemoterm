from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];base=root/'build/animated-memory-01';base.mkdir()
exe=root/'build/staging-single-01/nemoterm.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='9300a9cd87fc9f9fc4dff39408c07221addce0febc70e0b7b7fa2f7a3fee42c0'
cases=[('gdi','top'),('directx','left')]
for renderer,side in cases:
 dest=base/renderer
 for directory in ('dist','research','build','tools'):(dest/directory).mkdir(parents=True)
 shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
 shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(exe,dest/'dist/nemoterm.exe')
results=[]
for renderer,side in cases:
 dest=base/renderer
 with (dest/'controller.log').open('w') as log:
  run=subprocess.run([sys.executable,str(root.parent/'rtl-worktree/build/run-owned-check.py'),str(dest),'tabs',
       '--renderer',renderer,'--side',side,'--cols','160','--rows','48','--workload-memory','--animated-images'],stdout=log,stderr=subprocess.STDOUT)
 record=dict(renderer=renderer,side=side,exit_code=run.returncode)
 for p in (dest/'research').glob('*-memory.json'):
  d=json.loads(p.read_text());record.update(samples=d['sample_count'],peaks=d['peaks']['frontend'],injected=d['injected'])
 for p in (dest/'research').glob('*-observed.json'):
  d=json.loads(p.read_text());record.update(completed=d.get('completed'),checks=len(d.get('checks',[])),error=d.get('error'),animation=d.get('post_memory_animation'),memory_limit_passed=d.get('memory_limit_passed'),cleanup=d.get('owned_job_cleanup'))
 results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps(record),flush=True)
 if run.returncode:print((dest/'controller.log').read_text()[-2500:],flush=True)
assert all(r['exit_code']==0 for r in results),results
