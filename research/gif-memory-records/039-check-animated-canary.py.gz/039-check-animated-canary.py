from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];dest=root/'build/animated-memory-canary'
exe=root.parent/'iterm-images-worktree/build/ci-iterm-3187ec5/product/nemoterm.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='8e52b517787fb508937611b15eb48855ab0e73521978f579d853cf48d9748585'
for directory in ('dist','research','build','tools'):(dest/directory).mkdir(parents=True)
shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(exe,dest/'dist/nemoterm.exe')
with (dest/'controller.log').open('w') as log:
 run=subprocess.run([sys.executable,str(root.parent/'rtl-worktree/build/run-owned-check.py'),str(dest),'tabs',
       '--renderer','gdi','--side','top','--cols','160','--rows','48','--workload-memory','--animated-images'],stdout=log,stderr=subprocess.STDOUT)
data=json.loads((dest/'research/animated-workload-tabs-gdi-top-observed.json').read_text())
animation=data.get('post_memory_animation',[])
record=dict(exit_code=run.returncode,executable_sha256=data['executable_sha256'],error=data.get('error'),
            animation=animation,memory_limit_passed=data.get('memory_limit_passed'),cleanup=data.get('owned_job_cleanup'))
record['expected_failure_observed']=bool(run.returncode and data.get('memory_limit_passed') and animation and not animation[0]['frames'] and data.get('error','').startswith('AssertionError'))
(dest/'results.json').write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
print((dest/'controller.log').read_text()[-1800:],flush=True)
assert record['expected_failure_observed'],record
