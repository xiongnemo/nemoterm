# Placeholder paint batching evidence

Product: 62478182996cc0957800f2d03aa009382f86d7fe
Single EXE: 4,599,808 bytes, SHA-256 294912cf11f5cc5be92148ba95435415dabe40c32ea62345d35d5625872bb89f

- negative: test-only compiler run 44040910919, excessive frontend run counts.
- first-after: production run 44041427002, lower counts and retained Windows fixture assertion failure.
- verified: corrected compiler fixtures, run 44041610368.
- memory: full 160 by 48 Sarasa GDI and DirectX receipts from run 44041617145.
- interaction: all 26 original case receipts, including the failed shell teardown.
- shell-replay: diagnostic-only fixture bd0bc403167d904297ae90b18314ec18fd0056df against the same product, run 44043921945.
- dpi: all JSON/log receipts plus two selected 200 percent screenshots; complete images remain in Actions artifact 14310386267.
- core: sanitizer, MSVC and profile receipts.
- source: exact committed production/test changes.

Files are selected to retain machine-readable results and failure evidence without copying downloaded EXEs or client databases. The ZIP manifest hashes every retained member. Prior GDI failures are preserved separately in research/full-grid-memory-evidence.zip. No downloaded program or test was executed locally.
