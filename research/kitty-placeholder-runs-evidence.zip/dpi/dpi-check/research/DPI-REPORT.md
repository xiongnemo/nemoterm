# Remote DPI evidence

Product commit: `62478182996cc0957800f2d03aa009382f86d7fe`
Fixture commit: `62478182996cc0957800f2d03aa009382f86d7fe`

## Real system scaling

| Language | Renderer | Host | Start | Test | Actual window DPI sequence | Result |
|---|---|---|---:|---|---|---|
| en | gdi | standalone | 100% | Cold start | 96 | PASS |
| en | gdi | standalone | 125% | Cold start | 120 | PASS |
| en | gdi | standalone | 150% | Cold start | 144 | PASS |
| en | gdi | standalone | 175% | Cold start | 168 | PASS |
| en | gdi | standalone | 200% | Cold start | 192 | PASS |
| en | gdi | standalone | 100% | Live transition | 96, 120, 144, 168, 192, 96 | PASS |
| en | gdi | tabs | 100% | Cold start | 96 | PASS |
| en | gdi | tabs | 125% | Cold start | 120 | PASS |
| en | gdi | tabs | 150% | Cold start | 144 | PASS |
| en | gdi | tabs | 175% | Cold start | 168 | PASS |
| en | gdi | tabs | 200% | Cold start | 192 | PASS |
| en | gdi | tabs | 100% | Live transition | 96, 120, 144, 168, 192, 96 | PASS |
| zh-CN | gdi | standalone | 100% | Cold start | 96 | PASS |
| zh-CN | gdi | standalone | 125% | Cold start | 120 | PASS |
| zh-CN | gdi | standalone | 150% | Cold start | 144 | PASS |
| zh-CN | gdi | standalone | 175% | Cold start | 168 | PASS |
| zh-CN | gdi | standalone | 200% | Cold start | 192 | PASS |
| zh-CN | gdi | standalone | 100% | Live transition | 96, 120, 144, 168, 192, 96 | PASS |
| zh-CN | gdi | tabs | 100% | Cold start | 96 | PASS |
| zh-CN | gdi | tabs | 125% | Cold start | 120 | PASS |
| zh-CN | gdi | tabs | 150% | Cold start | 144 | PASS |
| zh-CN | gdi | tabs | 175% | Cold start | 168 | PASS |
| zh-CN | gdi | tabs | 200% | Cold start | 192 | PASS |
| zh-CN | gdi | tabs | 100% | Live transition | 96, 120, 144, 168, 192, 96 | PASS |

## Synthetic message coverage

These cases inject WM_DPICHANGED; the actual Windows DPI stays at 96. They are not real display-scale acceptance.

| Host | Requested DPI | Actual Windows DPI | Result |
|---|---|---|---|
| standalone | 96, 120, 144, 168, 192, 96 | 96, 96, 96, 96, 96, 96 | PASS |
| tabs | 96, 120, 144, 168, 192, 96 | 96, 96, 96, 96, 96, 96 | PASS |

## Coverage limits

- Mixed-DPI multi-monitor moves are not exercised by this single-monitor fixture
- Unavailable: no compatible installed IME

JSON, screenshots, display capabilities and executable identity are in the `dpi-evidence` artifact.
