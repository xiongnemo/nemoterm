"""Retain complete portable Sarasa memory and native-pixel acceptance."""
from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile
from PIL import Image

root=Path(__file__).resolve().parents[1]
stage=root/'build/local-gdi-display-cache-12ee33b'
work=root/'build/gdi-dense-memory-worktree'
research=stage/'research'
source='12ee33baa970363ddde687b3e612f9154e386356'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
identity=json.loads((stage/'IDENTITY.json').read_text())
assert identity['source']==identity['fixture']==source
for record in identity['files']:
    raw=(stage/'dist'/record['name']).read_bytes()
    assert len(raw)==record['bytes'] and sha(raw)==record['sha256']
digest=next(r['sha256'] for r in identity['files'] if r['name']=='nemoterm.exe')
assert digest=='ddf4ccfdedf6d6406884d27e24d0b8be87a022f65ae01c5041700bd05fa26452'

observed=json.loads((research/'unicode-kitty-workload-tabs-gdi-top-observed.json').read_text())
memory=json.loads((research/'unicode-kitty-workload-tabs-gdi-top-memory.json').read_text())
assert observed['completed'] and observed['phase']=='complete'
assert observed['executable_sha256']==digest and observed['actual_renderer']==1
assert observed['font']=='SarasaTermSC Nerd Font Light' and observed['requested_grid']==[160,48]
assert observed['session_seconds']==1800 and len(observed['checks'])==10
assert observed['memory_limit_passed'] and observed['memory_limit_bytes']==20_000_000
assert not observed['memory_limit_inclusive'] and observed['memory_limit_required']
assert observed['peak_private_ws']==18_481_152
assert not memory['errors'] and not memory['injected'] and not observed['memory_instrumented']
assert len(memory['samples'])==memory['sample_count']==2670
for key in ('private_ws','total_ws','private_commit'):
    assert memory['peaks']['frontend'][key]==max(s['groups']['frontend'][key] for s in memory['samples'])
assert observed['process_tree_memory']['peaks']==memory['peaks']
assert observed['host_close']['exit_code']==0
cleanup=observed['owned_job_cleanup']
assert not cleanup['terminated_remaining'] and cleanup['after']['active']==0
pixels=observed['post_memory_kitty_unicode']
assert len(pixels)==4 and sum(p['cells_verified'] for p in pixels)==29072
strips=0
for pixel in pixels:
    assert pixel['matched'] and pixel['after_memory_sampling'] and not pixel['injected']
    assert pixel['grid']==[160,48] and len(pixel['rows'])==46
    assert all(row['matched'] for row in pixel['rows'])
    for row in pixel['rows']:
        if 'image' not in row:continue
        with Image.open(research/row['image']) as image:
            image=image.convert('RGB');assert image.size==(1264,1)
            assert all(image.getpixel((column*8+4,0))==(0,0,255) for column in range(158))
        strips+=1
assert strips==12

native=[]
for kind,renderers,expected in [('unicode',('gdi','opengl','directx','presented-gdi'),32),
                                ('unicode-geometry',('gdi','opengl','directx'),19)]:
    for renderer in renderers:
        report=research/f'kitty-{kind}-{renderer}-observed.json'
        data=json.loads(report.read_text());checks=data.get('checks',data.get('phases'))
        assert data['completed'] and data['executable_sha256']==digest
        assert len(checks)==expected and all(c['matched'] for c in checks)
        assert data['actual_renderer']=={'gdi':0,'presented-gdi':0,'opengl':1,'directx':2}[renderer]
        assert not data['global_input'] and not data['clipboard_access']
        if 'profile_removed' in data:assert data['profile_removed']
        if renderer=='presented-gdi':
            capture=data['presented_capture']
            assert capture['method']=='GetDC(owned HWND) + BitBlt'
            assert not capture['wm_print'] and not capture['desktop_dc']
            assert capture['closed'] and capture['topmost_restored']
        ending=data['cleanup']
        assert not ending['terminated_remaining'] and not ending['remaining_processes']
        assert ending['after']['active']==0 and ending['after']['terminated']==0
        folder=Path(data['folder']);assert folder.parent==research
        for check in checks:
            png=folder/check.get('png',check.get('image'))
            with Image.open(png) as image:image.verify()
            if check.get('bmp'):
                assert sha((folder/check['bmp']).read_bytes())==check['bmp_sha256']
        native.append(dict(kind=kind,renderer=renderer,actual_renderer=data['actual_renderer'],
                           stages=expected,report=report.relative_to(stage).as_posix(),
                           capture=data['capture'],cleanup=ending))
assert sum(n['stages'] for n in native)==185

entries={}
for folder in ('research','logs','tests','tools','dist'):
    for path in (stage/folder).rglob('*'):
        if not path.is_file() or '__pycache__' in path.parts:continue
        relative=path.relative_to(stage).as_posix()
        # The earlier clipboard failure has its own retained failure bundle.
        if 'unicode-selection-gdi' in relative:continue
        entries[relative]=path
entries['IDENTITY.json']=stage/'IDENTITY.json'
entries['retainer.py']=Path(__file__)
for name,path in entries.items():
    if name.startswith(('tests/','tools/')):
        expected=subprocess.check_output(['git','show',source+':'+name],cwd=work)
        assert path.read_bytes()==expected,name
archive=work/'research/gdi-image-cache-local.tar.gz';records=[]
with archive.open('xb') as f,gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,path in sorted(entries.items()):
        raw=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(raw)
        tar.addfile(info,io.BytesIO(raw));records.append(dict(path=name,bytes=len(raw),sha256=sha(raw)))
with tarfile.open(archive) as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path'] and sha(tar.extractfile(member).read())==record['sha256']
manifest=dict(source=source,identity=identity,completed=True,
    scope='Local portable frontend with separate pinned host; not the CI single-image product. Clipboard preflight failure is retained separately.',
    font=observed['font'],grid=[160,48],sample_count=memory['sample_count'],sampled_seconds=memory['seconds'],
    frontend_peaks=memory['peaks']['frontend'],private_limit_bytes=20_000_000,private_limit_inclusive=False,
    verified_image_cells=29072,retained_pixel_strips=strips,tab_checks=observed['checks'],
    host_close=observed['host_close'],memory_cleanup=cleanup,native=native,native_pixel_stages=185,
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes())),records=records)
(archive.parent/'gdi-image-cache-local-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ('completed','sample_count','frontend_peaks','verified_image_cells','native_pixel_stages','archive')},indent=2))
