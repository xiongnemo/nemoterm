from pathlib import Path
from collections import Counter
import hashlib,json,tarfile,zipfile
root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
original=root/'build/ci-special-key-modifiers-8655aae/msvc-failure-early'
local=root/'build/tab-select-8655aae-local-01'
hosted=root/'build/ci-tab-select-8655aae-debugger'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source='8655aae163a81c927537e18845f930d42df6cafc'
image='11d36b78d616b27407e485bf4df36f304d84f292127432b6617749d5b6b37244'
run=load(original/'run.json')
assert run['headSha']==source
assert next(j for j in run['jobs'] if j['databaseId']==132980310939)['conclusion']=='failure'
for name in ('image','evidence'):
    receipt=load(original/(name+'-receipt.json'))
    assert sha(original/(name+'.zip'))==receipt['artifact']['digest'].split(':')[1]
    with zipfile.ZipFile(original/(name+'.zip')) as bundle:
        for f in receipt['files']:
            assert hashlib.sha256(bundle.read(f['path'])).hexdigest()==f['sha256']
            assert sha(original/name/f['path'])==f['sha256']
reports=original/'evidence/research'
for i in range(1,8):
    observed=load(reports/f'tabs-close-repeat-{i}.json')
    assert observed['completed'] and len(observed['checks'])==9
failed=load(reports/'tabs-close-repeat-8.json')
assert not failed['completed'] and failed['actual_renderer']==1
assert failed['executable_sha256']==image and failed['requested_grid']==[88,35]
assert failed['phase']=='synchronized-tab-transfer' and failed['session_seconds']==300
assert failed['process_before_cleanup']['exit_code']==0xc0000005
assert not failed['session_exits'] and failed['elapsed_seconds']<30
assert [b['matches_initial_entry'] for b in failed['probe_boundaries']]==[False,False,True]
identity=load(local/'IDENTITY.json')
assert identity['source_commit']==source and identity['executable_sha256']==image
assert identity['frida']=='17.24.3'
for path,checksum in identity['fixture_hashes'].items():assert sha(local/path)==checksum,path
for path,checksum in identity['package_hashes'].items():assert sha(local/'dist'/path)==checksum,path
results=load(local/'results.json');assert len(results)==6
for result in results:
    assert result['exit_code']==0 and result['completed'] and result['checks']==9
    assert result['actual_renderer']==1
remote=load(hosted/'tabs-run.json');assert remote['databaseId']==43771071811 and remote['conclusion']=='success'
assert remote['headSha']==source
evidence=hosted/'diagnostic'
identity_remote=load(evidence/'identity.json')
assert identity_remote['source_commit']==identity_remote['fixture_commit']==source
assert identity_remote['executable_sha256']==image and identity_remote['frida_version']=='17.24.3'
for entry in identity_remote['runtime_hashes']:
    assert identity['package_hashes'][Path(entry['Path']).name]==entry['Hash'].lower()
receipt=load(hosted/'diagnostic-download.json')
assert receipt['artifact_id']==14184525913
for f in receipt['files']:assert sha(evidence/f['path'])==f['sha256'],f['path']
exceptions=Counter()
for i in range(1,13):
    observed=load(evidence/f'replay-{i}-observed.json')
    assert observed['completed'] and observed['actual_renderer']==1 and len(observed['checks'])==9
    assert observed['executable_sha256']==image and observed['requested_grid']==[88,35]
    assert observed['session_seconds']==300 and observed['font']=='Consolas'
    assert observed['owned_job_cleanup']['after']==dict(total=54,active=0,terminated=0)
    assert not observed['owned_job_cleanup']['terminated_remaining']
    assert [b['matches_initial_entry'] for b in observed['probe_boundaries']]==[False,False,True,True]
    observer=observed['exception_observer'];assert observer['exit_code']==0 and observer['dumps']==[]
    events=evidence/Path(observer['events_file']).parent.name/'events.jsonl'
    for event in map(json.loads,events.read_text().splitlines()):
        assert event['event']!='observer_error'
        if event['event']=='exception' and not event['initial_attach_break']:
            assert event['first_chance'];exceptions[hex(event['code'])]+=1
assert len(load(evidence/'exception-controls/controls/results.json'))==4
paths={}
for prefix,folder in [('original',original),('local',local),('hosted',hosted)]:
    paths.update({prefix+'/'+p.relative_to(folder).as_posix():p for p in folder.rglob('*')
                  if p.is_file() and '__pycache__' not in p.parts})
paths['original/job.log']=root/'build/ci-special-key-modifiers-8655aae/msvc-job-132980310939.log'
paths['retainer.py']=Path(__file__)
files=[]
archive=work/'research/tab-select-msvc-8655aae.tar.gz'
with archive.open('xb') as raw,tarfile.open(fileobj=raw,mode='w:gz') as bundle:
    for name,path in sorted(paths.items()):
        files.append(dict(path=name,bytes=path.stat().st_size,sha256=sha(path)))
        bundle.add(path,arcname=name,recursive=False)
with tarfile.open(archive) as bundle:
    assert len(bundle.getmembers())==len(files)
    for f in files:assert hashlib.sha256(bundle.extractfile(f['path']).read()).hexdigest()==f['sha256']
validation=dict(source_commit=source,executable_sha256=image,
    original_run=43768960240,original_job=132980310939,original_exit_code=0xc0000005,
    original_phase=failed['phase'],original_seconds=failed['elapsed_seconds'],
    local_replays=results,hosted_run=43771071811,hosted_artifact=14184525913,
    hosted_replays=12,first_chance_exceptions=dict(exceptions),second_chance_exceptions=0,
    scope='Original native access violation remains unexplained. Three ordinary and three debugger local replays plus twelve hosted debugger replays pass; no root-cause claim or acceptance. Local requests GDI to match original actual renderer; hosted retains original OpenGL request and GDI fallback.',
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),files=files)
with (work/'research/tab-select-msvc-8655aae-validation.json').open('x') as stream:
    json.dump(validation,stream,indent=2);stream.write('\n')
print(json.dumps({k:v for k,v in validation.items() if k not in ('files','local_replays')},indent=2))
