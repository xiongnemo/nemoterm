"""Keep both original component runs, including the authored-assertion failures."""
from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/bell-modes-worktree'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
entries={'controller.py':Path(__file__).read_bytes()};summaries=[]
for short,number,conclusion,folder in [('b854196',43720699776,'failure','ci-bell-components-b854196'),
                                     ('f93cb3d',43721163137,'success','ci-bell-validation-f93cb3d')]:
    source=subprocess.check_output(['git','rev-parse',short],cwd=work,text=True).strip()
    base=root/'build'/folder
    run=json.loads((base/'ansi-components-run.json').read_bytes())
    assert (run['headSha'],run['databaseId'],run['status'],run['conclusion'])==(source,number,'completed',conclusion)
    jobs=[j for j in run['jobs'] if j['conclusion']!='skipped'];assert len(jobs)==3
    artifacts=json.loads((base/'ansi-components-artifacts.json').read_bytes())['artifacts']
    matches=[];receipts=[]
    def blob(name):
        key=short+'/source/'+name
        if key not in entries:entries[key]=subprocess.check_output(['git','show',source+':'+name],cwd=work)
        return entries[key]
    for compiler in ('gcc','clang','msvc'):
        receipt=json.loads((base/(compiler+'-download.json')).read_bytes())
        artifact=next(a for a in artifacts if a['id']==receipt['artifact_id'])
        assert artifact['name']==f'ansi-conformance-{compiler}-{source}' and receipt['source']==source
        receipts.append(dict(compiler=compiler,artifact_id=artifact['id']))
        if compiler=='msvc':
            pairs=[]
            for item in json.loads((base/compiler/'sources.json').read_text(encoding='utf-8-sig')):
                name=item['Path'].replace('\\','/')
                name='vendor/'+name.split('/vendor/',1)[1] if '/vendor/' in name else 'tests/'+name.split('/tests/',1)[1]
                pairs.append((name,item['Hash'].lower()))
        else:
            pairs=[(name,digest) for digest,name in (line.split(None,1) for line in (base/compiler/'sources.sha256').read_text().splitlines())]
        for name,digest in pairs:
            content=blob(name);assert digest in (sha(content),sha(content.replace(b'\n',b'\r\n'))),name
            matches.append(dict(compiler=compiler,path=name,sha256=digest))
        log=(base/compiler/'test_bell_modes.log').read_text(encoding='utf-8-sig')
        assert 'Bell modes terminal: passed' in log and 'FAILED' not in log
        for mode in ('whole','bytewise'):
            assert f'Bell {mode}: 112 fresh cases / 192 unchanged replies and modeled window states' in log
        for test in ('queries','state_control'):
            text=(base/compiler/f'test_{test}.log').read_text(encoding='utf-8-sig')
            assert ('FAILED' in text) == (conclusion=='failure')
        for test in ('udk_terminal','locator_terminal','cancellation_terminal','ansi_terminal','keyboard',
                     'pointer_terminal','osc52','sixel_terminal','selective_erase','sgr','tcap'):
            text=(base/compiler/f'test_{test}.log').read_text(encoding='utf-8-sig')
            assert ('passed' in text or '0 failures' in text) and 'FAILED' not in text,test
        for p in (base/compiler).rglob('*'):
            if p.is_file():entries[short+'/'+p.relative_to(base).as_posix()]=p.read_bytes()
        entries[short+'/'+compiler+'-download.json']=(base/(compiler+'-download.json')).read_bytes()
    for name in ('scripts/generate-bell-reference.py','vendor/putty-0.85/test/test_queries.c',
                 'vendor/putty-0.85/test/test_state_control.c','.github/workflows/ansi-conformance.yml',
                 'vendor/putty-0.85/unix/CMakeLists.txt','vendor/putty-0.85/windows/CMakeLists.txt'):blob(name)
    for p in base.glob('ansi-components-*'):entries[short+'/'+p.name]=p.read_bytes()
    summaries.append(dict(source=source,run=number,conclusion=conclusion,artifacts=receipts,source_matches=matches))
subprocess.run(['git','diff','--exit-code','b854196','f93cb3d','--','vendor/putty-0.85/terminal',
    'vendor/putty-0.85/windows','vendor/putty-0.85/putty.h','vendor/putty-0.85/conf.h'],cwd=work,check=True)
archive=work/'research/bell-modes-components.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(entries.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path'] and sha(tar.extractfile(member).read())==record['raw_sha256']
manifest=dict(runs=summaries,cases=112,steps_per_mode=192,modes=['whole','bytewise'],
    scope='Core protocol and modeled X11 attention only. Windows focus, stacking and visible taskbar acceptance are separate. Production source is identical between the failed authored assertions and passing regression run.',
    bundle=dict(path=archive.relative_to(work).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),records=records))
(work/'research/bell-modes-components-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Retained',len(records),'records,',archive.stat().st_size,'bytes;',sum(len(x['source_matches']) for x in summaries),'source matches')
