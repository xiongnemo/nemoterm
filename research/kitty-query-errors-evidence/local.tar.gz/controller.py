from pathlib import Path
import gzip,hashlib,io,json,re,subprocess,tarfile
root=Path(__file__).resolve().parent.parent;work=root/'build/kitty-features-worktree'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
baseline=work/'build/query-errors-accepted-baseline';fixed=work/'build/query-errors-fixed-development-v2'
b=load(baseline/'research/kitty-query-errors-gdi-observed.json')
assert not b['completed'] and b['executable_sha256']=='dfae1cdea10e091d209aa56ce291b63e3ae5ada2f02035254c3c3398cda6c5ab'
assert b['checks'][-1]['name']=='unknown-text-position-0-last-chunk'
assert b['checks'][-1]['reply_hex']=='1b5b306e' and not b['cleanup']['terminated_remaining']
identity=load(fixed/'identity.json');suites=[]
for name,actual in [('gdi',0),('opengl',1),('directx',2),('presented-gdi',0)]:
 d=load(fixed/f'research/kitty-query-errors-{name}-observed.json')
 assert d['completed'] and d['actual_renderer']==actual and len(d['checks'])==216
 assert d['executable_sha256']==identity['executable_sha256'] and not d['cleanup']['terminated_remaining']
 for check in d['checks']:
  assert check['matched']
  if 'expected_reply_hex' in check:assert check['reply_hex']==check['expected_reply_hex']
  else:
   assert check['name']=='continuation-invalid-base64-interleaved'
   reply=bytes.fromhex(check['reply_hex']);prefix=bytes.fromhex(check['expected_error_prefix_hex']);suffix=bytes.fromhex(check['expected_error_suffix_hex'])
   assert reply.startswith(prefix) and reply.endswith(suffix) and b'\x1b' not in reply[len(prefix):-len(suffix)]
  assert sha((Path(d['folder'])/check['bmp']).read_bytes())==check['bmp_sha256']
 suites.append(dict(name=name,actual_renderer=actual,stages=216,capture=d['capture'],cleanup=d['cleanup']))
old_sources={}
for name in ('nemo_kitty.c','nemo_kitty.h','nemo_kitty_terminal.inc'):
 raw=(work/'build/query-errors-baseline-fixture'/name).read_bytes()
 committed=subprocess.check_output(['git','show','6e05bd1:vendor/putty-0.85/terminal/'+name],cwd=work)
 assert raw.replace(b'\r\n',b'\n')==committed
 old_sources[name]=dict(checkout_sha256=sha(raw),git_blob_sha256=sha(committed),crlf_pairs=raw.count(b'\r\n'))
text=(work/'build/query-errors-baseline.log').read_text()
failed=sorted(set(re.findall(r'feature query: ([^/]+)/',text)));assert len(failed)==35
raw={}
for label,stage in [('accepted-baseline',baseline),('fixed-development',fixed)]:
 for folder in ('research','logs'):
  for p in (stage/folder).rglob('*'):
   if p.is_file():raw[label+'/'+p.relative_to(stage).as_posix()]=p.read_bytes()
 raw[label+'/identity.json']=(stage/'identity.json').read_bytes()
for p in (work/'build/query-errors-baseline-fixture').iterdir():raw['baseline-source/'+p.name]=p.read_bytes()
for name in ('query-errors-baseline-build.log','query-errors-baseline.log','query-errors-fix-build.log','query-errors-fix-core.log','query-errors-fix-transport.log','query-errors-native-build.log','query-errors-transport-final.log'):
 raw['core/'+name]=(work/'build'/name).read_bytes()
for name in ('vendor/putty-0.85/terminal/nemo_kitty.c','vendor/putty-0.85/terminal/nemo_kitty.h','vendor/putty-0.85/terminal/nemo_kitty_terminal.inc','vendor/putty-0.85/test/test_kitty_terminal.inc','tests/test_kitty_transport.c','scripts/generate-kitty-query-error-reference.py'):
 raw['fixed-source/'+name]=(work/name).read_bytes()
raw['controller.py']=Path(__file__).read_bytes()
buf=io.BytesIO();records=[]
with tarfile.open(fileobj=buf,mode='w') as tar:
 for name,data in sorted(raw.items()):
  item=tarfile.TarInfo(name);item.size=len(data);tar.addfile(item,io.BytesIO(data))
  records.append(dict(path=name,raw_bytes=len(data),raw_sha256=sha(data)))
compressed=gzip.compress(buf.getvalue(),mtime=0)
path='research/kitty-query-errors-evidence/local.tar.gz';(work/path).write_bytes(compressed)
with tarfile.open(fileobj=io.BytesIO(compressed),mode='r:gz') as tar:
 for r in records:assert sha(tar.extractfile(r['path']).read())==r['raw_sha256']
p=work/'research/kitty-query-errors-validation.json';manifest=load(p)
manifest['local']=dict(baseline_source='6e05bd1',baseline_source_sha256=old_sources,baseline_mismatching_core_cases=failed,
 baseline_native=dict(executable_sha256=b['executable_sha256'],last_stage=b['checks'][-1],cleanup=b['cleanup']),
 identity_clarification='The baseline controller product_sources field hashes the checked-out fixed source, not the old executable. Its executable hash and the separately verified baseline-source files identify the actual 6e05bd1 product.',
 preliminary_errors='First transport rerun still expected a trailing comma to be invalid; corrected using the captured upstream result. The first development-stage copy used an incorrect build output path and did not launch a target; corrected fresh stage v2 is retained.',
 fixed_identity=identity,suites=suites,core_assertions=2115791,constant_memory_rejected_headers=1000)
manifest['bundles']=[dict(path=path,archive_bytes=len(compressed),archive_sha256=sha(compressed),records=records)]
p.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(records=len(records),archive_bytes=len(compressed),core_failed_before=35,api_stages=648,presented_stages=216)))
