"""Finite A/B/C diagnosis on the original failed MSVC image; not acceptance."""
from pathlib import Path
import hashlib, io, json, os, shutil, subprocess, sys, tarfile, time

root=Path(__file__).resolve().parents[1]
work=root/'build/tab-callback-diagnostic-worktree'
source='8655aae163a81c927537e18845f930d42df6cafc'
original=root/'build/ci-special-key-modifiers-8655aae/msvc-failure-early/image'
stage=root/('build/'+(sys.argv[1] if len(sys.argv)>1 else 'tab-probe-lifetime-8655aae-local-02'))
assert stage.resolve().parent == (root/'build').resolve()
expected='11d36b78d616b27407e485bf4df36f304d84f292127432b6617749d5b6b37244'
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(original/'nemoterm.exe')==expected
assert not stage.exists()
stage.mkdir()
archive=subprocess.check_output(['git','archive',source,'tests','tools/nemoterm_debug.py'],cwd=work)
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    for entry in tar:
        if entry.isdir():continue
        assert entry.isfile()
        target=(stage/entry.name).resolve();assert target.is_relative_to(stage)
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(tar.extractfile(entry).read())
for name in ('tabs_window_smoke.py','owned_code_boundary.py','owned_code_boundary_controls.py','native_exception_control.c'):
    shutil.copy2(work/'tests'/name,stage/'tests'/name)
shutil.copytree(original,stage/'dist')
for name in ('research','logs','controls'):(stage/name).mkdir()
shutil.copy2(__file__,stage/'controller.py')
(stage/'fixture.patch').write_bytes(subprocess.check_output(['git','diff','--','tests/tabs_window_smoke.py'],cwd=work))
identity=dict(source_commit=source,source_run=43768960240,artifact_id=14183114733,
    executable_sha256=expected,frida=__import__('frida').__version__,
    package_hashes={p.name:digest(p) for p in (stage/'dist').iterdir() if p.is_file()},
    fixture_hashes={p.relative_to(stage).as_posix():digest(p) for p in (stage/'tests').iterdir() if p.is_file()},
    scope='Same failed MSVC image, GDI/right/88x35/Consolas/300 s; six counterbalanced probe lifetimes, no external debugger or physical/global input; diagnostic only')
(stage/'IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n')
assert identity['frida']=='17.24.3'
args=['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror','-municode',
      str(stage/'tests/native_exception_control.c'),'-o',str(stage/'controls/control.exe')]
with (stage/'logs/build-control.log').open('w') as log:
    subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
with (stage/'logs/controls.log').open('w') as log:
    subprocess.run([sys.executable,str(stage/'tests/owned_code_boundary_controls.py'),
        '--control',str(stage/'controls/control.exe'),'--destination',str(stage/'controls/results')],
        stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
print('Owned code-boundary positive/negative controls passed',flush=True)
env=dict(os.environ,NEMOTERM_TEST_EXE=str(stage/'dist/nemoterm.exe'),NEMOTERM_TEST_TRACEBACK_SECONDS='60')
env.pop('NEMOTERM_REQUIRE_OPENGL',None);env.pop('NEMOTERM_REQUIRE_DIRECTX',None)
rows=[]
for index,mode in enumerate(('immediate','unload-first','after-interactions',
                            'after-interactions','unload-first','immediate'),1):
    label=f'{index}-{mode}';started=time.monotonic()
    args=[sys.executable,'tests/tabs_window_smoke.py','--renderer','gdi','--side','right',
          '--cols','88','--rows','35','--font','Consolas','--probe-detach-mode',mode]
    print('Starting',label,flush=True)
    with (stage/f'logs/{label}.log').open('w',encoding='utf-8') as log:
        run=subprocess.run(args,cwd=stage,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
    observed=stage/f'research/probe-{mode}-tabs-gdi-right-observed.json'
    retained=stage/f'logs/{label}-observed.json'
    if observed.exists():shutil.copy2(observed,retained)
    row=dict(label=label,exit_code=run.returncode,seconds=time.monotonic()-started)
    if retained.exists():
        v=json.loads(retained.read_text());row.update(completed=v.get('completed'),phase=v.get('phase'),
            actual_renderer=v.get('actual_renderer'),checks=len(v.get('checks',[])),
            observed_sha256=digest(retained),process_before_cleanup=v.get('process_before_cleanup'),
            cleanup=v.get('owned_job_cleanup'),
            code_boundaries=[{k:r.get(k) for k in ('label','changed_blocks','omitted_blocks','observation_error','exit_code')}
                             for r in v.get('code_boundaries',[])])
    rows.append(row);(stage/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if row['exit_code'] or not row.get('completed'):break
assert digest(stage/'dist/nemoterm.exe')==expected
raise SystemExit(0 if len(rows)==6 and all(row['exit_code']==0 and row.get('completed') for row in rows) else 1)
