"""Archive already downloaded records, without running any executable."""
import hashlib
import json
from pathlib import Path
import zipfile

base = Path(__file__).resolve().parent
root = base.parent.parent
records = {}
for run in (44070383769, 44070871162, 44071392571, 44072174561, 44072637041):
    folder = base / str(run)
    metadata = json.loads((folder / 'run.json').read_text())
    if metadata['status'] != 'completed':
        raise ValueError('Unfinished run: ' + str(run))
    for path in [folder/'run.json', folder/'ARTIFACTS.json', *folder.glob('*.selected.zip'),
                 *folder.glob('failure-job.log')]:
        records[str(path.relative_to(base)).replace('\\', '/')] = path.read_bytes()
records['startup-analysis.json'] = (base/'startup-analysis.json').read_bytes()
for name in ('collect-evidence.py', 'analyze-records.py', 'package-evidence.py'):
    records['analysis-tools/'+name] = (base/name).read_bytes()
manifest = dict(description='Hosted upstream terminfo export and startup keyboard observations; no product acceptance.',
                omitted='Probe executables omitted; original ZIP and omitted executable hashes retained in ARTIFACTS.json.',
                files={name:dict(bytes=len(blob), sha256=hashlib.sha256(blob).hexdigest())
                       for name,blob in sorted(records.items())})
target = root/'research/terminfo-database-evidence.zip'
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name,blob in sorted(records.items()):
        archive.writestr(name, blob)
    archive.writestr('MANIFEST.json', json.dumps(manifest, indent=2)+'\n')
print(json.dumps(dict(path=str(target), records=len(records), bytes=target.stat().st_size,
                     sha256=hashlib.sha256(target.read_bytes()).hexdigest()), indent=2))
