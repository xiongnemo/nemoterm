"""Download hosted records and summarize them without executing any artifact."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import zipfile

base = Path(__file__).resolve().parent
runs = (44070383769, 44070871162, 44071392571, 44072174561, 44072637041)


def gh(*arguments):
    return subprocess.check_output(['gh', *map(str, arguments)])


for run in runs:
    folder = base / str(run)
    folder.mkdir(exist_ok=True)
    meta = json.loads(gh('run', 'view', run, '--json',
                        'status,conclusion,jobs,headSha,url,createdAt,updatedAt'))
    (folder / 'run.json').write_text(json.dumps(meta, indent=2) + '\n')
    if meta['status'] != 'completed':
        print(run, meta['status'], flush=True)
        continue
    log = folder / 'failure-job.log'
    if meta['conclusion'] != 'success' and not log.exists():
        log.write_bytes(gh('run', 'view', run, '--log'))
    artifacts = json.loads(gh('api', f'repos/xiongnemo/nemoterm/actions/runs/{run}/artifacts'))['artifacts']
    receipts = []
    for artifact in artifacts:
        target = folder / (str(artifact['id']) + '.selected.zip')
        receipt_path = folder / (str(artifact['id']) + '.receipt.json')
        if receipt_path.exists():
            receipts.append(json.loads(receipt_path.read_text()))
            continue
        blob = gh('api', f"repos/xiongnemo/nemoterm/actions/artifacts/{artifact['id']}/zip")
        archive = zipfile.ZipFile(io.BytesIO(blob))
        receipt = dict(artifact=artifact, original_zip_bytes=len(blob),
                       original_zip_sha256=hashlib.sha256(blob).hexdigest(), omitted_binaries=[])
        with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as out:
            for name in archive.namelist():
                data = archive.read(name)
                if Path(name).name in ('size-probe', 'database-probe'):
                    receipt['omitted_binaries'].append(dict(name=name, size=len(data),
                        sha256=hashlib.sha256(data).hexdigest()))
                else:
                    out.writestr(name, data)
                if name.endswith('/startup-keys.json'):
                    captured = json.loads(data)
                    cases = captured['cases']
                    receipt['startup'] = dict(completed=captured['completed'], cases=len(cases),
                        steps=sum(len(c['steps']) for c in cases.values()),
                        unsuccessful=[n for n, c in cases.items() if not c['completed'] or c['exit_code'] != 0],
                        unavailable=captured['unavailable'],
                        executable_sha256=captured['executable_sha256'])
                if name.endswith('/verification.json'):
                    receipt['verification'] = json.loads(data)
        receipt.update(retained_file=target.name, retained_sha256=hashlib.sha256(target.read_bytes()).hexdigest())
        receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
        receipts.append(receipt)
    (folder / 'ARTIFACTS.json').write_text(json.dumps(receipts, indent=2) + '\n')
    print(run, meta['conclusion'], [(r.get('startup'), r.get('verification')) for r in receipts], flush=True)
