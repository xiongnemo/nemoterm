"""Read downloaded records only; do not execute tests or product binaries."""
import gzip
import hashlib
import json
from pathlib import Path
import zipfile

base = Path(__file__).resolve().parent
capture_dir = base / '44072174561'
receipt = json.loads((capture_dir / 'ARTIFACTS.json').read_text())[0]
with zipfile.ZipFile(capture_dir / receipt['retained_file']) as source:
    observed = json.loads(source.read('terminfo-export/startup-keys.json'))
    raw = json.loads(gzip.decompress(source.read('terminfo-export/libtinfo-key-observations.json.gz')))
    manifest = json.loads(source.read('terminfo-export/manifest.json'))
    libraries = source.read('terminfo-source/xterm-libraries.txt').decode()

mapping = dict(F1='kf1', F5='kf5', F12='kf12', F20='kf20', F35='kf35',
               Up='kcuu1', Down='kcud1', Left='kcub1', Right='kcuf1',
               Home='khome', End='kend', Insert='kich1', Delete='kdch1',
               Prior='kpp', Next='knp', KP_Enter='kent', BackSpace='kbs')
required = ('xterm-256color', 'linux', 'vt100', 'screen', 'tmux')
comparisons, states, resources = [], {}, {}
for term in required:
    for key, cap in mapping.items():
        step = observed['cases'][term+'-key-'+key]['steps'][0]
        comparisons.append(dict(terminal=term, key=key, capability=cap,
            library_hex=raw['terminals'][term].get(cap), wire_hex=step['reply_hex'],
            input_observations=step['actions_observed'],
            equal=raw['terminals'][term].get(cap) == step['reply_hex']))
    states[term] = {state: [step['reply_hex'] for step in observed['cases'][term+'-'+state]['steps']]
        for state in ('cursor-normal', 'cursor-application', 'keypad-normal', 'keypad-application',
                      'soft-reset', 'hard-reset', 'alternate')}
    resources[term] = {str(resource): [step['reply_hex']
        for step in observed['cases'][term+'-resource-'+str(resource)]['steps']]
        for resource in (1, 2, 3)}
checks = []
for folder in sorted(base.iterdir()):
    if not folder.is_dir() or not (folder/'ARTIFACTS.json').exists():
        continue
    for record in json.loads((folder/'ARTIFACTS.json').read_text()):
        with zipfile.ZipFile(folder/record['retained_file']) as source:
            name = 'terminfo-export/nemo_tcap_database.inc'
            if name in source.namelist():
                checks.append(dict(run=folder.name, header_sha256=hashlib.sha256(source.read(name)).hexdigest()))
result = dict(capture_run=44072174561, capture=receipt['startup'], manifest=manifest,
    same_generated_header=checks,
    library_present_comparisons=sum(c['library_hex'] is not None for c in comparisons),
    library_present_differences=[c for c in comparisons if c['library_hex'] is not None and not c['equal']],
    library_absent_fallbacks=[c for c in comparisons if c['library_hex'] is None],
    key_comparisons=comparisons, state_observations=states, resource_observations=resources,
    reference_libraries=libraries)
(base/'startup-analysis.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('capture', 'same_generated_header',
    'library_present_comparisons', 'library_present_differences')}, indent=2))
print('State key output:', json.dumps({t:{k:v[1:] for k,v in values.items()} for t,values in states.items()},indent=2))
