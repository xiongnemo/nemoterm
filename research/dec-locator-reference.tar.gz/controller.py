"""Retain original DEC Locator captures, including the two harness failures."""
from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile

root=Path(__file__).resolve().parents[1]
work=root/'build/locator-worktree'
runs=[
    ('252d5551449b722badaa100be850fd237e99922c',43711225937,14160448265,'failure'),
    ('91deae30fa21dff367b87cf2953bfe846120e887',43711482990,14160274518,'failure'),
    ('435d4283bf92dcf5a01677e76c9e336fcdb2ec6a',43711890883,14161330528,'success'),
]
entries={'controller.py':Path(__file__)};summaries=[]
sha=lambda data:hashlib.sha256(data).hexdigest()
for source,run_id,artifact_id,conclusion in runs:
    prefix=source[:7];base=root/('build/ci-locator-reference-'+prefix)
    run=json.loads((base/'locator-run.json').read_text(encoding='utf-8'))
    assert (run['headSha'],run['databaseId'],run['status'],run['conclusion'])==(source,run_id,'completed',conclusion)
    assert json.loads((base/'reference-download.json').read_text(encoding='utf-8'))['artifact_id']==artifact_id
    ref=base/'reference'
    assert (ref/'upstream-commit.txt').read_text(encoding='utf-8').strip()=='5c75ead9a75d4b2e666ca06fa94503b5766ed93f'
    assert '#define OPT_DEC_LOCATOR 1' in (ref/'xtermcfg.h').read_text(encoding='utf-8')
    data=json.loads((ref/'dec-locator-xterm.json').read_text(encoding='utf-8'))
    fixture=subprocess.check_output(['git','show',f'{source}:tests/xterm_locator_oracle.py'],cwd=work)
    assert sha(fixture)==data['fixture_sha256']
    assert data['executable_sha256']==(ref/'executable-sha256.txt').read_text(encoding='utf-8').split()[0]
    upstream={}
    for path in (ref/'locator-source').iterdir():
        local=root/'build/locator-reference-source'/path.name
        assert sha(path.read_bytes())==sha(local.read_bytes())
        upstream[path.name]=sha(path.read_bytes())
    assert len(upstream)==6
    if conclusion=='success':
        assert data['completed'] and len(data['cases'])==100
        assert sum(len(case['steps']) for case in data['cases'].values())==421
        assert len(data['literal_controls'])==3
        for case in data['cases'].values():
            assert case['completed'] and case['exit_code']==0
            assert case['cell_pixels']==[6,13]
            for step in case['steps']:
                assert bytes.fromhex(step['wire_with_barriers_hex']).count(b'\x1b[0n')==2
    summaries.append(dict(source=source,run=run_id,artifact_id=artifact_id,conclusion=conclusion,
        completed_cases=len(data['cases']),capture_completed=data['completed'],
        observations_sha256=sha((ref/'dec-locator-xterm.json').read_bytes()),
        executable_sha256=data['executable_sha256'],upstream_source_sha256=upstream))
    for path in base.rglob('*'):
        if path.is_file():entries[prefix+'/'+path.relative_to(base).as_posix()]=path
    entries[prefix+'/source/tests/xterm_locator_oracle.py']=fixture
    entries[prefix+'/source/.github/workflows/protocol-reference.yml']=subprocess.check_output(
        ['git','show',f'{source}:.github/workflows/protocol-reference.yml'],cwd=work)

def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
archive=work/'research/dec-locator-reference.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,value in sorted(entries.items()):
        info=tarfile.TarInfo(name)
        if isinstance(value,bytes):
            info.size=len(value);checksum=sha(value);tar.addfile(info,io.BytesIO(value))
        else:
            info.size=value.stat().st_size;checksum=digest(value)
            with value.open('rb') as f:tar.addfile(info,f)
        records.append(dict(path=name,raw_bytes=info.size,raw_sha256=checksum))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path']
        assert hashlib.file_digest(tar.extractfile(member),'sha256').hexdigest()==record['raw_sha256']
manifest=dict(runs=summaries,current_source=runs[-1][0],cases=100,steps=421,literal_controls=3,
    configuration='Pinned XTerm(412), --enable-dec-locator, -ti vt525, fixed 6x13 font, 80x24 grid, private Xvfb and real XTest events.',
    scope='Independent upstream reference only; Nemoterm DEC Locator implementation and native Windows integration remain missing. Default XTerm button bindings affect Ctrl and wheel-button event delivery.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
                archive_sha256=digest(archive),records=records))
(work/'research/dec-locator-reference-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,runs=len(runs),cases=100,steps=421)))
