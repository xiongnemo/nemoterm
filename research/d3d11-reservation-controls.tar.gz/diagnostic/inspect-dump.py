"""Read exact exception context and raw stack words, without claiming an unwind."""
from pathlib import Path
import hashlib,json,struct
root=Path(__file__).resolve().parents[1]
base=root/'build/ci-caption-exceptions-8665092/diagnostic/build/bell-caption-exceptions/2-0'
paths=list(base.glob('crash-*.dmp'));assert len(paths)==1
path=paths[0];raw=path.read_bytes();assert raw[:4]==b'MDMP'
count,offset=struct.unpack_from('<II',raw,8)
streams={t:(size,rva) for t,size,rva in (struct.unpack_from('<III',raw,offset+12*i) for i in range(count))}
for size,rva in streams.values():assert rva+size<=len(raw)
_,rva=streams[4];modules=[]
for i in range(struct.unpack_from('<I',raw,rva)[0]):
    at=rva+4+108*i
    address,length,checksum,timestamp,name_at=struct.unpack_from('<QIIII',raw,at)
    name_bytes=struct.unpack_from('<I',raw,name_at)[0]
    name=raw[name_at+4:name_at+4+name_bytes].decode('utf-16le').split('\\')[-1]
    modules.append(dict(name=name,base=address,bytes=length,timestamp=timestamp,checksum=checksum))
def resolve(address):
    for m in modules:
        if m['base']<=address<m['base']+m['bytes']:return m['name']+'+'+hex(address-m['base'])
    return None
_,rva=streams[6]
tid=struct.unpack_from('<I',raw,rva)[0];code,flags=struct.unpack_from('<II',raw,rva+8)
address=struct.unpack_from('<Q',raw,rva+24)[0]
context_size,context_at=struct.unpack_from('<II',raw,rva+160)
assert context_size>=256 and context_at+context_size<=len(raw)
names=['rax','rcx','rdx','rbx','rsp','rbp','rsi','rdi','r8','r9','r10','r11','r12','r13','r14','r15','rip']
registers={name:struct.unpack_from('<Q',raw,context_at+120+8*i)[0] for i,name in enumerate(names)}
_,rva=streams[3];words=[];candidates=[]
for i in range(struct.unpack_from('<I',raw,rva)[0]):
    at=rva+4+48*i
    if struct.unpack_from('<I',raw,at)[0]!=tid:continue
    stack,size,stack_at=struct.unpack_from('<QII',raw,at+24)
    assert stack_at+size<=len(raw)
    for delta in range(max(0,registers['rsp']-stack),size-7,8):
        value=struct.unpack_from('<Q',raw,stack_at+delta)[0]
        word=dict(stack=hex(stack+delta),value=hex(value),module=resolve(value))
        if len(words)<32:words.append(word)
        if word['module'] and len(candidates)<60:candidates.append(word)
result=dict(path=str(path),sha256=hashlib.sha256(raw).hexdigest(),tid=tid,code=hex(code),
    instruction=resolve(address),registers={k:hex(v) for k,v in registers.items()},
    modules=modules,raw_stack_words=words,raw_stack_pointer_candidates=candidates,
    scope='Exact exception register context and raw stack candidates only; no stack unwind or source-symbol attribution.')
(base/'dump-structure.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result[k] for k in ('tid','code','instruction','registers','raw_stack_words')},indent=2))
