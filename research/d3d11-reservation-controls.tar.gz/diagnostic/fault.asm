
C:\Users\nemo\Documents\Projects\nemoterm\build\ci-legacy-modifiers-029bfac\unverified-product\nemoterm.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
14013df42: c4 e3 7d 18 c0 01           	vinsertf128	$0x1, %xmm0, %ymm0, %ymm0
14013df48: 4c 8b c9                    	movq	%rcx, %r9
14013df4b: 49 83 e1 1f                 	andq	$0x1f, %r9
14013df4f: 49 83 e9 20                 	subq	$0x20, %r9
14013df53: 49 2b c9                    	subq	%r9, %rcx
14013df56: 49 2b d1                    	subq	%r9, %rdx
14013df59: 4d 03 c1                    	addq	%r9, %r8
14013df5c: 49 81 f8 00 01 00 00        	cmpq	$0x100, %r8             # imm = 0x100
14013df63: 76 65                       	jbe	0x14013dfca <.text+0x13cfca>
14013df65: 4c 3b 05 74 b1 06 00        	cmpq	0x6b174(%rip), %r8      # 0x1401a90e0
14013df6c: 0f 87 ce 00 00 00           	ja	0x14013e040 <.text+0x13d040>
14013df72: 66 66 66 66 66 66 0f 1f 84 00 00 00 00 00   	nopw	(%rax,%rax)
14013df80: c5 fd 7f 01                 	vmovdqa	%ymm0, (%rcx)
14013df84: c5 fd 7f 41 20              	vmovdqa	%ymm0, 0x20(%rcx)
14013df89: c5 fd 7f 41 40              	vmovdqa	%ymm0, 0x40(%rcx)
14013df8e: c5 fd 7f 41 60              	vmovdqa	%ymm0, 0x60(%rcx)
14013df93: c5 fd 7f 81 80 00 00 00     	vmovdqa	%ymm0, 0x80(%rcx)
14013df9b: c5 fd 7f 81 a0 00 00 00     	vmovdqa	%ymm0, 0xa0(%rcx)
14013dfa3: c5 fd 7f 81 c0 00 00 00     	vmovdqa	%ymm0, 0xc0(%rcx)
14013dfab: c5 fd 7f 81 e0 00 00 00     	vmovdqa	%ymm0, 0xe0(%rcx)
14013dfb3: 48 81 c1 00 01 00 00        	addq	$0x100, %rcx            # imm = 0x100
14013dfba: 49 81 e8 00 01 00 00        	subq	$0x100, %r8             # imm = 0x100
