
C:\Users\nemo\Documents\Projects\nemoterm\build\ci-legacy-modifiers-029bfac\unverified-product\nemoterm.exe:	file format coff-x86-64

Disassembly of section .text:

0000000140001000 <.text>:
140123730: 55                          	pushq	%rbp
140123731: 41 56                       	pushq	%r14
140123733: 41 57                       	pushq	%r15
140123735: 48 83 ec 40                 	subq	$0x40, %rsp
140123739: 45 8a f0                    	movb	%r8b, %r14b
14012373c: 48 8b da                    	movq	%rdx, %rbx
14012373f: 48 8b e9                    	movq	%rcx, %rbp
140123742: 45 84 c0                    	testb	%r8b, %r8b
140123745: 74 09                       	je	0x140123750 <.text+0x122750>
140123747: e8 54 fd ff ff              	callq	0x1401234a0 <.text+0x1224a0>
14012374c: 84 c0                       	testb	%al, %al
14012374e: 74 3d                       	je	0x14012378d <.text+0x12278d>
140123750: 4c 63 23                    	movslq	(%rbx), %r12
140123753: 48 8d 85 9c 00 00 00        	leaq	0x9c(%rbp), %rax
14012375a: 8b 73 08                    	movl	0x8(%rbx), %esi
14012375d: 4c 8d 8d 98 00 00 00        	leaq	0x98(%rbp), %r9
140123764: 44 8b 7b 04                 	movl	0x4(%rbx), %r15d
140123768: 8b fe                       	movl	%esi, %edi
14012376a: 44 8b 6b 0c                 	movl	0xc(%rbx), %r13d
14012376e: 41 2b fc                    	subl	%r12d, %edi
140123771: 41 8b dd                    	movl	%r13d, %ebx
140123774: 48 89 44 24 20              	movq	%rax, 0x20(%rsp)
140123779: 41 2b df                    	subl	%r15d, %ebx
14012377c: 8b d7                       	movl	%edi, %edx
14012377e: 44 8b c3                    	movl	%ebx, %r8d
140123781: 48 8b cd                    	movq	%rbp, %rcx
140123784: e8 67 10 00 00              	callq	0x1401247f0 <.text+0x1237f0>
140123789: 84 c0                       	testb	%al, %al
14012378b: 75 07                       	jne	0x140123794 <.text+0x122794>
14012378d: 32 c0                       	xorb	%al, %al
14012378f: e9 4b 01 00 00              	jmp	0x1401238df <.text+0x1228df>
140123794: ff 15 b6 19 02 00           	callq	*0x219b6(%rip)          # 0x140145150
14012379a: c7 84 24 88 00 00 00 00 00 00 00    	movl	$0x0, 0x88(%rsp)
1401237a5: 85 db                       	testl	%ebx, %ebx
1401237a7: 7e 52                       	jle	0x1401237fb <.text+0x1227fb>
1401237a9: 44 8b b4 24 88 00 00 00     	movl	0x88(%rsp), %r14d
1401237b1: 8d 04 bd 00 00 00 00        	leal	(,%rdi,4), %eax
1401237b8: 48 63 f8                    	movslq	%eax, %rdi
1401237bb: 8b 85 9c 00 00 00           	movl	0x9c(%rbp), %eax
1401237c1: 4c 8b c7                    	movq	%rdi, %r8
1401237c4: 41 03 c6                    	addl	%r14d, %eax
1401237c7: 33 d2                       	xorl	%edx, %edx
1401237c9: 48 63 c8                    	movslq	%eax, %rcx
1401237cc: 48 63 45 78                 	movslq	0x78(%rbp), %rax
1401237d0: 48 0f af c8                 	imulq	%rax, %rcx
1401237d4: 48 63 85 98 00 00 00        	movslq	0x98(%rbp), %rax
1401237db: 48 03 c8                    	addq	%rax, %rcx
1401237de: 48 8b 45 68                 	movq	0x68(%rbp), %rax
1401237e2: 48 8d 0c 88                 	leaq	(%rax,%rcx,4), %rcx
1401237e6: e8 65 a6 01 00              	callq	0x14013de50 <.text+0x13ce50>
1401237eb: 41 ff c6                    	incl	%r14d
1401237ee: 44 3b f3                    	cmpl	%ebx, %r14d
1401237f1: 7c c8                       	jl	0x1401237bb <.text+0x1227bb>
1401237f3: 44 8a b4 24 90 00 00 00     	movb	0x90(%rsp), %r14b
1401237fb: 48 8b 4d 50                 	movq	0x50(%rbp), %rcx
1401237ff: 33 d2                       	xorl	%edx, %edx
140123801: ff 15 b9 18 02 00           	callq	*0x218b9(%rip)          # 0x1401450c0
140123807: 44 8b 85 9c 00 00 00        	movl	0x9c(%rbp), %r8d
14012380e: 45 33 c9                    	xorl	%r9d, %r9d
140123811: 8b 95 98 00 00 00           	movl	0x98(%rbp), %edx
140123817: 45 2b c7                    	subl	%r15d, %r8d
14012381a: 48 8b 4d 50                 	movq	0x50(%rbp), %rcx
14012381e: 41 2b d4                    	subl	%r12d, %edx
140123821: ff 15 41 19 02 00           	callq	*0x21941(%rip)          # 0x140145168
140123827: 48 8b 4d 50                 	movq	0x50(%rbp), %rcx
14012382b: 44 8b ce                    	movl	%esi, %r9d
14012382e: 45 8b c7                    	movl	%r15d, %r8d
