"""Retain actual activation-message order on the identified failed native image."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/bell-modes-worktree'
base=root/'build/ci-bell-state-9dd2d92';source='9dd2d926187d01bd2172c74893b46ca38c9bd4ab'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'bell-state-run.json').read_bytes())
assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(43726461817,source,'completed','failure')
artifacts=json.loads((base/'bell-state-artifacts.json').read_bytes())['artifacts']
receipt=json.loads((base/'diagnostic-download.json').read_bytes())
artifact=next(a for a in artifacts if a['id']==receipt['artifact_id'])
assert artifact['name']=='bell-window-state-'+source and receipt['source']==source
b=base/'diagnostic';provenance=json.loads((b/'bell-state-provenance.json').read_text(encoding='utf-8-sig'))
assert provenance['fixture_source']==source and provenance['diagnostic_failed_baseline']
assert provenance['image_source']=='5a1bcdbf4636b6062a08af77d9791a9ebdbb1221'
assert provenance['image_run']==43725655349 and provenance['image_conclusion']=='failure'
assert provenance['artifact_id']==14166267953
image_manifest=json.loads((work/'research/bell-activation-native-validation.json').read_bytes())
assert provenance['image_sha256'].lower()==image_manifest['image']['sha256']
data=json.loads((b/'research/bell-window-state-observed.json').read_bytes())
assert not data['completed'] and len(data['checks'])==19 and data['executable_sha256']==provenance['image_sha256'].lower()
last=data['checks'][-1];before=data['checks'][-2]['after']
assert last['name']=='new-active-notice-clears-on-foreground' and last['api']==[]
assert last['after']['foreground']!=before['foreground'] and last['after']['active']==before['active']
trace=data['window_events'][-1];host,other=hex(trace['host']),hex(trace['other'])
assert trace['events'][-1]['message']==134 and trace['events'][-1]['wparam']=='0x1'
assert trace['events'][-1]['before_foreground']==host
activation=max(i for i,e in enumerate(trace['events']) if e['hwnd']==host and e['message']==6 and e['wparam']=='0x1')
assert trace['events'][activation]['before_foreground']==other
assert not any(e['message'] in (6,7) and e['before_foreground']==host for e in trace['events'][activation+1:])
entries={'source/retainer.py':Path(__file__).read_bytes()}
for name in ('tests/bell_window_state_smoke.py','tests/owned_window_focus.py','tests/session_fixture.py',
             'tests/native_test_utils.py','tests/fixture_io.py','tests/mouse_fixture.py','tests/owned_job.py',
             'tests/protocol_oracle_window.py','tools/nemoterm_debug.py','.github/workflows/ansi-conformance.yml'):
    entries['source/'+name]=subprocess.check_output(['git','show',source+':'+name],cwd=work)
for name in ('vendor/putty-0.85/windows/window.c','vendor/putty-0.85/windows/nemo_tabs_host.inc'):
    entries['image-source/'+name]=subprocess.check_output(['git','show',provenance['image_source']+':'+name],cwd=work)
for p in base.rglob('*'):
    if p.is_file():entries[p.relative_to(base).as_posix()]=p.read_bytes()
archive=work/'research/bell-activation-trace.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(entries.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path'] and sha(tar.extractfile(member).read())==record['raw_sha256']
manifest=dict(fixture_source=source,run=43726461817,conclusion='failure',artifact_id=artifact['id'],image_provenance=provenance,
    finding='WM_ACTIVATE and WM_SETFOCUS occur while the other process is foreground after active-tab close. Real foreground restoration subsequently emits WM_NCACTIVATE only; the notification remains uncleared.',
    scope='Actual unmodified window procedures and foreground/focus observations on a diagnostic-only failed image. DirectX is not reached; the original failed assertion is retained.',
    image_retained_in='research/bell-activation-native.tar.gz',
    bundle=dict(path=archive.relative_to(work).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),records=records))
(work/'research/bell-activation-trace-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Retained',len(records),'records,',archive.stat().st_size,'bytes')
