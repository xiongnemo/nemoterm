"""After the existing memory controller finishes, compare old and fixed owned windows."""
from pathlib import Path
import hashlib,io,json,os,shutil,subprocess,sys,tarfile,time

root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
destination=root/'build/osc-colour-sequence-native-02'
destination.mkdir(exist_ok=False)
source='31747b9aba2199ddf896f06f87a05c829a223d69'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
fixtures=subprocess.check_output(['git','archive',source,'tests','tools/nemoterm_debug.py'],cwd=work)
images={
    'negative':root/'build/ci-answerback-nul-253855b/product/nemoterm.exe',
    'fixed':root/'build/gdi-dense-memory-build/nemoterm.exe',
}
assert digest(images['negative'])=='f086fde1d97b33d231281a939dcf855150b2270726e672d99b68fca631e32107'
assert not subprocess.check_output(['git','diff',source,'--','vendor','native'],cwd=work)
identity=dict(fixture_source=source,physical_input=False,clipboard_access=False,variants={})
for variant,image in images.items():
    stage=destination/variant
    for folder in ('dist','research','build','logs'):(stage/folder).mkdir(parents=True,exist_ok=False)
    with tarfile.open(fileobj=io.BytesIO(fixtures)) as archive:
        for entry in archive:
            if entry.isdir():continue
            assert entry.isfile()
            path=(stage/entry.name).resolve();assert path.is_relative_to(stage)
            path.parent.mkdir(parents=True,exist_ok=True)
            path.write_bytes(archive.extractfile(entry).read())
    shutil.copy2(image,stage/'dist/nemoterm.exe')
    record=dict(frontend_sha256=digest(image),single_executable=variant=='negative',sidecars={})
    if variant=='fixed':
        for name,checksum in [('OpenConsole.exe','e3f4f7ef4a8c8105bdf8dea84bb4d135d7e0e9cfc477c2c0ca11d2489b39ed68'),
                              ('conpty.dll','feeef341d891643c62d30b6b07800bc70f0bc148f44cb8c3bee84aa557ae805a')]:
            path=root/'build/ci-host-restore-d914972/unverified-mingw'/name
            assert digest(path)==checksum
            shutil.copy2(path,stage/'dist'/name);record['sidecars'][name]=checksum
    identity['variants'][variant]=record
(destination/'IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n')
shutil.copy2(__file__,destination/'controller.py')

print('Prepared exact old/fixed native comparison; waiting for the existing memory controller.',flush=True)
existing=root/'build/local-answerback-product-253855b-01'
deadline=time.monotonic()+3600
while time.monotonic()<deadline:
    results=json.loads((existing/'logs/results.json').read_text())
    if results[-1]['name']=='unicode-kitty-memory-directx':
        assert results[-1].get('exit_code') in (0,1) and not results[-1].get('controller_timeout')
        reports=list((existing/'case-evidence/unicode-kitty-memory-directx/research').glob('*-observed.json'))
        assert len(reports)==1
        report=json.loads(reports[0].read_text())
        assert report['renderer']=='directx' and report['actual_renderer']==3
        assert report['owned_job_cleanup']['after']['active']==0 and not report['owned_job_cleanup']['terminated_remaining']
        break
    time.sleep(10)
else:raise TimeoutError('Prior workload is still running; comparison did not launch')

results=[]
for variant in images:
    stage=destination/variant
    with (stage/'logs/native.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,'tests/osc_colour_sequence_window_smoke.py'],cwd=stage,
            env=dict(os.environ,NEMOTERM_TEST_EXE=str(stage/'dist/nemoterm.exe')),stdout=log,stderr=subprocess.STDOUT,timeout=180).returncode
    report=json.loads((stage/'research/osc-colour-sequence-observed.json').read_text())
    assert report['executable_sha256']==identity['variants'][variant]['frontend_sha256']
    assert report['cleanup']['after']['active']==0
    if variant=='negative':
        assert code==1 and not report['completed'] and len(report['cases'])==1
        reference=json.loads((stage/'tests/osc_colour_sequence_reference.json').read_text())['cases'][0]
        assert report['cases'][reference['name']]!=reference['reply_hex']+'1b5b306e'
    else:
        assert code==0 and report['completed'] and len(report['cases'])==64
        assert not report['cleanup']['terminated_remaining']
    results.append(dict(variant=variant,exit_code=code,completed=report['completed'],streams=len(report['cases']),cleanup=report['cleanup']))
    (destination/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results[-1]),flush=True)
print('Old image reproduces the colour mismatch; fixed portable image passes all 64 streams.',flush=True)
