import gzip,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
ci=root/'build/ci-ideogram-8ff214f'
exe=ci/'product/nemoterm.exe'
sha=hashlib.sha256(exe.read_bytes()).hexdigest()
validation=ci/'single-evidence/build/single-exe-check/research/single-exe-validation.json'
v=json.loads(validation.read_text());assert sha==v['executable_sha256'] and len(v['passed_checks'])==108
files=[ci/n for n in ['core-run.json','core-artifacts.json','single-run.json','single-artifacts.json']]
files += [validation,validation.with_name('single-exe-observed.json')]
local=root/'build/ci-ideogram-local'
for p in local.rglob('*'):
    if not p.is_file() or any(n in p.relative_to(local).parts for n in ['dist','tests','tools','__pycache__']):continue
    if p.suffix in ['.json','.log','.bmp','.png']:files.append(p)
files += [root/'build/check-ci-ideogram-native.py',root/'build/watch-ideogram-ci.py',Path(__file__)]
files += [local/'bindings/tests/bindings_window_smoke.py']
files=[p for p in files if p.is_file()]
dest=root/'research/sgr-ideogram-ci-records';dest.mkdir(exist_ok=True);records=[]
for p in sorted(set(files)):
    data=p.read_bytes();archive=dest/f'{len(records):03d}-{p.name}.gz'
    if archive.exists():assert gzip.decompress(archive.read_bytes())==data,archive
    else:archive.write_bytes(gzip.compress(data,mtime=0))
    records.append(dict(path=p.relative_to(root).as_posix(),archive=archive.relative_to(root).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
manifest=dict(source='8ff214feb549c2b79bb57960467c1d6963eab47e',image_sha256=sha,image_bytes=exe.stat().st_size,
    kind='CI and local owned Win32 observations, not REA-server Evidence',records=records)
(root/'research/sgr-ideogram-ci-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
for r in records:
    data=gzip.decompress((root/r['archive']).read_bytes());assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
print('Verified',len(records),'records;',sum((root/r['archive']).stat().st_size for r in records),'compressed bytes')
