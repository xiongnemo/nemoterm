import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/ci-enclosure-local';base.mkdir(exist_ok=False)
exe=root/'build/ci-sgr-enclosure-7a97307/product/nemoterm.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='4b7df978d3a4be3782ac28940619c222fd67f155e202f69692e5a6635fbd3288'
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
results=[]
cases=[('renderer','renderer',[]),('wire','sgr_stack',[])]
cases += [('memory-'+m,'tabs',['--renderer',m,'--side',side,'--cols','160','--rows','48','--workload-memory'])
          for m,side in [('gdi','top'),('directx','left')]]
for label,test,arguments in cases:
    dest=base/label
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),test,*arguments],cwd=root,
            stdout=log,stderr=subprocess.STDOUT).returncode
    record=dict(label=label,exit_code=code)
    memory=list((dest/'research').glob('*-memory.json'))
    if memory:
        data=json.loads(memory[0].read_text());record.update(peaks=data['peaks']['frontend'],samples=data['sample_count'])
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(record,flush=True)
    if code:
        print((dest/'controller.log').read_text()[-2500:]);raise SystemExit(code)
