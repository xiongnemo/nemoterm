import concurrent.futures,json,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
source='7a97307d24e58f38fdcd8a67a249c596280a7815'
base=root/'build/ci-sgr-enclosure-7a97307';base.mkdir(exist_ok=False)
pending={'core':43557702273,'single':43557702284};previous={}
deadline=time.monotonic()+2700
while pending:
    for name,run in list(pending.items()):
        raw=subprocess.check_output(['gh','run','view',str(run),'--json',
            'databaseId,headSha,status,conclusion,jobs,url'],cwd=root,text=True,timeout=30)
        v=json.loads(raw);assert v['headSha']==source
        (base/(name+'-run.json')).write_text(raw,encoding='utf-8')
        state=(v['status'],v['conclusion'])
        if previous.get(name)!=state:print(name,state,flush=True);previous[name]=state
        if v['status']=='completed':
            with (base/(name+'-run.log')).open('wb') as out:
                subprocess.run(['gh','run','view',str(run),'--log'],cwd=root,stdout=out,check=True,timeout=120)
            raw=subprocess.check_output(['gh','api',f'repos/xiongnemo/nemoterm/actions/runs/{run}/artifacts'],cwd=root,text=True,timeout=30)
            (base/(name+'-artifacts.json')).write_text(raw,encoding='utf-8')
            artifacts=json.loads(raw)['artifacts']
            wanted=([('nemoterm-single-exe-x64-','product'),('single-exe-evidence-','single-evidence'),('unverified-single-exe-x64-','unverified-product')]
                if name=='single' else [('test-results-windows-','core-evidence'),('test-results-sanitizers-','sanitizers'),
                    ('cluster-msvc-diagnostics-','msvc'),('nemoterm-windows-x64-','portable')])
            def download(item):
                prefix,folder=item
                found=[a for a in artifacts if a['name']==prefix+source and not a['expired']]
                if not found:return dict(folder=folder,missing=True)
                subprocess.run(['gh','run','download',str(run),'-n',prefix+source,'-D',str(base/folder)],cwd=root,check=True,timeout=240)
                return dict(folder=folder,artifact_id=found[0]['id'])
            with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
                for result in pool.map(download,wanted):print(json.dumps(result),flush=True)
            del pending[name]
    assert time.monotonic()<deadline,'Observation deadline; leave running workflows intact'
    if pending:time.sleep(20)
print('Visibility CI results collected',flush=True)
