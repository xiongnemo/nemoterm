from pathlib import Path
import json,os,subprocess
root=Path(__file__).resolve().parents[1];base=root/'build/integration-linux-02';results=[]
for kind in ('normal','sanitizers'):
    build=base/kind
    for label,command in [('build',['cmake','--build',str(build),'--target','test_sixel_terminal','--parallel','2']),
                          ('test',[str(build/'test_sixel_terminal')])]:
        log=base/f'cross-family-{kind}-{label}.log'
        with log.open('w',encoding='utf-8') as out:
            run=subprocess.run(command,cwd=root,stdout=out,stderr=subprocess.STDOUT,
                env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1'))
        results.append(dict(kind=kind,label=label,exit_code=run.returncode,log=str(log)))
        (base/'cross-family-results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
        print(kind,label,run.returncode,flush=True)
        if run.returncode:raise SystemExit(run.returncode)
