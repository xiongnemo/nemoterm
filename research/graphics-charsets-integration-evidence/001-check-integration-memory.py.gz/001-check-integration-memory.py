from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];base=root/'build/integration-memory-01';base.mkdir(exist_ok=False)
exe=root/'build/integration-single-02/nemoterm.exe';digest=hashlib.sha256(exe.read_bytes()).hexdigest()
assert digest=='f59a0e759eee75abb3cf647b5b7baa26afdc0d1cb1f6d607f446c6e53d365845'
assert all(r['exit_code']==0 for r in json.loads((root/'build/integration-native-01/results.json').read_text(encoding='utf-8')))
runner=root.parent/'rtl-worktree/build/run-owned-check.py';results=[]
for renderer,side in [('gdi','top'),('directx','left')]:
    for workload,flag,prefix in [('baseline',[],'workload'),('png',['--inline-images'],'inline-workload'),
                                  ('gif',['--animated-images'],'animated-workload')]:
        label=renderer+'-'+workload;dest=base/label
        for directory in ('dist','tools','build','research'):(dest/directory).mkdir(parents=True)
        shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
        shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools/nemoterm_debug.py');shutil.copy2(exe,dest/'dist/nemoterm.exe')
        print('Starting '+label,flush=True)
        with (dest/'outer.log').open('w',encoding='utf-8') as out:
            run=subprocess.run([sys.executable,str(runner),str(dest),'tabs','--renderer',renderer,'--side',side,
                '--cols','160','--rows','48','--font','SarasaTermSC Nerd Font Light','--workload-memory',*flag],
                cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=210)
        controller=json.loads((dest/'research/tabs-controller.json').read_text(encoding='utf-8'))
        observed=json.loads((dest/'research'/f'{prefix}-tabs-{renderer}-{side}-observed.json').read_text(encoding='utf-8'))
        memory=json.loads((dest/'research'/f'{prefix}-tabs-{renderer}-{side}-memory.json').read_text(encoding='utf-8'))
        row=dict(name=label,exit_code=run.returncode,executable_sha256=digest,seconds=controller['seconds'],
            actual_renderer=observed.get('actual_renderer'),actual_grid=observed.get('actual_grid'),
            checks=len(observed.get('checks',[])),error=observed.get('error'),phase=observed.get('phase'),
            memory_limit_passed=observed.get('memory_limit_passed'),samples=memory['sample_count'],
            peaks=memory['peaks']['frontend'],injected=memory['injected'],
            inner_cleanup=observed.get('owned_job_cleanup'),outer_cleanup=controller['cleanup'])
        results.append(row);(base/'results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
        print(json.dumps(row),flush=True)
        if run.returncode:raise SystemExit(run.returncode)
