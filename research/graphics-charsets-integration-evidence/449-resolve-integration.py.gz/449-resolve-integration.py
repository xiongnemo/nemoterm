from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
pattern=re.compile(r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> 4c8ccde\n',re.M|re.S)
for name in ('.github/workflows/ci.yml','scripts/test-single-exe.ps1','vendor/putty-0.85/CMakeLists.txt'):
    path=root/name;text=path.read_text(encoding='utf-8');count=0
    def merge(match):
        global count
        ours,theirs=match.groups();count+=1
        if name.endswith('CMakeLists.txt'):
            assert ours=='  terminal/nemo_charset.c\n'
            assert theirs=='  terminal/nemo_iterm.c\n  terminal/nemo_raster.c\n'
            return ours+theirs
        if name.endswith('test-single-exe.ps1'):
            combined=ours.replace("'sixel_background', ","'sixel_background', 'iterm_image', 'gif_animation', ")
            assert combined.replace("'iso2022', ",'')==theirs,(ours,theirs)
            return combined
        if 'cmake --build build-cluster' in ours:
            combined=ours.replace('test_iso2022_charset --parallel','test_iso2022_charset test_iterm test_raster --parallel')
            assert combined.splitlines(keepends=True)[0].replace(' test_iso2022_charset','')==theirs
            return combined
        if ours=='            charset-msvc.log\n':
            assert theirs=='            iterm-transport-msvc.log\n            raster-animation-msvc.log\n'
            return ours+theirs
        combined=ours.replace('test_sixel ','test_sixel test_iterm test_raster ')
        assert combined.replace(' test_iso2022_charset','')==theirs,(ours,theirs)
        return combined
    result=pattern.sub(merge,text)
    assert count and '<<<<<<<' not in result
    path.write_text(result,encoding='utf-8')
    print(name,count)
