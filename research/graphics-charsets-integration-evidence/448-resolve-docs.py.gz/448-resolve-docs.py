from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
pattern=re.compile(r'^<<<<<<< HEAD\n(.*?)^=======\n(.*?)^>>>>>>> 647a58b031947ef2a4c20af50e8e682923342d8f\n',re.M|re.S)
for name in ('PROTOCOL_COVERAGE.md','REQUIREMENTS.md'):
    path=root/'docs'/name;text=path.read_text(encoding='utf-8')
    def combine(m):
        ours,theirs=m.groups()
        if name=='PROTOCOL_COVERAGE.md':
            first=ours.splitlines(keepends=True)[0]
            assert first.startswith('| DCS Ps !u Pt ST; CSI &u')
            assert theirs.startswith('| DCS +q ... ST')
            return first+theirs
        return theirs+'\n'+ours.replace('## Current source and accepted executable','## Earlier separate-source checkpoint',1).replace('Main source is `8a41ad7`','At this checkpoint, main source was `8a41ad7`',1)
    result,count=pattern.subn(combine,text);assert count==1
    path.write_text(result,encoding='utf-8')
