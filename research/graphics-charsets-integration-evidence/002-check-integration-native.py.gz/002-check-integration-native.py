from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];base=root/'build/integration-native-01';base.mkdir(exist_ok=False)
exe=root/'build/integration-single-02/nemoterm.exe'
digest=hashlib.sha256(exe.read_bytes()).hexdigest()
assert digest=='f59a0e759eee75abb3cf647b5b7baa26afdc0d1cb1f6d607f446c6e53d365845'
runner=root.parent/'rtl-worktree/build/run-owned-check.py';results=[]
cases=[('iso2022',[])]+[(name,['--renderer',renderer]) for name in ('iterm_image','gif_animation') for renderer in ('gdi','opengl','directx')]
for name,args in cases:
    label=name+('-'+args[-1] if args else '')
    dest=base/label
    for directory in ('dist','tools','build','research'):(dest/directory).mkdir(parents=True)
    shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools/nemoterm_debug.py');shutil.copy2(exe,dest/'dist/nemoterm.exe')
    print('Starting '+label,flush=True)
    with (dest/'outer.log').open('w',encoding='utf-8') as out:
        run=subprocess.run([sys.executable,str(runner),str(dest),name,*args],cwd=root,
            stdout=out,stderr=subprocess.STDOUT,timeout=210)
    controller=json.loads((dest/'research'/f'{name}-controller.json').read_text(encoding='utf-8'))
    row=dict(name=label,exit_code=run.returncode,executable_sha256=digest,controller=controller)
    results.append(row);(base/'results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print(label,run.returncode,controller['seconds'],flush=True)
    if run.returncode:
        print((dest/'outer.log').read_text(encoding='utf-8',errors='replace')[-2500:],flush=True)
        raise SystemExit(run.returncode)
