from pathlib import Path
import json,os,subprocess,sys
root=Path(__file__).resolve().parents[1];project=root.parents[1]
tests=['test_iso2022_charset','test_iterm','test_raster','test_terminal','test_sixel',
       'test_sixel_terminal','test_state_control','test_queries','test_rectangle',
       'test_reflow','test_keyboard','test_grapheme_terminal','test_sgr','test_tcap',
       'test_osc52','test_resize','test_modes','test_hyperlink','test_cwd',
       'test_shell_marks','test_mouse','test_highlight','test_mok','test_titles',
       'test_osc_colour','test_selective_erase','test_margins','test_win32_input','test_sync']
windows=os.name=='nt'
# These six CMake targets require the native/GTK frontend. They are all built
# and run by the MSVC path; the headless Linux build has no corresponding target.
if not windows:
    tests=[t for t in tests if t not in {'test_terminal','test_resize','test_modes',
        'test_mouse','test_highlight','test_sync'}]
base=root/'build'/('integration-msvc' if windows else 'integration-linux-02')
base.mkdir(exist_ok=False);results=[]
cmake=str(project/'tools/python/cmake/data/bin/cmake.exe') if windows else 'cmake'
for kind in (['release'] if windows else ['normal','sanitizers']):
    dest=base/kind
    configure=[cmake,'-S',str(root/'vendor/putty-0.85'),'-B',str(dest),'-G','Ninja','-DPUTTY_GSSAPI=OFF']
    if windows:
        configure+=['-DCMAKE_MAKE_PROGRAM='+str(project/'tools/python/bin/ninja.exe'),
            '-DCMAKE_C_COMPILER=cl','-DCMAKE_CXX_COMPILER=cl','-DCMAKE_BUILD_TYPE=MinSizeRel',
            '-DCMAKE_C_FLAGS=/std:c11 /utf-8','-DCMAKE_C_FLAGS_MINSIZEREL=/O1 /Ob1 /Gy /Gw',
            '-DCMAKE_POLICY_DEFAULT_CMP0091=NEW','-DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded',
            '-DNEMOTERM_SINGLE_EXE=ON']
    else:
        configure+=['-DPUTTY_GTK_VERSION=NONE']
        if kind=='sanitizers':configure+=['-DCMAKE_C_FLAGS=-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer',
            '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined']
    commands=[configure,[cmake,'--build',str(dest),'--target',*tests,*(['pterm'] if windows else []),'--parallel','2']]
    commands.extend([[str(dest/(test+('.exe' if windows else '')))] for test in tests])
    for i,command in enumerate(commands):
        log=base/f'{kind}-{i:02}.log'
        with log.open('w',encoding='utf-8') as output:
            run=subprocess.run(command,cwd=root,stdout=output,stderr=subprocess.STDOUT,
                env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1'))
        results.append(dict(kind=kind,command=command,exit_code=run.returncode,log=str(log)))
        (base/'results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
        print(kind,i,run.returncode,flush=True)
        if run.returncode:
            print(log.read_text(encoding='utf-8',errors='replace')[-2500:]);raise SystemExit(run.returncode)
