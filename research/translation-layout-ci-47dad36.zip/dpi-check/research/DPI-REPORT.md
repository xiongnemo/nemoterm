# Remote DPI evidence

Product commit: `47dad363c81022b35e796c0eafdddee51bd9c3b5`
Fixture commit: `47dad363c81022b35e796c0eafdddee51bd9c3b5`

## Real system scaling

| Renderer | Host | Start | Test | Actual window DPI sequence | Result |
|---|---|---:|---|---|---|
| gdi | standalone | 100% | Cold start | 96 | PASS |
| gdi | standalone | 125% | Cold start | 120 | PASS |
| gdi | standalone | 150% | Cold start | 144 | PASS |
| gdi | standalone | 175% | Cold start | 168 | PASS |
| gdi | standalone | 200% | Cold start | 192 | PASS |
| gdi | standalone | 100% | Live transition | 96, 120, 144, 168, 192, 96 | PASS |
| gdi | tabs | 100% | Cold start | 96 | PASS |
| gdi | tabs | 125% | Cold start | 120 | PASS |
| gdi | tabs | 150% | Cold start | 144 | PASS |
| gdi | tabs | 175% | Cold start | 168 | PASS |
| gdi | tabs | 200% | Cold start | 192 | PASS |
| gdi | tabs | 100% | Live transition | 96, 120, 144, 168, 192, 96 | PASS |

## Synthetic message coverage

These cases inject WM_DPICHANGED; the actual Windows DPI stays at 96. They are not real display-scale acceptance.

| Host | Requested DPI | Actual Windows DPI | Result |
|---|---|---|---|
| standalone | 96, 120, 144, 168, 192, 96 | 96, 96, 96, 96, 96, 96 | PASS |
| tabs | 96, 120, 144, 168, 192, 96 | 96, 96, 96, 96, 96, 96 | PASS |

## Coverage limits

- Mixed-DPI multi-monitor moves are not exercised by this single-monitor fixture
- Chinese UI is not yet integrated into this product; UI assertions use English
- Unavailable: no compatible installed IME

JSON, screenshots, display capabilities and executable identity are in the `dpi-evidence` artifact.
