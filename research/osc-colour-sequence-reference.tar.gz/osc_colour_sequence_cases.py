"""Paired colour operations around a rejected specification; no expected replies."""
ESC = '\x1b'

def cases():
    result = {}
    for ending, end in [('st', ESC+'\\'), ('bel', '\x07')]:
        def osc(payload):
            return ESC+']'+payload+end
        invalid = [('unknown', 'not-a-colour'), ('bad-hex', '#gggggg'),
            ('missing-rgb-component', 'rgb:1/2'), ('extra-rgb-component', 'rgb:1/2/3/4'),
            ('long-rgb-component', 'rgb:00000/0/0'), ('trailing-space', 'red '),
            ('empty', ''), ('double-query', '??')]
        for family, command, first, second in [('indexed', 4, 1, 2),
                ('attribute', 5, 0, 1), ('attribute-alias', 4, 256, 257)]:
            initial = ESC+'c'+osc(f'{command};{first};#112233;{second};#445566')
            final = osc(f'{command};{first};?;{second};?')
            for name, spec in invalid:
                # Both a reply and a mutation precede the bad specification.
                # The later setter/query distinguishes command abortion from
                # skipping a pair, while a new OSC verifies parser recovery.
                result[f'{family}-{ending}-{name}'] = initial+osc(
                    f'{command};{first};#123456;{first};?;{first};{spec};'
                    f'{second};#778899;{second};?')+final
            result[f'{family}-{ending}-valid'] = initial+osc(
                f'{command};{first};#123456;{first};?;{second};#778899;{second};?')+final
        # Dynamic colours use a different upstream handler; observe rather
        # than assume they must abort like indexed/attribute pairs.
        initial = ESC+'c'+osc('10;#112233;#445566;#aabbcc')
        final = osc('10;?;?;?')
        for name, spec in invalid:
            result[f'dynamic-{ending}-{name}'] = initial+osc('10;?;'+spec+';#778899')+final
        result[f'dynamic-{ending}-valid'] = initial+osc('10;?;#123456;#778899')+final
    assert len(result) == 72
    return result
