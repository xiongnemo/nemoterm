"""Capture the pinned XTerm on a private Xvfb display, without desktop input."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys
from osc_colour_sequence_cases import cases

root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
stage=root/'build/osc-colour-sequence-01'
stage.mkdir(exist_ok=False)
source=Path('/tmp/nemoterm-legacy-reference-5RtbUr')
commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
assert commit=='5c75ead9a75d4b2e666ca06fa94503b5766ed93f'
subprocess.run(['git','-C',str(source),'diff','--exit-code'],check=True)
for path in (Path(__file__),Path(__file__).with_name('osc_colour_sequence_cases.py'),work/'tests/xterm_state_oracle.py'):
    shutil.copy2(path,stage/path.name)
sys.path.insert(0,str(stage))
from xterm_state_oracle import run_cases
identity=dict(source_commit=commit,source_directory=str(source),
    executable_sha256=hashlib.sha256((source/'xterm').read_bytes()).hexdigest(),
    case_count=len(cases()),display='Private Xvfb -displayfd; TCP disabled',
    global_input=False,clipboard_access=False)
(stage/'IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n')
run_cases(str(source/'xterm'),str(stage/'xterm.json'),cases(),['-ti','vt525'],raw_replies=True)
captured=json.loads((stage/'xterm.json').read_text())
assert len(captured['cases'])==len(cases()) and captured['executable_sha256']==identity['executable_sha256']
print('Captured',len(cases()),'independent colour-sequence cases; no product comparisons yet.')
