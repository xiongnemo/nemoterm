from pathlib import Path
import json,os,subprocess
root=Path(__file__).resolve().parents[1]
tests=['test_iso2022_charset','test_state_control','test_queries','test_rectangle',
       'test_sixel_terminal','test_reflow','test_keyboard','test_grapheme_terminal']
dest=root/'build/charset-parser-linux';dest.mkdir(exist_ok=True)
results=[]
for kind,flags in [('normal',[]),('sanitizers',['-DCMAKE_C_FLAGS=-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer',
    '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined'])]:
    out=dest/kind
    commands=[['cmake','-S',str(root/'vendor/putty-0.85'),'-B',str(out),'-G','Ninja',
        '-DPUTTY_GTK_VERSION=NONE','-DPUTTY_GSSAPI=OFF',*flags],
        ['cmake','--build',str(out),'--target',*tests,'--parallel','2']]
    for i,cmd in enumerate(commands+[[str(out/test)] for test in tests]):
        log=dest/f'{kind}-{i:02}.log'
        with log.open('w') as output:
            run=subprocess.run(cmd,cwd=root,stdout=output,stderr=subprocess.STDOUT,
                env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1'))
        results.append(dict(kind=kind,command=cmd,exit_code=run.returncode,log=str(log)))
        (dest/'results.json').write_text(json.dumps(results,indent=2)+'\n')
        print(kind,i,run.returncode,flush=True)
        if run.returncode:
            print(log.read_text()[-3000:]);raise SystemExit(run.returncode)
