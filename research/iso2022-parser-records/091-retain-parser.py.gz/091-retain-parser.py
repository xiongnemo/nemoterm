from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path(__file__).resolve().parents[1]
dest=root/'research/iso2022-parser-records';dest.mkdir(exist_ok=True)
files=set((root/'build').glob('parser-*.log'))
files.update((root/'build/charset-parser-linux').glob('*.log'))
files.add(root/'build/charset-parser-linux/results.json')
files.update((root/'build/reference').glob('charset-state*.*'))
files.update((root/'build/reference/charset-state-isolated').glob('*.json'))
for path in ['tests/test_charset.c','tests/charset_reference.h','tests/charset_parser_reference.h',
 'tests/charset_state_reference.h','tests/xterm_charset_state_oracle.py',
 'tools/generate_charset_parser_reference.py','tools/generate_charset_state_reference.py',
 'vendor/putty-0.85/terminal/nemo_charset.c','vendor/putty-0.85/terminal/nemo_charset.h',
 'vendor/putty-0.85/terminal/terminal.c','vendor/putty-0.85/terminal/terminal.h',
 'vendor/putty-0.85/test/test_state_control.c','build/check-charset-parser.py','build/retain-parser.py']:
    files.add(root/path)
reference=Path('//wsl.localhost/Debian/tmp/nemoterm-xterm-reference')
files.update([reference/'misc.c',reference/'ptydata.c'])
records=[]
for i,path in enumerate(sorted(files,key=str)):
    if not path.is_file():continue
    content=path.read_bytes();name=f'{i:03}-{path.name}.gz'
    packed=gzip.compress(content,mtime=0);(dest/name).write_bytes(packed)
    assert gzip.decompress(packed)==content
    records.append(dict(source=str(path.relative_to(root)) if path.is_relative_to(root) else str(path),
        archive=f'iso2022-parser-records/{name}',bytes=len(content),sha256=hashlib.sha256(content).hexdigest()))
def identity(path):
    content=path.read_bytes()
    return dict(path=str(path),bytes=len(content),sha256=hashlib.sha256(content).hexdigest())
report=dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    state='parser-development-checkpoint-not-promoted',independent_mapping_cells=15360,
    mapping_streams=160,isolated_state_streams=25,transport_shapes=['whole','single-byte'],
    records=records,
    built_frontend=identity(root/'build/parser-msvc/nemoterm.exe'),
    initial_mock_crash_asan_binary=identity(root/'build/parser-asan/test_state_control'),
    accepted_unchanged=identity(root.parents[1]/'dist/nemoterm.exe'),
    validation=['8 Linux suites normal and ASan/UBSan/leak checks passed',
                'modified mapping and state suites rechecked after handle/clipboard additions',
                'Windows frontend built; 8 MSVC suites passed'],
    limitations=['no native renderer/memory acceptance for this parser','input reverse mapping pending',
        'extended legacy checksum not implemented','UPSS reassignment pending',
        'lower-level JIS/DEC supplemental runtime mapping pending','full parser commit CI pending'])
(root/'research/iso2022-parser-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(records=len(records),archive_bytes=sum(p.stat().st_size for p in dest.glob('*.gz')),
    built=report['built_frontend'],accepted=report['accepted_unchanged']),indent=2))
