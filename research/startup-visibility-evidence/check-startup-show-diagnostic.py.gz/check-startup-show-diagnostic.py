from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=(root/'build/check-startup-activation.py').read_text(encoding='utf-8')
for a,b in [
    ("exe=source_root/'build/ci-io-7a3b95e/product/nemoterm.exe'", "exe=root.parent/'startup-worktree/build/show-diagnostic/nemoterm.exe'"),
    ("dest=root/'build/startup-activation'", "dest=root/'build/startup-show-diagnostic'"),
    ("u.GetForegroundWindow.restype=w.HWND", "u.GetForegroundWindow.restype=w.HWND\nu.GetPropW.argtypes,u.GetPropW.restype=[w.HWND,w.LPCWSTR],w.HANDLE"),
    ("        info=GuiInfo(size=c.sizeof(GuiInfo))", "        gui['startup_diagnostic']={n:int(u.GetPropW(host['hwnd'],'NemoDiagnostic'+n) or 0)-1 for n in ('Show','AfterShow','AfterForeground','AfterFocus')}\n        info=GuiInfo(size=c.sizeof(GuiInfo))"),
    ("diagnostic_completed=False,memory_acceptance=False,injected=False,cases=[]", "diagnostic_completed=False,memory_acceptance=False,injected=False,diagnostic_build=True,cases=[]")]:
    assert source.count(a)==1,a;source=source.replace(a,b)
compile(source,'show-diagnostic-preparation','exec')
(root/'build/check-startup-show-diagnostic-expanded.py').write_text(source,encoding='utf-8')
exec(compile(source,str(__file__),'exec'))
