import datetime,gzip,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1];prior=root.parent/'thread-lifetime-worktree'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
out=root/'research/startup-visibility-evidence';out.mkdir(exist_ok=False)
m=dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    local_frontend_base='7a3b95e285b9ea0e881e35501cd8040b60a7cf8f',
    ci=dict(core=43546782794,single=43546782899,status='in_progress'),files=[],cases={},
    original_gdi_failure_resolved=False,accepted_distribution_replaced=False)
def retain(p,name):
    b=p.read_bytes();packed=gzip.compress(b,mtime=0);dest=out/(name+'.gz')
    assert not dest.exists();dest.write_bytes(packed)
    m['files'].append(dict(path=dest.relative_to(root).as_posix(),bytes=len(packed),sha256=sha(packed),
        raw_bytes=len(b),raw_sha256=sha(b),encoding='gzip'))
for label in ('startup-activation','startup-show-diagnostic','startup-output','startup-visibility-fixed'):
    base=prior/'build'/label;v=read(base/'research/startup-activation-observed.json');ctl=read(base/'research/startup_activation-controller.json')
    assert v['diagnostic_completed'] and not v['completed'] and not v.get('error') and ctl['exit_code']==2
    assert not ctl['cleanup']['after']['active'] and not ctl['cleanup']['terminated_remaining']
    assert all(not c['cleanup']['terminated_remaining'] for c in v['cases'])
    m['cases'][label]=dict(executable_sha256=v['executable_sha256'],diagnostic_completed=True,controller=ctl,memory_acceptance=False)
    for p in sorted((base/'research').iterdir()):
        if p.is_file():retain(p,label+'-'+p.name)
    for rel in ('tests/startup_activation_window_smoke.py','startup_activation.log','controller.log'):
        retain(base/rel,label+'-'+rel.replace('/','_'))
for label in ('before','after'):
    base=root/'build'/('visibility-'+label);v=read(base/'research/startup-visibility-observed.json')
    ctl=read(base/'research/startup_visibility-controller.json')
    assert not ctl['cleanup']['after']['active']
    assert v['completed']==(label=='after') and ctl['exit_code']==(0 if label=='after' else 1)
    if label=='after':assert len(v['checks'])==8 and all(not c['cleanup']['terminated_remaining'] for c in v['cases'])
    else:assert v['cases'][1]['initial_iconic'] is False and v['cases'][1]['minimized'] is True
    m['cases'][label]=dict(executable_sha256=v['executable_sha256'],completed=v['completed'],checks=v['checks'],controller=ctl,cases=v['cases'])
    for rel in ('research/startup-visibility-observed.json','research/startup_visibility-controller.json',
        'tests/startup_visibility_window_smoke.py','tests/startup_visibility_fixture.py','startup_visibility.log','controller.log'):
        retain(base/rel,label+'-'+rel.replace('/','_'))
base=root/'build/visibility-gdi-workload';v=read(base/'research/workload-tabs-gdi-top-observed.json')
ctl=read(base/'research/tabs-controller.json');memory=read(base/'research/workload-tabs-gdi-top-memory.json')
assert v['completed'] and v['memory_limit_passed'] and not ctl['cleanup']['after']['active']
assert not ctl['cleanup']['terminated_remaining'] and not memory['injected'] and not memory['errors']
m['cases']['gdi_workload']=dict(executable_sha256=v['executable_sha256'],completed=True,actual_grid=v['actual_grid'],font=v['font'],
    baseline=v['two_tabs'],cycles=v['cycles'],checks=v['checks'],peaks=memory['peaks'],samples=memory['sample_count'],
    seconds=memory['seconds'],inner_cleanup=v['owned_job_cleanup'],controller=ctl)
for p in sorted((base/'research').iterdir()):
    if p.is_file():retain(p,'workload-'+p.name)
for rel in ('tests/tabs_window_smoke.py','tabs.log','controller.log'):retain(base/rel,'workload-'+rel.replace('/','_'))
for name in ('check-startup-activation.py','check-startup-show-diagnostic.py','check-startup-show-diagnostic-expanded.py',
    'check-startup-output.py','check-startup-output-expanded.py','check-startup-visibility-fixed.py','check-startup-visibility-fixed-expanded.py'):
    retain(prior/'build'/name,name)
for name in ('configure.log','configure-02.log','diagnostic-build.log','diagnostic-build-02.log','clean-frontend.log',
    'window-show-diagnostic.c','show-diagnostic.patch','link-image.py','build-visibility-overlay.py',
    'build-visibility-overlay-initial.py','link-clean-visibility.py','check-visibility-regression.py',
    'visibility-comparison.json','check-visibility-workload.py','watch-visibility-ci.py','retain-startup-visibility.py'):
    retain(root/'build'/name,name)
for folder in ('show-diagnostic','host-visibility','host-visibility-02','visibility-single'):
    for p in sorted((root/'build'/folder).rglob('*')):
        if p.is_file() and p.suffix in ('.log','.rsp','.json','.cpp'):
            retain(p,folder+'-'+p.relative_to(root/'build'/folder).as_posix().replace('/','_'))
for rel in ('scripts/prepare-single-exe.py','scripts/test-single-exe.ps1',
    'tests/startup_visibility_fixture.py','tests/startup_visibility_window_smoke.py'):
    retain(root/rel,'source-'+rel.replace('/','_'))
for f in m['files']:
    b=(root/f['path']).read_bytes();raw=gzip.decompress(b)
    assert len(b)==f['bytes'] and sha(b)==f['sha256'] and len(raw)==f['raw_bytes'] and sha(raw)==f['raw_sha256']
(root/'research/startup-visibility-validation.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(records=len(m['files']),workload=m['cases']['gdi_workload']['peaks']['frontend'])))
