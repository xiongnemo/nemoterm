from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=(root/'build/check-startup-show-diagnostic-expanded.py').read_text(encoding='utf-8')
for a,b in [
    ("dest=root/'build/startup-show-diagnostic'", "dest=root/'build/startup-output'"),
    ("        case=dict(minimized=minimized,snapshots=[]);evidence['cases'].append(case)",
     "        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,keypath,0,winreg.KEY_SET_VALUE) as key:\n            winreg.SetValueEx(key,'LogType',0,winreg.REG_DWORD,2)\n            winreg.SetValueEx(key,'LogFileClash',0,winreg.REG_DWORD,1)\n            winreg.SetValueEx(key,'LogFileName',0,winreg.REG_SZ,str(root/'research'/('startup-'+str(minimized)+'.vt')))\n        case=dict(minimized=minimized,snapshots=[]);evidence['cases'].append(case)")]:
    assert source.count(a)==1,a;source=source.replace(a,b)
compile(source,'startup-output-preparation','exec')
(root/'build/check-startup-output-expanded.py').write_text(source,encoding='utf-8')
exec(compile(source,str(__file__),'exec'))
