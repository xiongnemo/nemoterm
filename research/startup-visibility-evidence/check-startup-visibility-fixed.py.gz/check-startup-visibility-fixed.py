from pathlib import Path
root=Path(__file__).resolve().parents[1]
source=(root/'build/check-startup-output-expanded.py').read_text(encoding='utf-8')
for a,b in [
    ("startup-worktree/build/show-diagnostic/nemoterm.exe", "startup-worktree/build/host-visibility-02/nemoterm.exe"),
    ("dest=root/'build/startup-output'", "dest=root/'build/startup-visibility-fixed'")]:
    assert source.count(a)==1,a;source=source.replace(a,b)
compile(source,'startup-visibility-preparation','exec')
(root/'build/check-startup-visibility-fixed-expanded.py').write_text(source,encoding='utf-8')
exec(compile(source,str(__file__),'exec'))
