import json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
results=[]
for label,exe in [('before',root.parent/'io-lifetime-worktree/build/ci-io-7a3b95e/product/nemoterm.exe'),
    ('after',root/'build/visibility-single/nemoterm.exe')]:
    dest=root/'build'/('visibility-'+label);assert not dest.exists()
    for folder in ('dist','research','build'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),'startup_visibility'],
            cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    results.append(dict(label=label,exit_code=code))
    print(label,(dest/'controller.log').read_text(encoding='utf-8')[-1900:],flush=True)
(root/'build/visibility-comparison.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
assert results[0]['exit_code']==1 and results[1]['exit_code']==0,results
