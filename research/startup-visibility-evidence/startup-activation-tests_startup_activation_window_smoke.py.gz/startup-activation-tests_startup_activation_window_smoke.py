from native_test_utils import *
from owned_job import OwnedJob
from thread_snapshot import modules
import uuid,winreg

class GuiInfo(c.Structure):
    _fields_=[('size',w.DWORD),('flags',w.DWORD)]+[(n,w.HWND) for n in
        ('active','focus','capture','menu','move','caret')]+[('rect',w.RECT)]
u.GetGUIThreadInfo.argtypes=[w.DWORD,c.POINTER(GuiInfo)]
u.GetWindowThreadProcessId.argtypes=[w.HWND,c.POINTER(w.DWORD)]
u.GetForegroundWindow.restype=w.HWND
u.GetParent.argtypes,u.GetParent.restype=[w.HWND],w.HWND
u.IsIconic.argtypes=[w.HWND]
u.ShowWindowAsync.argtypes=[w.HWND,c.c_int]
u.SetForegroundWindow.argtypes=[w.HWND]
u.GetClassLongPtrW.argtypes,u.GetClassLongPtrW.restype=[w.HWND,c.c_int],c.c_size_t
u.GetGuiResources.argtypes,u.GetGuiResources.restype=[w.HANDLE,w.DWORD],w.DWORD
k.GetProcessHandleCount.argtypes=[w.HANDLE,c.POINTER(w.DWORD)]
callback=c.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
u.EnumChildWindows.argtypes=[w.HWND,callback,w.LPARAM]

def snapshot(pid,handle):
    found={};begun=time.monotonic();count=w.DWORD()
    assert k.GetProcessHandleCount(handle,c.byref(count))
    def record(hwnd):
        owner=w.DWORD();tid=u.GetWindowThreadProcessId(hwnd,c.byref(owner))
        if owner.value!=pid:return
        name=c.create_unicode_buffer(256);u.GetClassNameW(hwnd,name,len(name))
        found[int(hwnd)]=dict(hwnd=int(hwnd),tid=tid,kind=name.value,
            parent=int(u.GetParent(hwnd) or 0),iconic=bool(u.IsIconic(hwnd)),
            class_module=u.GetClassLongPtrW(hwnd,-16))
    @callback
    def child(hwnd,_):record(hwnd);return True
    @callback
    def top(hwnd,_):
        owner=w.DWORD();u.GetWindowThreadProcessId(hwnd,c.byref(owner))
        if owner.value==pid:record(hwnd);u.EnumChildWindows(hwnd,child,0)
        return True
    u.EnumWindows(top,0)
    host=next((v for v in found.values() if v['kind']=='NemotermHost'),None)
    gui={}
    if host:
        info=GuiInfo(size=c.sizeof(GuiInfo))
        if u.GetGUIThreadInfo(host['tid'],c.byref(info)):
            for n in ('active','focus','capture','menu','move','caret'):
                value=int(getattr(info,n) or 0);gui[n]=value if value in found else None
            gui['flags']=info.flags
    return dict(begun=begun,seconds=time.monotonic()-begun,handles=count.value,
        gdi=u.GetGuiResources(handle,0),user=u.GetGuiResources(handle,1),
        foreground_owned=int(u.GetForegroundWindow() or 0) in found,
        windows=list(found.values()),gui=gui)

exe=root/'dist/nemoterm.exe'
evidence=dict(executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),completed=False,
    diagnostic_completed=False,memory_acceptance=False,injected=False,cases=[])
try:
    for minimized in (False,True):
        profile='activation-'+uuid.uuid4().hex
        keypath='Software\\Nemo\\Nemoterm\\Sessions\\'+profile
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER,keypath) as key:
            for name,value in dict(WarnOnClose=0,CloseOnExit=1,NemoRenderer=0).items():
                winreg.SetValueEx(key,name,0,winreg.REG_DWORD,value)
        case=dict(minimized=minimized,snapshots=[]);evidence['cases'].append(case)
        try:
            with tempfile.TemporaryDirectory(prefix='nemoterm-activation-') as tmp,OwnedJob() as job:
                startup=subprocess.STARTUPINFO();startup.dwFlags=subprocess.STARTF_USESHOWWINDOW
                startup.wShowWindow=7 if minimized else 1
                process=job.spawn([str(exe),'-load',profile,'--tabs','--cols','160','--rows','48',
                    '--font','SarasaTermSC Nerd Font Light','-e',sys.executable,
                    str(root/'tests/session_fixture.py'),tmp],startupinfo=startup,
                    env=dict(os.environ,NEMOTERM_CONPTY='bundled',NEMOTERM_TEST_UTF8_INPUT='1'),
                    creationflags=subprocess.CREATE_NO_WINDOW)
                handle=k.OpenProcess(0x410,False,process.pid);assert handle
                host=None;begun=time.monotonic();restored=False
                try:
                    while time.monotonic()-begun<4:
                        assert process.poll() is None
                        value=snapshot(process.pid,handle);case['snapshots'].append(value)
                        host=next((w['hwnd'] for w in value['windows'] if w['kind']=='NemotermHost'),host)
                        if minimized and not restored and time.monotonic()-begun>=2 and host:
                            case['restore']=dict(seconds=time.monotonic()-begun,
                                show_result=bool(u.ShowWindowAsync(host,9)),
                                foreground_result=bool(u.SetForegroundWindow(host)))
                            restored=True
                        time.sleep(.02)
                    assert host and (not minimized or restored)
                    case['modules']=modules(handle)
                    launches=list(Path(tmp).glob('*.launch.json'));assert len(launches)==1
                    launch=read_snapshot(launches[0]);report=read_snapshot(Path(tmp)/f"{launch['pid']}.report.json")
                    assert report;case['actual_grid']=[report['columns'],report['rows']]
                    u.PostMessageW(host,0x10,0,0);process.wait(timeout=8)
                    case['cleanup']=job.finish(grace=5)
                    assert not case['cleanup']['terminated_remaining']
                finally:
                    k.CloseHandle(handle);case.setdefault('cleanup',job.finish(grace=0))
        finally:winreg.DeleteKey(winreg.HKEY_CURRENT_USER,keypath)
    evidence['diagnostic_completed']=True
finally:
    failure=sys.exc_info()[1]
    if failure:evidence['error']=repr(failure)
    (root/'research/startup-activation-observed.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
raise SystemExit(2)
