import shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];dest=root/'build/visibility-gdi-workload';assert not dest.exists()
for folder in ('dist','research','build'):(dest/folder).mkdir(parents=True,exist_ok=True)
shutil.copytree(root/'tests',dest/'tests');shutil.copy2(root/'build/visibility-single/nemoterm.exe',dest/'dist')
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
with (dest/'controller.log').open('w',encoding='utf-8') as log:
    code=subprocess.run([sys.executable,str(controller),str(dest),'tabs','--renderer','gdi',
        '--side','top','--cols','160','--rows','48','--workload-memory'],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
print((dest/'controller.log').read_text(encoding='utf-8')[-2500:],flush=True)
raise SystemExit(code)
