import hashlib,importlib.util,json,re,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
host=root.parent/'rtl-worktree/build/openconsole-single'
dest=root/'build/host-visibility-02';dest.mkdir(exist_ok=False)
source=dest/'src/interactivity/base/InteractivityFactory.cpp';source.parent.mkdir(parents=True)
original=host/'src/interactivity/base/InteractivityFactory.cpp';source.write_bytes(original.read_bytes())
spec=importlib.util.spec_from_file_location('prepare',root/'scripts/prepare-single-exe.py')
prepare=importlib.util.module_from_spec(spec);spec.loader.exec_module(prepare)
prepare.DEST=dest;prepare.patch_initial_window_visibility()
tlog=host/'obj/x64/Release/InteractivityBase/Interact.06EC74CB.tlog'
lines=(tlog/'CL.command.1.tlog').read_text(encoding='utf-16').splitlines()
i=next(i for i,line in enumerate(lines) if line.upper()=='^'+str(original).upper());cmd=lines[i+1]
assert cmd.upper().endswith(str(original).upper());cmd=cmd[:-len(str(original))]+'"'+str(source)+'"'
for flag,target in [('Fo',dest/'InteractivityFactory.obj'),('Fd',dest/'InteractivityFactory.pdb')]:
    cmd,n=re.subn('/'+flag+r'"[^"]+"',lambda _: '/'+flag+'"'+str(target)+'"',cmd,flags=re.I);assert n==1
for flag in ('Yu','Fp'):
    cmd,n=re.subn('/'+flag+r'"[^"]+"','',cmd,flags=re.I);assert n==1
cmd+=' /I"'+str(original.parent)+'"'
def run(tool,args,name,cwd):
    rsp=dest/(name+'.rsp');rsp.write_text(args,encoding='utf-8')
    with (dest/(name+'.log')).open('w',encoding='utf-8') as log:
        result=subprocess.run([tool,'@'+str(rsp)],cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
    print((dest/(name+'.log')).read_text(encoding='utf-8')[-2000:],flush=True)
    result.check_returncode()
run('cl.exe',cmd,'compile',original.parent)
lines=(tlog/'Lib.command.1.tlog').read_text(encoding='utf-16').splitlines()
cmd='\n'.join(line for line in lines if line and not line.startswith('^'))
cmd,n=re.subn(r'/OUT:"[^"]+"',lambda _: '/OUT:"'+str(dest/'ConInteractivityBaseLib.lib')+'"',cmd,flags=re.I);assert n==1
oldobj=host/'obj/x64/Release/InteractivityBase/InteractivityFactory.obj'
cmd,n=re.subn(re.escape(str(oldobj)),lambda _:str(dest/'InteractivityFactory.obj'),cmd,flags=re.I);assert n==1
run('lib.exe',cmd,'library',original.parent)
cmd=(root/'build/show-diagnostic/link.rsp').read_text(encoding='utf-8')
for flag,suffix in [('OUT','exe'),('PDB','pdb'),('IMPLIB','lib')]:
    cmd,n=re.subn('/'+flag+r':"[^"]+"',lambda _: '/'+flag+':"'+str(dest/('nemoterm.'+suffix))+'"',cmd,flags=re.I);assert n==1
oldlib=host/'bin/x64/Release/ConInteractivityBaseLib.lib'
cmd,n=re.subn(re.escape(str(oldlib)),lambda _:str(dest/'ConInteractivityBaseLib.lib'),cmd,flags=re.I);assert n==1
run('link.exe',cmd,'link',host/'src/host/exe')
records=[]
for p in [original,source,root/'scripts/prepare-single-exe.py',oldlib,dest/'ConInteractivityBaseLib.lib',dest/'nemoterm.exe']:
    b=p.read_bytes();records.append(dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(dest/'inputs.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')
print(json.dumps(records[-1]),flush=True)
