"""Retain the first complete single-image failure without accepting its product."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/udk-worktree'
base=root/'build/ci-udk-complete-fec0af2'
source='fec0af2b24e952a68f9d1deb20fee28e8273db14'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def digest(p):
    with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
run=json.loads((base/'single-run.json').read_bytes())
assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(43718800782,source,'completed','failure')
log=(base/'single-run.log').read_text()
assert 'FileNotFoundError' in log and 'dec-udk-reference.tar.gz' in log
image=base/'unverified-product/nemoterm.exe'
assert image.stat().st_size==4536832
assert digest(image)=='eee403f336c7ddd6588d825fad8654ede08b038dcae9c6d484d35d5cd34bc2e7'
artifacts=json.loads((base/'single-artifacts.json').read_bytes())['artifacts']
for key,prefix in [('single-evidence','single-exe-evidence-'),('unverified-product','unverified-single-exe-x64-')]:
    receipt=json.loads((base/(key+'-download.json')).read_bytes())
    artifact=next(a for a in artifacts if a['id']==receipt['artifact_id'])
    assert artifact['name']==prefix+source and receipt['source']==source
files=[]
for p in base.iterdir():
    if p.name.startswith(('single-','unverified-product')):
        files.extend(x for x in p.rglob('*') if x.is_file()) if p.is_dir() else files.append(p)
entries={'source/retainer.py':Path(__file__).read_bytes()}
for name in ['scripts/test-single-exe.ps1','tests/udk_window_smoke.py','.github/workflows/single-exe.yml']:
    entries['source/'+name]=subprocess.check_output(['git','show',source+':'+name],cwd=work)
archive=work/'research/dec-udk-single-first.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for p in sorted(files):
        name=p.relative_to(base).as_posix();info=tarfile.TarInfo(name);info.size=p.stat().st_size
        with p.open('rb') as stream:tar.addfile(info,stream)
        records.append(dict(path=name,raw_bytes=info.size,raw_sha256=digest(p)))
    for name,raw in sorted(entries.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path']
        assert hashlib.file_digest(tar.extractfile(member),'sha256').hexdigest()==record['raw_sha256']
manifest=dict(source=source,run=43718800782,conclusion='failure',
    failure='UDK fixture could not open its retained reference: isolation script omitted the archive. It failed before any native UDK assertion.',
    image=dict(bytes=image.stat().st_size,sha256=digest(image),accepted=False),
    artifacts=[dict(id=a['id'],name=a['name']) for a in artifacts],
    scope='Complete original single-image failure evidence; preceding successful checks do not certify the entire product. No local execution or promotion.',
    bundle=dict(path=archive.relative_to(work).as_posix(),bytes=archive.stat().st_size,sha256=digest(archive),records=records))
(work/'research/dec-udk-single-first-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Retained failed single run:',len(records),'records,',archive.stat().st_size,'bytes')
