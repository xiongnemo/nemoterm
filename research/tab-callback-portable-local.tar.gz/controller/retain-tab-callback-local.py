from pathlib import Path
import hashlib,json,tarfile
root=Path(__file__).resolve().parents[1]
work=root/'build/tab-callback-diagnostic-worktree'
ci=root/'build/ci-answerback-config-23c90fe'
stage=root/'build/tab-callback-23c90fe-local-02'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected='75c88c5236b53853ea7c992c870fef322822939592b07476d99730a88543663d'
original=load(ci/'core-evidence/test-results/tabs-opengl-right-observed.json')
assert original['executable_sha256']==expected and not original['completed']
assert original['phase']=='synchronized-tab-transfer' and original['actual_renderer']==1
assert original['process_before_cleanup']['exit_code']==0xc000041d
assert original['owned_job_cleanup']['after']['active']==0
rows=load(stage/'results.json');assert len(rows)==6
for row in rows:
    assert row['exit_code']==0 and row['completed'] and row['actual_renderer']==1 and row['checks']==9
    p=stage/'logs'/(row['label']+'-observed.json');assert sha(p)==row['observed_sha256']
    observed=load(p);assert observed['executable_sha256']==expected
    cleanup=observed['owned_job_cleanup']
    assert cleanup['after']=={'total':54,'active':0,'terminated':0} and not cleanup['terminated_remaining']
    boundaries=observed['probe_boundaries'];assert len(boundaries)==4
    assert [b['label'] for b in boundaries]==['after-load','before-detach','after-detach','after-select']
    assert [b['matches_initial_entry'] for b in boundaries]==[False,False,True,True]
    assert all(b['exit_code'] is None and b['exit_code_after_observation'] is None for b in boundaries)
    if row['label'].startswith('debugger'):
        observer=observed['exception_observer'];assert observer['exit_code']==0 and observer['dumps']==[]
        events=list(map(json.loads,Path(observer['events_file']).read_text().splitlines()))
        assert not any(e['event']=='exception' and not e['initial_attach_break'] for e in events)
files=[]
def add(path,name):files.append(dict(path=name,source=path,bytes=path.stat().st_size,sha256=sha(path)))
for p in stage.rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts:add(p,'local/'+p.relative_to(stage).as_posix())
first=root/'build/tab-callback-23c90fe-local-01'
for p in (first/'logs').iterdir():
    if p.is_file():add(p,'setup-attempt-01/logs/'+p.name)
for name in ('IDENTITY.json','controller.py'):add(first/name,'setup-attempt-01/'+name)
for name in ('ordinary-run.json','ordinary-artifacts.json','unverified-mingw-download.json','core-evidence-download.json'):
    add(ci/name,'failed-ci/'+name)
for name in ('tabs-gdi-top-observed.json','tabs-gdi-bottom-observed.json','tabs-directx-left-observed.json','tabs-opengl-right-observed.json'):
    add(ci/'core-evidence/test-results'/name,'failed-ci/'+name)
add(ci/'core-evidence/build/native-crashes/application-errors.json','failed-ci/application-errors.json')
add(work/'.github/workflows/tabs-close-replay.yml','diagnostic/tabs-close-replay.yml')
add(Path(__file__),'controller/retain-tab-callback-local.py')
archive=work/'research/tab-callback-portable-local.tar.gz';assert not archive.exists()
with tarfile.open(archive,'x:gz') as tar:
    for f in files:tar.add(f['source'],arcname=f['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for f in files:assert hashlib.sha256(tar.extractfile(f['path']).read()).hexdigest()==f['sha256']
manifest=dict(scope='Exact failed portable-image diagnosis; finite successful comparisons do not resolve the original callback exception or establish product acceptance.',
    source_commit='23c90fe3eb54d21b0d8c128c2d2a41090095b6d4',source_run=43755825354,
    artifact_id=14179250011,executable_sha256=expected,
    original_failure=dict(actual_renderer='GDI',phase=original['phase'],exit_code='0xc000041d',completed_groups=5,exception_stack_available=False),
    local=dict(replays=6,groups_per_replay=9,naturally_drained_processes=324,external_debugger_replays=3,external_observer_controls=4,
        setup_failure='Attempt 01 did not link the wmain helper because -municode was absent; no terminal replay ran. The corrected fresh attempt 02 is retained.'),
    diagnostic_workflow_commit='8c2d00484548e86351d2aa063fb67c57570458bd',
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),
    files=[{k:v for k,v in f.items() if k!='source'} for f in files])
(work/'research/tab-callback-portable-local-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='files'},indent=2))
