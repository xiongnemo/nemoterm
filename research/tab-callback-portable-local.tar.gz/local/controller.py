"""Diagnose the exact failed portable image using only fixture-owned windows."""
from pathlib import Path
import hashlib, io, json, os, shutil, subprocess, sys, tarfile, time

root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
source='23c90fe3eb54d21b0d8c128c2d2a41090095b6d4'
original=root/'build/ci-answerback-config-23c90fe/unverified-mingw'
stage=root/'build/tab-callback-23c90fe-local-02'
expected='75c88c5236b53853ea7c992c870fef322822939592b07476d99730a88543663d'
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(original/'nemoterm.exe')==expected
assert not stage.exists()
stage.mkdir()
archive=subprocess.check_output(['git','archive',source,'tests','tools/nemoterm_debug.py'],cwd=work)
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    for entry in tar:
        if entry.isdir():continue
        assert entry.isfile()
        target=(stage/entry.name).resolve();assert target.is_relative_to(stage)
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(tar.extractfile(entry).read())
shutil.copytree(original,stage/'dist')
for name in ('research','logs','controls'):(stage/name).mkdir()
shutil.copy2(__file__,stage/'controller.py')
identity=dict(source_commit=source,source_run=43755825354,artifact_id=14179250011,
    executable_sha256=expected,frida=__import__('frida').__version__,
    package_hashes={p.name:digest(p) for p in (stage/'dist').iterdir() if p.is_file()},
    fixture_hashes={p.relative_to(stage).as_posix():digest(p) for p in (stage/'tests').iterdir() if p.is_file()},
    scope='Exact failed portable image; local GDI comparison, no physical input or clipboard, diagnostic only')
(stage/'IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n')
assert identity['frida']=='17.24.3'
for kind in ('observer','control'):
    args=['gcc','-std=c11','-O2','-Wall','-Wextra','-Werror','-municode','-D_CRT_SECURE_NO_WARNINGS',
          str(stage/f'tests/native_exception_{kind}.c'),'-o',str(stage/f'controls/{kind}.exe'),'-ldbghelp']
    with (stage/f'logs/build-{kind}.log').open('w') as log:
        subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
with (stage/'logs/controls.log').open('w') as log:
    subprocess.run([sys.executable,str(stage/'tests/native_exception_controls.py'),
        '--observer',str(stage/'controls/observer.exe'),'--control',str(stage/'controls/control.exe'),
        '--destination',str(stage/'controls/results')],stdout=log,stderr=subprocess.STDOUT,check=True)
print('Four external exception-observer controls passed',flush=True)
env=dict(os.environ,NEMOTERM_TEST_EXE=str(stage/'dist/nemoterm.exe'),NEMOTERM_TEST_TRACEBACK_SECONDS='60')
env.pop('NEMOTERM_REQUIRE_OPENGL',None);env.pop('NEMOTERM_REQUIRE_DIRECTX',None)
rows=[]
for mode in ('ordinary','debugger'):
    for iteration in range(1,4):
        label=f'{mode}-{iteration}';started=time.monotonic()
        args=[sys.executable,'tests/tabs_window_smoke.py','--renderer','gdi','--side','right',
              '--cols','160','--rows','48','--font','Consolas','--probe-boundaries']
        if mode=='debugger':args.extend(['--exception-observer',str(stage/'controls/observer.exe')])
        print('Starting',label,flush=True)
        with (stage/f'logs/{label}.log').open('w',encoding='utf-8') as log:
            run=subprocess.run(args,cwd=stage,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
        prefix='exception-tabs' if mode=='debugger' else 'tabs'
        observed=stage/f'research/{prefix}-gdi-right-observed.json'
        retained=stage/f'logs/{label}-observed.json'
        if observed.exists():shutil.copy2(observed,retained)
        row=dict(label=label,exit_code=run.returncode,seconds=time.monotonic()-started)
        if retained.exists():
            v=json.loads(retained.read_text());row.update(completed=v.get('completed'),phase=v.get('phase'),
                actual_renderer=v.get('actual_renderer'),checks=len(v.get('checks',[])),
                observed_sha256=digest(retained),process_before_cleanup=v.get('process_before_cleanup'))
        rows.append(row);(stage/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
        print(json.dumps(row),flush=True)
assert digest(stage/'dist/nemoterm.exe')==expected
raise SystemExit(0 if all(row['exit_code']==0 and row.get('completed') for row in rows) else 1)
