"""Preserve the first native failure, including an API success with wrong Z order."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/bell-modes-worktree'
base=root/'build/ci-bell-validation-f93cb3d'
source='f93cb3dec32a73c87c3cbf9663f3d2b9265faf73'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'bell-window-run.json').read_bytes())
assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(43721167249,source,'completed','failure')
artifacts=json.loads((base/'bell-window-artifacts.json').read_bytes())['artifacts']
receipt=json.loads((base/'diagnostic-download.json').read_bytes())
artifact=next(a for a in artifacts if a['id']==receipt['artifact_id'])
assert artifact['name']=='bell-native-'+source and receipt['source']==source
d=base/'diagnostic'
image=d/'build/single-exe-dist/nemoterm.exe';image_sha=sha(image.read_bytes())
data=json.loads((d/'research/bell-modes-window-observed.json').read_bytes())
assert not data['completed'] and data['executable_sha256']==image_sha
assert data['reference_sha256']=='c5a87d9f9ee75d637293e3a6767d86102be622271720e8ee4b704e5727c9b6b4'
with tarfile.open(work/'research/bell-modes-reference.tar.gz') as tar:
    reference=json.loads(tar.extractfile('reference/bell-modes-xterm.json').read())
streams=0
for name,steps in data['cases'].items():
    for i,step in enumerate(steps):
        expected=reference['cases'][name]['steps'][i]
        for key in ('sequence_hex','reply_hex','wire_with_barrier_hex'):assert step[key]==expected[key]
        assert step['native_before']['foreground']==step['native_after']['foreground']
        streams+=1
log=(d/'bell-bell_modes.log').read_text(encoding='utf-8-sig')
assert "('00-lifetime-ris', 1," in log and "'result': 1" in log and "'above_other': False" in log
entries={'source/retainer.py':Path(__file__).read_bytes()}
for name in ['tests/bell_modes_window_smoke.py','tests/bell_window_smoke.py','tests/bell_visual_window_smoke.py',
             'tests/native_test_utils.py','tests/owned_job.py','tests/protocol_oracle_window.py',
             'tests/mouse_fixture.py','vendor/putty-0.85/windows/window.c','.github/workflows/ansi-conformance.yml']:
    entries['source/'+name]=subprocess.check_output(['git','show',source+':'+name],cwd=work)
for p in d.rglob('*'):
    if p.is_file():entries[p.relative_to(base).as_posix()]=p.read_bytes()
for p in base.glob('bell-window-*'):entries[p.name]=p.read_bytes()
entries['diagnostic-download.json']=(base/'diagnostic-download.json').read_bytes()
archive=work/'research/bell-modes-native-first.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(entries.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path'] and sha(tar.extractfile(member).read())==record['raw_sha256']
manifest=dict(source=source,run=43721167249,conclusion='failure',artifact_id=artifact['id'],
    image=dict(bytes=image.stat().st_size,sha256=image_sha,accepted=False),preceding_exact_reply_streams=streams,
    failure='SetWindowPos(HWND_TOP, flags=19) returned 1 but actual Z order remained below the foreground cover window.',
    scope='Native failing observation; existing sound-policy and visual fixtures pass separately. No local execution or product promotion.',
    bundle=dict(path=archive.relative_to(work).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),records=records))
(work/'research/bell-modes-native-first-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Retained',len(records),'records,',archive.stat().st_size,'bytes;',streams,'preceding exact reply streams')
