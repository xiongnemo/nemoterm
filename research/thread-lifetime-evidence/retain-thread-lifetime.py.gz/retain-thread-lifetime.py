import datetime,gzip,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
out=root/'research/thread-lifetime-evidence';out.mkdir(exist_ok=False)
m=dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    files=[],ci=[],cases={},full_goal_complete=False,fixture_promotion='pending GDI resource investigation')
def retain(p,name):
    raw=p.read_bytes();packed=gzip.compress(raw,mtime=0);dest=out/(name+'.gz')
    assert not dest.exists(),dest;dest.write_bytes(packed)
    m['files'].append(dict(path=dest.relative_to(root).as_posix(),bytes=len(packed),sha256=sha(packed),
        raw_bytes=len(raw),raw_sha256=sha(raw),encoding='gzip'))
for name in ['thread-adapter-01.json','thread-adapter-02.json','check-terminal-threads.py',
    'check-retained-terminal-threads.py','check-worker-completion.py','check-gdi-startup-resources.py',
    'io-thread-symbols.txt','thread-constructor-publics.txt','input-constructor-disassembly.txt',
    'output-constructor-disassembly.txt','retain-thread-lifetime.py']:
    retain(root/'build'/name,name)
for run,checks in [(43540854013,6),(43541843784,8)]:
    prefix='ci-thread-'+str(run)
    v=read(root/'build'/(prefix+'-run.json'))
    assert v['status']=='completed' and v['conclusion']=='success' and len(v['jobs'])==2
    assert all(j['conclusion']=='success' for j in v['jobs'])
    ci=dict(run=run,source_commit=v['headSha'],url=v['url'],checks=checks,results=[])
    for suffix in ('-run.json','-artifacts.json','-run.log'):retain(root/'build'/(prefix+suffix),prefix+suffix)
    for folder in (root/'build'/prefix).iterdir():
        observed=read(folder/'research/thread-snapshot-native.json')
        assert observed['completed'] and len(observed['checks'])==checks and not observed['cleanup']['terminated_remaining']
        ci['results'].append(dict(artifact=folder.name,checks=observed['checks'],cleanup=observed['cleanup']))
        for p in folder.rglob('*'):
            if p.is_file():retain(p,prefix+'-'+folder.name+'-'+p.relative_to(folder).as_posix().replace('/','_'))
    m['ci'].append(ci)
for label,renderer,side in [('thread-failure-diagnostic','directx','left'),
    ('thread-retained-diagnostic','directx','left'),('worker-completion-directx','directx','left'),
    ('worker-completion-gdi','gdi','top'),('gdi-startup-diagnostic','gdi','top')]:
    base=root/'build'/label
    v=read(base/'research'/f'workload-tabs-{renderer}-{side}-observed.json')
    ctl=read(base/'research/tabs-controller.json')
    assert not ctl['cleanup']['after']['active']
    memory=read(base/'research'/f'workload-tabs-{renderer}-{side}-memory.json')
    assert not memory['injected'] and not memory['errors']
    m['cases'][label]=dict(executable_sha256=v['executable_sha256'],controller=ctl,
        completed=v['completed'],diagnostic_completed=v.get('diagnostic_completed',False),
        memory_acceptance=v['completed'] and v.get('memory_limit_passed',False),
        actual_grid=v['actual_grid'],font=v['font'],checks=v['checks'],
        baseline=v['two_tabs'],cycles=v['cycles'],error=v.get('error'),
        peaks=memory['peaks'],samples=memory['sample_count'],seconds=memory['seconds'],
        inner_cleanup=v['owned_job_cleanup'])
    for p in sorted((base/'research').iterdir()):
        if p.is_file():retain(p,label+'-'+p.name)
    for relative in ('tabs.log','controller.log','tests/tabs_window_smoke.py','tests/thread_snapshot.py','tests/handle_snapshot.py'):
        retain(base/relative,label+'-'+relative.replace('/','_'))
for name in ('tests/thread_snapshot.py','tests/thread_snapshot_native_test.py','tests/tabs_window_smoke.py',
    '.github/workflows/handle-snapshot.yml'):
    retain(root/name,'source-'+name.replace('/','_'))
for f in m['files']:
    b=(root/f['path']).read_bytes()
    assert len(b)==f['bytes'] and sha(b)==f['sha256'] and sha(gzip.decompress(b))==f['raw_sha256']
(root/'research/thread-lifetime-validation.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(records=len(m['files']),cases={k:dict(completed=v['completed'],diagnostic_completed=v['diagnostic_completed'],
    peak=v['peaks']['frontend']) for k,v in m['cases'].items()}),indent=2))
