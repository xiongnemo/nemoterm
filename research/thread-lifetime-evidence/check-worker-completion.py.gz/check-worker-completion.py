import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
exe=root.parent/'d3d11-worktree/build/io-fix-single/nemoterm.exe'
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
for renderer,side in [('directx','left'),('gdi','top')]:
    dest=root/'build'/('worker-completion-'+renderer);assert not dest.exists(),dest
    for folder in ('dist','research','build'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    p=dest/'tests/tabs_window_smoke.py';source=p.read_text(encoding='utf-8')
    assert source.count("3:'NemotermDirect2D'")==1
    p.write_text(source.replace("3:'NemotermDirect2D'","3:'NemotermDirect3D11'"),encoding='utf-8')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),'tabs','--renderer',renderer,
            '--side',side,'--cols','160','--rows','48','--workload-memory'],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    print(json.dumps(dict(renderer=renderer,exit_code=code,executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest())),flush=True)
    if code:
        print((dest/'controller.log').read_text(encoding='utf-8')[-4500:],flush=True)
        raise SystemExit(code)
