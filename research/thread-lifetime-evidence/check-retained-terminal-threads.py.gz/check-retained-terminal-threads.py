import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
source_root=root.parent/'d3d11-worktree'
dest=root/'build/thread-retained-diagnostic';assert not dest.exists()
for folder in ('dist','research','build'):(dest/folder).mkdir(parents=True,exist_ok=True)
shutil.copytree(source_root/'tests',dest/'tests')
for name in ('thread_snapshot.py','handle_snapshot.py'):
    shutil.copy2(root/'tests'/name,dest/'tests'/name)
exe=source_root/'build/io-fix-single/nemoterm.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='00f9a30d6a4660efc020cfebef5bddc51146a460ebd0308a15b6ee50cc26fe49'
shutil.copy2(exe,dest/'dist')
p=dest/'tests/tabs_window_smoke.py';original=p.read_text(encoding='utf-8');source=original
def replace(a,b):
    global source
    assert source.count(a)==1,a;source=source.replace(a,b)
replace("3:'NemotermDirect2D'","3:'NemotermDirect3D11'")
replace('        handle=k.OpenProcess(0x410,False,process.pid)',
        '        worker_lease=None\n        handle=k.OpenProcess(0x410,False,process.pid)')
replace('                count=w.DWORD();assert k.GetProcessHandleCount(handle,c.byref(count))',
"""                count=w.DWORD();assert k.GetProcessHandleCount(handle,c.byref(count))
                counted=time.perf_counter_ns()
                worker_states=worker_lease.states() if worker_lease else None
                checked=time.perf_counter_ns()
                after_states=w.DWORD();assert k.GetProcessHandleCount(handle,c.byref(after_states))""")
replace('                return dict(handles=count.value,gdi=',
        '                return dict(worker_states=worker_states,handles_after_states=after_states.value,thread_check_ns=checked-counted,handles=count.value,gdi=')
replace('            for i in range(12):',"""            from thread_snapshot import OwnedThreadSnapshot
            thread_observer=OwnedThreadSnapshot(process,job)
            evidence.update(memory_acceptance=False,thread_snapshots=[],worker_waits=[])
            for i in range(12):
                before_threads=thread_observer.snapshot('before-'+str(i))
                evidence['thread_snapshots'].append(before_threads)""")
replace("                if args.dense_clusters:evidence['live_temporary_tabs'].append(resources())",
"""                if args.dense_clusters:evidence['live_temporary_tabs'].append(resources())
                live_threads=thread_observer.snapshot('live-'+str(i))
                evidence['thread_snapshots'].append(live_threads)
                previous={(t['tid'],t['created']) for t in before_threads['threads']}
                # Exact image only: constructor disassembly confirms these two
                # RVAs are passed to CreateThread by the input/output modules.
                entries=[t for t in live_threads['threads'] if t.get('module')=='nemoterm.exe'
                    and t.get('rva') in (0x11ecb0,0x11efc0) and (t['tid'],t['created']) not in previous]
                assert len(entries)==2 and {t['rva'] for t in entries}=={0x11ecb0,0x11efc0},entries
                worker_lease=thread_observer.retain(entries)""")
replace("                sample=resources();evidence['cycles'].append(sample)",
"""                sample=resources();evidence['cycles'].append(sample)
                wait_started=time.monotonic()
                signalled=worker_lease.wait(2000)
                after_wait=resources()
                evidence['worker_waits'].append(dict(cycle=i,threads=entries,before=sample,
                    all_signalled=signalled,seconds=time.monotonic()-wait_started,after=after_wait))
                assert signalled,evidence['worker_waits'][-1]
                worker_lease.close();worker_lease=None""")
replace("            evidence['completed']=True", "            evidence['diagnostic_completed']=True\n            raise SystemExit(2)")
replace('                if handle:k.CloseHandle(handle)',
        '                if worker_lease:worker_lease.close()\n                if handle:k.CloseHandle(handle)')
compile(source,str(p),'exec');p.write_text(source,encoding='utf-8')
(dest/'research/diagnostic-fixture.json').write_text(json.dumps(dict(
    original_sha256=hashlib.sha256(original.encode()).hexdigest(),modified_sha256=hashlib.sha256(source.encode()).hexdigest(),
    purpose='Retain exact newly created I/O worker handles in the observer; sample termination adjacent to original handle count and keep original assertions',
    injection=False,automation_enabled=False,memory_acceptance=False),indent=2)+'\n',encoding='utf-8')
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
with (dest/'controller.log').open('w',encoding='utf-8') as log:
    code=subprocess.run([sys.executable,str(controller),str(dest),'tabs','--renderer','directx',
        '--side','left','--cols','160','--rows','48','--workload-memory'],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
print((dest/'controller.log').read_text(encoding='utf-8')[-3500:],flush=True)
raise SystemExit(code)
