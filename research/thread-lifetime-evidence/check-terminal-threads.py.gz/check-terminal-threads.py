import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
source_root=root.parent/'d3d11-worktree'
dest=root/'build/thread-failure-diagnostic';assert not dest.exists()
for folder in ('dist','research','build'):(dest/folder).mkdir(parents=True,exist_ok=True)
shutil.copytree(source_root/'tests',dest/'tests')
for name in ('thread_snapshot.py','handle_snapshot.py'):
    shutil.copy2(root/'tests'/name,dest/'tests'/name)
shutil.copy2(source_root/'build/io-fix-single/nemoterm.exe',dest/'dist')
p=dest/'tests/tabs_window_smoke.py';original=p.read_text(encoding='utf-8');source=original
def replace(a,b):
    global source
    assert source.count(a)==1,a;source=source.replace(a,b)
replace("3:'NemotermDirect2D'","3:'NemotermDirect3D11'")
replace('            for i in range(12):',"""            from thread_snapshot import OwnedThreadSnapshot
            thread_observer=OwnedThreadSnapshot(process,job)
            evidence.update(memory_acceptance=False,thread_snapshots=[thread_observer.snapshot('baseline')])
            for i in range(12):""")
needle="                assert sample['handles']<=baseline['handles']+6,(baseline,sample)"
replace(needle,"""                if sample['handles']>baseline['handles']+6:
                    evidence['failure_before_thread_observation']=dict(cycle=i,baseline=baseline,sample=sample)
                    begun=time.monotonic()
                    evidence['failure_thread_samples']=[]
                    for delay in (0,.05,.2,1.0):
                        time.sleep(max(0,begun+delay-time.monotonic()))
                        value=thread_observer.snapshot('failure-'+str(delay))
                        value['seconds_after_failure']=time.monotonic()-begun
                        evidence['thread_snapshots'].append(value)
                        evidence['failure_thread_samples'].append(resources())
"""+needle)
replace("            evidence['completed']=True", "            evidence['diagnostic_completed']=True\n            raise SystemExit(2)")
compile(source,str(p),'exec');p.write_text(source,encoding='utf-8')
(dest/'research/diagnostic-fixture.json').write_text(json.dumps(dict(
    original_sha256=hashlib.sha256(original.encode()).hexdigest(),modified_sha256=hashlib.sha256(source.encode()).hexdigest(),
    purpose='Read owned thread metadata at baseline and only after a resource failure; retain the original failing sample and assertion',
    injection=False,automation_enabled=False,memory_acceptance=False),indent=2)+'\n',encoding='utf-8')
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
with (dest/'controller.log').open('w',encoding='utf-8') as log:
    code=subprocess.run([sys.executable,str(controller),str(dest),'tabs','--renderer','directx',
        '--side','left','--cols','160','--rows','48','--workload-memory'],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
print((dest/'controller.log').read_text(encoding='utf-8')[-3000:],flush=True)
raise SystemExit(code)
