// Standalone renderer initialization experiment, not a terminal or acceptance test.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d2d1.h>
#include <d3d9.h>
#include <stdio.h>
#include <stdlib.h>

static LRESULT CALLBACK window_proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg==WM_CLOSE) {DestroyWindow(hwnd);return 0;}
    if (msg==WM_DESTROY) {PostQuitMessage(0);return 0;}
    if (msg==WM_ERASEBKGND) return 1;
    if (msg==WM_PAINT) {PAINTSTRUCT ps;BeginPaint(hwnd,&ps);EndPaint(hwnd,&ps);return 0;}
    return DefWindowProcW(hwnd,msg,wp,lp);
}
static void require(HRESULT hr,const char *where) {
    if (FAILED(hr)) {fprintf(stderr,"%s failed: 0x%08lx\n",where,(unsigned long)hr);exit(1);}
}
int main(int argc,char **argv) {
    if (argc!=2) return 1;
    const int mode=atoi(argv[1]);
    if (mode<0 || mode>2) return 1; // 0 plain window, 1 Direct2D, 2 Direct3D9Ex
    SetProcessDPIAware();
    HINSTANCE instance=GetModuleHandleW(NULL);
    WNDCLASSW wc={};wc.hInstance=instance;wc.lpfnWndProc=window_proc;wc.lpszClassName=L"NemoGraphicsInitProbe";
    if (!RegisterClassW(&wc)) return 1;
    RECT box={0,0,1600,960};AdjustWindowRect(&box,WS_OVERLAPPEDWINDOW,FALSE);
    HWND hwnd=CreateWindowExW(0,wc.lpszClassName,L"Owned graphics initialization probe",WS_OVERLAPPEDWINDOW,
        20,20,box.right-box.left,box.bottom-box.top,NULL,NULL,instance,NULL);
    if (!hwnd) return 1;
    ShowWindow(hwnd,SW_SHOWNOACTIVATE);
    HMODULE module=NULL;
    ID2D1Factory *factory=NULL;ID2D1HwndRenderTarget *target=NULL;
    ID2D1BitmapRenderTarget *frame=NULL;ID2D1Bitmap *image=NULL;
    IDirect3D9Ex *d3d=NULL;IDirect3DDevice9Ex *device=NULL;
    IDirect3DTexture9 *texture=NULL;IDirect3DSurface9 *surface=NULL,*backbuffer=NULL;
    unsigned vendor=0,adapter_device=0;
    if (mode==1) {
        module=LoadLibraryExW(L"d2d1.dll",NULL,LOAD_LIBRARY_SEARCH_SYSTEM32);
        if (!module) return 1;
        typedef HRESULT (WINAPI *Create)(D2D1_FACTORY_TYPE,REFIID,const D2D1_FACTORY_OPTIONS *,void **);
        auto create=(Create)GetProcAddress(module,"D2D1CreateFactory");
        if (!create) return 1;
        require(create(D2D1_FACTORY_TYPE_SINGLE_THREADED,__uuidof(ID2D1Factory),NULL,(void **)&factory),"D2D factory");
        D2D1_RENDER_TARGET_PROPERTIES props={};props.type=D2D1_RENDER_TARGET_TYPE_HARDWARE;
        props.pixelFormat={DXGI_FORMAT_B8G8R8A8_UNORM,D2D1_ALPHA_MODE_IGNORE};props.dpiX=props.dpiY=96;
        D2D1_HWND_RENDER_TARGET_PROPERTIES window={};window.hwnd=hwnd;window.pixelSize={1600,960};
        require(factory->CreateHwndRenderTarget(&props,&window,&target),"D2D target");
        D2D1_SIZE_U size={1600,960};
        require(target->CreateCompatibleRenderTarget(NULL,&size,NULL,D2D1_COMPATIBLE_RENDER_TARGET_OPTIONS_GDI_COMPATIBLE,&frame),"D2D frame");
        require(frame->GetBitmap(&image),"D2D bitmap");
    } else if (mode==2) {
        module=LoadLibraryExW(L"d3d9.dll",NULL,LOAD_LIBRARY_SEARCH_SYSTEM32);
        if (!module) return 1;
        typedef HRESULT (WINAPI *Create)(UINT,IDirect3D9Ex **);
        auto create=(Create)GetProcAddress(module,"Direct3DCreate9Ex");
        if (!create) return 1;
        require(create(D3D_SDK_VERSION,&d3d),"D3D9Ex factory");
        D3DADAPTER_IDENTIFIER9 adapter={};require(d3d->GetAdapterIdentifier(D3DADAPTER_DEFAULT,0,&adapter),"D3D9 adapter");
        vendor=adapter.VendorId;adapter_device=adapter.DeviceId;
        D3DPRESENT_PARAMETERS pp={};pp.BackBufferWidth=1600;pp.BackBufferHeight=960;
        pp.BackBufferFormat=D3DFMT_X8R8G8B8;pp.BackBufferCount=1;pp.SwapEffect=D3DSWAPEFFECT_DISCARD;
        pp.hDeviceWindow=hwnd;pp.Windowed=TRUE;pp.PresentationInterval=D3DPRESENT_INTERVAL_IMMEDIATE;
        require(d3d->CreateDeviceEx(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,hwnd,
            D3DCREATE_HARDWARE_VERTEXPROCESSING|D3DCREATE_FPU_PRESERVE,&pp,NULL,&device),"D3D9Ex hardware device");
        require(device->CreateTexture(1600,960,1,D3DUSAGE_RENDERTARGET,D3DFMT_X8R8G8B8,D3DPOOL_DEFAULT,&texture,NULL),"D3D9 frame");
        require(texture->GetSurfaceLevel(0,&surface),"D3D9 frame surface");
        require(device->GetBackBuffer(0,0,D3DBACKBUFFER_TYPE_MONO,&backbuffer),"D3D9 backbuffer");
    }
    RECT actual={};GetClientRect(hwnd,&actual);
    printf("{\"ready\":true,\"hwnd\":%llu,\"mode\":%d,\"width\":%ld,\"height\":%ld,\"adapter_vendor\":%u,\"adapter_device\":%u}\n",
        (unsigned long long)(UINT_PTR)hwnd,mode,actual.right,actual.bottom,vendor,adapter_device);fflush(stdout);
    bool running=true;unsigned frames=0;
    while (running) {
        MSG msg;
        while (PeekMessageW(&msg,NULL,0,0,PM_REMOVE)) {
            if (msg.message==WM_QUIT) {running=false;break;}
            TranslateMessage(&msg);DispatchMessageW(&msg);
        }
        if (!running) break;
        if (frames<32) {
            if (mode==1) {
                D2D1_COLOR_F color={.1f,.4f,.6f,1.f};frame->BeginDraw();frame->Clear(&color);
                require(frame->EndDraw(),"D2D frame end");
                target->BeginDraw();target->DrawBitmap(image);
                require(target->EndDraw(),"D2D present");
            } else if (mode==2) {
                require(device->ColorFill(surface,NULL,D3DCOLOR_XRGB(26,102,153)),"D3D9 fill");
                require(device->StretchRect(surface,NULL,backbuffer,NULL,D3DTEXF_NONE),"D3D9 compose");
                require(device->PresentEx(NULL,NULL,NULL,NULL,0),"D3D9 present");
            }
            frames++;
        }
        MsgWaitForMultipleObjects(0,NULL,FALSE,25,QS_ALLINPUT);
    }
    if (backbuffer) backbuffer->Release();if (surface) surface->Release();if (texture) texture->Release();
    if (device) device->Release();if (d3d) d3d->Release();
    if (image) image->Release();if (frame) frame->Release();if (target) target->Release();if (factory) factory->Release();
    if (module) FreeLibrary(module);
    printf("{\"frames\":%u,\"released\":true}\n",frames);fflush(stdout);
    return 0;
}
