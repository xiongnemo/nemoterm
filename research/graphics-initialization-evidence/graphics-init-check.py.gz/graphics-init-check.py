import hashlib,json,queue,subprocess,sys,threading,time
from pathlib import Path
root=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(root/'tests'))
from native_test_utils import c,w,u,k,memory_sample
from owned_job import OwnedJob
exe=root/'build/graphics-init-probe.exe'
dest=root/'build/graphics-init-check'
dest.mkdir(exist_ok=False)
evidence=dict(executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),
    source_sha256=hashlib.sha256((root/'build/graphics-init-probe.cpp').read_bytes()).hexdigest(),
    prototype_only=True,terminal_acceptance=False,instrumented=False,cases=[])
try:
    for mode,label in enumerate(('plain-window','direct2d','direct3d9ex')):
        case=dict(mode=mode,label=label,completed=False,samples=[]);evidence['cases'].append(case)
        with OwnedJob() as job:
            with (dest/(label+'.stderr.log')).open('w') as errors:
                process=job.spawn([str(exe),str(mode)],stdout=subprocess.PIPE,stderr=errors,
                    text=True,creationflags=subprocess.CREATE_NO_WINDOW)
                handle=k.OpenProcess(0x410,False,process.pid)
                if not handle:raise c.WinError()
                lines=queue.Queue()
                def reader():
                    for line in process.stdout:lines.put(line)
                thread=threading.Thread(target=reader,daemon=True);thread.start()
                try:
                    started=time.monotonic()
                    ready=None
                    while time.monotonic()-started<20:
                        assert process.poll() is None,(label,process.poll())
                        case['samples'].append(dict(seconds=time.monotonic()-started,**memory_sample(handle)))
                        try:ready=json.loads(lines.get(timeout=.025));break
                        except queue.Empty:pass
                    assert ready and ready['ready'],label
                    assert (ready['width'],ready['height'])==(1600,960)
                    case['ready']=ready
                    while time.monotonic()-started<3:
                        assert process.poll() is None,(label,process.poll())
                        case['samples'].append(dict(seconds=time.monotonic()-started,**memory_sample(handle)))
                        time.sleep(.025)
                    hwnd=ready['hwnd'];owner=w.DWORD();u.GetWindowThreadProcessId(hwnd,c.byref(owner))
                    assert owner.value==process.pid
                    assert u.PostMessageW(hwnd,0x10,0,0)
                    assert process.wait(timeout=10)==0
                    thread.join(1);case['end']=json.loads(lines.get(timeout=1))
                    assert case['end']['released'] and case['end']['frames']==32
                    case['completed']=True
                finally:
                    k.CloseHandle(handle)
                    case['cleanup']=job.finish(grace=2)
                case['peaks']={key:max(s[key] for s in case['samples']) for key in ('private_ws','total_ws','private_commit')}
                print(label,case['peaks'],flush=True)
finally:
    if sys.exc_info()[0]:evidence['error']=repr(sys.exc_info()[1])
    evidence['completed']=all(c['completed'] for c in evidence['cases']) and len(evidence['cases'])==3
    (dest/'observed.json').write_text(json.dumps(evidence,indent=2))
