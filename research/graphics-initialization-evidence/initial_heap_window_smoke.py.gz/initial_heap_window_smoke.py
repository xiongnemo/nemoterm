"""Local, instrumented first-renderer-switch diagnostic; never acceptance."""
from native_test_utils import *
from fixture_io import wait_snapshot
from owned_job import OwnedJob
from allocation_census import AllocationCensus
import uuid, winreg

target = int(sys.argv[1])
assert target in (0, 2)
assert os.environ.get('CI') != 'true'
label = 'gdi' if target == 0 else 'directx'
exe = root/'dist/nemoterm.exe'
profile = 'initial-heap-'+uuid.uuid4().hex
keypath = 'Software\\Nemo\\Nemoterm\\Sessions\\'+profile
result = dict(executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),
    font='SarasaTermSC Nerd Font Light',requested_grid=[160,48],target=label,
    instrumented=True,memory_acceptance=False,diagnostic_completed=False,
    scope='First renderer application through owned settings; single window, no history workload')
u.GetPropW.argtypes,u.GetPropW.restype = [w.HWND,w.LPCWSTR],w.HANDLE
u.SendMessageTimeoutW.argtypes = [w.HWND,w.UINT,w.WPARAM,w.LPARAM,w.UINT,w.UINT,c.POINTER(c.c_size_t)]
u.RedrawWindow.argtypes = [w.HWND,c.c_void_p,w.HANDLE,w.UINT]
with winreg.CreateKey(winreg.HKEY_CURRENT_USER,keypath) as key:
    for name,value in dict(NemoRenderer=0,WarnOnClose=0,CloseOnExit=1,LockSize=0).items():
        winreg.SetValueEx(key,name,0,winreg.REG_DWORD,value)
try:
    with tempfile.TemporaryDirectory(prefix='nemoterm-initial-heap-') as tmp, OwnedJob() as job:
        tmp=Path(tmp);report=tmp/'report';control=tmp/'control';ui_report=tmp/'ui-report';ui_control=tmp/'ui-control'
        observer=None;handle=None
        process=job.spawn([str(exe),'-load',profile,'--cols','160','--rows','48','--font',result['font'],
            '-e',sys.executable,str(root/'tests/mouse_fixture.py'),str(report),str(control),'300'],
            env=dict(os.environ,NEMOTERM_CONPTY='bundled'),creationflags=subprocess.CREATE_NO_WINDOW)
        try:
            handle=k.OpenProcess(0x410,False,process.pid)
            if not handle:raise c.WinError()
            hwnd=wait_for(lambda:find_window(process.pid))
            wait_for(lambda:read_snapshot(report))
            def output(phase):
                text='\x1b[0m\x1b[2J\x1b[H\x1b[?25l'+('\x1b[32mInitial renderer 中文 e\u0301 \x1b[0m'+' abcdefghijklmnopqrstuvwxyz '*4+'\r\n')*40+'\x1b[5n'
                write_snapshot(control,dict(phase=phase,sequence=text))
                observed=wait_snapshot(lambda:read_snapshot(report),lambda v:v.get('phase')==phase and bytes.fromhex(v.get('hex','')).endswith(b'\x1b[0n'))
                assert [observed['columns'],observed['rows']]==[160,48],observed
                assert u.RedrawWindow(hwnd,None,None,0x101)
                time.sleep(.2)
                return observed
            assert int(u.GetPropW(hwnd,'NemotermRenderer') or 0)==1
            result['warmup']=output('warmup-gdi')
            env=dict(os.environ,PSModulePath=str(Path(os.environ['SystemRoot'])/'System32/WindowsPowerShell/v1.0/Modules'))
            driver=job.spawn(['powershell.exe','-NoProfile','-File',str(root/'tests/gpu_settings_driver.ps1'),
                '-TargetProcess',str(process.pid),'-TargetWindow',str(hwnd),'-Control',str(ui_control),'-Report',str(ui_report)],
                env=env,creationflags=subprocess.CREATE_NO_WINDOW)
            wait_snapshot(lambda:read_snapshot(ui_report),lambda v:v.get('ready'),timeout=20)
            observer=AllocationCensus(process.pid,handle,root/'research'/f'initial-heap-{label}-census.json',all_post_attach_heaps=True)
            observer.result.update(executable_sha256=result['executable_sha256'],diagnostic_scope=result['scope'])
            observer.start()
            write_snapshot(ui_control,dict(id=1,mode=target))
            def ui_state():
                value=read_snapshot(ui_report)
                assert not value.get('error'),value
                return value
            wait_snapshot(ui_state,lambda v:v.get('id')==1,timeout=30)
            returned=c.c_size_t()
            assert u.SendMessageTimeoutW(hwnd,0,0,0,2,10000,c.byref(returned))
            result['actual_renderer_property']=int(u.GetPropW(hwnd,'NemotermRenderer') or 0)
            assert result['actual_renderer_property']==target+1,result
            result['rendered']=output('after-settings')
            result['census']=observer.freeze()
            observer.close();observer=None
            write_snapshot(ui_control,dict(stop=True));assert driver.wait(timeout=10)==0
            write_snapshot(control,dict(stop=True));assert process.wait(timeout=10)==0
            result['diagnostic_completed']=True
        finally:
            if observer:observer.close()
            if handle:k.CloseHandle(handle)
            result['cleanup']=job.finish(grace=3)
finally:
    if sys.exc_info()[0]:result['error']=repr(sys.exc_info()[1])
    winreg.DeleteKey(winreg.HKEY_CURRENT_USER,keypath)
    (root/'research'/f'initial-heap-{label}-observed.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
assert result['diagnostic_completed'] and not result['cleanup']['terminated_remaining']
raise SystemExit(2)
