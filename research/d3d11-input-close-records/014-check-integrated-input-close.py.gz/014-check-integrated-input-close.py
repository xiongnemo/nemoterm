import json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
controller=root.parent/'rtl-worktree/build/run-owned-check.py';results=[]
for label,name,args in [('startup','startup_visibility',[]),
    ('automation','automation',['--renderer','directx']),
    ('workload','tabs',['--renderer','directx','--side','left','--cols','160','--rows','48','--workload-memory'])]:
    dest=root/'build'/('input-close-'+label);assert not dest.exists()
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(root/'build/integrated-input-close/nemoterm.exe',dest/'dist')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),name,*args],
            cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    results.append(dict(label=label,exit_code=code))
    print(label,(dest/'controller.log').read_text(encoding='utf-8')[-2200:],flush=True)
    (root/'build/input-close-results.json').write_text(json.dumps(results,indent=2)+'\n')
    if code:raise SystemExit(code)
