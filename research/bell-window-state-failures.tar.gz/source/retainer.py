"""Preserve both the original harness failure and the independently observed close bug."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/bell-modes-worktree'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
entries={'source/retainer.py':Path(__file__).read_bytes()};runs=[]
for short,number in [('af5badf',43723320663),('f654468',43723442007)]:
    source=subprocess.check_output(['git','rev-parse',short],cwd=work,text=True).strip()
    base=root/f'build/ci-bell-state-{short}'
    run=json.loads((base/'bell-state-run.json').read_bytes())
    assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(number,source,'completed','failure')
    artifacts=json.loads((base/'bell-state-artifacts.json').read_bytes())['artifacts']
    receipt=json.loads((base/'diagnostic-download.json').read_bytes())
    artifact=next(a for a in artifacts if a['id']==receipt['artifact_id'])
    assert artifact['name']=='bell-window-state-'+source and receipt['source']==source
    d=base/'diagnostic'
    provenance=json.loads((d/'bell-state-provenance.json').read_text(encoding='utf-8-sig'))
    assert provenance['fixture_source']==source
    assert provenance['image_source']=='994bee4b189850488a5ab4f29eed1fd7355850e9'
    assert provenance['image_run']==43721733820 and provenance['artifact_id']==14164424987
    assert provenance['image_sha256'].lower()=='8cb4d404fa7c861e828b1b8af1151de7370fba85943c8b9b00d873de864e9ba9'
    data=json.loads((d/'research/bell-window-state-observed.json').read_bytes())
    assert not data['completed'] and data['executable_sha256']==provenance['image_sha256'].lower()
    log=(d/'bell-window-state.log').read_text(encoding='utf-8-sig')
    if short=='af5badf':
        assert not data['checks'] and 'second_child=child()' in log
        failure='Fixture used New Tab, which intentionally launches the configured shell instead of duplicating the mailbox command.'
    else:
        assert len(data['checks'])==11
        last=data['checks'][-1]
        assert last['name']=='notifying-background-close' and last['api']==[]
        assert last['after']['active']==2 and last['after']['sessions']==[2]
        assert [x['name'] for x in data['checks'][:10]]==['active-unfocused','active-focus-clears','background-focused-host',
            'background-unfocused-host','background-focus-clears-after-disable','background-disabled',
            'already-topmost','minimized-background','restore-clears','background-before-close']
        failure='GDI: closing the sole notifying background tab leaves its host notification without a FlashWindowEx STOP.'
    for p in base.rglob('*'):
        if p.is_file():entries[short+'/'+p.relative_to(base).as_posix()]=p.read_bytes()
    for name in ['tests/bell_window_state_smoke.py','tests/session_fixture.py','tests/mouse_fixture.py',
                 'tests/native_test_utils.py','tests/protocol_oracle_window.py','tests/owned_job.py',
                 'tools/nemoterm_debug.py','.github/workflows/ansi-conformance.yml']:
        entries[short+'/source/'+name]=subprocess.check_output(['git','show',source+':'+name],cwd=work)
    runs.append(dict(fixture_source=source,run=number,artifact_id=artifact['id'],image_provenance=provenance,
                     observed_checks=len(data['checks']),failure=failure))
archive=work/'research/bell-window-state-failures.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(entries.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path'] and sha(tar.extractfile(member).read())==record['raw_sha256']
manifest=dict(runs=runs,image_retained_in='research/bell-modes-native.tar.gz',
    scope='Original cloud failures; the second run reaches a real notification ownership bug after ten passing GDI observations. DirectX was not reached. No local desktop execution.',
    bundle=dict(path=archive.relative_to(work).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),records=records))
(work/'research/bell-window-state-failures-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Retained',len(records),'records,',archive.stat().st_size,'bytes')
