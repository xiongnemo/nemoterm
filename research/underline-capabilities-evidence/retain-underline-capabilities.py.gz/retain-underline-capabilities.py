import datetime, gzip, hashlib, json, subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[1]
check = root/'build/underline-capability-check'
out = root/'research/underline-capabilities-evidence'
out.mkdir(exist_ok=False)
files = []

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def identity(path):
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=sha(raw))

def retain(name, path):
    raw = path.read_bytes()
    compressed = gzip.compress(raw, mtime=0)
    dest = out/(name+'.gz')
    assert not dest.exists(), name
    dest.write_bytes(compressed)
    files.append(dict(path=dest.relative_to(root).as_posix(), sha256=sha(compressed),
                      bytes=len(compressed), raw_sha256=sha(raw), raw_bytes=len(raw), encoding='gzip'))

for p in sorted(check.iterdir()):
    if p.is_file() and p.suffix in ('.log', '.json', '.txt'):
        retain(p.name, p)
for p in sorted((check/'native/research').iterdir()):
    retain('native-'+p.name, p)
for name in ('query.log', 'query-controller.log'):
    retain('native-'+name, check/'native'/name)
retain('retain-underline-capabilities.py', Path(__file__))

source_names = ['.github/workflows/ci.yml', 'tests/query_window_smoke.py',
                'tests/underline_capabilities.py', 'tests/test_underline_terminfo.py',
                'vendor/putty-0.85/terminal/nemo_tcap.c', 'vendor/putty-0.85/test/test_tcap.c',
                'vendor/putty-0.85/unix/CMakeLists.txt']
source_hashes = {name:sha((root/name).read_bytes().replace(b'\r\n',b'\n')) for name in source_names}
exe = identity(check/'native/dist/nemoterm.exe')
native = json.loads((check/'native/research/query-window-observed.json').read_text())
controller = json.loads((check/'native/research/query-controller.json').read_text())
assert exe['sha256'] == native['executable_sha256'] == controller['executable_sha256']
assert native['completed'] and controller['completed'] and not controller['cleanup']['terminated_remaining']
assert controller['cleanup']['after']['active'] == 0
oracles = {}
for kind in ('core', 'native'):
    evidence = json.loads((check/f'ncurses-{kind}.json').read_text())
    assert evidence['completed'] and len(evidence['checks']) == 780
    oracles[kind] = dict(checks=len(evidence['checks']), completed=True,
                         ncurses_version=evidence['ncurses_version'],
                         executable_sha256=evidence['executable_sha256'])
accepted = identity(root.parents[1]/'dist/nemoterm.exe')
assert accepted['sha256'] == 'a108894f50f7d797f7d2c01558a71f268a1c812fe365270e5a6a7fb7868ca4ed'
base = subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert base == '993b8c2e51449d34b08d9cbca23325ffec04e0d1'
manifest = dict(
    recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_base_commit=base,
    source_hash_format='SHA-256 of UTF-8 checkout files with CRLF normalized to LF',
    source_sha256=source_hashes, executable=exe,
    core_suites=['Windows MinGW test_tcap', 'Windows MinGW test_sgr', 'Windows MinGW test_queries',
                 'Linux ASan/UBSan test_tcap'],
    independent_ncurses=oracles,
    native=dict(completed=True, parameter_programs=2, numeric_replays=15, combined_reset=1,
                controller=controller, memory_instrumented=True,
                memory_acceptance=False, peak_private_ws_diagnostic=native['peak_private_ws']),
    external_sources=[
        dict(url='https://raw.githubusercontent.com/ThomasDickey/ncurses-snapshots/7404b376832583182c52722dc09d86b8675db375/misc/terminfo.src',
             **identity(check/'terminfo.src')),
        dict(url='https://raw.githubusercontent.com/tmux/tmux/d56d72094d3ace7a25330bba8a8392ff66083a09/tty-features.c',
             **identity(check/'tmux-tty-features.c'))],
    accepted_distribution_replaced=False, accepted_local_distribution=accepted,
    full_goal_complete=False, remote_ci='pending', files=files)
path=root/'research/underline-capabilities-validation.json'
path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
for f in files:
    compressed=(root/f['path']).read_bytes();raw=gzip.decompress(compressed)
    assert sha(compressed)==f['sha256'] and len(compressed)==f['bytes']
    assert sha(raw)==f['raw_sha256'] and len(raw)==f['raw_bytes']
print(json.dumps(dict(files=len(files), bytes=sum(f['bytes'] for f in files), executable=exe)))
