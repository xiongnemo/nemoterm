"""Run local v0 acceptance on the exact successful CI product, without promotion."""
from pathlib import Path
import argparse, hashlib, json, os, shutil, subprocess, sys, time

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--destination',type=Path,required=True)
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
base=root/'build/ci-gdi-display-cache-12ee33b'
source='12ee33baa970363ddde687b3e612f9154e386356'
fixture='12ee33baa970363ddde687b3e612f9154e386356'
stage=args.destination.resolve()
assert not stage.exists(),'Preserve earlier evidence; choose a fresh destination'

for kind,run_id,jobs in [('ordinary',43736421054,4),('single',43736421137,1)]:
    run=json.loads((base/(kind+'-run.json')).read_text())
    assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(run_id,source,'completed','success')
    assert len(run['jobs'])==jobs and all(j['conclusion']=='success' for j in run['jobs'])
receipt=json.loads((base/'product-download.json').read_text())
assert receipt['source']==source
artifacts=json.loads((base/'single-artifacts.json').read_text())['artifacts']
artifact=next(a for a in artifacts if a['id']==receipt['artifact_id'])
assert artifact['name']=='nemoterm-single-exe-x64-'+source and not artifact['expired']
image=base/'product/nemoterm.exe'
digest=hashlib.sha256(image.read_bytes()).hexdigest()
validation=json.loads((base/'single-evidence/build/single-exe-check/research/single-exe-validation.json').read_text(encoding='utf-8-sig'))
assert validation['executable_sha256']==digest and validation['executable_bytes']==image.stat().st_size
assert validation['executable_directory_files']==['nemoterm.exe']
assert len(validation['passed_checks'])==len(set(validation['passed_checks']))==160
assert {'feature_policy','bell_modes','bell-window-state','udk','locator'}<=set(validation['passed_checks'])
subprocess.run(['git','diff','--exit-code',source,fixture,'--','vendor/putty-0.85','native',
                'scripts/build-single-exe.ps1','scripts/prepare-single-exe.py'],cwd=work,check=True)

shutdown=root/'build/shutdown-python-17233-validation/Scripts/python.exe'
subprocess.run([str(shutdown),'-c',"import frida; assert frida.__version__=='17.23.3'"],check=True)
import frida
assert frida.__version__=='17.24.3'
font_map=root/'build/feature-policy-font-map-846b525.json'
font=json.loads(font_map.read_text())
assert font['resolved_font']=='SarasaTermSC Nerd Font Light' and font['native_cjk_glyph']

stage.mkdir(parents=True)
for folder in ('dist','tests','tools','logs','research','build','case-evidence'):(stage/folder).mkdir()
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',fixture,'--','tests','tools/nemoterm_debug.py'],cwd=work,text=True).splitlines()
for name in paths:
    target=stage/name;target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(subprocess.check_output(['git','show',fixture+':'+name],cwd=work))
shutil.copy2(image,stage/'dist/nemoterm.exe')
shutil.copy2(font_map,stage/'research/font-mapper-preflight.json')
shutil.copy2(Path(__file__),stage/'controller.py')
identity=dict(source_commit=source,fixture_commit=fixture,source_run=43736421137,
    artifact_id=receipt['artifact_id'],executable_sha256=digest,executable_bytes=image.stat().st_size,
    ci_groups=160,shutdown_python=str(shutdown),shutdown_frida='17.23.3',other_frida=frida.__version__,
    fixture_changes='Uses the exact product commit and its existing bounded 1800-second child option; no fixture-source override.',
    scope='Local successful-product acceptance; no automatic overwrite of dist or release publication')
(stage/'IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n')

cases=[('shutdown',['tests/shutdown_window_smoke.py']),
       ('startup-size',['tests/startup_size_window_smoke.py','--font',font['resolved_font']]),
       ('feature-policy',['tests/feature_policy_window_smoke.py']),
       ('shells',['tests/shell_window_smoke.py']),
       ('session',['tests/session_window_smoke.py']),
       ('session-restart',['tests/session_restart_window_smoke.py']),
       ('bindings',['tests/bindings_window_smoke.py']),
       ('font-zoom',['tests/font_zoom_window_smoke.py'])]
for renderer,number,side in [('gdi','0','top'),('directx','2','left')]:
    cases += [(f'automation-{renderer}',['tests/automation_window_smoke.py','--renderer',renderer]),
              (f'drop-{renderer}',['tests/drop_window_smoke.py','--renderer',renderer]),
              (f'selection-{renderer}',['tests/selection_window_smoke.py','--renderer',number,'--tabs','--tab-side',side])]
for side in ('top','bottom','left','right'):
    cases.append(('tabs-'+side,['tests/tabs_window_smoke.py','--renderer','gdi','--side',side,
                              '--cols','160','--rows','48','--font',font['resolved_font']]))
for input_api in ('byte','wide'):
    cases.append(('input-'+input_api,['tests/input_method_window_smoke.py','--tabs','--input-api',input_api,'--font',font['resolved_font']]))
for renderer in ('gdi','opengl','directx'):
    cases.append(('unicode-pixels-'+renderer,['tests/kitty_unicode_window_smoke.py','--renderer',renderer]))
    cases.append(('unicode-geometry-'+renderer,['tests/kitty_unicode_geometry_window_smoke.py','--renderer',renderer]))
cases.append(('unicode-presented-gdi',['tests/kitty_unicode_window_smoke.py','--renderer','gdi','--presented-gdi']))
for family,extra in [('sixel',[]),('inline',['--inline-images']),('animated',['--animated-images']),
                     ('kitty',['--kitty-images']),('compressed-kitty',['--kitty-images','--kitty-compression']),
                     ('unicode-kitty',['--kitty-images','--kitty-unicode'])]:
    for renderer,side in [('gdi','top'),('directx','left')]:
        cases.append((family+'-memory-'+renderer,['tests/tabs_window_smoke.py','--renderer',renderer,
            '--side',side,'--workload-memory','--cols','160','--rows','48','--font',font['resolved_font'],
            '--session-seconds','1800',*extra]))
assert len(cases)==39
# Resolve the observed portable GDI memory uncertainty on the actual product
# before spending time on the remaining local interactions. No case is removed.
priority=next(case for case in cases if case[0]=='unicode-kitty-memory-gdi')
cases.remove(priority);cases.insert(2,priority)
# The current desktop intermittently denies the clipboard preflight. Complete
# independent groups before attempting those tests; no test is removed and a
# clipboard failure still stops the run with a failing exit status.
clipboard_names={'bindings','drop-gdi','drop-directx','selection-gdi','selection-directx'}
cases=[case for case in cases if case[0] not in clipboard_names]+[case for case in cases if case[0] in clipboard_names]
assert len(cases)==39 and len({name for name,_ in cases})==39
(stage/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
env=dict(os.environ,NEMOTERM_TEST_EXE=str(stage/'dist/nemoterm.exe'),NEMOTERM_REQUIRE_OPENGL='1',
         NEMOTERM_REQUIRE_DIRECTX='1',NEMOTERM_TEST_FONT=font['resolved_font'],
         NEMOTERM_SHUTDOWN_DEADLINE_SECONDS='120',NEMOTERM_TEST_TRACEBACK_SECONDS='60')
env.pop('CI',None);env.pop('GITHUB_ACTIONS',None)
results=[]
def research_files():
    values={}
    for path in (stage/'research').rglob('*'):
        if path.is_file():
            with path.open('rb') as stream:checksum=hashlib.file_digest(stream,'sha256').hexdigest()
            values[path.relative_to(stage).as_posix()]=checksum
    return values

for name,arguments in cases:
    print('Starting local product acceptance:',name,flush=True)
    before=research_files()
    started=time.monotonic()
    with (stage/'logs'/f'{name}.log').open('w',encoding='utf-8') as log:
        try:
            result=subprocess.run([str(shutdown) if name=='shutdown' else sys.executable,*arguments],
                cwd=stage,env=env,stdout=log,stderr=subprocess.STDOUT,
                timeout=1800 if '-memory-' in name else 300)
            record=dict(name=name,exit_code=result.returncode,seconds=time.monotonic()-started)
        except subprocess.TimeoutExpired:
            record=dict(name=name,controller_timeout=True,seconds=time.monotonic()-started)
    # Some fixtures deliberately share output names across renderer/input
    # variants. Preserve each command's original evidence before the next can
    # overwrite it, including incomplete observations on failure.
    record['observations']=[]
    for relative,checksum in research_files().items():
        if before.get(relative)==checksum:continue
        target=stage/'case-evidence'/name/relative
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(stage/relative,target)
        record['observations'].append(dict(path=target.relative_to(stage).as_posix(),
                                           bytes=target.stat().st_size,sha256=checksum))
    results.append(record);(stage/'logs/results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    if record.get('exit_code')!=0:raise SystemExit(1)
assert [p.name for p in (stage/'dist').iterdir()]==['nemoterm.exe']
assert hashlib.sha256((stage/'dist/nemoterm.exe').read_bytes()).hexdigest()==digest
print('39 local commands passed; original observations still require review before promotion',flush=True)
