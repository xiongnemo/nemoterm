from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
stage=root/'build/legacy-parameter-fix-01'
records=json.loads((stage/'results.json').read_text())
assert [r['exit_code'] for r in records]==[1,0]
for report in records[1]['reports'].values():
    assert report['completed'] and len(report['cases'])==136
    assert not report['cleanup']['terminated_remaining'] and report['cleanup']['after']['active']==0
baseline=root/'build/legacy-parameter-baseline-01.log'
fixed=root/'build/legacy-parameter-fixed-01.log'
assert baseline.read_text().count('query reply differs')==20
assert fixed.read_text().strip()=='Query suite passed'
files=[]
def add(p,name):
    files.append(dict(path=name,source=p,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
add(baseline,'core/baseline.log');add(fixed,'core/fixed.log')
add(stage/'results.json','native/results.json')
for label in ('baseline','fixed'):
    add(stage/label/'native.log','native/'+label+'.log')
    add(stage/label/'dist/nemoterm.exe','images/'+label+'/nemoterm.exe')
    for p in (stage/label/'research').glob('*-observed.json'):add(p,'native/'+label+'/'+p.name)
for p in (stage/'fixed/tests').glob('*'):
    if p.is_file():add(p,'fixture/tests/'+p.name)
for name in ('conpty.dll','OpenConsole.exe','CONPTY-RUNTIME.json','SOURCE-HOST.json'):
    add(stage/'fixed/dist'/name,'images/sidecars/'+name)
for name in ('scripts/generate-legacy-parameter-reference.py','vendor/putty-0.85/terminal/terminal.c',
             'vendor/putty-0.85/test/test_queries.c'):
    add(work/name,'source/'+name)
for name in ('check-legacy-parameter-fix.py','retain-legacy-parameter-fix.py'):add(root/'build'/name,'controller/'+name)
archive=work/'research/legacy-parameter-fix.tar.gz'
assert not archive.exists()
assert len(files)==len({p['path'] for p in files})
with tarfile.open(archive,'x:gz') as tar:
    for record in files:tar.add(record['source'],arcname=record['path'],recursive=False)
validation=dict(completed=True,scope='DECREQTPARM syntax only; report identity policy is retained and full product acceptance is pending.',
    base_source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
    reference_archive_sha256='0ef5129230b862cecebdb0e6b74f3c77e0a076588886fd901766e03594db6b80',
    core=dict(reference_streams=136,whole_and_bytewise=272,baseline_failures=20,fixed_passed=True),
    native=dict(reference_streams_per_input_cp=136,input_code_pages=[28591,65001],fixed_checks=272,
                baseline_failed_case='parameters-F-plain-0:0',executable_sha256=records[1]['executable_sha256'],
                physical_input=False,clipboard_access=False,natural_cleanup=True,single_executable_acceptance=False),
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),
    files=[{k:v for k,v in record.items() if k!='source'} for record in files])
(work/'research/legacy-parameter-fix-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps({k:v for k,v in validation.items() if k!='files'},indent=2))
