from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time

root=Path(__file__).resolve().parents[1]
source=root/'build/gdi-dense-memory-worktree'
destination=root/'build/legacy-parameter-fix-01'
destination.mkdir()
host=root/'build/ci-host-restore-d914972/unverified-mingw'
assert hashlib.sha256((host/'OpenConsole.exe').read_bytes()).hexdigest()=='e3f4f7ef4a8c8105bdf8dea84bb4d135d7e0e9cfc477c2c0ca11d2489b39ed68'
results=[]
for label,image,expected in [
    ('baseline',host/'nemoterm.exe',1),
    ('fixed',root/'build/gdi-dense-memory-build/nemoterm.exe',0),
]:
    stage=destination/label
    for directory in ('dist','research','build'): (stage/directory).mkdir(parents=True)
    shutil.copytree(source/'tests',stage/'tests',ignore=shutil.ignore_patterns('__pycache__'))
    for name in ('conpty.dll','OpenConsole.exe','CONPTY-RUNTIME.json','SOURCE-HOST.json'):
        shutil.copy2(host/name,stage/'dist'/name)
    shutil.copy2(image,stage/'dist/nemoterm.exe')
    command=[sys.executable,str(stage/'tests/legacy_parameter_window_smoke.py')]
    env=dict(os.environ,NEMOTERM_TEST_EXE=str(stage/'dist/nemoterm.exe'))
    start=time.monotonic()
    with (stage/'native.log').open('w',encoding='utf-8') as log:
        result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    record=dict(label=label,exit_code=result.returncode,expected_exit=expected,
                seconds=time.monotonic()-start,executable_sha256=hashlib.sha256(image.read_bytes()).hexdigest(),
                files={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                       for p in (stage/'dist').iterdir()})
    record['reports']={p.name:json.loads(p.read_text()) for p in (stage/'research').glob('*-observed.json')}
    results.append(record)
    (destination/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(label,result.returncode,round(record['seconds'],2),flush=True)
    assert result.returncode==expected,record
    if expected==0:
        assert len(record['reports'])==2
        for report in record['reports'].values():
            assert report['completed'] and len(report['cases'])==136
            assert not report['cleanup']['terminated_remaining']
    else:
        assert 'parameters-F-plain-0:0' in (stage/'native.log').read_text()
print('Original failure and both fixed input code pages retained; no physical input or clipboard use.')
