from pathlib import Path
import hashlib,json,tarfile
root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
base=root/'build/ci-session-lifetime-900-a773546'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
run=load(base/'tabs-run.json')
assert run['databaseId']==43760974443 and run['headSha']=='a773546717b913c70c01c0d5c0beec4a4a6c481d' and run['conclusion']=='success'
identity=load(base/'diagnostic/identity.json')
observed=load(base/'diagnostic/replay-1-observed.json')
assert identity['fixture']=='tabs-unicode-900s' and identity['repetitions']==1
assert observed['executable_sha256']==identity['executable_sha256']=='4a50a382545ef40ffe06d2950e75bd71ff57a06558f3a6d518fd5653ba48319a'
assert observed['completed'] and observed['session_seconds']==900 and len(observed['checks'])==10
assert observed['actual_renderer']==1 and observed['actual_grid']==[109,34]
assert observed['memory_limit_passed'] and not observed['memory_instrumented']
assert observed['memory_limit_bytes']==20_000_000 and not observed['memory_limit_inclusive']
assert observed['peak_private_ws']<20_000_000
assert not observed['process_tree_memory']['errors'] and not observed['process_tree_memory']['injected']
assert observed['peak_private_ws']==observed['process_tree_memory']['peaks']['frontend']['private_ws']
assert observed['host_close']['exit_code']==0 and not observed['owned_job_cleanup']['terminated_remaining']
assert observed['owned_job_cleanup']['after']==dict(total=56,active=0,terminated=0)
assert len(observed['post_memory_kitty_unicode'])==4
assert all(v['matched'] and v['after_memory_sampling'] and not v['injected'] for v in observed['post_memory_kitty_unicode'])
cells=sum(v['cells_verified'] for v in observed['post_memory_kitty_unicode']);assert cells==13696
files=[]
def add(p,n):files.append(dict(path=n,source=p,bytes=p.stat().st_size,sha256=sha(p)))
for p in base.rglob('*'):
    if p.is_file():add(p,p.relative_to(base).as_posix())
add(Path(__file__),'controller/retain-session-lifetime-900.py')
archive=work/'research/session-lifetime-900.tar.gz';assert not archive.exists()
with tarfile.open(archive,'x:gz') as tar:
    for f in files:tar.add(f['source'],arcname=f['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for f in files:assert hashlib.sha256(tar.extractfile(f['path']).read()).hexdigest()==f['sha256']
result=dict(scope='Exact failed-image comparison with a longer synthetic client lifetime. Hosted grid and fixture observations only; no local 160x48 or complete product acceptance.',
    run_id=run['databaseId'],fixture_commit=run['headSha'],source_commit=identity['source_commit'],
    artifact_id=load(base/'diagnostic-download.json')['artifact_id'],executable_sha256=identity['executable_sha256'],
    elapsed_seconds=observed['elapsed_seconds'],session_seconds=900,groups=10,
    actual_grid=observed['actual_grid'],actual_renderer='GDI',private_ws_peak=observed['peak_private_ws'],
    verified_image_cells=cells,naturally_drained_processes=56,
    evidence_limit='Focused workflow retains the fixture observation, runtime identity and controller log; full raw memory samples and PNG pixels are retained by the original full CI artifacts, not this focused replay.',
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),
    files=[{k:v for k,v in f.items() if k!='source'} for f in files])
(work/'research/session-lifetime-900-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))
