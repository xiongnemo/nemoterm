import gzip,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
reference=root.parents[1]/'build/sixel-background-reference-20261114-150542'
for name,digest in json.loads((reference/'artifact-sha256.json').read_text()).items():
    assert hashlib.sha256((reference/name).read_bytes()).hexdigest()==digest,name
proof=root/'build/background-evidence';m=json.loads((proof/'manifest.json').read_text())
for name,digest in m['files'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for name,digest in m['evidence'].items():assert hashlib.sha256((proof/name).read_bytes()).hexdigest()==digest,name
files=[p for p in reference.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix in ['.json','.py','.md','.ppm','.ximage','.c','.h','.txt']]
files += [p for p in proof.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix in ['.json','.py','.md','.c','.h','.log','.diff']]
base=root/'build/background-native'
for p in base.rglob('*'):
    if not p.is_file() or any(n in p.relative_to(base).parts for n in ['dist','tests','tools','__pycache__']):continue
    if p.suffix in ['.json','.log','.bmp','.png']:files.append(p)
files += [root/'build/link-background-image.py',root/'build/check-background-native.py',Path(__file__)]
files += [root/'build/background-single'/name for name in ['image.json','link.log','link.rsp']]
dest=root/'research/sixel-background-records';dest.mkdir(exist_ok=False);records=[]
for p in sorted(set(files)):
    data=p.read_bytes();archive=dest/f'{len(records):03d}-{p.name}.gz';archive.write_bytes(gzip.compress(data,mtime=0))
    original='reference/'+str(p.relative_to(reference)) if p.is_relative_to(reference) else str(p.relative_to(root))
    records.append(dict(path=original.replace('\\','/'),archive=str(archive.relative_to(root)).replace('\\','/'),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
manifest=dict(product_commit='a7cb7bbd1977463e6165399435a7d11e0cc03424',
    image_sha256='f7afbe507a47ed3147481b5712a323fad55225ecbba3729e2f6ca820687e7e4c',
    kind='Pinned XTerm source and local owned Xvfb/Win32 observations, not REA-server Evidence',records=records)
(root/'research/sixel-background-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
for r in records:
    data=gzip.decompress((root/r['archive']).read_bytes());assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
print('Verified',len(records),'records;',sum((root/r['archive']).stat().st_size for r in records),'compressed bytes')
