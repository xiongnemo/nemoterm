# Sixel implicit foreground and opaque background fix

Branch: `fix/sixel-background-20261114`.
Base: `e436ecdad1a81e570e409c2bc856d77f4d098c45`.
Worktree: `C:/Users/nemo/Documents/Projects/nemoterm/build/sixel-background-worktree`.

## Reference and bounded scope

Reference report: `C:/Users/nemo/Documents/Projects/nemoterm/build/sixel-background-reference-20261114-150542/REPORT.md`.
It contains exact DCS/control bytes, raw XImage and PPM captures, per-pixel observations, source identity and owned-process cleanup for 35 bounded phases (26 initial, 7 narrow follow-ups, 2 VT330 controls).
Official XTerm source commit: `5c75ead9a75d4b2e666ca06fa94503b5766ed93f`.
Owned runtime: `/tmp/nemoterm-xterm-reference/xterm`, XTerm(412), SHA256 `089de40f5a47b2ee07ddb778e7e031116673c7c20a55facbd9caf8d78978573c`.

The pinned reference selects initial register 3 outside its model switch and uses register 0 for P2=0/2 fill; P2=1 uses transparent holes. The RGB defaults are model dependent: register 3 is #33cc33 for the existing VT340 palette and white for VT330. This change preserves NemoTerm's existing VT340 palette, not a universal green default for every DEC model. XTerm itself has a FIXME about physical-hardware certainty for the initial register choice; the evidence establishes pinned XTerm behavior.

Opaque fill becomes visible only when the first Sixel byte is parsed, including zero-bit `?`. Only the declared raster rectangle is filled. Without a declaration, or outside that rectangle when actual set pixels grow the image, unset pixels remain transparent. Raster-only DCS does not cover retained underlay. Both implicit set pixels and opaque fill retain palette register identity and obey private/shared palette ownership. OSC11 text-background changes flow through holes without changing register-0 fill.

This is a narrow pixel/palette fix, not full Sixel or physical VT340 conformance. Raster-only cursor-motion semantics were not separately characterized. No unrelated SGR behavior was implemented.

## Implementation and self-review

- Removed the internal decoder's literal text foreground/background API arguments. Set pixels start with index 3; tile values remain tagged register indices.
- Zero tile slots are holes. Readback synthesizes index-0 fill within two frozen declared dimensions, resolving the live per-image private/shared palette. No fill tiles, mask, or second bitmap are allocated.
- Added `has_sixels` to distinguish raster-only input from activated zero-bit fill. Terminal completion frees an invisible raster-only decoder instead of retaining an image.
- Preserved parsed shared definitions on CAN, invalidation callback, reset lifetime rules, allocation admission and the 4 MiB logical/storage budget.
- Checked every tracked C init/reset callsite after the internal API change. The removed text-color helper has no remaining callers.
- On the local Linux x86-64 ABI, decoder size is 3200 -> 3208 bytes; tile size remains 4112 and stats remains 40. `review-1.log` and `review-3.log` contain raw measurements. This is not a Windows memory measurement.

## Regression evidence

`baseline.json` + `baseline-0..3.log`: new behavior assertions were added before product edits and built against the old implementation. Decoder aborted at the first implicit default-color assertion (-6); terminal returned 1 for wrong text-derived foreground/background, raster-only retention, private/shared recoloring and reset assertions. Failures were retained, not relaxed.

`fixed-first.json` + logs: ordinary `test_sixel`, `test_sixel_terminal`, `test_state_control` passed.
`asan.json` + logs: the same three suites passed with AddressSanitizer, UndefinedBehaviorSanitizer and leak detection.
`review.json` + logs: standalone decoder regression passed strict C99 `-Wall -Wextra -Werror -pedantic`; before/after size probes compiled and ran with the same flags.

Decoder assertions cover exact implicit and fill colors, same-DCS definitions, transparent/opaque holes, no-raster versus declared bounds, raster-only versus first `?`, private/shared identity, equal-RGB/overwrite inherited tests, partial scanlines and both 32-pixel tile boundaries. Existing dense-image, bounds, 20,000 deterministic fuzz trials and allocation limits remain. Terminal assertions cover P2=0/1/2, independence from text colors, raster-only underlay/accounting, shared/private CAN recoloring and ATTR_INVALID, DECSTR retention, RIS release and restored defaults.

### Reusable Linux builds

All paths below are inside existing Debian WSL. No package was installed.

```sh
src=/mnt/c/Users/nemo/Documents/Projects/nemoterm/build/sixel-background-worktree
normal=/tmp/nemoterm-sixel-background-build-20261114-1521
cmake -S "$src/vendor/putty-0.85" -B "$normal" -G Ninja -DPUTTY_GTK_VERSION=NONE -DPUTTY_GSSAPI=OFF '-DCMAKE_C_FLAGS=-g -O1'
cmake --build "$normal" --target test_sixel test_sixel_terminal test_state_control --parallel 4
"$normal/test_sixel"
"$normal/test_sixel_terminal"
"$normal/test_state_control"

san=/tmp/nemoterm-sixel-background-asan-20261114-1534
cmake -S "$src/vendor/putty-0.85" -B "$san" -G Ninja -DPUTTY_GTK_VERSION=NONE -DPUTTY_GSSAPI=OFF '-DCMAKE_C_FLAGS=-g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer' '-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined'
cmake --build "$san" --target test_sixel test_sixel_terminal test_state_control --parallel 4
ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1 "$san/test_sixel"
ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1 "$san/test_sixel_terminal"
ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1 "$san/test_state_control"
```

The JSON manifests preserve exact argv, return codes, duration and log paths; `asan.py`, `fixed-first.py` and `review.py` replay the corresponding checks. `baseline.py` records the original pre-fix run configuration but the worktree now contains fixed source, so rerunning it is no longer a negative baseline.

## Native fixture handoff (not executed by this worker)

`tests/sixel_background_window_smoke.py` adds 22 phases through the same owned-process automation API harness as the palette test. Each phase compares all RGB values in three disjoint 8x6 probe regions, including black and transparent text-background observations; it does not accept a screenshot hash alone. It uses a fresh OwnedJob, unique registry profile, explicit PID discovery and stable session, mouse_fixture DSR output barrier, active-renderer BMP capture, owned HWND close/natural exit and finally job/profile cleanup. Captures, exact bytes, expected/observed counts and coordinate differences are retained under `research/sixel-background-<renderer>-*`.

Only syntax/static checks were run: both Python files py_compile; PowerShell parser accepted `scripts/test-single-exe.ps1`; git diff --check passed. No YAML module was available, so CI structure was reviewed manually without installing one. Both fixtures are wired into the single-executable test script and GDI/OpenGL/DirectX CI runs. The existing palette test continues to compare its original global red/green/blue pixel sets and keeps all 16 phases.

Parent should build the branch, then run each command under the existing outer 180-second controller:

```powershell
$env:NEMOTERM_TEST_EXE = 'C:\path\to\owned-build\nemoterm.exe'
python tests/sixel_background_window_smoke.py --renderer gdi
$env:NEMOTERM_REQUIRE_OPENGL = '1'
python tests/sixel_background_window_smoke.py --renderer opengl
$env:NEMOTERM_REQUIRE_DIRECTX = '1'
python tests/sixel_background_window_smoke.py --renderer directx
```

The `NEMOTERM_REQUIRE_*` checks verify the actual renderer reported by the API. Native CAN/OSC11/ConPTY behavior remains to be validated by the parent; no expectations have been changed to bypass that boundary. This worker did not run Windows applications, change the accepted EXE, use the clipboard, touch user processes, or push the branch.
