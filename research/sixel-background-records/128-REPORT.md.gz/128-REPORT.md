# Implicit Sixel foreground and opaque background reference

2026-11-14. This is a bounded local source/runtime investigation, not REA-server Evidence. No product, tracked docs, Windows executable, desktop or clipboard was changed or exercised.

## Identity and method

Official source commit: `5c75ead9a75d4b2e666ca06fa94503b5766ed93f` from ThomasDickey/xterm-snapshots. `source-manifest.json` preserves exact URLs and SHA-256 values; source copies retain upstream notices. Existing Debian XTerm reports `XTerm(412)`, executable SHA-256 `089de40f5a47b2ee07ddb778e7e031116673c7c20a55facbd9caf8d78978573c`. Adjacent runtime source hashes match the pinned copies. The executable was reused, not rebuilt.

`background_oracle.py`, `narrow_oracle.py`, and `vt330_oracle.py` each create an owned Xvfb display (`-displayfd`, `-nolisten tcp`) and one owned XTerm. All owned processes exited, as recorded in their observations JSON files. No tools/packages were installed. No existing display or process was controlled. There were 26 initial bounded phases, seven narrow confirmations, and two VT330 model checks. Exact sent bytes, replies, full XImage bytes, PPM captures and hashes are retained. Each phase captures immediately after its DSR barrier plus 150 ms, and again after explicit Expose plus 150 ms; these captures agree in all examined regions for this investigation.

The calibration draws an explicit 8x6 red image and observes exactly 48 red pixels at `(3,3)..(10,8)`. Subsequent `rois` preserve all 48 RGB pixels for each sampled 8x6 area at text rows 1, 4 and 7. Contrast text background is set by OSC 11 to magenta `ff00ff`; changing it to cyan `00ffff` makes transparent holes observable. DCS parameter 1 is 9 (square pixels even without DECGRA); declared fixtures also use `"1;1;8;6`. Cursor is hidden. Ordinary model is `-ti vt340`; the two model checks explicitly use `-ti vt330`.

## Confirmed behavior

1. **Default set-pixel identity is register 3.** With no `#` selection, `@` sets one pixel to `33cc33` under VT340. Redefining register 3 after drawing that pixel recolors it red. OSC 10 and text SGR foreground changes do not select the Sixel foreground.
2. **P2=0 and P2=2 use register 0 for the initialized opaque background.** In a declared 8x6 image with one set pixel, the other 47 pixels are initially black, despite the magenta text background. Same-DCS `#0;2;0;0;100?` makes those 47 pixels blue. The original implicit set pixel remains register-3 green.
3. **P2=1 leaves holes transparent.** The same one-set-pixel image leaves 47 magenta pixels visible. Defining register 0 blue does not color those holes; OSC 11 changing to cyan turns them cyan.
4. **Opaque fill retains register identity across shared images.** A later shared DCS redefining only register 0 turns the retained 47 background pixels blue, while its implicit foreground stays green. Changing OSC 11 to cyan leaves that blue fill intact and changes only the text background outside the image. This is not a literal copy of the OSC 11 background.
5. **Private versus shared palette lifetime applies to both implicit foreground and fill.** Later private definitions do not recolor an earlier private image. Later shared definitions of registers 3 and 0 recolor earlier shared set pixels/fill. A subsequent shared image inherits those changed colors; a subsequent private image initializes its independent default palette.
6. **RIS clears the images and resets the shared Sixel palette.** After custom shared red foreground/blue fill, RIS leaves only the existing magenta text background visible. A new shared opaque image is again register-3 green plus register-0 black. The retained OSC 11 magenta is independent of the reset Sixel palette in this tested XTerm configuration.

The principal samples are in `observations.json`; isolated register-0 and transparency confirmations are in `narrow-confirmation/observations.json`.

## The fill rectangle and activation boundary

Opaque must not mean every unset pixel inside the eventual image bounds:

* **No declared raster extent:** `@?A` draws only the two set pixels at `(0,0)` and `(2,1)`. Its other pixels are holes, even for P2=0. After OSC 11 changes, all 46 other pixels in the sampled 8x6 area follow the new text background. This includes holes inside the 3x2 actual set-pixel extent.
* **Small declared extent:** `"1;1;2;2@?A` gives two green set pixels, three black fill pixels in the declared 2x2 rectangle, and 43 transparent pixels in the sampled 8x6 region. In particular `(2,0)` remains transparent although actual set-pixel extent reaches column 2. OSC 11 turns those holes cyan while the three black pixels stay black.
* **Raster declaration alone is not painted:** an 8x6 raster-only DCS over an earlier red image leaves all 48 red pixels visible. It never reaches the first Sixel byte that initializes background and marks the graphic valid.
* **The first zero-bit Sixel still activates fill:** adding `?` to that raster-only opaque DCS covers the underlay with 48 register-0 black pixels even though no set bit is drawn. Under P2=1, the corresponding zero-bit DCS leaves the red underlay visible.

These boundaries are essential: blindly replacing every fallback background value with a register-0 tag would introduce opaque pixels where the reference still has holes.

## Pinned source and model distinction

`graphics_sixel.c:392` initializes `current_register=3` after the terminal-model aspect-ratio switch; the line has an upstream FIXME about historical hardware color certainty. `graphics_sixel.c:435-442` chooses `COLOR_HOLE` only for P2=1 and register 0 otherwise, without a model branch. Thus the **register indices** are model-independent in this pinned implementation, not an inference that every model has the same RGB defaults.

`graphics.c:580-592` initializes register 3 to white for VT330 and to `(20,80,20)` percent green for VT340. `vt330/observations.json` confirms one implicit white pixel and 47 black fill pixels under VT330; redefining registers 3/0 gives one red pixel and 47 blue pixels. NemoTerm currently has a VT340-style color palette; matching the known register indices does not require introducing a new VT330 palette mode.

`graphics_sixel.c:123-148` fills the initialized rectangle with background register indices. `:568-570` and `:818-821` initialize the background and mark the graphic valid upon the first repeat-Sixel or ordinary Sixel, including zero-bit `?`. `:670-675` extends actual dimensions from raster declaration, while `:180-186` extends them when set pixels are drawn. Initialization occurs once, before those first set bits grow actual extents. `graphics.c:1003-1008` resolves these stored indices through the image's live palette at repaint.

## Current patched decoder comparison

`investigation-identity.json` records the inspected palette-fix checkout and copied decoder hashes. `decoder_probe.c` compiles the unmodified copies using existing Linux GCC; build/run records and all raw/composited pixels are in `decoder-compile.json`, `decoder-run.json`, and `decoder-observations.json`.

With passed foreground white/background magenta, the current decoder gives:

* One white implicit pixel and 47 magenta opaque pixels, rather than green/black. Redefining registers 3 or 0 does not recolor these direct RGB values, even when the decoder is bound to a shared palette.
* An opaque 3x2 actual extent for both no-raster and 2x2-declared sparse cases; all four non-set pixels inside 3x2 are fixed magenta. Compositing over later cyan exposes the overly broad fill.
* A raster-only 8x6 result that covers a red underlay with 48 magenta pixels, although the reference leaves the underlay intact until a Sixel byte is consumed.

These are semantic comparison failures, not crashes. Compiler and owned runtime invocations succeeded; all observed differences and command results are retained. The existing explicit-register patch is intact and does not by itself fix these implicit RGB/fill cases.

## Minimal next fix supported by this evidence

* Initialize the decoder's selected pixel value to register 3, using the existing tagged-index representation and its current VT340 default palette. Remove/replace the actual terminal's direct text-foreground/text-background initialization path for Sixel.
* Track the declared raster fill rectangle separately from the actual set-pixel bounds. For P2=0/2, activate register-0 fill only on the first consumed Sixel character (including zero bits/repeat); P2=1 never activates opaque fill. Outside that rectangle preserve transparent holes even as actual dimensions grow.
* Synthesize unallocated background scanline portions from the activated rectangle and live palette; keep empty stored tile cells transparent and distinguish painted indices. No complete bitmap or extra pixel plane is necessary.
* Ensure a raster-only DCS cannot cover earlier content. Preserve shared/private ownership and parsed-definition side effects already implemented; cancellation must not undo shared definitions even if no image became visible.
* Add exact color/alpha checks across a tile boundary and exercise same/later-DCS background redefinition, first `?`, no-raster holes, zero-set-bit fill, CAN and reset. Retain the 4 MiB allocation/geometry bounds.

No product change is part of this reference directory. This evidence does not establish broad Sixel conformance, real VT hardware behavior, every emulation model, malformed/repeated late DECGRA, every palette-reset operation, or Windows renderer behavior. Those remain outside this bounded investigation.
