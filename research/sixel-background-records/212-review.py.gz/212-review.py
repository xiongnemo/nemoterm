import json,subprocess,time
from pathlib import Path
here=Path(__file__).resolve().parent;repo=here.parents[1]
commands=[]
for name in ['before','after']:
 commands += [['gcc','-std=c99','-Wall','-Wextra','-Werror','-pedantic',str(here/f'size-{name}.c'),'-o',str(here/f'size-{name}')],[str(here/f'size-{name}')]]
commands += [['gcc','-std=c99','-Wall','-Wextra','-Werror','-pedantic','-I',str(repo/'vendor/putty-0.85/terminal'),str(repo/'tests/test_sixel.c'),str(repo/'vendor/putty-0.85/terminal/nemo_sixel.c'),'-o',str(here/'strict-test-sixel')],[str(here/'strict-test-sixel')]]
results=[]
for i,cmd in enumerate(commands):
 start=time.monotonic();proc=subprocess.run(cmd,capture_output=True,text=True)
 name=f'review-{i}.log';(here/name).write_text(proc.stdout+proc.stderr)
 result={'argv':cmd,'returncode':proc.returncode,'seconds':time.monotonic()-start,'log':name};results.append(result)
 print(json.dumps(result),flush=True)
 if proc.returncode:break
(here/'review.json').write_text(json.dumps(results,indent=2)+'\n')
