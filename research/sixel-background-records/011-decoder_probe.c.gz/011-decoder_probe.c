#include "nemo_sixel.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#define WHITE 0xffffffffu
#define MAGENTA 0xffff00ffu
#define CYAN 0xff00ffffu
#define RED 0xffff0000u
static NemoSixel *fresh(bool transparent) {
    NemoSixel *s=nemo_sixel_init(0,WHITE,MAGENTA,transparent);assert(s);return s;
}
static void feed(NemoSixel *s,const char *payload) {
    assert(nemo_sixel_feed(s,payload,strlen(payload))&&nemo_sixel_finish(s));
}
static unsigned records;
static void show(const char *name,NemoSixel *s,uint32_t underlay) {
    NemoSixelStats st=nemo_sixel_stats(s);
    printf("%s{\"name\":\"%s\",\"width\":%u,\"height\":%u,\"allocated_bytes\":%zu,\"underlay\":\"%08x\",\"raw_8x6\":[",
        records++?",\n":"",name,st.width,st.height,st.allocated_bytes,underlay);
    for(unsigned y=0;y<6;y++) {
        uint32_t row[8]={0};nemo_sixel_read_row(s,y,0,row,8);printf("%s[",y?",":"");
        for(unsigned x=0;x<8;x++)printf("%s\"%08x\"",x?",":"",row[x]);
        putchar(']');
    }
    printf("],\"composited_8x6\":[");
    for(unsigned y=0;y<6;y++) {
        uint32_t row[8]={0};nemo_sixel_read_row(s,y,0,row,8);printf("%s[",y?",":"");
        for(unsigned x=0;x<8;x++)printf("%s\"%08x\"",x?",":"",row[x]>>24?row[x]:underlay);
        putchar(']');
    }
    printf("]}");
}
int main(void) {
    const struct {const char *name,*payload;bool transparent;uint32_t underlay;} cases[]={
        {"p2-0-implicit","\"1;1;8;6@",false,MAGENTA},
        {"p2-1-implicit","\"1;1;8;6@",true,MAGENTA},
        {"p2-2-implicit","\"1;1;8;6@",false,MAGENTA},
        {"implicit-redefine3","\"1;1;8;6@#3;2;100;0;0?",false,MAGENTA},
        {"opaque-redefine0","\"1;1;8;6@#0;2;0;0;100?",false,MAGENTA},
        {"opaque-OSC11-after","\"1;1;8;6@",false,CYAN},
        {"no-raster-OSC11-after","@?A",false,CYAN},
        {"small-raster-OSC11-after","\"1;1;2;2@?A",false,CYAN},
        {"raster-only-over-red","\"1;1;8;6",false,RED},
        {"raster-zero-bits-over-red","\"1;1;8;6?",false,RED}
    };
    puts("[");
    for(unsigned i=0;i<sizeof(cases)/sizeof(*cases);i++) {
        NemoSixel *s=fresh(cases[i].transparent);feed(s,cases[i].payload);
        show(cases[i].name,s,cases[i].underlay);nemo_sixel_free(s);
    }
    uint32_t palette[256];
    NemoSixel *old=fresh(false),*next=fresh(true);
    nemo_sixel_get_palette(old,palette);
    assert(nemo_sixel_share_palette(old,palette,NULL,NULL));
    assert(nemo_sixel_share_palette(next,palette,NULL,NULL));
    feed(old,"\"1;1;8;6@");show("shared-before",old,MAGENTA);
    feed(next,"#0;2;0;0;100#3;2;100;0;0?");
    show("shared-after",old,MAGENTA);
    nemo_sixel_free(old);nemo_sixel_free(next);
    puts("\n]");return 0;
}
