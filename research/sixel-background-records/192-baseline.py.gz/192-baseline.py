import json,os,resource,subprocess,time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
here=Path(__file__).resolve().parent
repo=here.parents[1]
build=Path('/tmp/nemoterm-sixel-background-build-20261114-1521')
assert not build.exists(),build
commands=[['cmake','-S',str(repo/'vendor/putty-0.85'),'-B',str(build),'-G','Ninja','-DPUTTY_GTK_VERSION=NONE','-DPUTTY_GSSAPI=OFF','-DCMAKE_C_FLAGS=-g -O1'],['cmake','--build',str(build),'--target','test_sixel','test_sixel_terminal','--parallel','4'],[str(build/'test_sixel')],[str(build/'test_sixel_terminal')]]
results=[]
for i,cmd in enumerate(commands):
 start=time.monotonic();proc=subprocess.run(cmd,capture_output=True,text=True)
 name=f'baseline-{i}.log';(here/name).write_text(proc.stdout+proc.stderr)
 result={'argv':cmd,'returncode':proc.returncode,'seconds':time.monotonic()-start,'log':name};results.append(result)
 print(json.dumps(result),flush=True)
 if i<2 and proc.returncode:break
(here/'baseline.json').write_text(json.dumps(results,indent=2)+'\n')
