import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/background-native';base.mkdir(exist_ok=False)
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
before=root.parents[1]/'dist/nemoterm.exe';after=root/'build/background-single/nemoterm.exe'
assert hashlib.sha256(before.read_bytes()).hexdigest()=='aa11c5398c102feef624764dda1a09ba96afadc33151358166c02e1eaf998bba'
cases=[('before-gdi',before,'sixel_background','gdi',1)]
cases += [('after-'+m,after,'sixel_background',m,0) for m in ('gdi','opengl','directx')]
cases += [('palette-'+m,after,'sixel_palette',m,0) for m in ('gdi','opengl','directx')]
cases += [('renderer',after,'renderer',None,0),('sixel',after,'sixel',None,0)]
results=[]
for label,exe,test,mode,expected in cases:
    dest=base/label
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    arguments=['--renderer',mode] if mode else []
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),test,*arguments],cwd=root,
            stdout=log,stderr=subprocess.STDOUT).returncode
    record=dict(label=label,exit_code=code,expected_exit_code=expected)
    if mode:
        report=dest/'research'/f"{test.replace('_','-')}-{mode}-observed.json"
        if report.exists():
            data=json.loads(report.read_text());record.update(completed=data['completed'],
                checks=len(data['checks']),matched=sum(c['matched'] for c in data['checks']))
            if expected:
                assert [r['name'] for r in data['checks']]==['p2-0-implicit-colours'],data.get('error')
                assert not data['checks'][0]['matched']
                assert not data['cleanup']['terminated_remaining']
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(record,flush=True)
    if code!=expected:
        print((dest/'controller.log').read_text()[-3500:]);raise SystemExit(1)
