#include <stdio.h>
#include "before/nemo_sixel.c"
int main(void){printf("decoder=%zu tile=%zu stats=%zu\n",sizeof(NemoSixel),sizeof(SixelTile),sizeof(NemoSixelStats));return 0;}
