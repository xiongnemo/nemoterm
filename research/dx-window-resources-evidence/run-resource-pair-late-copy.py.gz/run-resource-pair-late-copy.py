import json,shutil,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/ci-relative-43517911793'
dest=base/'resource-pair-02';assert not dest.exists()
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
results=[]
for mode,side in [('gdi','top'),('directx','left')]:
    preparation_start=time.monotonic()
    folder=dest/mode
    for name in ('dist','research','build','tools'):(folder/name).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',folder/'tests')
    shutil.copy2(root/'tools/nemoterm_debug.py',folder/'tools')
    shutil.copy2(base/'product/nemoterm.exe',folder/'dist')
    if mode=='directx':
        for name in ('tabs_window_smoke.py','owned_window_events.py'):
            shutil.copy2(base/'resource-pair-01/directx/tests'/name,folder/'tests')
    start=time.monotonic()
    with (folder/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(folder),'tabs','--renderer',mode,'--side',side,
            '--cols','160','--rows','48','--workload-memory'],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    results.append(dict(mode=mode,exit_code=code,preparation_start_monotonic=preparation_start,
                        start_monotonic=start,end_monotonic=time.monotonic()))
    (dest/'pair-results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(results[-1]),flush=True)
    if mode=='gdi' and code:raise SystemExit(code)
