import hashlib,json,shutil,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/ci-alignment-43515344377'
dest=base/('dx-resource-events-'+sys.argv[1])
assert not dest.exists()
for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
shutil.copytree(root/'tests',dest/'tests')
shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
shutil.copy2(base/'product/nemoterm.exe',dest/'dist')
shutil.copy2(root/'build/owned_window_events.py',dest/'tests')
path=dest/'tests/tabs_window_smoke.py';original=path.read_text(encoding='utf-8');text=original
def change(before,after):
    global text
    assert text.count(before)==1,before
    text=text.replace(before,after)
change('import winreg','import winreg\nfrom owned_window_events import OwnedWindowEvents')
change('memory_sampler=None;census_observer=None','memory_sampler=None;census_observer=None;window_watch=None')
change('        try:\n            if args.workload_memory:',
       "        try:\n            window_watch=OwnedWindowEvents(process.pid,root/'research/resource-window-events.json')\n            evidence['resource_events_diagnostic']=True\n            evidence['memory_acceptance']=False\n            if args.workload_memory:")
change('            for i in range(12):',
       "            window_watch.mark('baseline',baseline)\n            window_watch.snapshot('baseline')\n            for i in range(12):")
change("                sample=resources();evidence['cycles'].append(sample)",
       "                sample=resources();evidence['cycles'].append(sample)\n                window_watch.mark('post-close-'+str(i+1),sample)\n                if sample['handles']>baseline['handles']+6 or sample['gdi']>baseline['gdi']+3 or sample['user']>baseline['user']+2:\n                    window_watch.snapshot('failed-resource-gate')")
marker="            evidence['checks'].append('12 create/close cycles retain one shared renderer without handle growth')"
change(marker,marker+"\n            window_watch.snapshot('resource-phase-complete')\n            u.PostMessageW(host,0x10,0,0);process.wait(timeout=15)\n            assert process.returncode==0,process.returncode\n            evidence['owned_job_cleanup']=job.finish(grace=5)\n            assert not evidence['owned_job_cleanup']['terminated_remaining']\n            evidence['diagnostic_completed']=True\n            raise SystemExit(2)")
change('        finally:\n            try:\n                if census_observer:',
       '        finally:\n            if window_watch:window_watch.close()\n            try:\n                if census_observer:')
if len(sys.argv)>2 and sys.argv[2]=='passive':
    change("root/'research/resource-window-events.json')", "root/'research/resource-window-events.json',event_hook=False)")
path.write_text(text,encoding='utf-8')
digest=lambda b:hashlib.sha256(b).hexdigest()
(dest/'research/diagnostic-fixture.json').write_text(json.dumps(dict(
    original_sha256=digest(original.encode()),modified_sha256=digest(text.encode()),
    purpose='Creation/destruction metadata only; unchanged resource assertions; stop after twelve cycles',
    injected=False,memory_acceptance=False),indent=2)+'\n',encoding='utf-8')
print(dest)
