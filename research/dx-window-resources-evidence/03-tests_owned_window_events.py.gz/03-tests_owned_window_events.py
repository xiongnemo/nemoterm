"""Bounded out-of-context WinEvent metadata for one freshly owned PID."""
import ctypes as c
from ctypes import wintypes as w
import json
import threading
import time

u=c.WinDLL('user32',use_last_error=True)
k=c.WinDLL('kernel32',use_last_error=True)
ps=c.WinDLL('psapi',use_last_error=True)
EVENT=c.WINFUNCTYPE(None,w.HANDLE,w.DWORD,w.HWND,w.LONG,w.LONG,w.DWORD,w.DWORD)
ENUM=c.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
u.SetWinEventHook.argtypes=[w.DWORD,w.DWORD,w.HMODULE,EVENT,w.DWORD,w.DWORD,w.DWORD]
u.SetWinEventHook.restype=w.HANDLE
u.UnhookWinEvent.argtypes=[w.HANDLE]
u.UnhookWinEvent.restype=w.BOOL
u.PeekMessageW.argtypes=[c.POINTER(w.MSG),w.HWND,w.UINT,w.UINT,w.UINT]
u.PeekMessageW.restype=w.BOOL
u.GetWindowThreadProcessId.argtypes=[w.HWND,c.POINTER(w.DWORD)]
u.GetWindowThreadProcessId.restype=w.DWORD
u.GetClassNameW.argtypes=[w.HWND,w.LPWSTR,c.c_int]
u.GetClassLongPtrW.argtypes=[w.HWND,c.c_int]
u.GetClassLongPtrW.restype=c.c_size_t
u.GetParent.argtypes=[w.HWND];u.GetParent.restype=w.HWND
u.IsWindowVisible.argtypes=[w.HWND];u.IsWindowVisible.restype=w.BOOL
u.EnumWindows.argtypes=[ENUM,w.LPARAM]
u.EnumChildWindows.argtypes=[w.HWND,ENUM,w.LPARAM]
k.OpenProcess.argtypes=[w.DWORD,w.BOOL,w.DWORD];k.OpenProcess.restype=w.HANDLE
k.CloseHandle.argtypes=[w.HANDLE]
k.GetTickCount64.restype=c.c_ulonglong
ps.EnumProcessModules.argtypes=[w.HANDLE,c.POINTER(w.HMODULE),w.DWORD,c.POINTER(w.DWORD)]
ps.EnumProcessModules.restype=w.BOOL
ps.GetModuleBaseNameW.argtypes=[w.HANDLE,w.HMODULE,w.LPWSTR,w.DWORD]
ps.GetModuleBaseNameW.restype=w.DWORD
class MODULEINFO(c.Structure):
    _fields_=[('base',c.c_void_p),('size',w.DWORD),('entry',c.c_void_p)]
ps.GetModuleInformation.argtypes=[w.HANDLE,w.HMODULE,c.POINTER(MODULEINFO),w.DWORD]
ps.GetModuleInformation.restype=w.BOOL


class OwnedWindowEvents:
    def __init__(self,pid,path):
        assert pid>0
        self.pid=pid;self.path=path;self.start=time.monotonic()
        self.tick=k.GetTickCount64()&0xffffffff
        self.events=[];self.phases=[];self.snapshots=[];self.cache={};self.errors=[]
        self.lock=threading.RLock();self.stop=threading.Event();self.ready=threading.Event()
        self.truncated=False;self.hook=None;self.closed=False
        self.thread=threading.Thread(target=self.pump,name='owned-window-events',daemon=True)
        self.thread.start()
        if not self.ready.wait(3) or not self.hook:
            self.close()
            raise RuntimeError(('WinEvent hook unavailable',self.errors))

    def info(self,hwnd):
        pid=w.DWORD();tid=u.GetWindowThreadProcessId(hwnd,c.byref(pid))
        if pid.value!=self.pid:return None
        name=c.create_unicode_buffer(256)
        u.GetClassNameW(hwnd,name,len(name))
        return dict(hwnd=int(hwnd),kind=name.value,thread=tid,parent=int(u.GetParent(hwnd) or 0),
                    visible=bool(u.IsWindowVisible(hwnd)),class_module=int(u.GetClassLongPtrW(hwnd,-16)),
                    class_wndproc=int(u.GetClassLongPtrW(hwnd,-24)))

    def pump(self):
        @EVENT
        def callback(hook,event,hwnd,obj,child,tid,milliseconds):
            if not hwnd or obj!=0 or child!=0:return
            try:
                info=self.info(hwnd)
                with self.lock:
                    if info:self.cache[int(hwnd)]=info
                    elif event==0x8001:info=self.cache.get(int(hwnd))
                    if not info:return
                    if len(self.events)>=8192:self.truncated=True;return
                    self.events.append(dict(event='create' if event==0x8000 else 'destroy',
                        seconds=round(time.monotonic()-self.start,6),
                        source_milliseconds=(milliseconds-self.tick)&0xffffffff,**info))
                    if event==0x8001:self.cache.pop(int(hwnd),None)
            except BaseException as exc:self.errors.append(repr(exc))
        try:
            # OUTOFCONTEXT=0. Restrict both events to this exact owned PID.
            self.hook=u.SetWinEventHook(0x8000,0x8001,None,callback,self.pid,0,0)
            if not self.hook:raise c.WinError(c.get_last_error())
            self.ready.set()
            message=w.MSG()
            while True:
                for _ in range(2048):
                    if not u.PeekMessageW(c.byref(message),None,0,0,1):break
                    u.TranslateMessage(c.byref(message));u.DispatchMessageW(c.byref(message))
                if self.stop.is_set():break
                self.stop.wait(.01)
        except BaseException as exc:self.errors.append(repr(exc))
        finally:
            self.ready.set()
            if self.hook and not u.UnhookWinEvent(self.hook):self.errors.append('UnhookWinEvent failed')

    def mark(self,name,sample=None):
        with self.lock:
            self.phases.append(dict(name=name,seconds=round(time.monotonic()-self.start,6),resources=sample))

    def snapshot(self,name):
        windows=[]
        @ENUM
        def child(hwnd,_):
            info=self.info(hwnd)
            if info:windows.append(info)
            return True
        @ENUM
        def top(hwnd,_):
            info=self.info(hwnd)
            if info:
                windows.append(info)
                u.EnumChildWindows(hwnd,child,0)
            return True
        u.EnumWindows(top,0)
        handle=k.OpenProcess(0x410,False,self.pid)
        modules={};ranges=[]
        if handle:
            try:
                array=(w.HMODULE*2048)();needed=w.DWORD()
                if not ps.EnumProcessModules(handle,array,c.sizeof(array),c.byref(needed)):
                    self.errors.append('EnumProcessModules failed')
                elif needed.value>c.sizeof(array):self.errors.append('module table overflow')
                else:
                    for address in array[:needed.value//c.sizeof(w.HMODULE)]:
                        module=c.create_unicode_buffer(256)
                        if ps.GetModuleBaseNameW(handle,address,module,len(module)):
                            modules[str(int(address))]=module.value
                            info=MODULEINFO()
                            if ps.GetModuleInformation(handle,address,c.byref(info),c.sizeof(info)):
                                ranges.append(dict(name=module.value,base=int(info.base),size=info.size))
            finally:k.CloseHandle(handle)
        with self.lock:
            self.snapshots.append(dict(name=name,seconds=round(time.monotonic()-self.start,6),
                                       windows=windows,modules=modules,module_ranges=ranges))
            for window in windows:self.cache[window['hwnd']]=window

    def close(self):
        if self.closed:return
        self.closed=True
        self.stop.set();self.thread.join(3)
        if self.thread.is_alive():self.errors.append('observer did not stop within three seconds')
        with self.lock:
            value=dict(pid=self.pid,out_of_context=True,injected=False,memory_acceptance=False,
                events=self.events,phases=self.phases,snapshots=self.snapshots,errors=self.errors,
                truncated=self.truncated,observer_stopped=not self.thread.is_alive())
            self.path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
