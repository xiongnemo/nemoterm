import hashlib,json,shutil,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/ci-relative-43517911793'
dest=base/'resource-pair-01';assert not dest.exists()
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
for mode in ('gdi','directx'):
    folder=dest/mode
    for name in ('dist','research','build','tools'):(folder/name).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',folder/'tests')
    shutil.copy2(root/'tools/nemoterm_debug.py',folder/'tools')
    shutil.copy2(base/'product/nemoterm.exe',folder/'dist')
fixture=dest/'directx/tests/tabs_window_smoke.py'
source=(base/'local-workload-directx/tests/tabs_window_smoke.py').read_text(encoding='utf-8')
shutil.copy2(base/'local-workload-directx/tests/owned_window_events.py',dest/'directx/tests')
def replace(before,after):
    global source
    assert source.count(before)==1,before
    source=source.replace(before,after)
function='''def baseline_window_snapshot(pid):
    found={}
    @callback
    def record(hwnd,_):
        owner=w.DWORD();tid=u.GetWindowThreadProcessId(hwnd,c.byref(owner))
        if owner.value==pid:
            name=c.create_unicode_buffer(256);u.GetClassNameW(hwnd,name,len(name))
            found[int(hwnd)]=dict(hwnd=int(hwnd),kind=name.value,thread=tid)
        return True
    @callback
    def top(hwnd,_):
        owner=w.DWORD();u.GetWindowThreadProcessId(hwnd,c.byref(owner))
        if owner.value==pid:
            record(hwnd,0);u.EnumChildWindows(hwnd,record,0)
        return True
    u.EnumWindows(top,0)
    u.FindWindowExW.argtypes=[w.HWND,w.HWND,w.LPCWSTR,w.LPCWSTR];u.FindWindowExW.restype=w.HWND
    previous=None
    for _ in range(8192):
        hwnd=u.FindWindowExW(w.HWND(-3),previous,None,None)
        if not hwnd:break
        previous=hwnd;record(hwnd,0)
    else:raise RuntimeError('Message-window enumeration limit reached')
    return list(found.values())

def diagnostic_counts(handle):
    value=w.DWORD()
    ok=k.GetProcessHandleCount(handle,c.byref(value))
    return dict(handles=value.value if ok else None,gdi=u.GetGuiResources(handle,0),user=u.GetGuiResources(handle,1))

'''
replace('evidence=dict(executable_sha256=',function+'evidence=dict(executable_sha256=')
replace('            for i in range(12):',"""            evidence['paired_resource_diagnostic']=True
            evidence['memory_acceptance']=False
            evidence['baseline_counts_before_snapshot']=diagnostic_counts(handle)
            try:evidence['baseline_windows']=baseline_window_snapshot(process.pid)
            except Exception as diagnostic_error:evidence['baseline_snapshot_error']=repr(diagnostic_error)
            evidence['baseline_counts_after_snapshot']=diagnostic_counts(handle)
            for i in range(12):""")
replace("                    evidence['resource_failure_snapshot_requested']=True",
        "                    evidence['resource_failure_snapshot_requested']=True\n                    evidence['resource_counts_before_observer']=diagnostic_counts(handle)")
replace('                        if observer:observer.close()',"""                        if observer:observer.close()
                    evidence['resource_counts_after_observer']=diagnostic_counts(handle)
                    evidence['after_failed_sample_extra_cycles']=[]
                    try:
                        for extra in range(8):
                            followup=duplicate(second);output(followup,scene('DIAGNOSTIC FOLLOWUP','60;10;60'))
                            u.PostMessageW(followup['hwnd'],0x10,0,0)
                            wait_for(lambda:not u.IsWindow(followup['hwnd']))
                            select(second,1);wait_for(lambda:job.accounting()['active']==5)
                            evidence['after_failed_sample_extra_cycles'].append(resources())
                        evidence['after_extra_windows']=baseline_window_snapshot(process.pid)
                    except Exception as diagnostic_error:evidence['resource_followup_error']=repr(diagnostic_error)
                    # Keep sample and baseline unchanged for the original assertion.
""")
marker="            evidence['checks'].append('12 create/close cycles retain one shared renderer without handle growth')"
replace(marker,marker+"""
            u.PostMessageW(host,0x10,0,0);process.wait(timeout=15)
            assert process.returncode==0,process.returncode
            evidence['owned_job_cleanup']=job.finish(grace=5)
            assert not evidence['owned_job_cleanup']['terminated_remaining']
            evidence['diagnostic_completed']=True
            raise SystemExit(2)""")
fixture.write_text(source,encoding='utf-8')
compile(source,str(fixture),'exec')
results=[]
for mode,side in [('gdi','top'),('directx','left')]:
    folder=dest/mode;start=time.monotonic()
    with (folder/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(folder),'tabs','--renderer',mode,'--side',side,
            '--cols','160','--rows','48','--workload-memory'],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    results.append(dict(mode=mode,exit_code=code,start_monotonic=start,end_monotonic=time.monotonic()))
    (dest/'pair-results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(results[-1]),flush=True)
    if mode=='gdi' and code:raise SystemExit(code)
