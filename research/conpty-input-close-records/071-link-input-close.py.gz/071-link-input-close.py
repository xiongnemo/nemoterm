import hashlib,json,re,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1];dest=root/'build/input-close-single';dest.mkdir(exist_ok=False)
host=root.parent/'rtl-worktree/build/openconsole-single'
args=(root/'build/host-visibility-02/link.rsp').read_text(encoding='utf-8')
for flag,suffix in [('OUT','exe'),('PDB','pdb'),('IMPLIB','lib')]:
    args,n=re.subn('/'+flag+r':"[^"]+"',lambda _:'/'+flag+':"'+str(dest/('nemoterm.'+suffix))+'"',args,flags=re.I);assert n==1
rsp=dest/'link.rsp';rsp.write_text(args,encoding='utf-8')
with (dest/'link.log').open('w',encoding='utf-8') as log:
    subprocess.run(['link.exe','@'+str(rsp)],cwd=host/'src/host/exe',stdout=log,stderr=subprocess.STDOUT,check=True)
inputs=[]
for value in re.findall(r'"([^"\n]+\.(?:lib|obj|res))"',args,re.I):
    p=Path(value)
    if p.is_file():inputs.append(dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
p=dest/'nemoterm.exe';v=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),inputs=inputs)
(dest/'image.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8');print({k:v[k] for k in ('bytes','sha256')})
