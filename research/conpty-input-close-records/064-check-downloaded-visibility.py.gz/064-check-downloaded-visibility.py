import json,os,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
exe=next((root/'build/ci-visibility-unverified').rglob('nemoterm.exe'))
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
results=[]
for label,name,args in [('startup','startup_visibility',[]),('relative','relative_cursor',[]),
                        ('gdi','tabs',['--renderer','gdi','--side','top','--cols','160','--rows','48','--workload-memory'])]:
    dest=root/'build'/('downloaded-visibility-'+label);assert not dest.exists()
    for folder in ('dist','research','build'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),name,*args],
            cwd=root,env=dict(os.environ,NEMOTERM_TEST_TRACEBACK_SECONDS='5'),stdout=log,stderr=subprocess.STDOUT).returncode
    results.append(dict(label=label,exit_code=code))
    print(label,(dest/'controller.log').read_text(encoding='utf-8')[-2400:],flush=True)
    (root/'build/downloaded-visibility-results.json').write_text(json.dumps(results,indent=2)+'\n')
    if code:raise SystemExit(code)
