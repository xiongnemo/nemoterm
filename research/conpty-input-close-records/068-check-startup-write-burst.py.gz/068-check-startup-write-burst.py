import json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];dest=root/'build/startup-shutdown-write-burst';assert not dest.exists()
for folder in ('dist','research','build'):(dest/folder).mkdir(parents=True,exist_ok=True)
shutil.copytree(root/'tests',dest/'tests');shutil.copy2(next((root/'build/ci-visibility-unverified').rglob('nemoterm.exe')),dest/'dist')
p=dest/'tests/startup_visibility_window_smoke.py';s=p.read_text()
s=s.replace('for tabbed in (False,True):','for tabbed in (True,)*6:')
s=s.replace("write_snapshot(tmp/'control.json',dict(stop=True));process.wait(timeout=8)","""write_snapshot(tmp/'control.json',dict(stop=True))
                        try:process.wait(timeout=8)
                        except subprocess.TimeoutExpired:
                            case['last_report']=read_snapshot(tmp/'report.json')
                            case['job_before_observation']=job.accounting()
                            found=[]
                            @c.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
                            def record(hwnd,_):
                                owner=w.DWORD();tid=u.GetWindowThreadProcessId(hwnd,c.byref(owner))
                                if owner.value==process.pid:
                                    name=c.create_unicode_buffer(256);text=c.create_unicode_buffer(2048)
                                    u.GetClassNameW(hwnd,name,len(name));u.GetWindowTextW(hwnd,text,len(text))
                                    found.append(dict(hwnd=int(hwnd),tid=tid,kind=name.value,title=text.value,
                                        visible=bool(u.IsWindowVisible(hwnd)),enabled=bool(u.IsWindowEnabled(hwnd))))
                                return True
                            @c.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
                            def top(hwnd,_):
                                owner=w.DWORD();u.GetWindowThreadProcessId(hwnd,c.byref(owner))
                                if owner.value==process.pid:
                                    record(hwnd,0);u.EnumChildWindows(hwnd,record,0)
                                return True
                            u.EnumWindows(top,0);case['windows_at_failure']=found
                            result=c.c_size_t()
                            u.SendMessageTimeoutW.argtypes=[w.HWND,w.UINT,w.WPARAM,w.LPARAM,w.UINT,w.UINT,c.POINTER(c.c_size_t)]
                            case['ui_responsive']=bool(u.SendMessageTimeoutW(host,0,0,0,2,2000,c.byref(result)))
                            raise""")
s=s.replace("process=job.spawn(","write_events=[];instrument=None\n                    process=job.spawn(")
s=s.replace("host=wait_for(lambda:top_window", """import frida
                        instrument=frida.attach(process.pid)
                        probe=instrument.create_script("Interceptor.attach(Process.getModuleByName('kernelbase.dll').getExportByName('WriteFile'),{onEnter(args){this.h=args[0].toString();this.caller=this.returnAddress;},onLeave(result){if(result.toInt32()===0&&this.lastError!==997){const m=Process.findModuleByAddress(this.caller);send({handle:this.h,error:this.lastError,caller:m?m.name:null,rva:m?this.caller.sub(m.base).toString():null});}}});")
                        probe.on('message',lambda message,data:write_events.append(message) if len(write_events)<64 else None)
                        probe.load()
                        host=wait_for(lambda:top_window""")
s=s.replace("finally:case.setdefault('cleanup',job.finish(grace=0))", """finally:
                        case['write_events']=write_events
                        case.setdefault('cleanup',job.finish(grace=0))
                        if instrument and not instrument.is_detached:
                            from frida_test_utils import detach_session
                            detach_session(instrument)""")
p.write_text(s)
f=dest/'tests/startup_visibility_fixture.py'
t=f.read_text();t=t.replace("if request.get('stop'):break","if request.get('stop'):\n        print('\\x1b[5n'*4000,end='',flush=True)\n        break");f.write_text(t)
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
with (dest/'controller.log').open('w',encoding='utf-8') as log:
 code=subprocess.run([sys.executable,str(controller),str(dest),'startup_visibility'],stdout=log,stderr=subprocess.STDOUT).returncode
print((dest/'controller.log').read_text(encoding='utf-8')[-2500:]);raise SystemExit(code)
