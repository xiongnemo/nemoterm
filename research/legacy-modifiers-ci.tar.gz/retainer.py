from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1]
base=root/'build/ci-legacy-modifiers-029bfac'
work=root/'build/gdi-dense-memory-worktree'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source='029bfac4434d59a66dbd991d8281a94fe166e647'
run_id=43776658169
run=load(base/'ansi-components-run.json')
assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(run_id,source,'completed','success')
jobs={j['name']:j['conclusion'] for j in run['jobs']}
assert jobs['linux (gcc)']==jobs['linux (clang)']==jobs['msvc']=='success'
source_hashes={};checkout_variants={};source_bytes={}
def verify_source(path,checksum):
    if path not in source_hashes:
        raw=subprocess.check_output(['git','show',source+':'+path],cwd=work)
        source_bytes[path]=raw
        source_hashes[path]=hashlib.sha256(raw).hexdigest()
    if source_hashes[path]!=checksum.lower():
        # .gitattributes pins .c/.h to LF but leaves these .inc text files at
        # the runner checkout's default. Verify the exact CRLF variant only.
        assert path in ['vendor/putty-0.85/terminal/'+name for name in (
            'nemo_feature_policy_terminal.inc','nemo_udk_terminal.inc',
            'nemo_locator_terminal.inc','nemo_kitty_terminal.inc')],path
        raw=source_bytes[path];assert b'\r' not in raw
        assert hashlib.sha256(raw.replace(b'\n',b'\r\n')).hexdigest()==checksum.lower(),path
        checkout_variants[path]=checksum.lower()
artifacts={}
for compiler in ('gcc','clang','msvc'):
    folder=base/'ansi-components'/compiler
    log=(folder/'test_mok.log').read_text(encoding='utf-8-sig')
    assert log.rstrip().endswith('Modified keys suite passed')
    assert '2872 unchanged steps (whole)' in log and '2872 unchanged steps (bytes)' in log
    if compiler=='msvc':assert '243 unchanged steps' in log
    receipt=load(base/'ansi-components'/(compiler+'-download.json'))
    assert receipt['source']==source and receipt['run_id']==run_id
    for item in receipt['files']:
        path=folder/item['path'];assert path.stat().st_size==item['bytes'] and digest(path)==item['sha256']
    artifacts[compiler]=receipt['artifact_id']
    if compiler=='msvc':
        for name in ('sources.json','special-key-sources.json','colour-sources.json','legacy-key-sources.json'):
            for entry in load(folder/name):
                path=entry['Path'].split('\\nemoterm\\nemoterm\\',1)[1].replace('\\','/')
                verify_source(path,entry['Hash'])
    else:
        for line in (folder/'sources.sha256').read_text().splitlines():
            checksum,path=line.split(maxsplit=1);verify_source(path,checksum)
paths={p:p.relative_to(base).as_posix() for p in (base/'ansi-components').rglob('*') if p.is_file()}
for name in ('ansi-components-run.json','ansi-components-run.log','ansi-components-artifacts.json'):
    paths[base/name]=name
paths[Path(__file__)]='retainer.py'
archive=work/'research/legacy-modifiers-ci.tar.gz';records=[]
with archive.open('xb') as raw,tarfile.open(fileobj=raw,mode='w:gz') as bundle:
    for path,name in sorted(paths.items(),key=lambda pair:pair[1]):
        records.append(dict(path=name,bytes=path.stat().st_size,sha256=digest(path)))
        bundle.add(path,arcname=name,recursive=False)
with tarfile.open(archive) as bundle:
    assert len(set(bundle.getnames()))==len(bundle.getnames())==len(records)
    for item in records:
        raw=bundle.extractfile(item['path']).read()
        assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
record=dict(source=source,run_id=run_id,conclusion='success',artifacts=artifacts,
    reference_steps=2872,replay_modes=['whole','bytewise'],extended_mapper_regression_steps=243,
    verified_source_hashes=source_hashes,
    verified_windows_crlf_variants=checkout_variants,
    scope='Component GCC/Clang ASan/UBSan and MSVC; source receipts match exact Git content, including four verified Windows CRLF checkout variants for .inc files. Full product CI and native acceptance remain separate.',
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=digest(archive)),records=records)
with (work/'research/legacy-modifiers-ci-validation.json').open('x',encoding='utf-8') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('records','verified_source_hashes')},indent=2))
