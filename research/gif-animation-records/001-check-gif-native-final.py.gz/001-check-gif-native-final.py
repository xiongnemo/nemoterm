from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];base=root/'build/gif-native-02';base.mkdir()
old=root.parent/'iterm-images-worktree/build/iterm-single-03/nemoterm.exe'
new=root/'build/gif-single-02/nemoterm.exe'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='6c1bfae51422477abe5a87c3a2e44bb0843ba2d27d75d33cea68cba3ae97711b'
assert hashlib.sha256(new.read_bytes()).hexdigest()=='c83b8f54000b017116069419eedb7f6cfbaacd1fd8b7d69d134f4d1a5f734299'
cases=[('before','gif_animation','gdi',old)]
cases += [('gif-'+r,'gif_animation',r,new) for r in ['gdi','opengl','directx']]
cases += [('static-'+r,'iterm_image',r,new) for r in ['gdi','opengl','directx']]
cases=cases[1:]
results=[]
for name,test,renderer,exe in cases:
    dest=base/name
    for directory in ('dist','research','build','tools'):(dest/directory).mkdir(parents=True)
    shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(exe,dest/'dist/nemoterm.exe')
    with (dest/'controller.log').open('w') as log:
        result=subprocess.run([sys.executable,str(root.parent/'rtl-worktree/build/run-owned-check.py'),str(dest),test,'--renderer',renderer],stdout=log,stderr=subprocess.STDOUT)
    suite='gif-animation' if test=='gif_animation' else 'iterm-images'
    observed=dest/f'research/{suite}-{renderer}-observed.json'
    d=json.loads(observed.read_text()) if observed.exists() else {}
    record=dict(name=name,exit_code=result.returncode,completed=d.get('completed'),actual_renderer=d.get('actual_renderer'),checks=len(d.get('checks',[])),error=d.get('error'))
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps(record),flush=True)
    if name=='before':
        assert result.returncode==1 and d['checks'][0]['name']=='infinite-red' and not d['checks'][0]['matched']
        assert d['checks'][0]['observed_counts']['black']==2 and not d['cleanup']['terminated_remaining']
    elif result.returncode:
        print((dest/'controller.log').read_text()[-3500:]);raise SystemExit(result.returncode)

