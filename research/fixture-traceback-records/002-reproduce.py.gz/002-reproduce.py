import faulthandler,json,sys,time
from pathlib import Path
faulthandler.dump_traceback_later(.005, repeat=True)
limit=time.monotonic()+3
def read():
    return json.loads(Path(__file__).read_text().split('# DATA:')[-1])
while time.monotonic()<limit:
    value=read()
faulthandler.cancel_dump_traceback_later()
print('COMPLETED',flush=True)
# DATA:{"probe":true}
