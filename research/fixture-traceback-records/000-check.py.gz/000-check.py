import json,subprocess
from pathlib import Path
base=Path(__file__).resolve().parent;rows=[]
for index in range(8):
    with (base/f'old-{index}.log').open('wb') as log:
        run=subprocess.run([str(base/'runtime/python.exe'),str(base/'reproduce.py')],
                           stdout=log,stderr=subprocess.STDOUT,timeout=15)
    rows.append(dict(index=index,exit_code=run.returncode))
    print(rows[-1],flush=True)
(base/'old-results.json').write_text(json.dumps(rows,indent=2))
