import faulthandler,json,sys,time
from pathlib import Path
sys.path.insert(0,'C:\\Users\\nemo\\Documents\\Projects\\nemoterm\\build\\startup-worktree\\tests')
from fixture_traceback import start_periodic_tracebacks
stop=start_periodic_tracebacks(.005)
limit=time.monotonic()+3
def read():
    return json.loads(Path(__file__).read_text().split('# DATA:')[-1])
while time.monotonic()<limit:
    value=read()
stop()
print('COMPLETED',flush=True)
# DATA:{"probe":true}
