from pathlib import Path
import json,os,subprocess
root=Path(__file__).resolve().parents[1]
tests=['test_iso2022_charset','test_state_control','test_queries','test_rectangle',
       'test_sixel_terminal','test_reflow','test_keyboard','test_grapheme_terminal','test_sgr']
dest=root/'build/checksum-linux-01';dest.mkdir(exist_ok=False);results=[]
for kind in ('normal','sanitizers'):
    base=root/'build/charset-upss-linux'/kind
    commands=[['cmake','--build',str(base),'--target',*tests,'--parallel','2']]
    commands.extend([[str(base/test)] for test in tests])
    for i,command in enumerate(commands):
        log=dest/f'{kind}-{i:02}.log'
        with log.open('w') as output:
            run=subprocess.run(command,cwd=root,stdout=output,stderr=subprocess.STDOUT,
                env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1'))
        results.append(dict(kind=kind,command=command,exit_code=run.returncode,log=str(log)))
        (dest/'results.json').write_text(json.dumps(results,indent=2)+'\n')
        print(kind,i,run.returncode,flush=True)
        if run.returncode:
            print(log.read_text()[-2000:]);raise SystemExit(run.returncode)
