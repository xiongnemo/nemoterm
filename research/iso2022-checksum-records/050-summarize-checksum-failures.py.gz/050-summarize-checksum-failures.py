import json,re,sys
from pathlib import Path
path=Path(sys.argv[1]); records=[]
for line in path.read_text(encoding='utf-8').splitlines():
    name=re.search(r'charset checksum (.*?) / fragmented (\d+)',line)
    if not name:continue
    sides=line.split("' != '")
    if len(sides)!=2:continue
    a=re.findall(r'\x1bP\d+!~([0-9A-F]{4})\x1b\\',sides[0])
    b=re.findall(r'\x1bP\d+!~([0-9A-F]{4})\x1b\\',sides[1])
    diff=[dict(mode='legacy' if i<96 else 'unicode',byte=hex(0x20+i%96),actual=x,expected=y)
          for i,(x,y) in enumerate(zip(a,b)) if x!=y]
    records.append(dict(name=name[1],fragmented=int(name[2]),counts=[len(a),len(b)],differences=diff))
path.with_suffix('.summary.json').write_text(json.dumps(records,indent=2))
print('failed cases',len(records),'differences',sum(len(r['differences']) for r in records))
for record in records[:24]:
    print(record['name'],record['counts'],len(record['differences']),record['differences'][:4])
