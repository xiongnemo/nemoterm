/*
 * Terminal emulator.
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <limits.h>
#include <wchar.h>

#include <time.h>
#include <assert.h>
#include "putty.h"
#include "terminal.h"
#include "nemo_colour.h"
#include "nemo_charset.h"

static void term_bidi_cache_clear_line(Terminal *term, size_t line);
static void nemo_reset_ansi_colours(Terminal *term);
static void nemo_set_reverse_video(Terminal *term, bool state);

#define VT52_PLUS

#define CL_ANSIMIN      0x0001         /* Codes in all ANSI like terminals. */
#define CL_VT100        0x0002         /* VT100 */
#define CL_VT100AVO     0x0004         /* VT100 +AVO; 132x24 (not 132x14) & attrs */
#define CL_VT102        0x0008         /* VT102 */
#define CL_VT220        0x0010         /* VT220 */
#define CL_VT320        0x0020         /* VT320 */
#define CL_VT420        0x0040         /* VT420 */
#define CL_VT510        0x0080         /* VT510, NB VT510 includes ANSI */
#define CL_VT340TEXT    0x0100         /* VT340 extensions that appear in the VT420 */
#define CL_SCOANSI      0x1000         /* SCOANSI not in ANSIMIN. */
#define CL_ANSI         0x2000         /* ANSI ECMA-48 not in the VT100..VT420 */
#define CL_OTHER        0x4000         /* Others, Xterm, linux, putty, dunno, etc */

#define TM_VT100        (CL_ANSIMIN|CL_VT100)
#define TM_VT100AVO     (TM_VT100|CL_VT100AVO)
#define TM_VT102        (TM_VT100AVO|CL_VT102)
#define TM_VT220        (TM_VT102|CL_VT220)
#define TM_VT340        (TM_VT220|CL_VT320|CL_VT340TEXT)
#define TM_VT420        (TM_VT340|CL_VT420)
#define TM_VTXXX        (TM_VT420|CL_VT510)
#define TM_SCOANSI      (CL_ANSIMIN|CL_SCOANSI)

#define TM_PUTTY        (0xFFFF)

#define UPDATE_DELAY    ((TICKSPERSEC+49)/50)/* ticks to defer window update */
#define TBLINK_DELAY    ((TICKSPERSEC*9+19)/20)/* ticks between text blinks*/
#define CBLINK_DELAY    (CURSORBLINK) /* ticks between cursor blinks */
#define VBELL_DELAY     (VBELL_TIMEOUT) /* visual bell timeout in ticks */

#define compatibility(x) \
    if ( ((CL_##x)&term->compatibility_level) == 0 ) {  \
       term->termstate=TOPLEVEL;                        \
       break;                                           \
    }
#define compatibility2(x,y) \
    if ( ((CL_##x|CL_##y)&term->compatibility_level) == 0 ) { \
       term->termstate=TOPLEVEL;                        \
       break;                                           \
    }

#define has_compat(x) ( ((CL_##x)&term->compatibility_level) != 0 )

static const char *const EMPTY_WINDOW_TITLE = "";

/* Only call this for generated protocol records. Payload bytes are not scanned:
 * text, UTF-8, clipboard data and configured answerback are never transcoded.
 * Framing may arrive as separate DCS/OSC header, payload and ST writes. */
static void nemo_protocol_send(Terminal *term, const void *data, int len)
{
    const unsigned char *p = data;
    if (!term->ldisc || len <= 0) return;
    bool prefix = term->c1_8bit && len >= 2 && p[0] == 0x1b &&
        (p[1] == '[' || p[1] == 'P' || p[1] == ']' || p[1] == '\\');
    bool suffix = prefix && (p[1] == 'P' || p[1] == ']') && len >= 4 &&
        p[len-2] == 0x1b && p[len-1] == '\\';
    if (prefix) {
        char c1[2];
        int size = ldisc_format_c1(term->ldisc, c1, p[1] + 0x40);
        ldisc_send(term->ldisc, c1, size, false);
        p += 2; len -= 2;
    }
    if (suffix) len -= 2;
    if (len) ldisc_send(term->ldisc, p, len, false);
    if (suffix) {
        char st[2];
        int size = ldisc_format_c1(term->ldisc, st, 0x9c);
        ldisc_send(term->ldisc, st, size, false);
    }
}

int term_format_c1_key(Terminal *term, char *buf, int len)
{
    if (term->c1_8bit && !term->vt52_mode && len >= 3 && buf[0] == 0x1b &&
        (buf[1] == '[' || buf[1] == 'O')) {
        char c1[2];
        int size = ldisc_format_c1(term->ldisc, c1, (unsigned char)buf[1] + 0x40);
        memmove(buf+size, buf+2, len-2);
        memcpy(buf, c1, size);
        return len-2+size;
    }
    return len;
}

/* XTerm shares ten slots between stack and indexed title operations. Allocate
 * only on the first push. Bound both depth and saved strings independently of
 * any locally configured title, and retain each string's original encoding. */
#define TITLE_STACK_SLOTS 10
#define TITLE_STACK_STRING_MAX 4096
#define TITLE_WIRE_MAX 1000
struct nemo_saved_title {
    char *text[2];                  /* icon, window; NULL differs from empty */
    int codepage[2];
};
struct nemo_title_stack {
    unsigned next, depth;
    struct nemo_saved_title slot[TITLE_STACK_SLOTS];
};

/* Fixed slot count, lazy snapshots: an unused terminal pays one pointer.
 * Slots survive pops because indexed restoration can revisit them. */
#define PALETTE_STACK_SLOTS 10
struct NemoPaletteSnapshot {
    rgb entries[OSC4_NCOLOURS];
    optionalrgb selection[2];
    optionalrgb attributes[5];
};
struct NemoPaletteStack {
    unsigned used, last;
    struct NemoPaletteSnapshot *slot[PALETTE_STACK_SLOTS];
};

static void nemo_palette_stack_free(struct NemoPaletteStack *stack)
{
    if (!stack) return;
    for (unsigned i = 0; i < PALETTE_STACK_SLOTS; i++) sfree(stack->slot[i]);
    sfree(stack);
}

static void nemo_saved_title_free(struct nemo_saved_title *title)
{
    for (unsigned i = 0; i < 2; i++) {
        sfree(title->text[i]);
        title->text[i] = NULL;
    }
}

static void nemo_title_stack_free(struct nemo_title_stack *stack)
{
    if (!stack) return;
    for (unsigned i = 0; i < TITLE_STACK_SLOTS; i++)
        nemo_saved_title_free(&stack->slot[i]);
    sfree(stack);
}

static const char sco2ansicolour[] = { 0, 4, 2, 6, 1, 5, 3, 7 };

#define sel_nl_sz  (sizeof(sel_nl)/sizeof(wchar_t))
static const wchar_t sel_nl[] = SEL_NL;

/* forward declaration */
static void term_userpass_state_free(struct term_userpass_state *s);

/*
 * Fetch the character at a particular position in a line array,
 * for purposes of `wordtype'. The reason this isn't just a simple
 * array reference is that if the character we find is UCSWIDE,
 * then we must look one space further to the left.
 */
#define UCSGET(a, x) \
    ( (x)>0 && (a)[(x)].chr == UCSWIDE ? (a)[(x)-1].chr : (a)[(x)].chr )

/*
 * Detect the various aliases of U+0020 SPACE.
 */
#define IS_SPACE_CHR(chr) \
        ((chr) == 0x20 || (DIRECT_CHAR(chr) && ((chr) & 0xFF) == 0x20))

/*
 * Spot magic CSETs.
 */
#define CSET_OF(chr) (DIRECT_CHAR(chr)||DIRECT_FONT(chr) ? (chr)&CSET_MASK : 0)

/*
 * Internal prototypes.
 */
static void resizeline(Terminal *, termline *, int);
static termline *lineptr(Terminal *, int, int);
static void check_line_size(Terminal *, termline *);
static void do_paint(Terminal *);
static void erase_lots(Terminal *, bool, bool, bool);
static int find_last_nonempty_line(Terminal *, tree234 *);
static void swap_screen(Terminal *, int, bool, bool);
static void update_sbar(Terminal *);
static void deselect(Terminal *);
static void term_print_finish(Terminal *);
static uint32_t nemo_checksum_legacy(unsigned long ch);
static bool nemo_charset_base_utf8(Terminal *term);
static void scroll(Terminal *, int, int, int, bool);
static void check_boundary(Terminal *, int, int);
static bool nemo_in_lr(Terminal *term)
{
    return term->curs.x >= term->marg_l && term->curs.x <= term->marg_r;
}
static int nemo_cr_x(Terminal *term)
{
    return term->curs.x >= term->marg_l ? term->marg_l : 0;
}
static int nemo_right(Terminal *term)
{
    return term->curs.x <= term->marg_r ? term->marg_r : term->cols-1;
}
static void nemo_linefeed(Terminal *term)
{
    if (term->curs.y == term->marg_b) {
        if (nemo_in_lr(term)) scroll(term, term->marg_t, term->marg_b, 1, true);
    } else if (term->curs.y < term->rows-1) term->curs.y++;
}
static void term_added_data(Terminal *term, bool);
static void term_update_raw_mouse_mode(Terminal *term);
static void nemo_highlight_cancel(Terminal *term, bool report);
static void nemo_highlight_request(Terminal *term);
static void term_out_cb(void *);
static void osc52_cancel_query(Terminal *term)
{
    nemo_osc52_cancel(term->osc52);
    term->osc52_query_pending = false;
    if (term->osc52_query_id < UINT64_MAX) term->osc52_query_id++;
}

static termline *newtermline(Terminal *term, int cols, bool bce)
{
    termline *line;
    int j;

    line = snew(termline);
    line->chars = snewn(cols, termchar);
    for (j = 0; j < cols; j++)
        line->chars[j] = (bce ? term->erase_char : term->basic_erase_char);
    line->cols = line->size = cols;
    line->lattr = LATTR_NORM;
    line->trusted = false;
    line->temporary = false;
    line->cc_free = 0;

    return line;
}

static void freetermline(termline *line)
{
    if (line) {
        sfree(line->chars);
        sfree(line);
    }
}

void term_release_line(termline *line)
{
    if (line->temporary)
        freetermline(line);
}

const int colour_indices_conf_to_oscp[CONF_NCOLOURS] = {
    #define COLOUR_ENTRY(id,name) OSCP_COLOUR_##id,
    CONF_COLOUR_LIST(COLOUR_ENTRY)
    #undef COLOUR_ENTRY
};

const int colour_indices_conf_to_osc4[CONF_NCOLOURS] = {
    #define COLOUR_ENTRY(id,name) OSC4_COLOUR_##id,
    CONF_COLOUR_LIST(COLOUR_ENTRY)
    #undef COLOUR_ENTRY
};

const int colour_indices_oscp_to_osc4[OSCP_NCOLOURS] = {
    #define COLOUR_ENTRY(id) OSC4_COLOUR_##id,
    OSCP_COLOUR_LIST(COLOUR_ENTRY)
    #undef COLOUR_ENTRY
};

#ifdef TERM_CC_DIAGS
/*
 * Diagnostic function: verify that a termline has a correct
 * combining character structure.
 *
 * This is a performance-intensive check, so it's no longer enabled
 * by default.
 */
static void cc_check(termline *line)
{
    unsigned char *flags;
    int i, j;

    assert(line->size >= line->cols);

    flags = snewn(line->size, unsigned char);

    for (i = 0; i < line->size; i++)
        flags[i] = (i < line->cols);

    for (i = 0; i < line->cols; i++) {
        j = i;
        while (line->chars[j].cc_next) {
            j += line->chars[j].cc_next;
            assert(j >= line->cols && j < line->size);
            assert(!flags[j]);
            flags[j] = true;
        }
    }

    j = line->cc_free;
    if (j) {
        while (1) {
            assert(j >= line->cols && j < line->size);
            assert(!flags[j]);
            flags[j] = true;
            if (line->chars[j].cc_next)
                j += line->chars[j].cc_next;
            else
                break;
        }
    }

    j = 0;
    for (i = 0; i < line->size; i++)
        j += (flags[i] != 0);

    assert(j == line->size);

    sfree(flags);
}
#endif

static void clear_cc(termline *line, int col);

/*
 * Add a combining character to a character cell.
 */
static void add_cc(termline *line, int col, unsigned long chr)
{
    int newcc;

    assert(col >= 0 && col < line->cols);

    /*
     * Don't add combining characters at all to U+FFFD REPLACEMENT
     * CHARACTER. (Partly it's a slightly incoherent idea in the first
     * place; mostly, U+FFFD is what we generate if a cell already has
     * too many ccs, in which case we want it to be a fixed point when
     * further ccs are added.)
     */
    if (line->chars[col].chr == 0xFFFD)
        return;

    /*
     * Walk the cc list of the cell in question to find its current
     * end point.
     */
    size_t ncc = 0;
    int origcol = col;
    while (line->chars[col].cc_next) {
        col += line->chars[col].cc_next;
        if (++ncc >= CC_LIMIT) {
            /*
             * There are already too many combining characters in this
             * character cell. Change strategy: throw out the entire
             * chain and replace the main character with U+FFFD.
             *
             * (Rationale: extrapolating from UTR #36 section 3.6.2
             * suggests the principle that it's better to substitute
             * U+FFFD than to _ignore_ input completely. Also, if the
             * user copies and pastes an overcombined character cell,
             * this way it will clearly indicate that we haven't
             * reproduced the writer's original intentions, instead of
             * looking as if it was the _writer's_ fault that the 33rd
             * cc is missing.)
             *
             * Per the code above, this will also prevent any further
             * ccs from being added to this cell.
             */
            clear_cc(line, origcol);
            line->chars[origcol].chr = 0xFFFD;
            return;
        }
    }

    /*
     * Extend the cols array if the free list is empty.
     */
    if (!line->cc_free) {
        int n = line->size;

        size_t tmpsize = line->size;
        sgrowarray(line->chars, tmpsize, tmpsize);
        assert(tmpsize <= INT_MAX);
        line->size = tmpsize;

        line->cc_free = n;
        while (n < line->size) {
            if (n+1 < line->size)
                line->chars[n].cc_next = 1;
            else
                line->chars[n].cc_next = 0;
            n++;
        }
    }

    /*
     * `col' now points at the last cc currently in this cell; so
     * we simply add another one.
     */
    newcc = line->cc_free;
    if (line->chars[newcc].cc_next)
        line->cc_free = newcc + line->chars[newcc].cc_next;
    else
        line->cc_free = 0;
    line->chars[newcc].cc_next = 0;
    line->chars[newcc].chr = chr;
    line->chars[col].cc_next = newcc - col;

#ifdef TERM_CC_DIAGS
    cc_check(line);
#endif
}

/*
 * Clear the combining character list in a character cell.
 */
static void clear_cc(termline *line, int col)
{
    int oldfree, origcol = col;

    assert(col >= 0 && col < line->cols);

    if (!line->chars[col].cc_next)
        return;                        /* nothing needs doing */

    oldfree = line->cc_free;
    line->cc_free = col + line->chars[col].cc_next;
    while (line->chars[col].cc_next)
        col += line->chars[col].cc_next;
    if (oldfree)
        line->chars[col].cc_next = oldfree - col;
    else
        line->chars[col].cc_next = 0;

    line->chars[origcol].cc_next = 0;

#ifdef TERM_CC_DIAGS
    cc_check(line);
#endif
}

/*
 * Compare two character cells for equality. Special case required
 * in do_paint() where we override what we expect the chr and attr
 * fields to be.
 */
static bool termchars_equal_override(termchar *a, termchar *b,
                                     unsigned long bchr, unsigned long battr)
{
    /* FULL-TERMCHAR */
    if (!truecolour_equal(a->truecolour, b->truecolour))
        return false;
    if (a->hyperlink != b->hyperlink)
        return false;
    if (a->chr != bchr)
        return false;
    if ((a->attr &~ DATTR_MASK) != (battr &~ DATTR_MASK))
        return false;
    while (a->cc_next || b->cc_next) {
        if (!a->cc_next || !b->cc_next)
            return false;              /* one cc-list ends, other does not */
        a += a->cc_next;
        b += b->cc_next;
        if (a->chr != b->chr)
            return false;
    }
    return true;
}

static bool termchars_equal(termchar *a, termchar *b)
{
    return termchars_equal_override(a, b, b->chr, b->attr);
}

/*
 * Copy a character cell. (Requires a pointer to the destination
 * termline, so as to access its free list.)
 */
static void copy_termchar(termline *destline, int x, termchar *src)
{
    clear_cc(destline, x);

    destline->chars[x] = *src;         /* copy everything except cc-list */
    destline->chars[x].cc_next = 0;    /* and make sure this is zero */

    while (src->cc_next) {
        src += src->cc_next;
        add_cc(destline, x, src->chr);
    }

#ifdef TERM_CC_DIAGS
    cc_check(destline);
#endif
}

/*
 * Move a character cell within its termline.
 */
static void move_termchar(termline *line, termchar *dest, termchar *src)
{
    /* First clear the cc list from the original char, just in case. */
    clear_cc(line, dest - line->chars);

    /* Move the character cell and adjust its cc_next. */
    *dest = *src;                      /* copy everything except cc-list */
    if (src->cc_next)
        dest->cc_next = src->cc_next - (dest-src);

    /* Ensure the original cell doesn't have a cc list. */
    src->cc_next = 0;

#ifdef TERM_CC_DIAGS
    cc_check(line);
#endif
}

#ifndef NO_SCROLLBACK_COMPRESSION

/*
 * Compress and decompress a termline into an RLE-based format for
 * storing in scrollback. (Since scrollback almost never needs to
 * be modified and exists in huge quantities, this is a sensible
 * tradeoff, particularly since it allows us to continue adding
 * features to the main termchar structure without proportionally
 * bloating the terminal emulator's memory footprint unless those
 * features are in constant use.)
 */
static void makerle(strbuf *b, termline *ldata,
                    void (*makeliteral)(strbuf *b, termchar *c,
                                        unsigned long *state))
{
    int hdrpos, hdrsize, n, prevlen, prevpos, thislen, thispos;
    bool prev2;
    termchar *c = ldata->chars;
    unsigned long state = 0, oldstate;

    n = ldata->cols;

    hdrpos = b->len;
    hdrsize = 0;
    put_byte(b, 0);
    prevlen = prevpos = 0;
    prev2 = false;

    while (n-- > 0) {
        thispos = b->len;
        makeliteral(b, c++, &state);
        thislen = b->len - thispos;
        if (thislen == prevlen &&
            !memcmp(b->u + prevpos, b->u + thispos, thislen)) {
            /*
             * This literal precisely matches the previous one.
             * Turn it into a run if it's worthwhile.
             *
             * With one-byte literals, it costs us two bytes to
             * encode a run, plus another byte to write the header
             * to resume normal output; so a three-element run is
             * neutral, and anything beyond that is unconditionally
             * worthwhile. With two-byte literals or more, even a
             * 2-run is a win.
             */
            if (thislen > 1 || prev2) {
                int runpos, runlen;

                /*
                 * It's worth encoding a run. Start at prevpos,
                 * unless hdrsize==0 in which case we can back up
                 * another one and start by overwriting hdrpos.
                 */

                hdrsize--;             /* remove the literal at prevpos */
                if (prev2) {
                    assert(hdrsize > 0);
                    hdrsize--;
                    prevpos -= prevlen;/* and possibly another one */
                }

                if (hdrsize == 0) {
                    assert(prevpos == hdrpos + 1);
                    runpos = hdrpos;
                    strbuf_shrink_to(b, prevpos+prevlen);
                } else {
                    memmove(b->u + prevpos+1, b->u + prevpos, prevlen);
                    runpos = prevpos;
                    strbuf_shrink_to(b, prevpos+prevlen+1);
                    /*
                     * Terminate the previous run of ordinary
                     * literals.
                     */
                    assert(hdrsize >= 1 && hdrsize <= 128);
                    b->u[hdrpos] = hdrsize - 1;
                }

                runlen = prev2 ? 3 : 2;

                while (n > 0 && runlen < 129) {
                    int tmppos, tmplen;
                    tmppos = b->len;
                    oldstate = state;
                    makeliteral(b, c, &state);
                    tmplen = b->len - tmppos;
                    bool match = tmplen == thislen &&
                        !memcmp(b->u + runpos+1, b->u + tmppos, tmplen);
                    strbuf_shrink_to(b, tmppos);
                    if (!match) {
                        state = oldstate;
                        break;         /* run over */
                    }
                    n--, c++, runlen++;
                }

                assert(runlen >= 2 && runlen <= 129);
                b->u[runpos] = runlen + 0x80 - 2;

                hdrpos = b->len;
                hdrsize = 0;
                put_byte(b, 0);
                /* And ensure this run doesn't interfere with the next. */
                prevlen = prevpos = 0;
                prev2 = false;

                continue;
            } else {
                /*
                 * Just flag that the previous two literals were
                 * identical, in case we find a third identical one
                 * we want to turn into a run.
                 */
                prev2 = true;
                prevlen = thislen;
                prevpos = thispos;
            }
        } else {
            prev2 = false;
            prevlen = thislen;
            prevpos = thispos;
        }

        /*
         * This character isn't (yet) part of a run. Add it to
         * hdrsize.
         */
        hdrsize++;
        if (hdrsize == 128) {
            b->u[hdrpos] = hdrsize - 1;
            hdrpos = b->len;
            hdrsize = 0;
            put_byte(b, 0);
            prevlen = prevpos = 0;
            prev2 = false;
        }
    }

    /*
     * Clean up.
     */
    if (hdrsize > 0) {
        assert(hdrsize <= 128);
        b->u[hdrpos] = hdrsize - 1;
    } else {
        strbuf_shrink_to(b, hdrpos);
    }
}
static void makeliteral_chr(strbuf *b, termchar *c, unsigned long *state)
{
    /*
     * My encoding for characters is UTF-8-like, in that it stores
     * 7-bit ASCII in one byte and uses high-bit-set bytes as
     * introducers to indicate a longer sequence. However, it's
     * unlike UTF-8 in that it doesn't need to be able to
     * resynchronise, and therefore I don't want to waste two bits
     * per byte on having recognisable continuation characters.
     * Also I don't want to rule out the possibility that I may one
     * day use values 0x80000000-0xFFFFFFFF for interesting
     * purposes, so unlike UTF-8 I need a full 32-bit range.
     * Accordingly, here is my encoding:
     *
     * 00000000-0000007F: 0xxxxxxx (but see below)
     * 00000080-00003FFF: 10xxxxxx xxxxxxxx
     * 00004000-001FFFFF: 110xxxxx xxxxxxxx xxxxxxxx
     * 00200000-0FFFFFFF: 1110xxxx xxxxxxxx xxxxxxxx xxxxxxxx
     * 10000000-FFFFFFFF: 11110ZZZ xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx
     *
     * (`Z' is like `x' but is always going to be zero since the
     * values I'm encoding don't go above 2^32. In principle the
     * five-byte form of the encoding could extend to 2^35, and
     * there could be six-, seven-, eight- and nine-byte forms as
     * well to allow up to 64-bit values to be encoded. But that's
     * completely unnecessary for these purposes!)
     *
     * The encoding as written above would be very simple, except
     * that 7-bit ASCII can occur in several different ways in the
     * terminal data; sometimes it crops up in the D800 page
     * (CSET_ASCII) but at other times it's in the 0000 page (real
     * Unicode). Therefore, this encoding is actually _stateful_:
     * the one-byte encoding of 00-7F actually indicates `reuse the
     * upper three bytes of the last character', and to encode an
     * absolute value of 00-7F you need to use the two-byte form
     * instead.
     */
    if ((c->chr & ~0x7F) == *state) {
        put_byte(b, (unsigned char)(c->chr & 0x7F));
    } else if (c->chr < 0x4000) {
        put_byte(b, (unsigned char)(((c->chr >> 8) & 0x3F) | 0x80));
        put_byte(b, (unsigned char)(c->chr & 0xFF));
    } else if (c->chr < 0x200000) {
        put_byte(b, (unsigned char)(((c->chr >> 16) & 0x1F) | 0xC0));
        put_uint16(b, c->chr & 0xFFFF);
    } else if (c->chr < 0x10000000) {
        put_byte(b, (unsigned char)(((c->chr >> 24) & 0x0F) | 0xE0));
        put_byte(b, (unsigned char)((c->chr >> 16) & 0xFF));
        put_uint16(b, c->chr & 0xFFFF);
    } else {
        put_byte(b, 0xF0);
        put_uint32(b, c->chr);
    }
    *state = c->chr & ~0xFF;
}
static void makeliteral_attr(strbuf *b, termchar *c, unsigned long *state)
{
    /*
     * My encoding for attributes is 16-bit-granular and assumes
     * that the top bit of the word is never required. I either
     * store a two-byte value with the top bit clear (indicating
     * just that value), or a four-byte value with the top bit set
     * (indicating the same value with its top bit clear).
     *
     * However, first I permute the bits of the attribute value, so
     * that the eight bits of colour (four in each of fg and bg)
     * which are never non-zero unless xterm 256-colour mode is in
     * use are placed higher up the word than everything else. This
     * ensures that attribute values remain 16-bit _unless_ the
     * user uses extended colour.
     */
    unsigned attr, colourbits;

    attr = c->attr;

    assert(ATTR_BGSHIFT > ATTR_FGSHIFT);

    colourbits = (attr >> (ATTR_BGSHIFT + 4)) & 0xF;
    colourbits <<= 4;
    colourbits |= (attr >> (ATTR_FGSHIFT + 4)) & 0xF;

    attr = (((attr >> (ATTR_BGSHIFT + 8)) << (ATTR_BGSHIFT + 4)) |
            (attr & ((1 << (ATTR_BGSHIFT + 4))-1)));
    attr = (((attr >> (ATTR_FGSHIFT + 8)) << (ATTR_FGSHIFT + 4)) |
            (attr & ((1 << (ATTR_FGSHIFT + 4))-1)));

    attr |= (colourbits << (32-9));

    if (attr < 0x8000) {
        put_byte(b, (unsigned char)((attr >> 8) & 0xFF));
        put_byte(b, (unsigned char)(attr & 0xFF));
    } else {
        put_byte(b, (unsigned char)(((attr >> 24) & 0x7F) | 0x80));
        put_byte(b, (unsigned char)((attr >> 16) & 0xFF));
        put_byte(b, (unsigned char)((attr >> 8) & 0xFF));
        put_byte(b, (unsigned char)(attr & 0xFF));
    }
}
static void makeliteral_truecolour(strbuf *b, termchar *c, unsigned long *state)
{
    /*
     * Put optional colour/link metadata into the buffer. Unlinked cells
     * retain the original compressed representation.
     */
    put_byte(b, ((c->truecolour.fg.enabled ? 1 : 0) |
                 (c->truecolour.bg.enabled ? 2 : 0) |
                 ((c->truecolour.decoration & UINT32_MAX) ? 4 : 0) |
                 (c->hyperlink ? 8 : 0) |
                 ((c->truecolour.decoration >> 32) ? 16 : 0)));
    if (c->truecolour.fg.enabled) {
        put_byte(b, c->truecolour.fg.r);
        put_byte(b, c->truecolour.fg.g);
        put_byte(b, c->truecolour.fg.b);
    }
    if (c->truecolour.bg.enabled) {
        put_byte(b, c->truecolour.bg.r);
        put_byte(b, c->truecolour.bg.g);
        put_byte(b, c->truecolour.bg.b);
    }
    if (c->truecolour.decoration & UINT32_MAX) put_uint32(b, c->truecolour.decoration);
    if (c->hyperlink) put_uint32(b, c->hyperlink);
    if (c->truecolour.decoration >> 32) put_uint32(b, c->truecolour.decoration >> 32);
}
static void makeliteral_cc(strbuf *b, termchar *c, unsigned long *state)
{
    /*
     * For combining characters, I just encode a bunch of ordinary
     * chars using makeliteral_chr, and terminate with a \0
     * character (which I know won't come up as a combining char
     * itself).
     *
     * I don't use the stateful encoding in makeliteral_chr.
     */
    unsigned long zstate;
    termchar z;

    while (c->cc_next) {
        c += c->cc_next;

        assert(c->chr != 0);

        zstate = 0;
        makeliteral_chr(b, c, &zstate);
    }

    z.chr = 0;
    zstate = 0;
    makeliteral_chr(b, &z, &zstate);
}

typedef struct compressed_scrollback_line {
    size_t len;
    /* compressed data follows after this */
} compressed_scrollback_line;

static termline *decompressline_no_free(compressed_scrollback_line *line);

static compressed_scrollback_line *compressline_no_free(termline *ldata)
{
    strbuf *b = strbuf_new();

    /* Leave space for the header structure */
    strbuf_append(b, sizeof(compressed_scrollback_line));

    /*
     * First, store the column count, 7 bits at a time, least
     * significant `digit' first, with the high bit set on all but
     * the last.
     */
    {
        int n = ldata->cols;
        while (n >= 128) {
            put_byte(b, (unsigned char)((n & 0x7F) | 0x80));
            n >>= 7;
        }
        put_byte(b, (unsigned char)(n));
    }

    /*
     * Next store the lattrs; same principle. We add one extra bit to
     * this to indicate the trust state of the line.
     */
    {
        int n = ldata->lattr | (ldata->trusted ? 0x10000 : 0);
        while (n >= 128) {
            put_byte(b, (unsigned char)((n & 0x7F) | 0x80));
            n >>= 7;
        }
        put_byte(b, (unsigned char)(n));
    }

    /*
     * Now we store a sequence of separate run-length encoded
     * fragments, each containing exactly as many symbols as there
     * are columns in the ldata.
     *
     * All of these have a common basic format:
     *
     *  - a byte 00-7F indicates that X+1 literals follow it
     *  - a byte 80-FF indicates that a single literal follows it
     *    and expects to be repeated (X-0x80)+2 times.
     *
     * The format of the `literals' varies between the fragments.
     */
    makerle(b, ldata, makeliteral_chr);
    makerle(b, ldata, makeliteral_attr);
    makerle(b, ldata, makeliteral_truecolour);
    makerle(b, ldata, makeliteral_cc);

    size_t linelen = b->len - sizeof(compressed_scrollback_line);
    compressed_scrollback_line *line =
        (compressed_scrollback_line *)strbuf_to_str(b);
    line->len = linelen;

    /*
     * Diagnostics: ensure that the compressed data really does
     * decompress to the right thing.
     *
     * This is a bit performance-heavy for production code.
     */
#ifdef TERM_CC_DIAGS
#ifndef CHECK_SB_COMPRESSION
    {
        termline *dcl;
        int i;

#ifdef DIAGNOSTIC_SB_COMPRESSION
        for (i = 0; i < b->len; i++) {
            printf(" %02x ", b->data[i]);
        }
        printf("\n");
#endif

        dcl = decompressline_no_free(line);
        assert(ldata->cols == dcl->cols);
        assert(ldata->lattr == dcl->lattr);
        for (i = 0; i < ldata->cols; i++)
            assert(termchars_equal(&ldata->chars[i], &dcl->chars[i]));

#ifdef DIAGNOSTIC_SB_COMPRESSION
        printf("%d cols (%d bytes) -> %d bytes (factor of %g)\n",
               ldata->cols, 4 * ldata->cols, dused,
               (double)dused / (4 * ldata->cols));
#endif

        freetermline(dcl);
    }
#endif
#endif /* TERM_CC_DIAGS */

    return line;
}

static compressed_scrollback_line *compressline_and_free(termline *ldata)
{
    compressed_scrollback_line *cline = compressline_no_free(ldata);
    freetermline(ldata);
    return cline;
}

static void readrle(BinarySource *bs, termline *ldata,
                    void (*readliteral)(BinarySource *bs, termchar *c,
                                        termline *ldata, unsigned long *state))
{
    int n = 0;
    unsigned long state = 0;

    while (n < ldata->cols) {
        int hdr = get_byte(bs);

        if (hdr >= 0x80) {
            /* A run. */

            size_t pos = bs->pos, count = hdr + 2 - 0x80;
            while (count--) {
                assert(n < ldata->cols);
                bs->pos = pos;
                readliteral(bs, ldata->chars + n, ldata, &state);
                n++;
            }
        } else {
            /* Just a sequence of consecutive literals. */

            int count = hdr + 1;
            while (count--) {
                assert(n < ldata->cols);
                readliteral(bs, ldata->chars + n, ldata, &state);
                n++;
            }
        }
    }

    assert(n == ldata->cols);
}
static void readliteral_chr(BinarySource *bs, termchar *c, termline *ldata,
                            unsigned long *state)
{
    int byte;

    /*
     * 00000000-0000007F: 0xxxxxxx
     * 00000080-00003FFF: 10xxxxxx xxxxxxxx
     * 00004000-001FFFFF: 110xxxxx xxxxxxxx xxxxxxxx
     * 00200000-0FFFFFFF: 1110xxxx xxxxxxxx xxxxxxxx xxxxxxxx
     * 10000000-FFFFFFFF: 11110ZZZ xxxxxxxx xxxxxxxx xxxxxxxx xxxxxxxx
     */

    byte = get_byte(bs);
    if (byte < 0x80) {
        c->chr = byte | *state;
    } else if (byte < 0xC0) {
        c->chr = (byte &~ 0xC0) << 8;
        c->chr |= get_byte(bs);
    } else if (byte < 0xE0) {
        c->chr = (byte &~ 0xE0) << 16;
        c->chr |= get_uint16(bs);
    } else if (byte < 0xF0) {
        c->chr = (byte &~ 0xF0) << 24;
        c->chr |= get_byte(bs) << 16;
        c->chr |= get_uint16(bs);
    } else {
        assert(byte == 0xF0);
        c->chr = get_uint32(bs);
    }
    *state = c->chr & ~0xFF;
}
static void readliteral_attr(BinarySource *bs, termchar *c, termline *ldata,
                             unsigned long *state)
{
    unsigned val, attr, colourbits;

    val = get_uint16(bs);

    if (val >= 0x8000) {
        val &= ~0x8000;
        val <<= 16;
        val |= get_uint16(bs);
    }

    colourbits = (val >> (32-9)) & 0xFF;
    attr = (val & ((1<<(32-9))-1));

    attr = (((attr >> (ATTR_FGSHIFT + 4)) << (ATTR_FGSHIFT + 8)) |
            (attr & ((1 << (ATTR_FGSHIFT + 4))-1)));
    attr = (((attr >> (ATTR_BGSHIFT + 4)) << (ATTR_BGSHIFT + 8)) |
            (attr & ((1 << (ATTR_BGSHIFT + 4))-1)));

    attr |= (colourbits >> 4) << (ATTR_BGSHIFT + 4);
    attr |= (colourbits & 0xF) << (ATTR_FGSHIFT + 4);

    c->attr = attr;
}
static void readliteral_truecolour(
    BinarySource *bs, termchar *c, termline *ldata, unsigned long *state)
{
    int flags = get_byte(bs);

    if (flags & 1) {
        c->truecolour.fg.enabled = true;
        c->truecolour.fg.r = get_byte(bs);
        c->truecolour.fg.g = get_byte(bs);
        c->truecolour.fg.b = get_byte(bs);
    } else {
        c->truecolour.fg = optionalrgb_none;
    }

    if (flags & 2) {
        c->truecolour.bg.enabled = true;
        c->truecolour.bg.r = get_byte(bs);
        c->truecolour.bg.g = get_byte(bs);
        c->truecolour.bg.b = get_byte(bs);
    } else {
        c->truecolour.bg = optionalrgb_none;
    }
    c->truecolour.decoration = flags & 4 ? get_uint32(bs) : 0;
    c->hyperlink = flags & 8 ? get_uint32(bs) : 0;
    if (flags & 16) c->truecolour.decoration |= (uint64_t)get_uint32(bs) << 32;
}
static void readliteral_cc(BinarySource *bs, termchar *c, termline *ldata,
                           unsigned long *state)
{
    termchar n;
    unsigned long zstate;
    int x = c - ldata->chars;

    c->cc_next = 0;

    while (1) {
        zstate = 0;
        readliteral_chr(bs, &n, ldata, &zstate);
        if (!n.chr)
            break;
        add_cc(ldata, x, n.chr);
    }
}

static termline *decompressline_no_free(compressed_scrollback_line *line)
{
    int ncols, byte, shift;
    BinarySource bs[1];
    termline *ldata;

    BinarySource_BARE_INIT(bs, line+1, line->len);

    /*
     * First read in the column count.
     */
    ncols = shift = 0;
    do {
        byte = get_byte(bs);
        ncols |= (byte & 0x7F) << shift;
        shift += 7;
    } while (byte & 0x80);

    /*
     * Now create the output termline.
     */
    ldata = snew(termline);
    ldata->chars = snewn(ncols, termchar);
    ldata->cols = ldata->size = ncols;
    ldata->temporary = true;
    ldata->cc_free = 0;

    /*
     * We must set all the cc pointers in ldata->chars to 0 right
     * now, so that cc diagnostics that verify the integrity of the
     * whole line will make sense while we're in the middle of
     * building it up.
     */
    {
        int i;
        for (i = 0; i < ldata->cols; i++)
            ldata->chars[i].cc_next = 0;
    }

    /*
     * Now read in the lattr.
     */
    int lattr = shift = 0;
    do {
        byte = get_byte(bs);
        lattr |= (byte & 0x7F) << shift;
        shift += 7;
    } while (byte & 0x80);
    ldata->lattr = lattr & 0xFFFF;
    ldata->trusted = (lattr & 0x10000) != 0;

    /*
     * Now we read in each of the RLE streams in turn.
     */
    readrle(bs, ldata, readliteral_chr);
    readrle(bs, ldata, readliteral_attr);
    readrle(bs, ldata, readliteral_truecolour);
    readrle(bs, ldata, readliteral_cc);

    /* And we always expect that we ended up exactly at the end of the
     * compressed data. */
    assert(!get_err(bs));
    assert(get_avail(bs) == 0);

    return ldata;
}

static inline void free_compressed_line(compressed_scrollback_line *cline)
{
    sfree(cline);
}

static termline *decompressline_and_free(compressed_scrollback_line *cline)
{
    termline *ldata = decompressline_no_free(cline);
    free_compressed_line(cline);
    return ldata;
}

#else /* NO_SCROLLBACK_COMPRESSION */

static termline *duptermline(termline *oldline)
{
    termline *newline = snew(termline);
    *newline = *oldline;               /* copy the POD structure fields */
    newline->chars = snewn(newline->size, termchar);
    for (int j = 0; j < newline->size; j++)
        newline->chars[j] = oldline->chars[j];
    return newline;
}

typedef termline compressed_scrollback_line;

static inline compressed_scrollback_line *compressline_and_free(
    termline *ldata)
{
    return ldata;
}

static inline compressed_scrollback_line *compressline_no_free(termline *ldata)
{
    return duptermline(ldata);
}

static inline termline *decompressline_no_free(
    compressed_scrollback_line *line)
{
    /* This will return a line without the 'temporary' flag, which
     * means that unlineptr() is already set up to avoid freeing it */
    return line;
}

static inline termline *decompressline_and_free(
    compressed_scrollback_line *line)
{
    /* Same as decompressline_no_free, because the caller will free
     * our returned termline, and that does all the freeing necessary */
    return line;
}

static inline void free_compressed_line(compressed_scrollback_line *line)
{
    freetermline(line);
}

#endif /* NO_SCROLLBACK_COMPRESSION */

/*
 * Resize a line to make it `cols' columns wide.
 */
static void resizeline(Terminal *term, termline *line, int cols)
{
    int i, oldcols;

    if (line->cols != cols) {

        oldcols = line->cols;

        /*
         * This line is the wrong length, which probably means it
         * hasn't been accessed since a resize. Resize it now.
         *
         * First, go through all the characters that will be thrown
         * out in the resize (if we're shrinking the line) and
         * return their cc lists to the cc free list.
         */
        for (i = cols; i < oldcols; i++)
            clear_cc(line, i);

        /*
         * If we're shrinking the line, we now bodily move the
         * entire cc section from where it started to where it now
         * needs to be. (We have to do this before the resize, so
         * that the data we're copying is still there. However, if
         * we're expanding, we have to wait until _after_ the
         * resize so that the space we're copying into is there.)
         */
        if (cols < oldcols)
            memmove(line->chars + cols, line->chars + oldcols,
                    (line->size - line->cols) * TSIZE);

        /*
         * Now do the actual resize, leaving the _same_ amount of
         * cc space as there was to begin with.
         */
        line->size += cols - oldcols;
        line->chars = sresize(line->chars, line->size, TTYPE);
        line->cols = cols;

        /*
         * If we're expanding the line, _now_ we move the cc
         * section.
         */
        if (cols > oldcols)
            memmove(line->chars + cols, line->chars + oldcols,
                    (line->size - line->cols) * TSIZE);

        /*
         * Go through what's left of the original line, and adjust
         * the first cc_next pointer in each list. (All the
         * subsequent ones are still valid because they are
         * relative offsets within the cc block.) Also do the same
         * to the head of the cc_free list.
         */
        for (i = 0; i < oldcols && i < cols; i++)
            if (line->chars[i].cc_next)
                line->chars[i].cc_next += cols - oldcols;
        if (line->cc_free)
            line->cc_free += cols - oldcols;

        /*
         * And finally fill in the new space with erase chars. (We
         * don't have to worry about cc lists here, because we
         * _know_ the erase char doesn't have one.)
         */
        for (i = oldcols; i < cols; i++)
            line->chars[i] = term->basic_erase_char;

#ifdef TERM_CC_DIAGS
        cc_check(line);
#endif
    }
}

/*
 * Get the number of lines in the scrollback.
 */
static int sblines(Terminal *term)
{
    int sblines = count234(term->scrollback);
    if (term->erase_to_scrollback &&
        term->alt_which && term->alt_screen) {
        sblines += term->alt_sblines;
    }
    return sblines;
}

static void null_line_error(Terminal *term, int y, int lineno,
                            tree234 *whichtree, int treeindex,
                            const char *varname)
{
    modalfatalbox("%s==NULL in terminal.c\n"
                  "lineno=%d y=%d w=%d h=%d\n"
                  "count(scrollback=%p)=%d\n"
                  "count(screen=%p)=%d\n"
                  "count(alt=%p)=%d alt_sblines=%d\n"
                  "whichtree=%p treeindex=%d\n"
                  "commitid=%s\n\n"
                  "Please contact <putty@projects.tartarus.org> "
                  "and pass on the above information.",
                  varname, lineno, y, term->cols, term->rows,
                  term->scrollback, count234(term->scrollback),
                  term->screen, count234(term->screen),
                  term->alt_screen, count234(term->alt_screen),
                  term->alt_sblines, whichtree, treeindex, commitid);
}

static inline int checkscr(int y, int lineno)
{
    if (y < 0)
        modalfatalbox("screen line %d < 0 in terminal.c:%d", y, lineno);
    return y;
}

/*
 * Retrieve a line of the screen or of the scrollback, according to
 * whether the y coordinate is non-negative or negative
 * (respectively).
 */
static termline *lineptr(Terminal *term, int y, int lineno)
{
    termline *line;
    tree234 *whichtree;
    int treeindex;

    if (y >= 0) {
        whichtree = term->screen;
        treeindex = y;
    } else {
        int altlines = 0;

        if (term->erase_to_scrollback &&
            term->alt_which && term->alt_screen) {
            altlines = term->alt_sblines;
        }
        if (y < -altlines) {
            whichtree = term->scrollback;
            treeindex = y + altlines + count234(term->scrollback);
        } else {
            whichtree = term->alt_screen;
            treeindex = y + term->alt_sblines;
            /* treeindex = y + count234(term->alt_screen); */
        }
    }
    if (whichtree == term->scrollback) {
        compressed_scrollback_line *cline = index234(whichtree, treeindex);
        if (!cline)
            null_line_error(term, y, lineno, whichtree, treeindex, "cline");
        line = decompressline_no_free(cline);
    } else {
        line = index234(whichtree, treeindex);
    }

    /* We assume that we don't screw up and retrieve something out of range. */
    if (line == NULL)
        null_line_error(term, y, lineno, whichtree, treeindex, "line");
    assert(line != NULL);

    /*
     * Here we resize lines to _at least_ the right length, but we
     * don't truncate them. Truncation is done as a side effect of
     * modifying the line.
     *
     * The point of this policy is to try to arrange that resizing the
     * terminal window repeatedly - e.g. successive steps in an X11
     * opaque window-resize drag, or resizing as a side effect of
     * retiling by tiling WMs such as xmonad - does not throw away
     * data gratuitously. Specifically, we want a sequence of resize
     * operations with no terminal output between them to have the
     * same effect as a single resize to the ultimate terminal size,
     * and also (for the case in which xmonad narrows a window that's
     * scrolling things) we want scrolling up new text at the bottom
     * of a narrowed window to avoid truncating lines further up when
     * the window is re-widened.
     */
    if (term->cols > line->cols)
        resizeline(term, line, term->cols);

    return line;
}

/*
 * Macro wrappers for lineptr. The distinction between lineptr and
 * scrlineptr is that lineptr can retrieve any line, from the screen
 * _or_ from scrollback, and in return, you have to call unlineptr
 * when you're done with it, in case it was a dynamically allocated
 * line decompressed from scrollback that needs freeing. But
 * scrlineptr will only retrieve lines from the active screen (and
 * enforces this by an assertion), which means it's always just
 * returning a pointer to an existing unpacked termline, and you don't
 * have to call unlineptr afterwards. So drawing code (which might
 * need the scrollback) will have to call lineptr/unlineptr, but
 * update code during term_out can call scrlineptr.
 *
 * The 'assertion' in scrlineptr is done using a helper function that
 * returns the input column number, which allows this macro to avoid
 * double-evaluating its argument.
 */
#define lineptr(x) (lineptr)(term,x,__LINE__)
#define scrlineptr(x) (lineptr)(term,checkscr(x,__LINE__),__LINE__)
#define unlineptr(line) term_release_line(line)

/* Wrapper for external use (e.g. tests), without the __LINE__ parameter */
termline *term_get_line(Terminal *term, int y) { return lineptr(y); }

/*
 * Coerce a termline to the terminal's current width. Unlike the
 * optional resize in lineptr() above, this is potentially destructive
 * of text, since it can shrink as well as grow the line.
 *
 * We call this whenever a termline is actually going to be modified.
 * Helpfully, putting a single call to this function in check_boundary
 * deals with _nearly_ all such cases, leaving only a few things like
 * bulk erase and ESC#8 to handle separately.
 */
static void check_line_size(Terminal *term, termline *line)
{
    if (term->cols != line->cols)      /* trivial optimisation */
        resizeline(term, line, term->cols);
}

static void term_schedule_tblink(Terminal *term);
static void term_schedule_cblink(Terminal *term);
static void term_update_callback(void *ctx);

static void term_timer(void *ctx, unsigned long now)
{
    Terminal *term = (Terminal *)ctx;

    if (term->tblink_pending && now == term->next_tblink) {
        term->tblinker = !term->tblinker;
        term->tblink_pending = false;
        term_schedule_tblink(term);
        term->window_update_pending = true;
    }

    if (term->cblink_pending && now == term->next_cblink) {
        term->cblinker = !term->cblinker;
        term->cblink_pending = false;
        term_schedule_cblink(term);
        term->window_update_pending = true;
    }

    if (term->in_vbell && now == term->vbell_end) {
        term->in_vbell = false;
        term->window_update_pending = true;
    }

    if (term->window_update_cooldown &&
        now == term->window_update_cooldown_end) {
        term->window_update_cooldown = false;
    }

    if (term->mouse_highlight == HIGHLIGHT_WAIT && now == term->mouse_highlight_deadline)
        nemo_highlight_cancel(term, true);
    if (term->synchronized_update && now == term->synchronized_update_deadline)
        term_end_synchronized_update(term);
    if (term->window_update_pending)
        term_update_callback(term);
}

static void term_update_callback(void *ctx)
{
    Terminal *term = (Terminal *)ctx;
    if (!term->window_update_pending || term->synchronized_update)
        return;
    if (!term->window_update_cooldown) {
        term_update(term);
        term->window_update_cooldown = true;
        term->window_update_cooldown_end = schedule_timer(
            UPDATE_DELAY, term_timer, term);
    }
}

static void term_schedule_update(Terminal *term)
{
    if (!term->window_update_pending) {
        term->window_update_pending = true;
        queue_toplevel_callback(term_update_callback, term);
    }
}

/* DECSET 2026 defers presentation, never input parsing or protocol replies.
 * A fixed one-second deadline bounds an incomplete update. Repeated SET is
 * idempotent and does not prolong the deadline. */
static void term_start_synchronized_update(Terminal *term)
{
    if (term->synchronized_update || !term->win->vt->set_synchronized_update)
        return;
    term_update(term);
    if (term->win->vt->set_synchronized_update(term->win, true)) {
        term->synchronized_update = true;
        term->synchronized_update_deadline = schedule_timer(
            TICKSPERSEC, term_timer, term);
    }
}

void term_end_synchronized_update(Terminal *term)
{
    if (!term->synchronized_update) return;
    term->synchronized_update = false;
    term->win->vt->set_synchronized_update(term->win, false);
    /* The callback queued before the freeze may already have run and deferred
     * itself. Queue a fresh repaint even when that left pending=true. */
    term->window_update_pending = false;
    term_invalidate(term);
}

/*
 * Call this whenever the terminal window state changes, to queue an
 * update. This also resets the phase of cursor blinking, so that the
 * cursor remains visible as it moves with the output, and sets a flag
 * to indicate that if we have the 'reset scrollback on display
 * activity' setting enabled, then we should activate it.
 */
static void seen_disp_event(Terminal *term)
{
    if (term->scroll_on_disp) {
        term->disptop = 0;
        term->win_scrollbar_update_pending = true;
    }
    term->cblinker = true;
    term->cblink_pending = false;
    term_schedule_cblink(term);
    term_schedule_update(term);
}

/*
 * Call when the terminal's blinking-text settings change, or when
 * a text blink has just occurred.
 */
static void term_schedule_tblink(Terminal *term)
{
    if (term->blink_is_real) {
        if (!term->tblink_pending)
            term->next_tblink = schedule_timer(TBLINK_DELAY, term_timer, term);
        term->tblink_pending = true;
    } else {
        term->tblinker = true;         /* reset when not in use */
        term->tblink_pending = false;
    }
}

/*
 * Likewise with cursor blinks.
 */
static void term_schedule_cblink(Terminal *term)
{
    int delay = CBLINK_DELAY;
    if (term->blink_cur && term->has_focus && delay > 0) {
        if (!term->cblink_pending)
            term->next_cblink = schedule_timer(delay, term_timer, term);
        term->cblink_pending = true;
    } else {
        term->cblinker = true;         /* reset when not in use */
        term->cblink_pending = false;
    }
}

static void nemo_cursor_style(Terminal *term, unsigned style)
{
    if (style > 7) return;
    if (style == 7) {
        term->cursor_type = conf_get_int(term->conf, CONF_cursor_type);
        term->blink_cur = conf_get_bool(term->conf, CONF_blink_cur);
    } else {
        if (!style) style = 1;
        term->cursor_type = (style-1)/2;
        term->blink_cur = (style & 1) != 0;
    }
    term->big_cursor = false;
    term->cblinker = true;
    term->cblink_pending = false;
    term_schedule_cblink(term);
    term_invalidate(term);
}

/*
 * Call to begin a visual bell.
 */
static void term_schedule_vbell(Terminal *term, bool already_started,
                                long startpoint)
{
    long ticks_already_gone;

    if (already_started)
        ticks_already_gone = GETTICKCOUNT() - startpoint;
    else
        ticks_already_gone = 0;

    if (ticks_already_gone < VBELL_DELAY) {
        term->in_vbell = true;
        term->vbell_end = schedule_timer(VBELL_DELAY - ticks_already_gone,
                                         term_timer, term);
    } else {
        term->in_vbell = false;
    }
}

/*
 * Set up power-on settings for the terminal.
 * If 'clear' is false, don't actually clear the primary screen, and
 * position the cursor below the last non-blank line (scrolling if
 * necessary).
 */
/* NemoTerm image storage. Every retained image and in-flight tile allocation
 * shares the same budget; no whole-DCS string is buffered. */
#define NEMO_IMAGE_MASK_ROWS 32

static void nemo_image_remove(Terminal *term, NemoTermImage **link)
{
    NemoTermImage *image = *link;
    *link = image->next;
    term->image_bytes -= image->memory_bytes;
    assert(image->source->references);
    if (!--image->source->references) {
        term->image_bytes -= image->source->memory_bytes;
        nemo_sixel_free(image->source->bitmap);
        sfree(image->source);
    }
    for (unsigned i = 0; i < image->band_count; i++) sfree(image->mask_bands[i]);
    sfree(image->mask_bands);
    sfree(image->lines);
    sfree(image);
}

static void nemo_images_clear(Terminal *term)
{
    while (term->images) nemo_image_remove(term, &term->images);
    nemo_sixel_free(term->sixel_pending);
    term->sixel_pending = NULL;
}

static bool nemo_image_admit(void *ctx, size_t current, size_t extra)
{
    Terminal *term = ctx;
    const size_t budget = NEMO_SIXEL_DEFAULT_BUDGET;
    if (current > budget || extra > budget - current) return false;
    bool changed = false;
    while (term->images && term->image_bytes > budget - current - extra) {
        nemo_image_remove(term, &term->images);
        changed = true;
    }
    if (changed) term_invalidate(term);
    return term->image_bytes <= budget - current - extra;
}

static bool nemo_image_live(Terminal *term, NemoTermImage *image);

void term_set_cell_size(Terminal *term, int width, int height)
{
    if (!term || width < 1 || height < 1) return;
    if (term->cell_width == width && term->cell_height == height) return;
    nemo_highlight_cancel(term, true);
    term_end_synchronized_update(term);
    nemo_sixel_free(term->sixel_pending);
    term->sixel_pending = NULL;
    term->cell_width = width;
    term->cell_height = height;
    for (NemoTermImage *image = term->images; image; image = image->next)
        nemo_image_live(term, image);
    term_invalidate(term);
}

int64_t term_image_pixel_y(const NemoTermImage *image, unsigned y, int cell_height)
{
    if (y >= (unsigned)image->pixel_height || image->lines[y].anchor == INT_MIN)
        return INT64_MIN;
    return (int64_t)image->lines[y].anchor * cell_height + y;
}

size_t term_image_read_row(const NemoTermImage *image, unsigned y, unsigned x,
                          uint32_t *out, size_t count)
{
    NemoSixelStats st = nemo_sixel_stats(image->source->bitmap);
    if (!st.width || !st.height || y >= (unsigned)image->pixel_height ||
        x >= (unsigned)image->pixel_width || !count) return 0;
    size_t n = min(count, (size_t)image->pixel_width - x);
    unsigned scale = st.aspect_horizontal;
    unsigned source_x = image->pixel_x + x;
    unsigned first = source_x / scale, last = (source_x+n-1) / scale;
    if (nemo_sixel_read_row(image->source->bitmap, y / st.aspect_vertical,
                           first, out, last-first+1) != last-first+1) return 0;
    /* Expand backwards in the caller's buffer; no second raster allocation. */
    for (size_t i = n; i-- > 0;) out[i] = out[(source_x+i)/scale-first];
    const NemoImageRow *row = &image->lines[y];
    if (row->anchor == INT_MIN) {
        memset(out, 0, n * sizeof(*out));
        return n;
    }
    if (!row->erased) return n;
    for (size_t i = 0; i < n; i++) {
        size_t pixel = x+i;
        if (row->erased[pixel / 8] & (1u << (pixel % 8))) out[i] = 0;
    }
    return n;
}

static size_t nemo_image_mask_bytes(const NemoTermImage *image)
{
    return ((size_t)image->pixel_width + 7) / 8;
}

static size_t nemo_image_band_bytes(const NemoTermImage *image, unsigned band)
{
    return nemo_image_mask_bytes(image) *
        min(NEMO_IMAGE_MASK_ROWS, image->pixel_height - band*NEMO_IMAGE_MASK_ROWS);
}

static void nemo_image_drop_row(Terminal *term, NemoTermImage *image, int y)
{
    NemoImageRow *row = &image->lines[y];
    if (row->anchor == INT_MIN) return;
    row->anchor = INT_MIN;
    image->live_rows--;
    if (row->erased) {
        row->erased = NULL;
        unsigned band = y / NEMO_IMAGE_MASK_ROWS;
        int first = band*NEMO_IMAGE_MASK_ROWS;
        int last = min(first+NEMO_IMAGE_MASK_ROWS, image->pixel_height);
        bool used = false;
        for (int i = first; i < last; i++)
            if (image->lines[i].anchor != INT_MIN && image->lines[i].erased_pixels)
                used = true;
        if (!used) {
            size_t bytes = nemo_image_band_bytes(image, band);
            sfree(image->mask_bands[band]); image->mask_bands[band] = NULL;
            for (int i = first; i < last; i++) image->lines[i].erased = NULL;
            image->erased_bytes -= bytes;
            image->memory_bytes -= bytes;
            term->image_bytes -= bytes;
        }
    }
}

static bool nemo_image_erase_pixels(Terminal *term, NemoTermImage *image, int y,
                                    int first, int last)
{
    bool changed = false;
    NemoImageRow *row = &image->lines[y];
    for (int x = first; x < last; x++) {
        unsigned char mask = (unsigned char)(1u << (x % 8));
        if (!(row->erased[x / 8] & mask)) {
            row->erased[x / 8] |= mask;
            row->erased_pixels++;
            changed = true;
        }
    }
    if (row->erased_pixels == (unsigned)image->pixel_width)
        nemo_image_drop_row(term, image, y);
    return changed;
}

/* Refresh the cached top row and report whether any scanlines remain. */
static bool nemo_image_live(Terminal *term, NemoTermImage *image)
{
    image->y = INT_MAX;
    image->last_y = INT_MIN;
    for (int y = 0; y < image->pixel_height; y++)
        if (image->lines[y].anchor != INT_MIN) {
            int64_t row = (int64_t)image->lines[y].anchor + y / term->cell_height;
            image->y = (int)min((int64_t)image->y, row);
            image->last_y = (int)min((int64_t)INT_MAX,
                max((int64_t)image->last_y, row));
        }
    return image->live_rows != 0;
}

/* Move and clip strips when text rows enter/leave temporary scrollback during
 * a resize, or when history is truncated. This also handles inactive screens. */
static void nemo_images_rows(Terminal *term, int screen,
                             int first, int last, int delta)
{
    NemoTermImage **link = &term->images;
    while (*link) {
        NemoTermImage *image = *link;
        if (image->screen == screen) {
            for (int y = 0; y < image->pixel_height; y++) {
                NemoImageRow *row = &image->lines[y];
                if (row->anchor == INT_MIN) continue;
                int64_t moved = (int64_t)row->anchor + y / term->cell_height + delta;
                int64_t anchor = (int64_t)row->anchor + delta;
                if (moved < first || moved > last ||
                    anchor <= INT_MIN || anchor > INT_MAX) {
                    nemo_image_drop_row(term, image, y);
                } else row->anchor = (int)anchor;
            }
            if (!nemo_image_live(term, image)) {
                nemo_image_remove(term, link);
                continue;
            }
        }
        link = &image->next;
    }
}

/* Map an erase operation in the current cell grid into original raster pixels.
 * Pixel offsets and holes stay fixed when the font changes. */
static bool nemo_image_erase_range(Terminal *term, NemoTermImage *image, int y,
                                    pos start, pos end, int *left, int *right)
{
    if (image->screen != term->alt_which || image->lines[y].anchor == INT_MIN)
        return false;
    int64_t row = (int64_t)image->lines[y].anchor + y / term->cell_height;
    if (row < start.y || row > end.y) return false;
    int64_t x0 = row == start.y ?
        ((int64_t)start.x-image->x) * term->cell_width - image->pixel_x : 0;
    int64_t x1 = row == end.y ?
        ((int64_t)end.x-image->x) * term->cell_width - image->pixel_x : image->pixel_width;
    *left = (int)max(0, min((int64_t)image->pixel_width, x0));
    *right = (int)max(0, min((int64_t)image->pixel_width, x1));
    return *left < *right;
}

static size_t nemo_image_erase_need(Terminal *term, NemoTermImage *image,
                                   pos start, pos end)
{
    if (image->screen != term->alt_which ||
        image->y > end.y || image->last_y < start.y) return 0;
    size_t needed = 0;
    for (unsigned band = 0; band < image->band_count; band++) {
        if (image->mask_bands[band]) continue;
        int first = band*NEMO_IMAGE_MASK_ROWS;
        int last = min(first+NEMO_IMAGE_MASK_ROWS, image->pixel_height);
        for (int y = first; y < last; y++) {
            int left, right;
            if (nemo_image_erase_range(term, image, y, start, end, &left, &right)) {
                needed += nemo_image_band_bytes(image, band);
                break;
            }
        }
    }
    return needed;
}

/* Erase a half-open, lexicographic range of terminal cells. Masks are allocated
 * in 32-row bands only when needed, avoiding thousands of tiny heap blocks.
 * First release fully erased rows, then
 * admit all necessary masks before traversing again: admission can evict old
 * images, but must never invalidate an in-progress list iterator. */
static void nemo_images_erase(Terminal *term, pos start, pos end)
{
    bool changed = false;
    NemoTermImage **link = &term->images;
    while (*link) {
        NemoTermImage *image = *link;
        if (image->screen != term->alt_which ||
            image->y > end.y || image->last_y < start.y) {
            link = &image->next;
            continue;
        }
        for (int y = 0; y < image->pixel_height; y++) {
            int left, right;
            if (!nemo_image_erase_range(term, image, y, start, end, &left, &right))
                continue;
            if (!left && right == image->pixel_width) {
                nemo_image_drop_row(term, image, y);
                changed = true;
            } else if (image->lines[y].erased) {
                changed |= nemo_image_erase_pixels(term, image, y, left, right);
            }
        }
        if (!nemo_image_live(term, image)) {
            nemo_image_remove(term, link);
            continue;
        }
        link = &image->next;
    }

    size_t needed = 0;
    for (NemoTermImage *image = term->images; image; image = image->next)
        needed += nemo_image_erase_need(term, image, start, end);
    size_t pending = nemo_sixel_stats(term->sixel_pending).allocated_bytes;
    while (term->images && needed >
           NEMO_SIXEL_DEFAULT_BUDGET - pending - term->image_bytes) {
        needed -= nemo_image_erase_need(term, term->images, start, end);
        nemo_image_remove(term, &term->images);
        changed = true;
    }
    for (NemoTermImage *image = term->images; image; image = image->next) {
        if (image->screen != term->alt_which ||
            image->y > end.y || image->last_y < start.y) continue;
        for (int y = 0; y < image->pixel_height; y++) {
            int left, right;
            NemoImageRow *row = &image->lines[y];
            if (!nemo_image_erase_range(
                    term, image, y, start, end, &left, &right)) continue;
            if (!row->erased) {
                unsigned band = y/NEMO_IMAGE_MASK_ROWS;
                int first = band*NEMO_IMAGE_MASK_ROWS;
                int last = min(first+NEMO_IMAGE_MASK_ROWS, image->pixel_height);
                size_t stride = nemo_image_mask_bytes(image);
                size_t bytes = nemo_image_band_bytes(image, band);
                assert(!image->mask_bands[band]);
                image->mask_bands[band] = snewn(bytes, unsigned char);
                memset(image->mask_bands[band], 0, bytes);
                for (int i = first; i < last; i++)
                    if (image->lines[i].anchor != INT_MIN)
                        image->lines[i].erased = image->mask_bands[band] + (i-first)*stride;
                image->erased_bytes += bytes;
                image->memory_bytes += bytes;
                term->image_bytes += bytes;
            }
            changed |= nemo_image_erase_pixels(term, image, y, left, right);
        }
    }
    if (changed) term_invalidate(term);
}

/* An upper bound on a cropped view, including temporarily duplicated masks.
 * The pixel storage is already charged once to its shared owner. */
static size_t nemo_image_crop_need(const NemoTermImage *image, int width)
{
    size_t bytes = sizeof(*image) + image->pixel_height*sizeof(NemoImageRow) +
        image->band_count*sizeof(unsigned char *);
    for (unsigned band = 0; band < image->band_count; band++)
        if (image->mask_bands[band])
            bytes += ((size_t)width+7)/8 *
                min(NEMO_IMAGE_MASK_ROWS, image->pixel_height-band*NEMO_IMAGE_MASK_ROWS);
    return bytes;
}

/* Admission precedes this operation; it cannot evict the source being read. */
static NemoTermImage *nemo_image_crop(Terminal *term, const NemoTermImage *src,
                                     int left, int right)
{
    NemoTermImage *dst = snew(NemoTermImage);
    *dst = *src;
    dst->next = NULL;
    dst->source->references++;
    dst->pixel_x += left;
    dst->pixel_width = right-left;
    dst->erased_bytes = 0;
    dst->memory_bytes = sizeof(*dst) + dst->pixel_height*sizeof(NemoImageRow) +
        dst->band_count*sizeof(unsigned char *);
    dst->lines = snewn(dst->pixel_height, NemoImageRow);
    memset(dst->lines, 0, dst->pixel_height*sizeof(NemoImageRow));
    dst->mask_bands = snewn(dst->band_count, unsigned char *);
    memset(dst->mask_bands, 0, dst->band_count*sizeof(unsigned char *));
    for (int y = 0; y < dst->pixel_height; y++)
        dst->lines[y].anchor = src->lines[y].anchor;
    size_t stride = nemo_image_mask_bytes(dst);
    for (unsigned band = 0; band < dst->band_count; band++) {
        if (!src->mask_bands[band]) continue;
        size_t bytes = nemo_image_band_bytes(dst, band);
        unsigned char *mask = snewn(bytes, unsigned char);
        memset(mask, 0, bytes);
        int first = band*NEMO_IMAGE_MASK_ROWS;
        int last = min(first+NEMO_IMAGE_MASK_ROWS, dst->pixel_height);
        bool used = false;
        for (int y = first; y < last; y++) {
            if (dst->lines[y].anchor == INT_MIN) continue;
            NemoImageRow *row = &dst->lines[y];
            row->erased = mask + (y-first)*stride;
            if (src->lines[y].erased)
                for (int x = left; x < right; x++)
                    if (src->lines[y].erased[x/8] & (1u << (x%8))) {
                        row->erased[(x-left)/8] |= 1u << ((x-left)%8);
                        row->erased_pixels++;
                        used = true;
                    }
        }
        if (used) {
            dst->mask_bands[band] = mask;
            dst->erased_bytes += bytes;
            dst->memory_bytes += bytes;
        } else {
            sfree(mask);
            for (int y = first; y < last; y++) dst->lines[y].erased = NULL;
        }
    }
    term->image_bytes += dst->memory_bytes;
    /* Masks are fully copied before dropping any row: dropping the last
     * erased row in a band releases that band's allocation. */
    for (int y = 0; y < dst->pixel_height; y++)
        if (dst->lines[y].anchor != INT_MIN &&
            dst->lines[y].erased_pixels == (unsigned)dst->pixel_width)
            nemo_image_drop_row(term, dst, y);
    nemo_image_live(term, dst);
    return dst;
}

static unsigned nemo_image_column_cuts(Terminal *term, const NemoTermImage *image,
                                       int left, int right, int top, int bottom,
                                       int cuts[4])
{
    if (image->screen != term->alt_which || image->y > bottom || image->last_y < top)
        return 0;
    int64_t a = ((int64_t)left-image->x)*term->cell_width - image->pixel_x;
    int64_t b = ((int64_t)right-image->x)*term->cell_width - image->pixel_x;
    if (a >= image->pixel_width || b <= 0 || (a <= 0 && b >= image->pixel_width))
        return 0;
    bool intersects = false;
    for (int y = 0; y < image->pixel_height && !intersects; y++) {
        if (image->lines[y].anchor == INT_MIN) continue;
        int64_t row = (int64_t)image->lines[y].anchor + y/term->cell_height;
        intersects = row >= top && row <= bottom;
    }
    if (!intersects) return 0;
    unsigned count = 0;
    cuts[count++] = 0;
    if (a > 0 && a < image->pixel_width) cuts[count++] = (int)a;
    if (b > 0 && b < image->pixel_width) cuts[count++] = (int)b;
    cuts[count++] = image->pixel_width;
    return count;
}

static size_t nemo_image_column_need(Terminal *term, const NemoTermImage *image,
                                     int left, int right, int top, int bottom)
{
    int cuts[4];
    unsigned count = nemo_image_column_cuts(term, image, left, right, top, bottom, cuts);
    size_t bytes = 0;
    for (unsigned i = 1; i < count; i++)
        bytes += nemo_image_crop_need(image, cuts[i]-cuts[i-1]);
    return bytes;
}

static void nemo_images_split_columns(Terminal *term, int left, int right,
                                       int top, int bottom)
{
    size_t needed = 0;
    for (NemoTermImage *image = term->images; image; image = image->next)
        needed += nemo_image_column_need(term, image, left, right, top, bottom);
    size_t pending = nemo_sixel_stats(term->sixel_pending).allocated_bytes;
    /* Include peak temporary view storage. Evict before constructing any view
     * so no source, mask or iterator can be invalidated during a crop. */
    while (term->images && needed > NEMO_SIXEL_DEFAULT_BUDGET-pending-term->image_bytes) {
        needed -= nemo_image_column_need(term, term->images, left, right, top, bottom);
        nemo_image_remove(term, &term->images);
    }
    NemoTermImage **link = &term->images;
    while (*link) {
        NemoTermImage *image = *link;
        int cuts[4];
        unsigned count = nemo_image_column_cuts(term, image, left, right, top, bottom, cuts);
        if (!count) { link = &image->next; continue; }
        NemoTermImage *first = NULL, **tail = &first;
        for (unsigned i = 1; i < count; i++) {
            *tail = nemo_image_crop(term, image, cuts[i-1], cuts[i]);
            if (!(*tail)->live_rows)
                nemo_image_remove(term, tail);
            else
                tail = &(*tail)->next;
            assert(pending + term->image_bytes <= NEMO_SIXEL_DEFAULT_BUDGET);
        }
        nemo_image_remove(term, link);
        *tail = *link;
        *link = first;
        link = tail;
    }
}

static bool nemo_image_in_columns(Terminal *term, const NemoTermImage *image,
                                  int left, int right)
{
    int64_t x = (int64_t)image->x*term->cell_width + image->pixel_x;
    return image->screen == term->alt_which &&
        x >= (int64_t)left*term->cell_width &&
        x+image->pixel_width <= (int64_t)right*term->cell_width;
}

/* Bit 0: live pixels inside the row interval; bit 1: outside it. */
static unsigned nemo_image_row_regions(Terminal *term, const NemoTermImage *image,
                                       int top, int bottom)
{
    unsigned regions = 0;
    for (int y = 0; y < image->pixel_height && regions != 3; y++) {
        if (image->lines[y].anchor == INT_MIN) continue;
        int64_t row = (int64_t)image->lines[y].anchor+y/term->cell_height;
        regions |= row >= top && row <= bottom ? 1 : 2;
    }
    return regions;
}

/* Shift a rectangle of raster pixels without copying its immutable bitmap.
 * Column views isolate the surviving source; row views let the surrounding
 * pixels stay fixed. Admit all temporary view/mask storage before iterating. */
static void nemo_images_shift(Terminal *term, int left, int right,
                              int top, int bottom, int delta)
{
    int source_left = left + max(0, -delta);
    int source_right = right - max(0, delta);
    for (int y = top; y <= bottom; y++)
        nemo_images_erase(term, (pos){y, delta > 0 ? source_right : left},
                          (pos){y, delta > 0 ? right : source_left});
    if (source_left >= source_right) return;
    nemo_images_split_columns(term, source_left, source_right, top, bottom);
    size_t needed = 0;
    for (NemoTermImage *im = term->images; im; im = im->next)
        if (nemo_image_in_columns(term, im, source_left, source_right) &&
            nemo_image_row_regions(term, im, top, bottom) == 3)
            needed += nemo_image_crop_need(im, im->pixel_width);
    size_t pending = nemo_sixel_stats(term->sixel_pending).allocated_bytes;
    while (term->images && needed > NEMO_SIXEL_DEFAULT_BUDGET-pending-term->image_bytes) {
        NemoTermImage *im = term->images;
        if (nemo_image_in_columns(term, im, source_left, source_right) &&
            nemo_image_row_regions(term, im, top, bottom) == 3)
            needed -= nemo_image_crop_need(im, im->pixel_width);
        nemo_image_remove(term, &term->images);
    }
    for (NemoTermImage *im = term->images; im; im = im->next) {
        if (!nemo_image_in_columns(term, im, source_left, source_right)) continue;
        unsigned regions = nemo_image_row_regions(term, im, top, bottom);
        if (regions == 1) {
            im->x += delta;
        } else if (regions == 3) {
            NemoTermImage *moved = nemo_image_crop(term, im, 0, im->pixel_width);
            moved->next = im->next;
            im->next = moved;
            for (int y = 0; y < im->pixel_height; y++) {
                if (im->lines[y].anchor == INT_MIN) continue;
                int64_t row = (int64_t)im->lines[y].anchor+y/term->cell_height;
                nemo_image_drop_row(term, row >= top && row <= bottom ? im : moved, y);
            }
            nemo_image_live(term, im);
            nemo_image_live(term, moved);
            moved->x += delta;
            im = moved; /* Do not shift the newly inserted view twice. */
        }
    }
    term_invalidate(term);
}

void term_scroll_images(Terminal *term, int left, int right, int top, int bottom,
                         int lines, bool sb)
{
    left = max(0, left); right = min(term->cols, right);
    top = max(0, top); bottom = min(term->rows-1, bottom);
    if (!lines || left >= right || top > bottom) return;
    lines = max(top-bottom-1, min(lines, bottom-top+1));
    bool partial = left != 0 || right != term->cols;
    if (partial || top || term->alt_which) sb = false;
    if (partial) nemo_images_split_columns(term, left, right, top, bottom);
    NemoTermImage **link = &term->images;
    while (*link) {
        NemoTermImage *image = *link;
        int64_t x = (int64_t)image->x*term->cell_width + image->pixel_x;
        bool inside = !partial || (x < (int64_t)right*term->cell_width &&
                                   x+image->pixel_width > (int64_t)left*term->cell_width);
        if (image->screen == term->alt_which && inside) {
            for (int y = 0; y < image->pixel_height; y++) {
                NemoImageRow *row = &image->lines[y];
                if (row->anchor == INT_MIN) continue;
                int64_t dest = (int64_t)row->anchor + y / term->cell_height;
                int64_t anchor = (int64_t)row->anchor - lines;
                bool discard = false;
                if (sb && lines > 0 && dest <= bottom) {
                    int64_t moved = dest - lines;
                    discard = moved < -(int64_t)term->savelines ||
                        anchor <= INT_MIN || anchor > INT_MAX;
                    if (!discard) row->anchor = (int)anchor;
                } else if (dest >= top && dest <= bottom) {
                    dest -= lines;
                    discard = dest < top || dest > bottom ||
                        anchor <= INT_MIN || anchor > INT_MAX;
                    if (!discard) row->anchor = (int)anchor;
                }
                if (discard) nemo_image_drop_row(term, image, y);
            }
            nemo_image_live(term, image);
        }
        if (!image->live_rows) {
            nemo_image_remove(term, link);
            continue;
        }
        link = &image->next;
    }
    term_invalidate(term);
}

static void nemo_sixel_cancel(Terminal *term)
{
    nemo_sixel_free(term->sixel_pending);
    term->sixel_pending = NULL;
}

static void nemo_status_query(Terminal *term, bool private)
{
    if (!term->ldisc) return;
    unsigned request = term->esc_args[0];
    if (!private && request != 5 && request != 6) return;
    char reply[64];
    int n = 0;
    switch (request) {
      case 5:
        n = sprintf(reply, "\033[%s0n", private ? "?" : "");
        break;
      case 6:
        n = sprintf(reply, "\033[%s%d;%d%sR", private ? "?" : "",
            term->curs.y + 1 - (term->dec_om ? term->marg_t : 0),
            term->curs.x + 1 - (term->dec_om ? term->marg_l : 0),
            private && (has_compat(VT340TEXT) || has_compat(VT420)) ? ";1" : "");
        break;
      case 15:
        if (has_compat(VT220)) {
            /* A query must not open a printer or initiate a print job. */
            unsigned status = !conf_get_str(term->conf, CONF_printer)[0] ? 13 :
                term->print_job ? 10 : 11;
            n = sprintf(reply, "\033[?%un", status);
        }
        break;
      case 25:
        /* UDKs are unavailable, not merely locked against reprogramming. */
        if (has_compat(VT220)) n = sprintf(reply, "\033[?23n");
        break;
      case 26:
        if (has_compat(VT220))
            n = sprintf(reply, "\033[?27;1%sn", has_compat(VT420) ? ";0;0" :
                        has_compat(VT320) ? ";0" : "");
        break;
      case 55: case 56:
        if (has_compat(VT320))
            n = sprintf(reply, "%s", request == 55 ? "\033[?53n" : "\033[?57;0n");
        break;
      case 62:
        if (has_compat(VT420)) n = sprintf(reply, "\033[0000*{");
        break;
      case 63:
        /* No macro storage: its checksum is zero, never process memory. */
        if (has_compat(VT420))
            n = sprintf(reply, "\033P%u!~0000\033\\",
                        term->esc_nargs > 1 ? min(term->esc_args[1], 65535u) : 0);
        break;
      case 75: case 85:
        if (has_compat(VT420))
            n = sprintf(reply, "\033[?%un", request == 75 ? 70 : 83);
        break;
      case 9001:
        /* Same-image ConPTY synchronization, separate from application CPR.
         * Absolute viewport coordinates are required even under DECOM.
         * Its internal UTF-8 transport always uses 7-bit framing. */
        if (term->esc_nargs == 2 && term->esc_args[1] > 0 && term->esc_args[1] <= 65535)
            n = sprintf(reply, "\033[?9001;%u;%d;%dR", term->esc_args[1],
                        term->curs.y + 1, term->curs.x + 1);
        if (n) ldisc_send(term->ldisc, reply, n, false);
        return;
    }
    if (n) nemo_protocol_send(term, reply, n);
}

static void nemo_graphics_query(Terminal *term)
{
    /* Xterm dispatches only an exact item/action/value triple. Geometry
     * bounds are per axis, not a reservation of the shared raster budget. */
    if (term->esc_nargs != 3) return;
    unsigned item = term->esc_args[0], action = term->esc_args[1];
    unsigned status = 0, value = 0, height = 0;
    if (item == 1) {
        switch (action) {
          case 1: value = term->sixel_register_count; break;
          case 2:
            value = term->sixel_register_count = NEMO_SIXEL_PALETTE_SIZE;
            break;
          case 3:
            value = term->esc_args[2];
            if (value < 2 || value > NEMO_SIXEL_PALETTE_SIZE) status = 3;
            else term->sixel_register_count = value;
            break;
          case 4: value = NEMO_SIXEL_PALETTE_SIZE; break;
          default: status = 2; break;
        }
    } else if (item == 2) {
        switch (action) {
          case 1:
            value = min((uint64_t)max(0, term->cols) * max(0, term->cell_width),
                        NEMO_SIXEL_MAX_DIMENSION);
            height = min((uint64_t)max(0, term->rows) * max(0, term->cell_height),
                         NEMO_SIXEL_MAX_DIMENSION);
            break;
          case 2: case 3: status = 3; break; /* fixed decoder geometry limit */
          case 4: value = height = NEMO_SIXEL_MAX_DIMENSION; break;
          default: status = 2; break;
        }
    } else {
        status = 1; /* no ReGIS decoder or other graphics attribute items */
    }
    if (term->ldisc) {
        char reply[96];
        int n = status ? sprintf(reply, "\033[?%u;%uS", item, status) :
            item == 1 ? sprintf(reply, "\033[?1;0;%uS", value) :
            sprintf(reply, "\033[?2;0;%u;%uS", value, height);
        nemo_protocol_send(term, reply, n);
    }
}

static void nemo_sixel_palette_changed(void *ctx)
{
    Terminal *term = ctx;
    /* Shared register changes also recolor older retained sources. The
     * palette mutation is independent of whether this DCS later completes. */
    if (term->images) term_invalidate(term);
}

static void nemo_sixel_begin(Terminal *term)
{
    /* 8 KiB is larger than the fixed decoder object. Reserve before init,
     * then admission tracks precise allocations, including the list node. */
    if (!nemo_image_admit(term, 0, 8192)) return;
    term->sixel_pending = nemo_sixel_init(
        NEMO_SIXEL_DEFAULT_BUDGET - sizeof(NemoTermImage),
        term->sixel_header[1] == 1);
    if (!term->sixel_pending) return;
    nemo_sixel_set_register_count(term->sixel_pending, term->sixel_register_count);
    nemo_sixel_set_allocation_guard(term->sixel_pending, nemo_image_admit, term);
    if (!term->sixel_private_palette) {
        if (!term->sixel_palette_valid) {
            nemo_sixel_get_palette(term->sixel_pending, term->sixel_palette);
            term->sixel_palette_valid = true;
        }
        /* This binding is retained by the decoder after completion, so mode
         * changes affect future images only. All decoders die before term. */
        if (!nemo_sixel_share_palette(term->sixel_pending, term->sixel_palette,
                                     nemo_sixel_palette_changed, term)) {
            nemo_sixel_cancel(term);
            return;
        }
    }
    /* Modern square-pixel default; explicit legacy macros retain DEC ratios. */
    unsigned macro = term->sixel_header[0];
    unsigned ratio = macro == 2 ? 5 : macro == 3 || macro == 4 ? 3 :
        macro == 1 || macro == 5 || macro == 6 ? 2 : 1;
    nemo_sixel_set_aspect(term->sixel_pending, ratio, 1);
    term->sixel_x = term->sixel_display_mode ? 0 : term->curs.x;
    term->sixel_y = term->sixel_display_mode ? 0 : term->curs.y;
    term->sixel_screen = term->alt_which;
}

static void nemo_sixel_complete(Terminal *term)
{
    term->grapheme_pending = false;
    NemoSixel *decoder = term->sixel_pending;
    if (!decoder) return;
    if (!nemo_sixel_finish(decoder)) { nemo_sixel_cancel(term); return; }
    NemoSixelStats st = nemo_sixel_stats(decoder);
    uint64_t pw = (uint64_t)st.width * st.aspect_horizontal;
    uint64_t ph = (uint64_t)st.height * st.aspect_vertical;
    if (!st.has_sixels || !pw || !ph || pw > NEMO_SIXEL_MAX_DIMENSION ||
        ph > NEMO_SIXEL_MAX_DIMENSION) { nemo_sixel_cancel(term); return; }
    int cols = ((int)pw-1) / term->cell_width + 1;
    int rows = ((int)ph-1) / term->cell_height + 1;
    unsigned bands = ((unsigned)ph+NEMO_IMAGE_MASK_ROWS-1) / NEMO_IMAGE_MASK_ROWS;
    size_t extra = ph * sizeof(NemoImageRow) + bands*sizeof(unsigned char *) +
        sizeof(NemoTermImage) + sizeof(NemoImageSource);
    if (!nemo_image_admit(term, st.allocated_bytes, extra)) {
        nemo_sixel_cancel(term); return;
    }
    NemoTermImage *image = snew(NemoTermImage);
    memset(image, 0, sizeof(*image));
    image->source = snew(NemoImageSource);
    *image->source = (NemoImageSource){decoder, 1,
        st.allocated_bytes + sizeof(NemoImageSource)};
    image->lines = snewn(ph, NemoImageRow);
    memset(image->lines, 0, ph * sizeof(NemoImageRow));
    for (unsigned y = 0; y < ph; y++) image->lines[y].anchor = term->sixel_y;
    image->band_count = bands;
    image->mask_bands = snewn(bands, unsigned char *);
    memset(image->mask_bands, 0, bands*sizeof(unsigned char *));
    image->x = term->sixel_x; image->y = term->sixel_y;
    image->last_y = (int)min((int64_t)INT_MAX, (int64_t)term->sixel_y + rows-1);
    image->screen = term->sixel_screen;
    image->pixel_width = (int)pw; image->pixel_height = (int)ph;
    image->live_rows = (int)ph;
    image->memory_bytes = extra - sizeof(NemoImageSource);
    NemoTermImage **tail = &term->images;
    while (*tail) tail = &(*tail)->next;
    *tail = image;
    term->image_bytes += image->memory_bytes + image->source->memory_bytes;
    term->sixel_pending = NULL;
    nemo_sixel_set_allocation_guard(decoder, NULL, NULL);
    if (!term->sixel_display_mode) {
        int target_y = term->sixel_y + rows - 1;
        int target_x = term->sixel_x + (term->sixel_scrolls_right ? cols : 0);
        /* XTerm's graphic completion wraps once at the right margin and
         * scrolls into the vertical region, including a graphic that began
         * outside that region. DECSDM display mode leaves the cursor alone. */
        if (target_x > term->marg_r) {
            target_x = term->marg_l;
            target_y++;
        }
        while (target_y > term->marg_b) {
            scroll(term, term->marg_t, term->marg_b, 1, true);
            target_y--;
        }
        term->curs.y = min(target_y, term->rows-1);
        term->curs.x = target_x;
        term->wrapnext = false;
    }
    term_invalidate(term);
}

static void set_erase_char(Terminal *term);

static void nemo_report_sgr_colour(strbuf *reply, unsigned prefix,
                                   unsigned index, optionalrgb rgb, bool colon)
{
    if (rgb.enabled)
        put_fmt(reply, ";%u:2::%u:%u:%u", prefix, rgb.r, rgb.g, rgb.b);
    else if (index < 8)
        put_fmt(reply, ";%u", (prefix == 38 ? 30 : 40) + index);
    else if (index < 16)
        put_fmt(reply, ";%u", (prefix == 38 ? 90 : 100) + index-8);
    else if (index < 256)
        put_fmt(reply, colon ? ";%u:5:%u" : ";%u;5;%u", prefix, index);
}

struct NemoSgrStack {
    uint64_t used;
    struct {
        uint64_t mask;
        unsigned long attr;
        truecolour tc;
    } frames[10];
};

/* The ten retained frames match xterm. Excess pushes consume only a bounded
 * counter, so their corresponding pops cannot prematurely restore a frame. */
static void nemo_push_sgr(Terminal *term)
{
    uint64_t mask = 0;
    if (term->esc_nargs == 1 && !term->esc_arg_present) {
        mask = UINT64_MAX;
    } else {
        for (int i = 0; i < term->esc_nargs; i++) {
            unsigned selector = term->esc_args[i];
            if (selector == 10) selector = 30;
            if (selector == 11) selector = 31;
            if (selector == 53) {mask |= UINT32_C(1) << 31;continue;}
            if (selector == 51) {mask |= UINT64_C(1) << 32;continue;}
            if (selector == 52) {mask |= UINT64_C(1) << 33;continue;}
            if (selector >= 60 && selector <= 64) {
                mask |= UINT64_C(1) << (selector-26);
                continue;
            }
            if (selector > 0 && selector < 32)
                mask |= UINT32_C(1) << (selector-1);
        }
    }
    if (!term->sgr_stack) {
        term->sgr_stack = snew(struct NemoSgrStack);
        memset(term->sgr_stack, 0, sizeof(*term->sgr_stack));
    }
    struct NemoSgrStack *stack = term->sgr_stack;
    if (stack->used < lenof(stack->frames)) {
        stack->frames[stack->used].mask = mask;
        stack->frames[stack->used].attr = term->curr_attr;
        stack->frames[stack->used].tc = term->curr_truecolour;
    }
    if (stack->used < UINT64_MAX) stack->used++;
}

static void nemo_pop_sgr(Terminal *term)
{
    struct NemoSgrStack *stack = term->sgr_stack;
    if (!stack) return;
    assert(stack->used);
    if (--stack->used < lenof(stack->frames)) {
        uint64_t mask = stack->frames[stack->used].mask;
        unsigned long saved = stack->frames[stack->used].attr, attrs = 0;
        truecolour tc = stack->frames[stack->used].tc;
        static const struct { unsigned selector; unsigned long bits; } flags[] = {
            {1, ATTR_BOLD}, {2, ATTR_DIM}, {3, ATTR_ITALIC}, {4, ATTR_UNDER},
            {5, ATTR_BLINK}, {7, ATTR_REVERSE}, {8, ATTR_CONCEAL}, {9, ATTR_STRIKE},
            {30, ATTR_FGMASK}, {31, ATTR_BGMASK},
        };
        for (size_t i = 0; i < lenof(flags); i++)
            if (mask & (UINT32_C(1) << (flags[i].selector-1))) attrs |= flags[i].bits;
        term->curr_attr = (term->curr_attr & ~attrs) | (saved & attrs);
        if (mask & (UINT32_C(1) << 29)) term->curr_truecolour.fg = tc.fg;
        if (mask & (UINT32_C(1) << 30)) term->curr_truecolour.bg = tc.bg;
        uint64_t decorations = 0;
        if (mask & (UINT32_C(1) << 3)) decorations |= UNDER_STYLE_MASK;
        if (mask & (UINT32_C(1) << 20)) decorations |= UNDER_DOUBLE_LEGACY;
        if (mask & (UINT32_C(1) << 31)) decorations |= DECOR_OVERLINE;
        if (mask & (UINT64_C(1) << 32)) decorations |= DECOR_FRAMED;
        if (mask & (UINT64_C(1) << 33)) decorations |= DECOR_ENCIRCLED;
        for (unsigned i = 0; i < 5; i++)
            if (mask & (UINT64_C(1) << (34+i)))
                decorations |= DECOR_IDEO_UNDERLINE << i;
        /* No-argument saves also preserve our modern underline colour. */
        if (mask == UINT64_MAX) decorations |= UNDER_COLOUR_MASK;
        term->curr_truecolour.decoration =
            (term->curr_truecolour.decoration & ~decorations) | (tc.decoration & decorations);
        set_erase_char(term);
    }
    if (!stack->used) {
        sfree(stack);
        term->sgr_stack = NULL;
    }
}

static void nemo_modify_keys_setting(Terminal *term, bool format)
{
    bool reset_all = term->esc_nargs == 1 && !term->esc_arg_present && !term->esc_has_subargs;
    if (!reset_all && (term->esc_args[0] != 4 || term->esc_nargs > 2)) return;
    if (term->esc_has_subargs && (format || term->esc_nargs != 2 ||
        term->esc_sub_count[0] || term->esc_sub_count[1] != 1)) return;
    unsigned value = (term->esc_arg_present & 2) ? term->esc_args[1] :
        conf_get_int(term->conf, format ? CONF_nemo_format_other_keys : CONF_nemo_modify_other_keys);
    if (format) {
        if (value <= 1) term->modify_keys.format = value;
    } else if (value <= 3 || value == 65535) {
        term->modify_keys.level = value == 65535 ? -1 : (int)value;
        term->modify_keys.ignore = term->esc_has_subargs ? term->esc_subargs[1][0] : 0;
    }
}

static void nemo_modify_keys_query(Terminal *term, bool format)
{
    if (!term->ldisc) return;
    for (int i = 0; i < term->esc_nargs; i++) {
        if (term->esc_args[i] != 4) continue;
        char reply[32];
        unsigned value = format ? term->modify_keys.format :
            term->modify_keys.level < 0 ? 65535 : term->modify_keys.level;
        int n = sprintf(reply, "\033[>4;%u%c", value, format ? 'f' : 'm');
        nemo_protocol_send(term, reply, n);
    }
}

/* The input string is at most 63 bytes. Replies describe only implemented
 * state, with bounded output independent of the request's length. */
static void nemo_decrqss(Terminal *term)
{
    if (!term->ldisc) return;
    const char *query = term->dcs_query;
    if (!term->dcs_query_invalid && !strcmp(query, "\"p") && !has_compat(VT220))
        return;
    strbuf *reply = strbuf_new();
    bool valid = !term->dcs_query_invalid;
    if (valid && !strcmp(query, "m")) {
        unsigned long attr = term->curr_attr;
        truecolour tc = term->curr_truecolour;
        put_byte(reply, '0');
        static const struct { unsigned long attr; unsigned sgr; } flags[] = {
            {ATTR_BOLD, 1}, {ATTR_DIM, 2}, {ATTR_ITALIC, 3},
            {ATTR_BLINK, 5}, {ATTR_REVERSE, 7}, {ATTR_CONCEAL, 8},
            {ATTR_STRIKE, 9},
        };
        for (size_t i = 0; i < lenof(flags); i++)
            if (attr & flags[i].attr) put_fmt(reply, ";%u", flags[i].sgr);
        if (attr & ATTR_UNDER) {
            unsigned style = UNDER_STYLE_RAW(tc);
            if (style <= 1) put_dataz(reply, ";4");
            else put_fmt(reply, ";4:%u", style);
        }
        if (tc.decoration & UNDER_DOUBLE_LEGACY) put_dataz(reply, ";21");
        if (tc.decoration & DECOR_FRAMED) put_dataz(reply, ";51");
        if (tc.decoration & DECOR_ENCIRCLED) put_dataz(reply, ";52");
        if (tc.decoration & DECOR_OVERLINE) put_dataz(reply, ";53");
        for (unsigned i = 0; i < 5; i++)
            if (tc.decoration & (DECOR_IDEO_UNDERLINE << i))
                put_fmt(reply, ";%u", 60+i);
        nemo_report_sgr_colour(reply, 38, (attr & ATTR_FGMASK) >> ATTR_FGSHIFT, tc.fg, false);
        nemo_report_sgr_colour(reply, 48, (attr & ATTR_BGMASK) >> ATTR_BGSHIFT, tc.bg, false);
        uint32_t colour = tc.decoration & UNDER_COLOUR_MASK;
        if (colour & UNDER_RGB)
            put_fmt(reply, ";58:2::%u:%u:%u", (colour >> 16) & 255,
                    (colour >> 8) & 255, colour & 255);
        else if (colour & UNDER_INDEXED)
            put_fmt(reply, ";58;5;%u", colour & 255);
        put_byte(reply, 'm');
    } else if (valid && !strcmp(query, "\"p")) {
        unsigned level = has_compat(VT510) ? 65 : has_compat(VT420) ? 64 :
            has_compat(VT320) ? 63 : 62;
        put_fmt(reply, "%u;%u\"p", level, term->c1_8bit ? 0 : 1);
    } else if (valid && !strcmp(query, "r")) {
        put_fmt(reply, "%d;%dr", term->marg_t+1, term->marg_b+1);
    } else if (valid && !strcmp(query, "s")) {
        put_fmt(reply, "%d;%ds", term->marg_l+1, term->marg_r+1);
    } else if (valid && !strcmp(query, "*x")) {
        put_fmt(reply, "%u*x", term->rectangle_extent);
    } else if (valid && !strcmp(query, "\"q")) {
        put_fmt(reply, "%u\"q", term->protection_mode == NEMO_PROTECT_DEC &&
                !!(term->curr_truecolour.decoration & CELL_PROTECTED));
    } else if (valid && !strcmp(query, " q")) {
        int type = term->big_cursor ? CURSOR_BLOCK : term->cursor_type;
        put_fmt(reply, "%d q", 2*type + (term->blink_cur ? 1 : 2));
    } else if (valid && !strcmp(query, "$|")) {
        put_fmt(reply, "%d$|", term->cols);
    } else if (valid && !strcmp(query, "*|")) {
        put_fmt(reply, "%d*|", term->rows);
    } else if (valid && (!strcmp(query, ">4m") || !strcmp(query, ">4f"))) {
        bool format = query[2] == 'f';
        unsigned value = format ? term->modify_keys.format :
            term->modify_keys.level < 0 ? 65535 : term->modify_keys.level;
        put_fmt(reply, ">4;%u", value);
        if (!format && term->modify_keys.ignore) put_fmt(reply, ":%u", term->modify_keys.ignore);
        put_byte(reply, format ? 'f' : 'm');
    } else if (valid && query[0] == '>' &&
               !strcmp(query + 1 + strspn(query + 1, "0123456789;"), "t")) {
        /* XTerm reports all four bits for an omitted first parameter, or
         * only the requested bit. Remaining numeric parameters are ignored. */
        const char *p = query + 1;
        unsigned bit = 0;
        bool present = *p >= '0' && *p <= '9';
        while (*p >= '0' && *p <= '9') {
            if (bit > 3) valid = false;
            if (valid) bit = bit * 10 + (*p - '0');
            p++;
        }
        if (!present)
            put_fmt(reply, ">%u;%u;%u;%ut", !!(term->title_modes & 1),
                    !!(term->title_modes & 2), !!(term->title_modes & 4),
                    !!(term->title_modes & 8));
        else if (valid && bit < 4)
            put_fmt(reply, ">%ut", !!(term->title_modes & (1u << bit)));
        else valid = false;
    } else {
        valid = false;
    }
    nemo_protocol_send(term, valid ? "\033P1$r" : "\033P0$r", 5);
    if (valid) nemo_protocol_send(term, reply->s, reply->len);
    nemo_protocol_send(term, "\033\\", 2);
    strbuf_free(reply);
}

static int nemo_charset_code(unsigned char c)
{
    switch (c) {
      case 'B': return CSET_ASCII;
      case 'A': return CSET_GBCHR;
      case '0': return CSET_LINEDRW;
      case 'U': return CSET_SCOACS;
      default: return -1;
    }
}

static unsigned nemo_charset_level(Terminal *term)
{
    return has_compat(VT510) ? 5 : has_compat(VT420) ? 4 :
        has_compat(VT320) ? 3 : has_compat(VT220) ? 2 : 1;
}

/* Negative values are immutable table handles, never cell/font tags. The
 * 96-introducer bit is distinct from the descriptor's reported set size. */
static const NemoCharset *nemo_charset_descriptor(int attr)
{
    return attr < 0 && attr > -512 ?
        nemo_charset_by_id((unsigned)-attr & 255) : NULL;
}

static int nemo_charset_select(Terminal *term, bool size96,
                               const char *name, size_t length)
{
    if (!size96 && length == 1) {
        int legacy = nemo_charset_code((unsigned char)*name);
        if (legacy >= 0) return legacy;
    }
    const NemoCharset *cs = nemo_charset_designate(size96 ? 3 : 1,
        nemo_charset_level(term), term->nrc_mode, name, length);
    return cs ? -(int)(nemo_charset_id(cs) | (size96 ? 256 : 0)) : CSET_ASCII;
}

static unsigned long nemo_charset_graphic(Terminal *term, int attr, unsigned byte)
{
    const NemoCharset *cs = nemo_charset_descriptor(attr);
    if (!cs || (byte == 0x7f && !((unsigned)-attr & 256))) return UCSINCOMPLETE;
    cs = nemo_charset_resolve(cs, term->upss_id, nemo_charset_level(term));
    uint32_t value = nemo_charset_map_mode(cs, byte, nemo_charset_level(term), term->nrc_mode,
                                         !term->nrc_mode || nemo_charset_base_utf8(term));
    if (value == NEMO_CHARSET_NOCHAR) return UCSINCOMPLETE;
    /* Mapped codepoints are data, including DEL/C1 glyphs from 96 sets.
     * Existing direct-character tags prevent a second control interpretation. */
    if (value < 0x20 || (value >= 0x7f && value < 0xa0)) return value | CSET_ASCII;
    return value;
}

static uint64_t nemo_charset_checksum_metadata(Terminal *term, int attr,
                                              unsigned byte)
{
    const NemoCharset *cs = nemo_charset_descriptor(attr);
    if (!cs) {
        const char *name = attr == CSET_LINEDRW ? "0" : attr == CSET_GBCHR ? "A" : "B";
        cs = nemo_charset_designate(1, nemo_charset_level(term), term->nrc_mode, name, 1);
    }
    cs = nemo_charset_resolve(cs, term->upss_id, nemo_charset_level(term));
    uint64_t result = CELL_CHECKSUM_VALID |
        (uint64_t)nemo_charset_checksum(cs, byte) << CELL_CHECKSUM_SHIFT;
    if (cs && !strcmp(cs->designation, "A") && term->nrc_mode &&
        !nemo_charset_base_utf8(term) && (byte & 0x7f) == 0x23)
        result |= CELL_CHECKSUM_BYTE_POUND;
    return result;
}

static bool nemo_charset_escape(Terminal *term, unsigned char final)
{
    if (term->esc_query <= 0) return false;
    unsigned intro = term->esc_query & 255;
    bool size96 = intro >= '-' && intro <= '/';
    if (!(intro >= '(' && intro <= '+') && !size96) return false;
    if (term->no_remote_charset || !has_compat(VT100) ||
        (size96 && !has_compat(VT320)) ||
        ((intro == '*' || intro == '+') && !has_compat(VT220))) return true;
    unsigned prefix = (unsigned)term->esc_query >> 8;
    /* The SCS parser admits only registered finals after these intermediates.
     * Other finals cancel the designation, preserving the previous bank. */
    if (prefix && !(prefix == '%' ? strchr("02356=", final) != NULL :
                    prefix == '&' ? strchr("45", final) != NULL :
                    prefix == '"' ? strchr("4>?", final) != NULL : false)) return true;
    char name[2] = { prefix ? (char)prefix : (char)final, (char)final };
    int bank = size96 ? intro-'-'+1 : intro-'(';
    if (final != 'U' || prefix || has_compat(OTHER))
        term->cset_attr[bank] = nemo_charset_select(term, size96, name, prefix ? 2 : 1);
    return true;
}

static bool nemo_charset_base_utf8(Terminal *term)
{
    return term->utf > 0 ||
        (term->utf == 0 && term->ucsdata->line_codepage == CP_UTF8);
}

static void nemo_charset_reset(Terminal *term)
{
    bool latin1 = !nemo_charset_base_utf8(term) &&
        !term->no_remote_charset && nemo_charset_level(term) >= 2;
    const NemoCharset *cs = nemo_charset_designate(latin1 ? 3 : 1, 5,
                                                  false, latin1 ? "A" : "B", 1);
    term->upss_id = nemo_charset_id(cs);
    for (size_t i=0; i<lenof(term->cset_attr); i++) term->cset_attr[i]=CSET_ASCII;
    if (latin1) term->cset_attr[2] = term->cset_attr[3] = -(int)(term->upss_id | 256);
}

static void nemo_charset_assign_preferred(Terminal *term)
{
    if (term->no_remote_charset || in_utf(term) || term->dcs_query_invalid ||
        !term->dcs_upss_header_valid) return;
    const NemoCharset *cs = nemo_charset_preferred(term->sixel_header[0],
        term->dcs_query, term->dcs_query_len);
    if (cs) term->upss_id = nemo_charset_id(cs);
}

static void nemo_charset_report_preferred(Terminal *term)
{
    const NemoCharset *cs = nemo_charset_by_id(term->upss_id);
    if (!cs || !term->ldisc) return;
    char reply[16];
    int length = snprintf(reply, sizeof(reply), "\033P%d!u%s\033\\",
                          cs->size96 ? 1 : 0, cs->designation);
    nemo_protocol_send(term, reply, length);
}

static void nemo_charset_docs(Terminal *term, bool utf8)
{
    if (term->no_remote_charset) return;
    bool before = in_utf(term);
    term->utf = utf8 ? 1 : -1;
    term->utf8.state = 0;
    if (before == in_utf(term)) return;
    if (utf8) {
        memcpy(term->ansi_csattr, term->cset_attr, sizeof(term->ansi_csattr));
        term->ansi_upss_id = term->upss_id;
        term->upss_id = nemo_charset_id(nemo_charset_designate(1,5,false,"B",1));
        for (size_t i=0; i<lenof(term->cset_attr); i++) term->cset_attr[i]=CSET_ASCII;
        term->cset=term->cset_ss=0;
        term->cset_gr=2;
    } else {
        memcpy(term->cset_attr, term->ansi_csattr, sizeof(term->cset_attr));
        term->upss_id = term->ansi_upss_id;
    }
}

static void nemo_presentation_report(Terminal *term)
{
    if (!term->ldisc || (term->esc_args[0] != 1 && term->esc_args[0] != 2)) return;
    strbuf *reply = strbuf_new();
    put_fmt(reply, "\033P%u$u", term->esc_args[0]);
    if (term->esc_args[0] == 1) {
        unsigned rendition = 0x40 |
            ((term->curr_attr & ATTR_BOLD) ? 1 : 0) |
            ((term->curr_attr & ATTR_UNDER) ? 2 : 0) |
            ((term->curr_attr & ATTR_BLINK) ? 4 : 0) |
            ((term->curr_attr & ATTR_REVERSE) ? 8 : 0);
        unsigned flags = 0x40 | (term->dec_om ? 1 : 0) |
            (term->cset_ss == 2 ? 2 : term->cset_ss == 3 ? 4 : 0) |
            (term->wrapnext ? 8 : 0);
        unsigned sizes = 0x40;
        for (size_t i = 0; i < lenof(term->cset_attr); i++) {
            const NemoCharset *cs = nemo_charset_descriptor(term->cset_attr[i]);
            if (cs && cs->size96) sizes |= 1u << i;
        }
        put_fmt(reply, "%d;%d;1;%c;%c;%c;%d;%d;%c;", term->curs.y+1, term->curs.x+1,
                rendition, (term->protection_mode & NEMO_PROTECT_DEC) ? 'A' : '@', flags,
                term->cset, term->cset_gr, sizes);
        for (size_t i = 0; i < lenof(term->cset_attr); i++) {
            const NemoCharset *cs = nemo_charset_descriptor(term->cset_attr[i]);
            if (cs) put_dataz(reply, cs->designation);
            else put_byte(reply, term->cset_attr[i] == CSET_GBCHR ? 'A' :
                     term->cset_attr[i] == CSET_LINEDRW ? '0' :
                     term->cset_attr[i] == CSET_SCOACS ? 'U' : 'B');
        }
    } else {
        bool first = true;
        for (int col = 1; col < term->cols; col++) if (term->tabs[col]) {
            if (!first) put_byte(reply, '/');
            put_fmt(reply, "%d", col+1);
            first = false;
        }
    }
    put_dataz(reply, "\033\\");
    nemo_protocol_send(term, reply->s, reply->len);
    strbuf_free(reply);
}

static unsigned nemo_presentation_uint(const char **input)
{
    unsigned value = 0;
    bool found = false;
    const char *p = *input;
    while (*p >= '0' && *p <= '9') {
        unsigned digit = *p++ - '0';
        value = value <= (UINT_MAX-digit)/10 ? value*10+digit : UINT_MAX;
        found = true;
    }
    if (*p == ';') p++;
    else if (*p) p += strlen(p);
    *input = p;
    return found ? value : UINT_MAX;
}

static unsigned nemo_presentation_char(const char **input)
{
    const char *p = *input;
    unsigned value = (unsigned char)*p;
    if (*p) {
        p++;
        if (*p == ';') p++;
        else if (*p) value = 0;
    }
    *input = p;
    return value;
}

/* Apply valid fields in order as xterm does, but only after receiving ST. */
static void nemo_restore_cursor_information(Terminal *term)
{
    if (term->dcs_query_invalid) return;
    const char *p = term->dcs_query;
    unsigned value = nemo_presentation_uint(&p);
    if (!value || value > (unsigned)term->rows) return;
    term->curs.y = value-1;
    term->grapheme_pending = false;
    seen_disp_event(term);
    value = nemo_presentation_uint(&p);
    if (!value || value > (unsigned)term->cols) return;
    term->curs.x = value-1;
    if (nemo_presentation_uint(&p) != 1) return;
    value = nemo_presentation_char(&p);
    if ((value & 0xf0) != 0x40 &&
        ((value & 0x10) ? !has_compat(VT510) : !(value & 0x40))) return;
    term->curr_attr &= ~(ATTR_BOLD | ATTR_UNDER | ATTR_BLINK | ATTR_REVERSE);
    if (value & 1) term->curr_attr |= ATTR_BOLD;
    if (value & 2) term->curr_attr |= ATTR_UNDER;
    if (value & 4) term->curr_attr |= ATTR_BLINK;
    if (value & 8) term->curr_attr |= ATTR_REVERSE;
    if (value & 16) term->curr_attr |= ATTR_CONCEAL;
    term->curr_truecolour.decoration &= ~UNDER_STYLE_MASK;
    if (value & 2) term->curr_truecolour.decoration |= UINT32_C(1) << UNDER_STYLE_SHIFT;
    set_erase_char(term);
    value = nemo_presentation_char(&p);
    if ((value & 0xfe) != 0x40) return;
    term->protection_mode = (term->protection_mode & NEMO_PROTECT_ISO) |
        ((value & 1) ? NEMO_PROTECT_DEC : NEMO_PROTECT_NONE);
    value = nemo_presentation_char(&p);
    if ((value & 0xf0) != 0x40) return;
    term->wrapnext = value & 8;
    term->dec_om = value & 1;
    if (!term->no_remote_charset)
        term->cset_ss = (value & 4) ? 3 : (value & 2) ? 2 : 0;
    value = nemo_presentation_char(&p);
    if (value < '0' || value > '3') return;
    if (!term->no_remote_charset) term->cset = value-'0';
    value = nemo_presentation_char(&p);
    if (value < '0' || value > '3') return;
    if (!term->no_remote_charset) term->cset_gr = value-'0';
    unsigned sizes = nemo_presentation_char(&p);
    if ((sizes & 0xf0) != 0x40) return;
    for (size_t i = 0; i < lenof(term->cset_attr) && *p; i++) {
        size_t length = (*p == '%' || *p == '&' || *p == '"') ? 2 : 1;
        if (length == 2 && !p[1]) break;
        if (!term->no_remote_charset)
            /* XTerm's restore_DECCIR validates but does not use the size field:
             * ambiguous designations take the first 94-group table match. */
            term->cset_attr[i] = nemo_charset_select(term, false, p, length);
        p += length;
    }
}

static void nemo_presentation_cancel(Terminal *term)
{
    sfree(term->dcs_tabs_pending);
    term->dcs_tabs_pending = NULL;
    term->dcs_tabs_bytes = 0;
}

static void nemo_presentation_tab_stop(Terminal *term)
{
    unsigned stop = term->dcs_tab_value;
    if (stop > 1 && stop-1 < term->dcs_tabs_bytes*8)
        term->dcs_tabs_pending[(stop-1)/8] |= 1u << ((stop-1)%8);
    term->dcs_tab_value = 0;
}

static void nemo_presentation_tab_byte(Terminal *term, unsigned char c)
{
    if (term->dcs_tab_stopped) return;
    if (c >= '0' && c <= '9') {
        unsigned digit = c-'0';
        term->dcs_tab_value = term->dcs_tab_value <= (UINT_MAX-digit)/10 ?
            term->dcs_tab_value*10+digit : UINT_MAX;
    } else {
        nemo_presentation_tab_stop(term);
        if (c != '/') term->dcs_tab_stopped = true;
    }
}

/* true means the raw byte was consumed here. An unexpected ESC sequence
 * cancels DCS and returns the next byte to PuTTY's normal ESC state machine. */
static bool nemo_dcs_byte(Terminal *term, unsigned char c)
{
    if (c == 0x18 || c == 0x1a) {
        nemo_presentation_cancel(term);
        term->dcs_query_active = false;
        nemo_sixel_cancel(term); term->termstate = TOPLEVEL; return true;
    }
    if (c == 0x9c || (term->termstate == NEMO_DCS_MAYBE_ST && c == '\\')) {
        if (term->dcs_query_active) {
            if (term->dcs_query_type == 'U') nemo_charset_assign_preferred(term);
            else if (term->dcs_query_type == '$') nemo_decrqss(term);
            else if (term->dcs_query_type == '1') nemo_restore_cursor_information(term);
            else if (term->dcs_query_type == '2') {
                if (!term->dcs_tab_stopped) nemo_presentation_tab_stop(term);
                for (int i = 0; i < term->tabs_size; i++)
                    term->tabs[i] = (size_t)i/8 < term->dcs_tabs_bytes &&
                        (term->dcs_tabs_pending[i/8] & (1u << (i%8))) != 0;
            } else if (term->ldisc) {
                strbuf *reply = nemo_tcap_reply(term, term->dcs_query,
                                               term->dcs_query_invalid);
                nemo_protocol_send(term, reply->s, reply->len);
                strbuf_free(reply);
            }
        }
        term->dcs_query_active = false;
        nemo_presentation_cancel(term);
        nemo_sixel_complete(term); term->termstate = TOPLEVEL; return true;
    }
    if (term->termstate == NEMO_DCS_MAYBE_ST) {
        nemo_presentation_cancel(term);
        term->dcs_query_active = false;
        nemo_sixel_cancel(term); term->termstate = SEEN_ESC;
        term->esc_query = 0;
        return false;
    }
    if (term->termstate == NEMO_DCS_MAYBE_ST_UTF8) {
        nemo_presentation_cancel(term);
        term->dcs_query_invalid = true;
        nemo_sixel_cancel(term); term->termstate = NEMO_DCS_DROP;
    }
    if (term->termstate == NEMO_DCS_QUERY && term->dcs_query_type == 'U') {
        /* UPSS designators are seven-bit string data. C0 bytes make the
         * designator invalid; they must not silently join its two halves. */
        if (c >= 0xa0) c &= 0x7f;
        if (c < ' ' && c != 0x1b) term->dcs_query_invalid = true;
    }
    if (c == 0x1b) { term->termstate = NEMO_DCS_MAYBE_ST; return true; }
    if (c == 0xc2) { term->termstate = NEMO_DCS_MAYBE_ST_UTF8; return true; }
    if (term->termstate == NEMO_DCS_HEADER) {
        if (c <= ' ') term->dcs_upss_header_valid = false;
        if (c >= '0' && c <= '9') {
            term->dcs_query_type = !term->dcs_header_params && (c >= '0' && c <= '2') ? c : 0;
            term->dcs_header_params = true;
            unsigned *p = &term->sixel_header[term->sixel_header_index];
            if (*p > (UINT_MAX - (c-'0')) / 10) term->termstate = NEMO_DCS_DROP;
            else *p = *p * 10 + c-'0';
        } else if (c == ';' && term->sixel_header_index < 2) {
            term->dcs_query_type = 0;
            term->dcs_header_params = true;
            term->sixel_header_index++;
        } else if (((c == '$' || c == '+') && !term->dcs_header_params) ||
                   (c == '$' && (term->dcs_query_type == '1' || term->dcs_query_type == '2'))) {
            if (!term->dcs_header_params) term->dcs_query_type = c;
            term->termstate = NEMO_DCS_QUERY_PREFIX;
        } else if (c == '!' && (term->dcs_query_type == '0' || term->dcs_query_type == '1')) {
            term->dcs_query_type = 'U';
            term->termstate = NEMO_DCS_QUERY_PREFIX;
        } else if (c == 'q') {
            nemo_sixel_begin(term);
            term->termstate = term->sixel_pending ? NEMO_DCS_SIXEL : NEMO_DCS_DROP;
        } else if (c > ' ') term->termstate = NEMO_DCS_DROP;
    } else if (term->termstate == NEMO_DCS_QUERY_PREFIX) {
        if ((c == 'u' && term->dcs_query_type == 'U' && has_compat(VT320)) ||
            (c == 'q' && (term->dcs_query_type == '$' || term->dcs_query_type == '+')) ||
            (c == 't' && has_compat(VT320) &&
             (term->dcs_query_type == '1' || term->dcs_query_type == '2'))) {
            term->dcs_query_active = true;
            term->termstate = NEMO_DCS_QUERY;
            if (term->dcs_query_type == '2') {
                term->dcs_tabs_bytes = ((size_t)term->tabs_size+7)/8;
                term->dcs_tabs_pending = snewn(term->dcs_tabs_bytes, unsigned char);
                memset(term->dcs_tabs_pending, 0, term->dcs_tabs_bytes);
                term->dcs_tab_value = 0;
                term->dcs_tab_stopped = false;
            }
        } else if (c >= ' ') term->termstate = NEMO_DCS_DROP;
    } else if (term->termstate == NEMO_DCS_QUERY) {
        if (c >= ' ') {
            if (term->dcs_query_type == '2') {
                nemo_presentation_tab_byte(term, c);
                return true;
            }
            unsigned limit = term->dcs_query_type == 'U' ? 2 :
                term->dcs_query_type == '$' ? 63 : NEMO_DCS_QUERY_SIZE-1;
            if (c > '~' || term->dcs_query_len >= limit)
                term->dcs_query_invalid = true;
            else {
                term->dcs_query[term->dcs_query_len++] = c;
                term->dcs_query[term->dcs_query_len] = '\0';
            }
        }
    } else if (term->termstate == NEMO_DCS_SIXEL) {
        if (!nemo_sixel_feed(term->sixel_pending, &c, 1)) {
            nemo_sixel_cancel(term); term->termstate = NEMO_DCS_DROP;
        }
    }
    return true;
}

static void power_on(Terminal *term, bool clear, bool keep_encoding)
{
    term->c1_8bit = false;
    term->nrc_mode = false;
    nemo_reset_ansi_colours(term);
    nemo_presentation_cancel(term);
    term->protection_mode = NEMO_PROTECT_NONE;
    term->cset_gr = 2;
    term->cset_ss = 0;
    term_set_grapheme_clustering(term, false);
    term->title_modes = 0;
    nemo_shell_marks_clear(&term->shell_marks);
    term->shell_mark_selected = 0;
    osc52_cancel_query(term);
    term->termstate = TOPLEVEL;
    term->esc_query = 0;
    nemo_highlight_cancel(term, false);
    term_end_synchronized_update(term);
    nemo_images_clear(term);
    term->sixel_display_mode = term->sixel_scrolls_right = false;
    term->sixel_private_palette = true;
    term->sixel_palette_valid = false;
    term->alt_x = term->alt_y = 0;
    term->savecurs.x = term->savecurs.y = 0;
    term->alt_savecurs.x = term->alt_savecurs.y = 0;
    term->marg_t = 0;
    term->marg_l = 0; term->marg_r = max(0, term->cols-1);
    term->lrmm = false;
    if (term->rows != -1)
        term->marg_b = term->rows - 1;
    else
        term->marg_b = 0;
    if (term->cols != -1) {
        int i;
        for (i = 0; i < term->tabs_size; i++)
            term->tabs[i] = (i % 8 == 0 ? true : false);
    }
    term->alt_om = term->dec_om = conf_get_bool(term->conf, CONF_dec_om);
    term->save_om = term->alt_save_om = term->dec_om;
    term->alt_ins = false;
    term->insert = false;
    term->alt_wnext = false;
    term->wrapnext = false;
    term->save_wnext = false;
    term->alt_save_wnext = false;
    term->alt_wrap = term->wrap = conf_get_bool(term->conf, CONF_wrap_mode);
    term->reverse_wrap = term->reverse_wrap_extended = false;
    term->alt_cset = term->cset = term->save_cset = term->alt_save_cset = 0;
    if (!keep_encoding) term->utf = 0;
    term->utf8.state = 0;
    term->alt_sco_acs = term->sco_acs =
        term->save_sco_acs = term->alt_save_sco_acs = 0;
    term->save_cset_gr = term->alt_save_cset_gr = 2;
    for (size_t i = 0; i < lenof(term->cset_attr); i++)
        term->cset_attr[i] = term->save_csattr[i] =
            term->alt_save_csattr[i] = CSET_ASCII;
    nemo_charset_reset(term);
    memcpy(term->save_csattr, term->cset_attr, sizeof(term->save_csattr));
    memcpy(term->alt_save_csattr, term->cset_attr, sizeof(term->alt_save_csattr));
    term->save_upss_id = term->alt_save_upss_id = term->upss_id;
    if (!keep_encoding) {
        for (size_t i=0; i<lenof(term->ansi_csattr); i++) term->ansi_csattr[i]=CSET_ASCII;
        term->ansi_upss_id = nemo_charset_id(nemo_charset_designate(1,5,false,"B",1));
    }
    nemo_set_reverse_video(term, false);
    term->in_vbell = false;
    term->cursor_on = true;
    term->big_cursor = false;
    term->cursor_type = conf_get_int(term->conf, CONF_cursor_type);
    term->blink_cur = conf_get_bool(term->conf, CONF_blink_cur);
    term->dcs_query_active = term->dcs_query_invalid = term->dcs_header_params = false;
    term->cblinker = true;
    term->cblink_pending = false;
    term->dcs_query_len = 0;
    term->dcs_query[0] = '\0';
    term->default_attr = term->save_attr =
        term->alt_save_attr = term->curr_attr = ATTR_DEFAULT;
    term->curr_truecolour.fg = term->curr_truecolour.bg = optionalrgb_none;
    term->curr_truecolour.decoration = 0;
    term->rectangle_extent = 0;
    term->checksum_flags = 0;
    term->save_truecolour = term->alt_save_truecolour = term->curr_truecolour;
    term->curr_hyperlink = term->save_hyperlink = term->alt_save_hyperlink = 0;
    term->hover_hyperlink = 0;
    memset(term->keyboard, 0, sizeof(term->keyboard));
    term->win32_input = false;
    term->win32_input_epoch++;
    nemo_mok_reset(&term->modify_keys, conf_get_int(term->conf, CONF_nemo_modify_other_keys),
                   conf_get_int(term->conf, CONF_nemo_format_other_keys));
    term->app_cursor_keys = conf_get_bool(term->conf, CONF_app_cursor);
    term->app_keypad_keys = conf_get_bool(term->conf, CONF_app_keypad);
    term->use_bce = conf_get_bool(term->conf, CONF_bce);
    term->blink_is_real = conf_get_bool(term->conf, CONF_blinktext);
    term->erase_char = term->basic_erase_char;
    term->alt_which = 0;
    term_print_finish(term);
    term->xterm_mouse = 0;
    term->mouse_encoding = 0;
    term->mouse_focus_reporting = term->mouse_alternate_scroll = false;
    term->mouse_buttons = 0;
    term->raw_mouse_reported_code = -1;
    term->raw_mouse_reported_x = term->raw_mouse_reported_y = -1;
    term->mouse_last_x = term->mouse_last_y = 0;
    term->mouse_last_px = term->mouse_last_py = 0;
    term->mouse_last_ctrl = term->mouse_last_alt = false;
    win_set_raw_mouse_mode(term->win, false);
    term->win_pointer_shape_pending = true;
    term->win_pointer_shape_raw = false;
    term->bracketed_paste = false;
    term->srm_echo = false;
    {
        int i;
        for (i = 0; i < 256; i++)
            term->wordness[i] = conf_get_int_int(term->conf, CONF_wordness, i);
    }
    if (term->screen) {
        swap_screen(term, 1, false, false);
        erase_lots(term, false, true, true);
        for (int y = 0; y < term->rows; y++)
            scrlineptr(y)->lattr = LATTR_NORM;
        swap_screen(term, 0, false, false);
        if (clear) {
            erase_lots(term, false, true, true);
            /* erase_lots may skip already blank rows. RIS must also reset
             * their double-width/height attributes, including on both screens. */
            for (int y = 0; y < term->rows; y++)
                scrlineptr(y)->lattr = LATTR_NORM;
        }
        term->curs.y = find_last_nonempty_line(term, term->screen) + 1;
        if (term->curs.y == term->rows) {
            term->curs.y--;
            scroll(term, 0, term->rows - 1, 1, true);
        }
    } else {
        term->curs.y = 0;
    }
    term->curs.x = 0;
    term_schedule_tblink(term);
    term_schedule_cblink(term);
    term_schedule_update(term);
}

/*
 * Force a screen update.
 */
void term_update(Terminal *term)
{
    if (term->synchronized_update) return;
    term->window_update_pending = false;

    if (term->win_move_pending) {
        win_move(term->win, term->win_move_pending_x,
                 term->win_move_pending_y);
        term->win_move_pending = false;
    }
    if (term->win_resize_pending == WIN_RESIZE_NEED_SEND) {
        term->win_resize_pending = WIN_RESIZE_AWAIT_REPLY;
        if (term->win_resize_kind == WIN_SIZE_CELLS) {
            win_request_resize(term->win, term->win_resize_pending_w,
                               term->win_resize_pending_h);
        } else if (term->no_remote_resize || !term->win->vt->request_window_resize) {
            term_resize_request_completed(term);
        } else {
            term->win->vt->request_window_resize(term->win,
                term->win_resize_pending_w, term->win_resize_pending_h,
                term->win_resize_kind == WIN_SIZE_XT_PIXELS);
        }
    }
    if (term->win_zorder_pending) {
        win_set_zorder(term->win, term->win_zorder_top);
        term->win_zorder_pending = false;
    }
    if (term->win_minimise_pending) {
        win_set_minimised(term->win, term->win_minimise_enable);
        term->win_minimise_pending = false;
    }
    if (term->win_maximise_pending) {
        win_set_maximised(term->win, term->win_maximise_enable);
        term->win_maximise_pending = false;
    }
    if (term->win_title_pending) {
        win_set_title(term->win, term->window_title,
                      term->wintitle_codepage);
        term->win_title_pending = false;
    }
    if (term->win_icon_title_pending) {
        win_set_icon_title(term->win, term->icon_title,
                           term->icontitle_codepage);
        term->win_icon_title_pending = false;
    }
    if (term->win_pointer_shape_pending) {
        win_set_raw_mouse_mode_pointer(term->win, term->win_pointer_shape_raw);
        term->win_pointer_shape_pending = false;
    }
    if (term->win_refresh_pending) {
        win_refresh(term->win);
        term->win_refresh_pending = false;
    }
    if (term->win_palette_pending) {
        unsigned start = term->win_palette_pending_min;
        unsigned ncolours = term->win_palette_pending_limit - start;
        win_palette_set(term->win, start, ncolours, term->palette + start);
        term->win_palette_pending = false;
    }

    if (win_setup_draw_ctx(term->win)) {
        if (term->win_scrollbar_update_pending) {
            term->win_scrollbar_update_pending = false;
            update_sbar(term);
        }
        do_paint(term);
        win_set_cursor_pos(
            term->win, term->curs.x, term->curs.y - term->disptop);
        win_free_draw_ctx(term->win);
    }
}

/*
 * Called from front end when a keypress occurs, to trigger
 * anything magical that needs to happen in that situation.
 */
void term_seen_key_event(Terminal *term)
{
    /*
     * On any keypress, clear the bell overload mechanism
     * completely, on the grounds that large numbers of
     * beeps coming from deliberate key action are likely
     * to be intended (e.g. beeps from filename completion
     * blocking repeatedly).
     */
    term->beep_overloaded = false;
    while (term->beephead) {
        struct beeptime *tmp = term->beephead;
        term->beephead = tmp->next;
        sfree(tmp);
    }
    term->beeptail = NULL;
    term->nbeeps = 0;

    /*
     * Reset the scrollback on keypress, if we're doing that.
     */
    if (term->scroll_on_key && term->disptop != 0) {
        term->disptop = 0;
        term->win_scrollbar_update_pending = true;
        term_schedule_update(term);
    }
}

/*
 * Same as power_on(), but an external function.
 */
void term_pwron(Terminal *term, bool clear)
{
    power_on(term, clear, false);
    if (term->ldisc)                   /* cause ldisc to notice changes */
        ldisc_echoedit_update(term->ldisc);
    term->disptop = 0;
    deselect(term);
    term_update(term);
}

static void set_erase_char(Terminal *term)
{
    term->erase_char = term->basic_erase_char;
    if (term->use_bce) {
        term->erase_char.attr = (term->curr_attr &
                                 (ATTR_FGMASK | ATTR_BGMASK));
        /* BCE drops rendition flags, but retains the resolved foreground.
         * It can become visible later through reverse/rectangle attributes. */
        unsigned fg = (term->curr_attr & ATTR_FGMASK) >> ATTR_FGSHIFT;
        if ((term->curr_attr & ATTR_BOLD) &&
            (conf_get_int(term->conf, CONF_bold_style) & BOLD_STYLE_COLOUR) &&
            !term->curr_truecolour.fg.enabled && fg < 8)
            term->erase_char.attr = (term->erase_char.attr & ~ATTR_FGMASK) |
                ((fg+8) << ATTR_FGSHIFT);
        term->erase_char.truecolour.fg = term->curr_truecolour.fg;
        term->erase_char.truecolour.bg = term->curr_truecolour.bg;
    }
}

/*
 * We copy a bunch of stuff out of the Conf structure into local
 * fields in the Terminal structure, to avoid the repeated tree234
 * lookups which would be involved in fetching them from the former
 * every time.
 */
static const int attribute_colour_keys[] = {
    CONF_nemo_attribute_bold, CONF_nemo_attribute_underline,
    CONF_nemo_attribute_blink, CONF_nemo_attribute_reverse,
    CONF_nemo_attribute_italic
};

static unsigned attribute_conf_mask(Conf *conf, int key, unsigned maximum)
{
    unsigned value = conf_get_int(conf, key);
    return value <= maximum ? value : 0;
}

static void term_copy_stuff_from_conf(Terminal *term)
{
    static const int selection_enable[] = {
        CONF_nemo_selection_bg_enabled, CONF_nemo_selection_fg_enabled
    };
    static const int selection_rgb[] = {
        CONF_nemo_selection_bg, CONF_nemo_selection_fg
    };
    for (unsigned i = 0; i < lenof(selection_enable); i++) {
        unsigned value = conf_get_int(term->conf, selection_rgb[i]);
        if (value > 0xffffff)
            value = conf_key_info[selection_rgb[i]].default_value.ival;
        term->selection_defaults[i] = (optionalrgb){
            conf_get_bool(term->conf, selection_enable[i]),
            (value >> 16) & 255, (value >> 8) & 255, value & 255
        };
    }
    unsigned custom = attribute_conf_mask(term->conf, CONF_nemo_attribute_custom, 31);
    for (unsigned i = 0; i < lenof(attribute_colour_keys); i++) {
        unsigned value = conf_get_int(term->conf, attribute_colour_keys[i]);
        if (value > 0xffffff)
            value = conf_key_info[attribute_colour_keys[i]].default_value.ival;
        term->attribute_defaults[i] = (optionalrgb){
            (custom & (1u << i)) != 0, (value >> 16) & 255,
            (value >> 8) & 255, value & 255
        };
    }
    term->attribute_keep_styles = attribute_conf_mask(
        term->conf, CONF_nemo_attribute_keep_styles, 31);
    term->ansi_colour = conf_get_bool(term->conf, CONF_ansi_colour);
    term->no_arabicshaping = conf_get_bool(term->conf, CONF_no_arabicshaping);
    term->beep = conf_get_int(term->conf, CONF_beep);
    term->bellovl = conf_get_bool(term->conf, CONF_bellovl);
    term->bellovl_n = conf_get_int(term->conf, CONF_bellovl_n);
    term->bellovl_s = conf_get_int(term->conf, CONF_bellovl_s);
    term->bellovl_t = conf_get_int(term->conf, CONF_bellovl_t);
    term->no_bidi = conf_get_bool(term->conf, CONF_no_bidi);
    term->no_bracketed_paste = conf_get_bool(term->conf, CONF_no_bracketed_paste);
    term->bksp_is_delete = conf_get_bool(term->conf, CONF_bksp_is_delete);
    term->blink_cur = conf_get_bool(term->conf, CONF_blink_cur);
    term->blinktext = conf_get_bool(term->conf, CONF_blinktext);
    term->cursor_type = conf_get_int(term->conf, CONF_cursor_type);
    term->cjk_ambig_wide = conf_get_bool(term->conf, CONF_cjk_ambig_wide);
    term->conf_height = conf_get_int(term->conf, CONF_height);
    term->conf_width = conf_get_int(term->conf, CONF_width);
    term->crhaslf = conf_get_bool(term->conf, CONF_crhaslf);
    term->erase_to_scrollback = conf_get_bool(term->conf, CONF_erase_to_scrollback);
    term->funky_type = conf_get_int(term->conf, CONF_funky_type);
    term->sharrow_type = conf_get_int(term->conf, CONF_sharrow_type);
    term->lfhascr = conf_get_bool(term->conf, CONF_lfhascr);
    term->logflush = conf_get_bool(term->conf, CONF_logflush);
    term->logtype = conf_get_int(term->conf, CONF_logtype);
    term->mouse_override = conf_get_bool(term->conf, CONF_mouse_override);
    term->nethack_keypad = conf_get_bool(term->conf, CONF_nethack_keypad);
    term->no_alt_screen = conf_get_bool(term->conf, CONF_no_alt_screen);
    term->no_applic_c = conf_get_bool(term->conf, CONF_no_applic_c);
    term->no_applic_k = conf_get_bool(term->conf, CONF_no_applic_k);
    term->no_dbackspace = conf_get_bool(term->conf, CONF_no_dbackspace);
    term->no_mouse_rep = conf_get_bool(term->conf, CONF_no_mouse_rep);
    term->no_remote_charset = conf_get_bool(term->conf, CONF_no_remote_charset);
    term->no_remote_hyperlinks = conf_get_bool(term->conf, CONF_no_remote_hyperlinks);
    if (term->no_remote_hyperlinks)
        term->curr_hyperlink = term->save_hyperlink = term->alt_save_hyperlink = 0;
    term->no_remote_resize = conf_get_bool(term->conf, CONF_no_remote_resize);
    term->no_remote_wintitle = conf_get_bool(term->conf, CONF_no_remote_wintitle);
    term->no_remote_clearscroll = conf_get_bool(term->conf, CONF_no_remote_clearscroll);
    term->rawcnp = conf_get_bool(term->conf, CONF_rawcnp);
    term->utf8linedraw = conf_get_bool(term->conf, CONF_utf8linedraw);
    term->rect_select = conf_get_bool(term->conf, CONF_rect_select);
    term->remote_qtitle_action = conf_get_int(term->conf, CONF_remote_qtitle_action);
    term->rxvt_homeend = conf_get_bool(term->conf, CONF_rxvt_homeend);
    term->scroll_on_disp = conf_get_bool(term->conf, CONF_scroll_on_disp);
    term->scroll_on_key = conf_get_bool(term->conf, CONF_scroll_on_key);
    term->xterm_mouse_forbidden = conf_get_bool(term->conf, CONF_no_mouse_rep);
    term->xterm_256_colour = conf_get_bool(term->conf, CONF_xterm_256_colour);
    term->true_colour = conf_get_bool(term->conf, CONF_true_colour);

    /*
     * Parse the control-character escapes in the configured
     * answerback string.
     */
    {
        char *answerback = conf_get_str(term->conf, CONF_answerback);

        strbuf_clear(term->answerback);

        while (*answerback) {
            char *n;
            char c = ctrlparse(answerback, &n);
            if (n) {
                put_byte(term->answerback, c);
                answerback = n;
            } else {
                put_byte(term->answerback, *answerback++);
            }
        }
    }
}

void term_pre_reconfig(Terminal *term, Conf *conf)
{

    /*
     * Copy the current window title into the stored previous
     * configuration, so that doing nothing to the window title field
     * in the config box doesn't reset the title to its startup state.
     */
    conf_set_str(conf, CONF_wintitle, term->window_title);
}

/*
 * When the user reconfigures us, we need to check the forbidden-
 * alternate-screen config option, disable raw mouse mode if the
 * user has disabled mouse reporting, and abandon a print job if
 * the user has disabled printing.
 */
void term_reconfig(Terminal *term, Conf *conf)
{
    osc52_cancel_query(term);
    nemo_highlight_cancel(term, true);
    term_end_synchronized_update(term);
    /*
     * Before adopting the new config, check all those terminal
     * settings which control power-on defaults; and if they've
     * changed, we will modify the current state as well as the
     * default one. The full list is: Auto wrap mode, DEC Origin
     * Mode, BCE, blinking text, cursor style, character classes.
     */
    bool reset_wrap, reset_decom, reset_bce, reset_tblink, reset_charclass;
    bool reset_selection[] = {
        conf_get_bool(term->conf, CONF_nemo_selection_bg_enabled) !=
            conf_get_bool(conf, CONF_nemo_selection_bg_enabled) ||
        conf_get_int(term->conf, CONF_nemo_selection_bg) !=
            conf_get_int(conf, CONF_nemo_selection_bg),
        conf_get_bool(term->conf, CONF_nemo_selection_fg_enabled) !=
            conf_get_bool(conf, CONF_nemo_selection_fg_enabled) ||
        conf_get_int(term->conf, CONF_nemo_selection_fg) !=
            conf_get_int(conf, CONF_nemo_selection_fg)
    };
    unsigned attribute_custom_changed =
        attribute_conf_mask(term->conf, CONF_nemo_attribute_custom, 31) ^
        attribute_conf_mask(conf, CONF_nemo_attribute_custom, 31);
    unsigned attribute_modes_changed =
        attribute_conf_mask(term->conf, CONF_nemo_attribute_modes, 63) ^
        attribute_conf_mask(conf, CONF_nemo_attribute_modes, 63);
    bool attribute_styles_changed =
        attribute_conf_mask(term->conf, CONF_nemo_attribute_keep_styles, 31) !=
        attribute_conf_mask(conf, CONF_nemo_attribute_keep_styles, 31);
    for (unsigned i = 0; i < lenof(attribute_colour_keys); i++)
        if (conf_get_int(term->conf, attribute_colour_keys[i]) !=
            conf_get_int(conf, attribute_colour_keys[i]))
            attribute_custom_changed |= 1u << i;
    bool reset_graphemes = conf_get_bool(term->conf, CONF_nemo_grapheme_widths) !=
                           conf_get_bool(conf, CONF_nemo_grapheme_widths);
    if (conf_get_bool(term->conf, CONF_nemo_win32_input) !=
        conf_get_bool(conf, CONF_nemo_win32_input)) term->win32_input_epoch++;
    bool reset_mok = conf_get_int(term->conf, CONF_nemo_modify_other_keys) !=
                     conf_get_int(conf, CONF_nemo_modify_other_keys);
    bool reset_mok_format = conf_get_int(term->conf, CONF_nemo_format_other_keys) !=
                            conf_get_int(conf, CONF_nemo_format_other_keys);
    bool reset_cursor = conf_get_int(term->conf, CONF_cursor_type) !=
                        conf_get_int(conf, CONF_cursor_type) ||
                        conf_get_bool(term->conf, CONF_blink_cur) !=
                        conf_get_bool(conf, CONF_blink_cur);
    int old_cursor_type = term->cursor_type;
    bool old_blink_cur = term->blink_cur;
    bool palette_changed = false;
    int i;

    reset_wrap = (conf_get_bool(term->conf, CONF_wrap_mode) !=
                  conf_get_bool(conf, CONF_wrap_mode));
    reset_decom = (conf_get_bool(term->conf, CONF_dec_om) !=
                   conf_get_bool(conf, CONF_dec_om));
    reset_bce = (conf_get_bool(term->conf, CONF_bce) !=
                 conf_get_bool(conf, CONF_bce));
    reset_tblink = (conf_get_bool(term->conf, CONF_blinktext) !=
                    conf_get_bool(conf, CONF_blinktext));
    reset_charclass = false;
    for (i = 0; i < 256; i++)
        if (conf_get_int_int(term->conf, CONF_wordness, i) !=
            conf_get_int_int(conf, CONF_wordness, i))
            reset_charclass = true;

    /*
     * If the bidi or shaping settings have changed, flush the bidi
     * cache completely.
     */
    if (conf_get_bool(term->conf, CONF_no_arabicshaping) !=
        conf_get_bool(conf, CONF_no_arabicshaping) ||
        conf_get_bool(term->conf, CONF_no_bidi) !=
        conf_get_bool(conf, CONF_no_bidi)) {
        for (i = 0; i < term->bidi_cache_size; i++) {
            term_bidi_cache_clear_line(term, i);
        }
    }

    {
        const char *old_title = conf_get_str(term->conf, CONF_wintitle);
        const char *new_title = conf_get_str(conf, CONF_wintitle);
        if (strcmp(old_title, new_title)) {
            sfree(term->window_title);
            term->window_title = dupstr(new_title);
            term->wintitle_codepage = DEFAULT_CODEPAGE;
            term->win_title_pending = true;
            term_schedule_update(term);
        }
    }

    /*
     * Just setting conf is sufficient to cause colour setting changes
     * to appear on the next ESC]R palette reset. But we should also
     * check whether any colour settings have been changed, so that
     * they can be updated immediately if they haven't been overridden
     * by some escape sequence.
     */
    {
        int i, j;
        for (i = 0; i < CONF_NCOLOURS; i++) {
            for (j = 0; j < 3; j++)
                if (conf_get_int_int(term->conf, CONF_colours, i*3+j) !=
                    conf_get_int_int(conf, CONF_colours, i*3+j))
                    break;
            if (j < 3) {
                /* Actually enacting the change has to be deferred 
                 * until the new conf is installed. */
                palette_changed = true;
                break;
            }
        }
    }

    conf_free(term->conf);
    term->conf = conf_copy(conf);

    if (reset_graphemes)
        term_set_grapheme_clustering(term,
            conf_get_bool(conf, CONF_nemo_grapheme_widths));
    if (reset_mok) {
        NemoModifyKeys initial;
        nemo_mok_reset(&initial, conf_get_int(conf, CONF_nemo_modify_other_keys), 0);
        term->modify_keys.level = initial.level;
        term->modify_keys.ignore = 0;
    }
    if (reset_mok_format)
        term->modify_keys.format = conf_get_int(conf, CONF_nemo_format_other_keys) == 1;

    if (reset_wrap) {
        term->alt_wrap = term->wrap = conf_get_bool(term->conf, CONF_wrap_mode);
        if (!term->wrap)
            term->wrapnext = false;
        if (!term->alt_wrap)
            term->alt_wnext = false;
    }
    if (reset_decom)
        term->alt_om = term->dec_om = conf_get_bool(term->conf, CONF_dec_om);
    if (reset_bce) {
        term->use_bce = conf_get_bool(term->conf, CONF_bce);
        set_erase_char(term);
    }
    if (reset_tblink) {
        term->blink_is_real = conf_get_bool(term->conf, CONF_blinktext);
    }
    if (reset_charclass)
        for (i = 0; i < 256; i++)
            term->wordness[i] = conf_get_int_int(term->conf, CONF_wordness, i);

    if (conf_get_bool(term->conf, CONF_no_alt_screen))
        swap_screen(term, 0, false, false);
    if (conf_get_bool(term->conf, CONF_no_remote_charset)) {
        term->cset_attr[0] = term->cset_attr[1] = term->cset_attr[2] = term->cset_attr[3] = CSET_ASCII;
        term->nrc_mode = false;
        term->sco_acs = term->alt_sco_acs = 0;
        term->utf = false;
    }
    if (!conf_get_str(term->conf, CONF_printer)) {
        term_print_finish(term);
    }
    if (palette_changed)
        term_notify_palette_changed(term);
    term_copy_stuff_from_conf(term);
    for (unsigned i = 0; i < lenof(term->attribute_colours); i++)
        if (attribute_custom_changed & (1u << i))
            term->attribute_colours[i] = optionalrgb_none;
    term->attribute_colour_modes =
        (term->attribute_colour_modes & ~attribute_modes_changed) |
        (attribute_conf_mask(conf, CONF_nemo_attribute_modes, 63) & attribute_modes_changed);
    if (attribute_custom_changed || attribute_modes_changed || attribute_styles_changed)
        term_invalidate(term);
    for (unsigned i = 0; i < lenof(reset_selection); i++) {
        if (reset_selection[i]) {
            /* Explicit local changes apply immediately to that component;
             * unrelated settings leave application overrides untouched. */
            term->selection_colours[i] = optionalrgb_none;
            term_invalidate(term);
        }
    }
    if (!reset_cursor) {
        term->cursor_type = old_cursor_type;
        term->blink_cur = old_blink_cur;
    } else {
        term->big_cursor = false;
        term->cblinker = true;
        term->cblink_pending = false;
        term_invalidate(term);
    }
    term_schedule_tblink(term);
    term_schedule_cblink(term);
    term_update_raw_mouse_mode(term);
}

/*
 * Clear the scrollback.
 */
void term_clrsb(Terminal *term)
{
    nemo_shell_marks_rows(&term->shell_marks, 0, term->rows-1, 0);
    nemo_images_rows(term, 0, 0, INT_MAX, 0);
    unsigned char *line;
    int i;

    /*
     * Scroll forward to the current screen, if we were back in the
     * scrollback somewhere until now.
     */
    term->disptop = 0;

    /*
     * Clear the actual scrollback.
     */
    while ((line = delpos234(term->scrollback, 0)) != NULL) {
        sfree(line);            /* this is compressed data, not a termline */
    }

    /*
     * When clearing the scrollback, we also truncate any termlines on
     * the current screen which have remembered data from a previous
     * larger window size. Rationale: clearing the scrollback is
     * sometimes done to protect privacy, so the user intention is
     * specifically that we should not retain evidence of what
     * previously happened in the terminal, and that ought to include
     * evidence to the right as well as evidence above.
     */
    for (i = 0; i < term->rows; i++)
        check_line_size(term, scrlineptr(i));

    /*
     * That operation has invalidated the selection, if it overlapped
     * the scrollback at all.
     */
    if (term->selstate != NO_SELECTION && term->selstart.y < 0)
        deselect(term);

    /*
     * There are now no lines of real scrollback which can be pulled
     * back into the screen by a resize, and no lines of the alternate
     * screen which should be displayed as if part of the scrollback.
     */
    term->tempsblines = 0;
    term->alt_sblines = 0;

    /*
     * The scrollbar will need updating to reflect the new state of
     * the world.
     */
    term->win_scrollbar_update_pending = true;
    term_schedule_update(term);
}

const optionalrgb optionalrgb_none = {0, 0, 0, 0};

void term_setup_window_titles(Terminal *term, const char *title_hostname)
{
    const char *conf_title = conf_get_str(term->conf, CONF_wintitle);
    sfree(term->window_title);
    sfree(term->icon_title);
    if (*conf_title) {
        term->window_title = dupstr(conf_title);
        term->icon_title = dupstr(conf_title);
    } else {
        if (title_hostname && *title_hostname)
            term->window_title = dupcat(title_hostname, " - ", appname);
        else
            term->window_title = dupstr(appname);
        term->icon_title = dupstr(term->window_title);
    }
    term->wintitle_codepage = term->icontitle_codepage = DEFAULT_CODEPAGE;
    term->win_title_pending = true;
    term->win_icon_title_pending = true;
}

static void palette_rebuild(Terminal *term)
{
    unsigned min_changed = OSC4_NCOLOURS, max_changed = 0;

    if (term->win_palette_pending) {
        /* Possibly extend existing range. */
        min_changed = term->win_palette_pending_min;
        max_changed = term->win_palette_pending_limit - 1;
    } else {
        /* Start with empty range. */
        min_changed = OSC4_NCOLOURS;
        max_changed = 0;
    }

    for (unsigned i = 0; i < OSC4_NCOLOURS; i++) {
        rgb new_value;
        bool found = false;

        for (unsigned j = lenof(term->subpalettes); j-- > 0 ;) {
            if (term->subpalettes[j].present[i]) {
                new_value = term->subpalettes[j].values[i];
                found = true;
                break;
            }
        }

        assert(found);    /* we expect SUBPAL_CONF to always be set */

        if (new_value.r != term->palette[i].r ||
            new_value.g != term->palette[i].g ||
            new_value.b != term->palette[i].b) {
            term->palette[i] = new_value;
            if (min_changed > i)
                min_changed = i;
            if (max_changed < i)
                max_changed = i;
        }
    }

    if (min_changed <= max_changed) {
        /*
         * At least one colour changed (or we had an update scheduled
         * already). Schedule a redraw event to pass the result back
         * to the TermWin. This also requires invalidating the rest
         * of the window, because usually all the text will need
         * redrawing in the new colours.
         * (If there was an update pending and this palette rebuild
         * didn't actually change anything, we'll harmlessly reinforce
         * the existing update request.)
         */
        term->win_palette_pending = true;
        term->win_palette_pending_min = min_changed;
        term->win_palette_pending_limit = max_changed + 1;
        term_invalidate(term);
    }
}

/* XTerm's ReverseOldColors keeps a cursor matching the displayed foreground
 * visible by moving it to the new foreground. Other cursor colours stay fixed.
 * Our foreground/background palette slots themselves remain in normal order. */
static void nemo_set_reverse_video(Terminal *term, bool state)
{
    if (term->rvideo != state && term->subpalettes[SUBPAL_CONF].present[0]) {
        rgb cursor = term->palette[OSC4_COLOUR_cursor_bg];
        rgb old_fg = term->palette[term->rvideo ? OSC4_COLOUR_bg : OSC4_COLOUR_fg];
        if (cursor.r == old_fg.r && cursor.g == old_fg.g && cursor.b == old_fg.b) {
            term->subpalettes[SUBPAL_SESSION].values[OSC4_COLOUR_cursor_bg] =
                term->palette[state ? OSC4_COLOUR_bg : OSC4_COLOUR_fg];
            term->subpalettes[SUBPAL_SESSION].present[OSC4_COLOUR_cursor_bg] = true;
            palette_rebuild(term);
        }
    }
    term->rvideo = state;
}

static void nemo_selection_colour_set(Terminal *term, unsigned which,
                                      optionalrgb colour)
{
    assert(which < lenof(term->selection_colours));
    if (!optionalrgb_equal(term->selection_colours[which], colour)) {
        term->selection_colours[which] = colour;
        /* No screen or scrollback cell changes. Defer repaint during 2026. */
        term_invalidate(term);
    }
}

static rgb nemo_attribute_colour(Terminal *term, unsigned which)
{
    optionalrgb c = term->attribute_colours[which].enabled ?
        term->attribute_colours[which] : term->attribute_defaults[which];
    unsigned layer = term->subpalettes[SUBPAL_PLATFORM].present[OSC4_COLOUR_fg] ?
        SUBPAL_PLATFORM : SUBPAL_CONF;
    return c.enabled ? (rgb){c.r, c.g, c.b} :
        term->subpalettes[layer].values[OSC4_COLOUR_fg];
}

static void nemo_attribute_colour_set(Terminal *term, unsigned which,
                                      optionalrgb colour)
{
    assert(which < lenof(term->attribute_colours));
    if (!optionalrgb_equal(term->attribute_colours[which], colour)) {
        term->attribute_colours[which] = colour;
        term_invalidate(term);
    }
}

/* XTerm ReallyReset restores indexed and special colours for RIS and DECSTR.
 * Dynamic foreground/background/cursor and selection colours remain separate. */
static void nemo_reset_ansi_colours(Terminal *term)
{
    for (unsigned i = 0; i < 256; i++)
        term->subpalettes[SUBPAL_SESSION].present[i] = false;
    for (unsigned i = 0; i < lenof(term->attribute_colours); i++)
        nemo_attribute_colour_set(term, i, optionalrgb_none);
    /* Initial power_on precedes palette_reset, so there is no configured
     * palette to rebuild yet. Later resets always have this base layer. */
    if (term->subpalettes[SUBPAL_CONF].present[0])
        palette_rebuild(term);
}

static void nemo_palette_stack_op(Terminal *term, bool push)
{
    for (unsigned p = 0; p < term->esc_nargs; p++) {
        struct NemoPaletteStack *stack = term->palette_stack;
        unsigned used = stack ? stack->used : 0, arg = term->esc_args[p];
        bool omitted = !(term->esc_arg_present & (1u << p));
        unsigned slot = arg ? arg-1 : push ? used : used-1;
        if (slot >= PALETTE_STACK_SLOTS) continue;
        if (push) {
            if (!stack) {
                term->palette_stack = stack = snew(struct NemoPaletteStack);
                memset(stack, 0, sizeof(*stack));
            }
            if (!stack->slot[slot])
                stack->slot[slot] = snew(struct NemoPaletteSnapshot);
            memcpy(stack->slot[slot]->entries, term->palette, sizeof(term->palette));
            memcpy(stack->slot[slot]->selection, term->selection_colours,
                   sizeof(term->selection_colours));
            memcpy(stack->slot[slot]->attributes, term->attribute_colours,
                   sizeof(term->attribute_colours));
            /* XTerm distinguishes an omitted value from an explicit zero:
             * omitted increments; explicit zero saves at used and seeks to 0.
             * Indexed writes seek to that index without raising last. */
            stack->used = omitted ? used+1 : arg;
            if (omitted && stack->last < stack->used) stack->last = stack->used;
        } else if (stack && stack->slot[slot]) {
            memcpy(term->subpalettes[SUBPAL_SESSION].values,
                   stack->slot[slot]->entries, sizeof(term->palette));
            for (unsigned i = 0; i < OSC4_NCOLOURS; i++)
                term->subpalettes[SUBPAL_SESSION].present[i] = true;
            for (unsigned i = 0; i < lenof(term->selection_colours); i++)
                nemo_selection_colour_set(term, i, stack->slot[slot]->selection[i]);
            for (unsigned i = 0; i < lenof(term->attribute_colours); i++)
                nemo_attribute_colour_set(term, i, stack->slot[slot]->attributes[i]);
            stack->used = slot;
            palette_rebuild(term);
        }
    }
}

static void nemo_report_palette_stack(Terminal *term)
{
    if (!term->ldisc) return;
    struct NemoPaletteStack *stack = term->palette_stack;
    char reply[40];
    int n = sprintf(reply, "\033[?%u;%u#Q", stack ? stack->used : 0,
                    stack ? stack->last : 0);
    nemo_protocol_send(term, reply, n);
}

/*
 * Rebuild the palette from configuration and platform colours.
 * If 'keep_overrides' set, any escape-sequence-specified overrides will
 * remain in place.
 */
static void palette_reset(Terminal *term, bool keep_overrides)
{
    for (unsigned i = 0; i < OSC4_NCOLOURS; i++)
        term->subpalettes[SUBPAL_CONF].present[i] = true;

    /*
     * Copy all the palette information out of the Conf.
     */
    for (unsigned i = 0; i < CONF_NCOLOURS; i++) {
        rgb *col = &term->subpalettes[SUBPAL_CONF].values[
            colour_indices_conf_to_osc4[i]];
        col->r = conf_get_int_int(term->conf, CONF_colours, i*3+0);
        col->g = conf_get_int_int(term->conf, CONF_colours, i*3+1);
        col->b = conf_get_int_int(term->conf, CONF_colours, i*3+2);
    }

    /*
     * Directly invent the rest of the xterm-256 colours.
     */
    for (unsigned i = 0; i < 216; i++) {
        rgb *col = &term->subpalettes[SUBPAL_CONF].values[i + 16];
        int r = i / 36, g = (i / 6) % 6, b = i % 6;
        col->r = r ? r * 40 + 55 : 0;
        col->g = g ? g * 40 + 55 : 0;
        col->b = b ? b * 40 + 55 : 0;
    }
    for (unsigned i = 0; i < 24; i++) {
        rgb *col = &term->subpalettes[SUBPAL_CONF].values[i + 232];
        int shade = i * 10 + 8;
        col->r = col->g = col->b = shade;
    }

    /*
     * Re-fetch any OS-local overrides.
     */
    for (unsigned i = 0; i < OSC4_NCOLOURS; i++)
        term->subpalettes[SUBPAL_PLATFORM].present[i] = false;
    win_palette_get_overrides(term->win, term);

    if (!keep_overrides) {
        /*
         * Get rid of all escape-sequence configuration.
         */
        for (unsigned i = 0; i < OSC4_NCOLOURS; i++)
            term->subpalettes[SUBPAL_SESSION].present[i] = false;
        for (unsigned i = 0; i < lenof(term->selection_colours); i++)
            nemo_selection_colour_set(term, i, optionalrgb_none);
        for (unsigned i = 0; i < lenof(term->attribute_colours); i++)
            nemo_attribute_colour_set(term, i, optionalrgb_none);
    }

    /*
     * Rebuild the composite palette.
     */
    palette_rebuild(term);
}

void term_palette_override(Terminal *term, unsigned osc4_index, rgb rgb)
{
    /*
     * We never expect to be called except as re-entry from our own
     * call to win_palette_get_overrides above, so we need not mess
     * about calling palette_rebuild.
     */
    term->subpalettes[SUBPAL_PLATFORM].present[osc4_index] = true;
    term->subpalettes[SUBPAL_PLATFORM].values[osc4_index] = rgb;
}

/*
 * Initialise the terminal.
 */
Terminal *term_init(Conf *myconf, struct unicode_data *ucsdata, TermWin *win)
{
    Terminal *term;

    /*
     * Allocate a new Terminal structure and initialise the fields
     * that need it.
     */
    term = snew(Terminal);
    memset(term, 0, sizeof(Terminal));
    term->cell_width = 8;
    term->cell_height = 16;
    term->sixel_register_count = NEMO_SIXEL_PALETTE_SIZE;
    term->win = win;
    term->ucsdata = ucsdata;
    term->conf = conf_copy(myconf);
    term->compatibility_level = TM_PUTTY;
    strcpy(term->id_string, "\033[?62;4;22c");
    bufchain_init(&term->inbuf);
    bufchain_init(&term->printer_buf);
    term->has_focus = true;
    term->termstate = TOPLEVEL;
    term->selstate = NO_SELECTION;
    term->answerback = strbuf_new();

    term_copy_stuff_from_conf(term);

    term->attribute_colour_modes = attribute_conf_mask(
        term->conf, CONF_nemo_attribute_modes, 63);
    deselect(term);
    term->rows = term->cols = -1;
    power_on(term, true, false);
    /* This is a startup preference, not a replacement for mode 2027's
     * specified reset state: subsequent RIS/DECSTR must still disable it. */
    term_set_grapheme_clustering(term,
        conf_get_bool(term->conf, CONF_nemo_grapheme_widths));
    term->attr_mask = 0xffffffff;

    /* FULL-TERMCHAR */
    term->basic_erase_char.chr = CSET_ASCII | ' ';
    term->basic_erase_char.attr = ATTR_DEFAULT;
    term->basic_erase_char.truecolour.fg = optionalrgb_none;
    term->basic_erase_char.truecolour.bg = optionalrgb_none;
    term->basic_erase_char.truecolour.decoration = CELL_UNDRAWN;
    term->basic_erase_char.hyperlink = 0;
    term->erase_char = term->basic_erase_char;

    /* TermWin implementations will typically extend these with
     * clipboard ids they know about */
    term->mouse_select_clipboards[0] = CLIP_LOCAL;
    term->n_mouse_select_clipboards = 1;
    term->mouse_paste_clipboard = CLIP_NULL;

    term->trusted = true;

    term->window_title = dupstr("");
    term->icon_title = dupstr("");
    term->wintitle_codepage = term->icontitle_codepage = DEFAULT_CODEPAGE;

    term->win_resize_pending = WIN_RESIZE_NO;

    term->bidi_ctx = bidi_new_context();

    palette_reset(term, false);

    return term;
}

void term_free(Terminal *term)
{
    nemo_palette_stack_free(term->palette_stack);
    nemo_presentation_cancel(term);
    nemo_osc52_free(term->osc52);
    sfree(term->sgr_stack);
    term_end_synchronized_update(term);
    nemo_images_clear(term);
    nemo_hyperlink_free(term->hyperlinks);
    nemo_cwd_clear(&term->working_directory);
    nemo_shell_marks_clear(&term->shell_marks);
    compressed_scrollback_line *cline;
    termline *line;
    struct beeptime *beep;
    int i;

    while ((cline = delpos234(term->scrollback, 0)) != NULL)
        free_compressed_line(cline);
    freetree234(term->scrollback);
    while ((line = delpos234(term->screen, 0)) != NULL)
        freetermline(line);
    freetree234(term->screen);
    while ((line = delpos234(term->alt_screen, 0)) != NULL)
        freetermline(line);
    freetree234(term->alt_screen);
    if (term->disptext) {
        for (i = 0; i < term->rows; i++)
            freetermline(term->disptext[i]);
    }
    sfree(term->disptext);
    while (term->beephead) {
        beep = term->beephead;
        term->beephead = beep->next;
        sfree(beep);
    }
    bufchain_clear(&term->inbuf);
    if (term->print_job)
        printer_finish_job(term->print_job);
    bufchain_clear(&term->printer_buf);
    sfree(term->paste_buffer);
    sfree(term->last_selected_text);
    sfree(term->last_selected_attr);
    sfree(term->last_selected_tc);
    sfree(term->ltemp);
    sfree(term->wcFrom);
    sfree(term->wcTo);
    strbuf_free(term->answerback);

    for (i = 0; i < term->bidi_cache_size; i++) {
        term_bidi_cache_clear_line(term, i);
    }
    sfree(term->pre_bidi_cache);
    sfree(term->post_bidi_cache);

    sfree(term->tabs);

    expire_timer_context(term);
    delete_callbacks_for_context(term);

    conf_free(term->conf);

    sfree(term->window_title);
    sfree(term->icon_title);

    nemo_title_stack_free(term->title_stack);

    bidi_free_context(term->bidi_ctx);

    /* In case a term_userpass_state is still around */
    if (term->userpass_state)
        term_userpass_state_free(term->userpass_state);

    freetermline(term->preedit_termline);

    sfree(term);
}

void term_set_trust_status(Terminal *term, bool trusted)
{
    if (term->trusted != trusted) term->grapheme_pending = false;
    term->trusted = trusted;
}

void term_get_cursor_position(Terminal *term, int *x, int *y)
{
    *x = term->curs.x;
    *y = term->curs.y;
}

/* Reflow consumes old rows in order and immediately compresses completed
 * output rows. At most one source and one output row are expanded in addition
 * to the existing screen; no unbounded logical-line buffer is needed. */
typedef struct NemoReflowPoint {
    int row, col, x;
    int64_t y;
    bool pending;
} NemoReflowPoint;

typedef struct NemoReflowMark {
    NemoShellPoint *dest;
    int row, col, x;
    int64_t y;
    bool mapped;
} NemoReflowMark;

static int nemo_reflow_mark_order(const void *av, const void *bv)
{
    const NemoReflowMark *a = av, *b = bv;
    if (a->row != b->row) return a->row < b->row ? -1 : 1;
    return a->col < b->col ? -1 : a->col > b->col;
}

typedef struct NemoReflow {
    Terminal *term;
    tree234 *lines;
    termline *line;
    int cols, rows, x, capacity;
    int64_t count, first, limit;
    NemoReflowPoint point[2]; /* current cursor, saved cursor */
    NemoReflowMark *marks;
    size_t nmarks, nextmark;
} NemoReflow;

static void nemo_reflow_emit(NemoReflow *r, bool wrapped)
{
    if (!r->line) r->line = newtermline(r->term, r->cols, false);
    if (wrapped) r->line->lattr |= LATTR_WRAPPED;
    if (r->count < r->limit) {
        addpos234(r->lines, compressline_and_free(r->line), count234(r->lines));
        if (count234(r->lines) > r->capacity) {
            free_compressed_line(delpos234(r->lines, 0));
            r->first++;
        }
    } else {
        freetermline(r->line);
    }
    r->count++;
    r->line = NULL;
    r->x = 0;
}

static void nemo_reflow_point(NemoReflow *r, int row, int first, int width)
{
    /* The bounded sorted mark stream is consumed once, alongside the cells.
     * Preserve half-open endpoints at x == cols, including clipped wide pairs. */
    while (r->nextmark < r->nmarks) {
        NemoReflowMark *p = &r->marks[r->nextmark];
        if (p->row != row || p->col < first || p->col >= first + width) break;
        p->x = r->x + p->col - first;
        p->y = r->count;
        p->mapped = true;
        r->nextmark++;
    }
    for (int i = 0; i < 2; i++) {
        NemoReflowPoint *p = &r->point[i];
        if (p->row != row || p->col < first || p->col >= first + width)
            continue;
        int x = r->x + p->col - first;
        p->pending = x >= r->cols;
        p->x = min(x, r->cols - 1);
        p->y = r->count;
        if (!i) r->limit = p->y + r->rows;
    }
}

static int nemo_reflow_length(Terminal *term, termline *line)
{
    int length = line->cols;
    if (line->lattr & LATTR_WRAPPED)
        return length - !!(line->lattr & LATTR_WRAPPED2);
    /* An erased coloured cell, hyperlink or combining mark is content. */
    while (length && termchars_equal(&line->chars[length-1], &term->basic_erase_char))
        length--;
    return length;
}

static void nemo_reflow(Terminal *term, int rows, int cols, int savelines)
{
    int history = count234(term->scrollback);
    size_t total = (size_t)history + term->rows;
    int64_t *rowmap = snewn(total, int64_t);
    bool *fixed = snewn(total, bool);
    memset(fixed, 0, total * sizeof(*fixed));
    for (size_t i = 0; i < total; i++) rowmap[i] = -1;
    NemoReflow r = { .term = term, .lines = newtree234(NULL),
        .cols = cols, .rows = rows, .limit = INT64_MAX,
        .capacity = (int)min((int64_t)INT_MAX, (int64_t)rows + savelines),
        .point = {
            { .row = term->curs.y, .col = term->curs.x + term->wrapnext },
            { .row = term->savecurs.y, .col = term->savecurs.x + term->save_wnext }
        } };
    int used = max(term->curs.y, term->savecurs.y) + 1;
    if (term->shell_marks.count)
        r.marks = snewn(term->shell_marks.count * 4, NemoReflowMark);
    for (size_t i = 0; i < term->shell_marks.count; i++) {
        for (int j = 0; j < 4; j++) {
            NemoShellPoint *p = &term->shell_marks.commands[i].point[j];
            if (!p->valid || p->truncated || p->y < -history || p->y >= term->rows)
                continue;
            r.marks[r.nmarks++] = (NemoReflowMark){
                .dest = p, .row = p->y, .col = p->x };
            used = max(used, p->y + 1);
        }
    }
    if (r.nmarks > 1)
        qsort(r.marks, r.nmarks, sizeof(*r.marks), nemo_reflow_mark_order);
    for (int i = term->rows; i-- > used;) {
        termline *line = index234(term->screen, i);
        if (nemo_reflow_length(term, line) || line->lattr || line->trusted) {
            used = i+1;
            break;
        }
    }
    /* Raster rows keep their grid and intrinsic pixel size. Reflow around
     * them can move them vertically, but must not merge or split scanlines.
     * DEC double-size and trusted rows are similar fixed-grid barriers. */
    for (NemoTermImage *im = term->images; im; im = im->next) {
        if (im->screen) continue;
        for (int y = 0; y < im->pixel_height; y++) {
            if (im->lines[y].anchor == INT_MIN) continue;
            int64_t at = (int64_t)im->lines[y].anchor + y/term->cell_height;
            int64_t index = at + history;
            if (index >= 0 && (uint64_t)index < total) {
                fixed[index] = true;
                if (at >= used) used = (int)at + 1;
            }
        }
    }

    for (size_t i = 0; i < total; i++) {
        termline *src = i < (size_t)history ?
            decompressline_and_free(delpos234(term->scrollback, 0)) :
            delpos234(term->screen, 0);
        src->temporary = false;
        int oldrow = (int)((int64_t)i - history);
        if (oldrow >= used) {
            freetermline(src);
            continue;
        }
        if (fixed[i] || (src->lattr & LATTR_MODE) || src->trusted) {
            if (r.line) nemo_reflow_emit(&r, true);
            rowmap[i] = r.count;
            while (r.nextmark < r.nmarks && r.marks[r.nextmark].row == oldrow) {
                NemoReflowMark *p = &r.marks[r.nextmark++];
                p->x = p->col; p->y = r.count; p->mapped = true;
            }
            for (int p = 0; p < 2; p++) {
                if (r.point[p].row == oldrow) {
                    r.point[p].x = min(r.point[p].col, cols-1);
                    r.point[p].y = r.count;
                    r.point[p].pending = false;
                    if (!p) r.limit = r.count + rows;
                }
            }
            r.line = src;
            nemo_reflow_emit(&r, false);
            continue;
        }
        if (r.x >= cols) nemo_reflow_emit(&r, true);
        rowmap[i] = r.count;
        int length = nemo_reflow_length(term, src);
        for (size_t p = r.nextmark; p < r.nmarks && r.marks[p].row == oldrow; p++)
            length = max(length, r.marks[p].col);
        for (int p = 0; p < 2; p++)
            if (r.point[p].row == oldrow)
                length = max(length, r.point[p].col);
        /* Cursors can address blank cells beyond a lazily grown row. */
        if (length > src->cols) resizeline(term, src, length);
        for (int x = 0; x < length;) {
            int width = x+1 < length && src->chars[x+1].chr == UCSWIDE ? 2 : 1;
            if (r.x && r.x + width > cols) {
                if (r.x < cols) r.line->lattr |= LATTR_WRAPPED2;
                nemo_reflow_emit(&r, true);
                if (!x) rowmap[i] = r.count;
            }
            /* At one column retain the wide pair in a clipped two-cell row.
             * A later resize can recover it without replacing the character. */
            if (!r.line) r.line = newtermline(term, max(cols, width), false);
            nemo_reflow_point(&r, oldrow, x, width);
            for (int j = 0; j < width; j++)
                copy_termchar(r.line, r.x+j, &src->chars[x+j]);
            r.x += width;
            x += width;
        }
        nemo_reflow_point(&r, oldrow, length, 1);
        bool wrapped = src->lattr & LATTR_WRAPPED;
        freetermline(src);
        if (!wrapped) nemo_reflow_emit(&r, false);
    }
    if (r.line) nemo_reflow_emit(&r, false);

    int64_t end = min(r.count, r.limit);
    int boundary = history - term->tempsblines;
    /* Blank space below the prompt is not a reason to pull unrelated history
     * back onto a cleared screen. Recover temporary resize history, and allow
     * added window rows to expose older history, while keeping the cursor. */
    int64_t top = max((int64_t)0, max(end - rows,
        rowmap[boundary] - max(0, rows - term->rows)));
    top = min(top, r.point[0].y);
    freetree234(term->scrollback);
    term->scrollback = r.lines;
    /* Leave the oldest retained rows compressed in the same tree. */
    int keep = (int)(top - r.first);
    assert(keep >= 0 && keep <= count234(r.lines));
    while (count234(r.lines) > keep) {
        termline *line = decompressline_and_free(delpos234(r.lines, keep));
        line->temporary = false;
        addpos234(term->screen, line, count234(term->screen));
    }
    while (count234(term->screen) < rows)
        addpos234(term->screen, newtermline(term, cols, false), count234(term->screen));
    int newhistory = count234(term->scrollback);
    term->tempsblines = (int)max((int64_t)0,
        min((int64_t)newhistory, top - rowmap[boundary]));
    int64_t view = history + (int64_t)term->disptop;
    term->disptop = term->disptop < 0 && view >= 0 && (uint64_t)view < total ?
        (int)max(-(int64_t)newhistory, min((int64_t)0, rowmap[view] - top)) : 0;
    term->curs = (pos){ .x = r.point[0].x, .y = (int)(r.point[0].y-top) };
    term->savecurs = (pos){ .x = r.point[1].x,
        .y = (int)max((int64_t)INT_MIN, r.point[1].y-top) };
    term->wrapnext = r.point[0].pending;
    term->save_wnext = r.point[1].pending;
    for (size_t i = 0; i < r.nmarks; i++) {
        NemoReflowMark *p = &r.marks[i];
        int64_t y = p->y - top;
        if (!p->mapped || y >= rows) p->dest->valid = false;
        else if (y < -newhistory) {
            p->dest->y = -newhistory-1; p->dest->x = 0;
            p->dest->truncated = true;
        } else {
            p->dest->y = (int)y; p->dest->x = p->x;
        }
    }
    sfree(r.marks);
    nemo_shell_marks_rows(&term->shell_marks, -newhistory, rows-1, 0);
    for (NemoTermImage *im = term->images; im; im = im->next) {
        if (im->screen) continue;
        for (int y = 0; y < im->pixel_height; y++) {
            if (im->lines[y].anchor == INT_MIN) continue;
            int64_t at = (int64_t)im->lines[y].anchor + y/term->cell_height + history;
            int64_t dest = at >= 0 && (uint64_t)at < total ? rowmap[at]-top : INT_MIN;
            int64_t anchor = dest - y/term->cell_height;
            if (dest < -newhistory || dest >= rows || anchor <= INT_MIN || anchor > INT_MAX)
                nemo_image_drop_row(term, im, y);
            else im->lines[y].anchor = (int)anchor;
        }
    }
    term->rows = rows;
    sfree(fixed);
    sfree(rowmap);
}

/*
 * Set up the terminal for a given size.
 */
void term_size(Terminal *term, int newrows, int newcols, int newsavelines)
{
    term->grapheme_pending = false;
    tree234 *newalt;
    termline **newdisp, *line;
    int i, j, oldrows = term->rows;
    int sblen;
    int save_alt_which = term->alt_which;
    bool reflow = term->cols > 0 && term->cols != max(newcols, 1) &&
        conf_get_bool(term->conf, CONF_nemo_reflow);

    if (newrows == term->rows && newcols == term->cols &&
        newsavelines == term->savelines)
        return;                        /* nothing to do */

    term_end_synchronized_update(term);

    nemo_highlight_cancel(term, true);

    /* A partial DCS has not established its placement yet. Retained images
     * follow text-row moves, without splitting raster rows or copying tiles. */
    nemo_sixel_cancel(term);

    /* Behave sensibly if we're given zero (or negative) rows/cols */

    if (newrows < 1) newrows = 1;
    if (newcols < 1) newcols = 1;
    if (newsavelines < 0) newsavelines = 0;

    deselect(term);
    int resize_view = term->disptop;
    swap_screen(term, 0, false, false);
    if (!save_alt_which && reflow) term->disptop = resize_view;

    term->marg_t = 0;
    term->marg_b = newrows - 1;
    term->marg_l = 0; term->marg_r = newcols-1;

    if (term->rows == -1) {
        term->scrollback = newtree234(NULL);
        term->screen = newtree234(NULL);
        term->tempsblines = 0;
        term->rows = 0;
    }

    /*
     * Resize the screen and scrollback. We only need to shift
     * lines around within our data structures, because lineptr()
     * will take care of resizing each individual line if
     * necessary. So:
     *
     *  - If the new screen is longer, we shunt lines in from temporary
     *    scrollback if possible, otherwise we add new blank lines at
     *    the bottom.
     *
     *  - If the new screen is shorter, we remove any blank lines at
     *    the bottom if possible, otherwise shunt lines above the cursor
     *    to scrollback if possible, otherwise delete lines below the
     *    cursor.
     *
     *  - Then, if the new scrollback length is less than the
     *    amount of scrollback we actually have, we must throw some
     *    away.
     */
    if (reflow) nemo_reflow(term, newrows, newcols, newsavelines);
    sblen = count234(term->scrollback);
    /* Do this loop to expand the screen if newrows > rows */
    assert(term->rows == count234(term->screen));
    while (term->rows < newrows) {
        if (term->tempsblines > 0) {
            compressed_scrollback_line *cline;
            /* Insert a line from the scrollback at the top of the screen. */
            assert(sblen >= term->tempsblines);
            cline = delpos234(term->scrollback, --sblen);
            line = decompressline_and_free(cline);
            line->temporary = false;   /* reconstituted line is now real */
            term->tempsblines -= 1;
            addpos234(term->screen, line, 0);
            term->curs.y += 1;
            term->savecurs.y += 1;
            nemo_images_rows(term, 0, INT_MIN+1, INT_MAX, 1);
            nemo_shell_marks_rows(&term->shell_marks, INT_MIN+1, INT_MAX, 1);
        } else {
            /* Add a new blank line at the bottom of the screen. */
            line = newtermline(term, newcols, false);
            addpos234(term->screen, line, count234(term->screen));
        }
        term->rows += 1;
    }
    /* Do this loop to shrink the screen if newrows < rows */
    while (term->rows > newrows) {
        if (term->curs.y < term->rows - 1) {
            /* delete bottom row, unless it contains the cursor */
            line = delpos234(term->screen, term->rows - 1);
            freetermline(line);
            nemo_images_rows(term, 0, INT_MIN+1, term->rows-2, 0);
            nemo_shell_marks_rows(&term->shell_marks, INT_MIN+1, term->rows-2, 0);
        } else {
            /* push top row to scrollback */
            line = delpos234(term->screen, 0);
            addpos234(term->scrollback, compressline_and_free(line), sblen++);
            term->tempsblines += 1;
            term->curs.y -= 1;
            term->savecurs.y -= 1;
            nemo_images_rows(term, 0, INT_MIN+1, INT_MAX, -1);
            nemo_shell_marks_rows(&term->shell_marks, INT_MIN+1, INT_MAX, -1);
        }
        term->rows -= 1;
    }
    assert(term->rows == newrows);
    assert(count234(term->screen) == newrows);

    /* Delete any excess lines from the scrollback. */
    while (sblen > newsavelines) {
        line = delpos234(term->scrollback, 0);
        free_compressed_line((compressed_scrollback_line *)line);
        sblen--;
    }
    if (sblen < term->tempsblines)
        term->tempsblines = sblen;
    assert(count234(term->scrollback) <= newsavelines);
    assert(count234(term->scrollback) >= term->tempsblines);
    term->disptop = reflow ? max(term->disptop, -sblen) : 0;

    nemo_images_rows(term, 0, -sblen, newrows-1, 0);
    nemo_shell_marks_rows(&term->shell_marks, -sblen, newrows-1, 0);
    nemo_images_rows(term, 1, 0, newrows-1, 0);

    /* Make a new displayed text buffer. */
    newdisp = snewn(newrows, termline *);
    for (i = 0; i < newrows; i++) {
        newdisp[i] = newtermline(term, newcols, false);
        for (j = 0; j < newcols; j++)
            newdisp[i]->chars[j].attr = ATTR_INVALID;
    }
    if (term->disptext) {
        for (i = 0; i < oldrows; i++)
            freetermline(term->disptext[i]);
    }
    sfree(term->disptext);
    term->disptext = newdisp;

    /* Keep the alternate screen's top-left grid across a resize. Full-screen
     * applications receive the size notification below and may repaint, but
     * resizing must not itself erase their current contents or reset their
     * cursor. As on the main screen, lineptr grows widths lazily and an
     * untouched clipped tail can reappear if the window is enlarged again. */
    newalt = newtree234(NULL);
    for (i = 0; i < newrows; i++) {
        line = term->alt_screen ? delpos234(term->alt_screen, 0) : NULL;
        if (!line) line = newtermline(term, newcols, true);
        addpos234(newalt, line, i);
    }
    if (term->alt_screen) {
        while (NULL != (line = delpos234(term->alt_screen, 0)))
            freetermline(line);
        freetree234(term->alt_screen);
    }
    term->alt_screen = newalt;
    term->alt_sblines = 0;

    /* Keep offscreen stops like xterm's 1024-column table. Larger grids can
     * extend it, but shrinking must not silently restore default tab stops. */
    int tabs_size = max(term->tabs_size, max(newcols, 1024));
    if (tabs_size > term->tabs_size) {
        term->tabs = sresize(term->tabs, tabs_size, unsigned char);
        for (int i = term->tabs_size; i < tabs_size; i++)
            term->tabs[i] = (i % 8 == 0 ? true : false);
        term->tabs_size = tabs_size;
    }

    /* Check that the cursor positions are still valid. */
    if (term->savecurs.y < 0)
        term->savecurs.y = 0;
    if (term->savecurs.y >= newrows)
        term->savecurs.y = newrows - 1;
    if (term->savecurs.x >= newcols)
        term->savecurs.x = newcols - 1;
    if (term->alt_savecurs.y < 0)
        term->alt_savecurs.y = 0;
    if (term->alt_savecurs.y >= newrows)
        term->alt_savecurs.y = newrows - 1;
    if (term->alt_savecurs.x >= newcols)
        term->alt_savecurs.x = newcols - 1;
    if (term->curs.y < 0)
        term->curs.y = 0;
    if (term->curs.y >= newrows)
        term->curs.y = newrows - 1;
    if (term->curs.x >= newcols)
        term->curs.x = newcols - 1;
    if (term->alt_y < 0)
        term->alt_y = 0;
    if (term->alt_y >= newrows)
        term->alt_y = newrows - 1;
    if (term->alt_x >= newcols)
        term->alt_x = newcols - 1;
    if (!reflow) term->wrapnext = false;
    term->alt_wnext = false;

    term->rows = newrows;
    term->cols = newcols;
    term->savelines = newsavelines;

    resize_view = term->disptop;
    swap_screen(term, save_alt_which, false, false);
    if (!save_alt_which && reflow) term->disptop = resize_view;

    term->win_scrollbar_update_pending = true;
    term_schedule_update(term);
    if (term->backend)
        backend_size(term->backend, term->cols, term->rows);
}

void term_resize_request_completed(Terminal *term)
{
    assert(term->win_resize_pending == WIN_RESIZE_AWAIT_REPLY);
    /* ConPTY may have already applied CSI 8 to the child's console buffer.
     * A denied or unchanged request must put it back in agreement with the
     * actual frontend grid. A changed grid already sent this via term_size. */
    if (term->win_resize_kind != WIN_SIZE_CELLS && term->backend &&
        term->cols == term->win_resize_old_cols &&
        term->rows == term->win_resize_old_rows)
        backend_size(term->backend, term->cols, term->rows);
    term->win_resize_pending = WIN_RESIZE_NO;
    queue_toplevel_callback(term_out_cb, term);
}

/*
 * Hand a backend to the terminal, so it can be notified of resizes.
 */
void term_provide_backend(Terminal *term, Backend *backend)
{
    term->backend = backend;
    if (term->userpass_state)
        term_userpass_state_free(term->userpass_state);
    if (term->backend && term->cols > 0 && term->rows > 0)
        backend_size(term->backend, term->cols, term->rows);
}

/* Find the bottom line on the screen that has any content.
 * If only the top line has content, returns 0.
 * If no lines have content, return -1.
 */
static int find_last_nonempty_line(Terminal *term, tree234 *screen)
{
    int i;
    for (i = count234(screen) - 1; i >= 0; i--) {
        termline *line = index234(screen, i);
        int j;
        for (j = 0; j < line->cols; j++)
            if (!termchars_equal(&line->chars[j], &term->erase_char))
                break;
        if (j != line->cols) break;
    }
    return i;
}

/*
 * Swap screens. If `reset' is true and we have been asked to
 * switch to the alternate screen, we must bring most of its
 * configuration from the main screen and erase the contents of the
 * alternate screen completely. (This is even true if we're already
 * on it! Blame xterm.)
 */
static void swap_screen(Terminal *term, int which,
                        bool reset, bool keep_cur_pos)
{
    term->grapheme_pending = false;
    int t;
    bool bt;
    pos tp;
    truecolour ttc;
    tree234 *ttr;

    if (which != term->alt_which || reset) nemo_highlight_cancel(term, true);
    if (!which)
        reset = false;                 /* do no weird resetting if which==0 */

    if (which != term->alt_which) {
        if (term->erase_to_scrollback && term->alt_screen &&
            term->alt_which && term->disptop < 0) {
            /*
             * We're swapping away from the alternate screen, so some
             * lines are about to vanish from the virtual scrollback.
             * Adjust disptop by that much, so that (if we're not
             * resetting the scrollback anyway on a display event) the
             * current scroll position still ends up pointing at the
             * same text.
             */
            term->disptop += term->alt_sblines;
            if (term->disptop > 0)
                term->disptop = 0;
        }

        term->alt_which = which;

        ttr = term->alt_screen;
        term->alt_screen = term->screen;
        term->screen = ttr;
        term->alt_sblines = (
            term->alt_screen ?
            find_last_nonempty_line(term, term->alt_screen) + 1 : 0);
        t = term->curs.x;
        if (!reset && !keep_cur_pos)
            term->curs.x = term->alt_x;
        term->alt_x = t;
        t = term->curs.y;
        if (!reset && !keep_cur_pos)
            term->curs.y = term->alt_y;
        term->alt_y = t;
        /* Scrolling margins are global operating state, as in xterm. */
        bt = term->dec_om;
        if (!reset) term->dec_om = term->alt_om;
        term->alt_om = bt;
        bt = term->wrap;
        if (!reset) term->wrap = term->alt_wrap;
        term->alt_wrap = bt;
        bt = term->wrapnext;
        if (!reset) term->wrapnext = term->alt_wnext;
        term->alt_wnext = bt;
        bt = term->insert;
        if (!reset) term->insert = term->alt_ins;
        term->alt_ins = bt;
        t = term->cset;
        if (!reset) term->cset = term->alt_cset;
        term->alt_cset = t;
        t = term->sco_acs;
        if (!reset) term->sco_acs = term->alt_sco_acs;
        term->alt_sco_acs = t;

        tp = term->savecurs;
        if (!reset)
            term->savecurs = term->alt_savecurs;
        term->alt_savecurs = tp;
        t = term->save_cset;
        if (!reset)
            term->save_cset = term->alt_save_cset;
        term->alt_save_cset = t;
        t = term->save_cset_gr;
        if (!reset)
            term->save_cset_gr = term->alt_save_cset_gr;
        term->alt_save_cset_gr = t;
        for (size_t i = 0; i < lenof(term->save_csattr); i++) {
            t = term->save_csattr[i];
            if (!reset)
                term->save_csattr[i] = term->alt_save_csattr[i];
            term->alt_save_csattr[i] = t;
        }
        unsigned upss = term->save_upss_id;
        if (!reset) term->save_upss_id = term->alt_save_upss_id;
        term->alt_save_upss_id = upss;
        t = term->save_attr;
        if (!reset)
            term->save_attr = term->alt_save_attr;
        term->alt_save_attr = t;
        ttc = term->save_truecolour;
        if (!reset)
            term->save_truecolour = term->alt_save_truecolour;
        term->alt_save_truecolour = ttc;
        uint32_t link = term->save_hyperlink;
        if (!reset)
            term->save_hyperlink = term->alt_save_hyperlink;
        term->alt_save_hyperlink = link;
        bt = term->save_wnext;
        if (!reset)
            term->save_wnext = term->alt_save_wnext;
        term->alt_save_wnext = bt;
        bt = term->save_om;
        if (!reset) term->save_om = term->alt_save_om;
        term->alt_save_om = bt;
        t = term->save_sco_acs;
        if (!reset)
            term->save_sco_acs = term->alt_save_sco_acs;
        term->alt_save_sco_acs = t;

        if (term->erase_to_scrollback && term->alt_screen &&
            term->alt_which && term->disptop < 0) {
            /*
             * Inverse of the adjustment at the top of this function.
             * This time, we're swapping _to_ the alternate screen, so
             * some lines are about to _appear_ in the virtual
             * scrollback, and we adjust disptop in the other
             * direction.
             *
             * Both these adjustments depend on the value stored in
             * term->alt_sblines while the alt screen is selected,
             * which is why we had to do one _before_ switching away
             * from it and the other _after_ switching to it.
             */
            term->disptop -= term->alt_sblines;
            int limit = -sblines(term);
            if (term->disptop < limit)
                term->disptop = limit;
        }
    }

    if (reset && term->screen) {
        /*
         * Yes, this _is_ supposed to honour background-colour-erase.
         */
        erase_lots(term, false, true, true);
    }

    seen_disp_event(term);
}

/*
 * Update the scroll bar.
 */
static void update_sbar(Terminal *term)
{
    int nscroll = sblines(term);
    win_set_scrollbar(term->win, nscroll + term->rows,
                      nscroll + term->disptop, term->rows);
}

/*
 * Check whether the region bounded by the two pointers intersects
 * the scroll region, and de-select the on-screen selection if so.
 */
static void check_selection(Terminal *term, pos from, pos to)
{
    if (poslt(from, term->selend) && poslt(term->selstart, to))
        deselect(term);
}

static int nemo_line_columns(Terminal *term, termline *line)
{
    return (line->lattr & LATTR_MODE) == LATTR_NORM ?
        term->cols : max(1, term->cols / 2);
}

static int nemo_write_right(Terminal *term, termline *line)
{
    int right = min(nemo_right(term), nemo_line_columns(term, line)-1);
    if (line->trusted) right = min(right, max(0, term->cols-TRUST_SIGIL_WIDTH-1));
    return right;
}

static void nemo_tabulate(Terminal *term, unsigned count, bool forward)
{
    pos old_curs = term->curs;
    termline *line = scrlineptr(term->curs.y);
    int limit = forward ? term->marg_r : term->dec_om ? term->marg_l : 0;
    if (forward) limit = min(limit, nemo_line_columns(term, line)-1);
    count = min(count ? count : 1, (unsigned)term->cols);
    while (count--) {
        if (forward) {
            /* HT/CHT clamp to the right margin even when starting outside
             * it. This intentionally differs from ordinary CUF movement. */
            if (term->curs.x >= limit) { term->curs.x = limit; break; }
            do { term->curs.x++; }
            while (term->curs.x < limit && !term->tabs[term->curs.x]);
        } else {
            if (term->curs.x <= limit) { term->curs.x = limit; break; }
            do { term->curs.x--; }
            while (term->curs.x > limit && !term->tabs[term->curs.x]);
        }
    }
    /* Like xterm, both directions preserve a pending automatic wrap. */
    check_selection(term, old_curs, term->curs);
    seen_disp_event(term);
}

static void clear_line(Terminal *term, termline *line)
{
    resizeline(term, line, term->cols);
    for (int i = 0; i < term->cols; i++)
        copy_termchar(line, i, &term->erase_char);
    line->lattr = LATTR_NORM;
}

static void check_trust_status(Terminal *term, termline *line)
{
    if (line->trusted != term->trusted) {
        /*
         * If we're displaying trusted output on a previously
         * untrusted line, or vice versa, we need to switch the
         * 'trusted' attribute on this terminal line, and also clear
         * all its previous contents.
         */
        clear_line(term, line);
        line->trusted = term->trusted;
    }
}

/*
 * Scroll the screen. (`lines' is +ve for scrolling forward, -ve
 * for backward.) `sb' is true if the scrolling is permitted to
 * affect the scrollback buffer.
 */
static void scroll(Terminal *term, int topline, int botline,
                   int lines, bool sb)
{
    termline *line;
    int seltop, scrollwinsize;

    if (topline != 0 || term->alt_which != 0)
        sb = false;

    scrollwinsize = botline - topline + 1;
    if (!term->alt_which)
        nemo_shell_marks_scroll(&term->shell_marks, term->marg_l,
            term->marg_r+1, topline, botline,
            -max(-scrollwinsize, min(lines, scrollwinsize)),
            !term->marg_l && term->marg_r == term->cols-1,
            sb && term->savelines > 0);
    term_scroll_images(term, term->marg_l, term->marg_r+1, topline, botline,
                       max(-scrollwinsize, min(lines, scrollwinsize)), sb);

    if (term->marg_l || term->marg_r != term->cols-1) {
        lines = max(-scrollwinsize, min(lines, scrollwinsize));
        if (!lines) return;
        int left = term->marg_l, right = term->marg_r+1;
        /* Clean wide-glyph boundaries before any row becomes a source.
         * Only full-width rotation can move complete lines into history. */
        for (int y = topline; y <= botline; y++) {
            termline *row = scrlineptr(y); check_line_size(term, row);
            check_boundary(term, left, y); check_boundary(term, right, y);
            check_selection(term, (pos){y,left}, (pos){y,right});
            if (row->lattr & LATTR_WRAPPED) row->lattr |= LATTR_CURSOR_WRAPPED;
            row->lattr &= ~(LATTR_WRAPPED | LATTR_WRAPPED2);
        }
        int step = lines > 0 ? 1 : -1;
        for (int y = step > 0 ? topline : botline;
             y >= topline && y <= botline; y += step) {
            termline *dst = scrlineptr(y);
            check_trust_status(term, dst);
            termline *src = y+lines >= topline && y+lines <= botline ?
                scrlineptr(y+lines) : NULL;
            for (int x = left; x < right; x++)
                copy_termchar(dst, x, src ? &src->chars[x] : &term->erase_char);
        }
        if (!term->alt_which)
            nemo_shell_marks_rows(&term->shell_marks,
                -count234(term->scrollback), term->rows-1, 0);
        seen_disp_event(term);
        return;
    }

    if (lines < 0) {
        lines = -lines;
        if (lines > scrollwinsize)
            lines = scrollwinsize;
        while (lines-- > 0) {
            line = delpos234(term->screen, botline);
            resizeline(term, line, term->cols);
            clear_line(term, line);
            addpos234(term->screen, line, topline);

            if (term->selstart.y >= topline && term->selstart.y <= botline) {
                term->selstart.y++;
                if (term->selstart.y > botline) {
                    term->selstart.y = botline + 1;
                    term->selstart.x = 0;
                }
            }
            if (term->selend.y >= topline && term->selend.y <= botline) {
                term->selend.y++;
                if (term->selend.y > botline) {
                    term->selend.y = botline + 1;
                    term->selend.x = 0;
                }
            }
        }
    } else {
        if (lines > scrollwinsize)
            lines = scrollwinsize;
        while (lines-- > 0) {
            line = delpos234(term->screen, topline);
#ifdef TERM_CC_DIAGS
            cc_check(line);
#endif
            if (sb && term->savelines > 0) {
                int sblen = count234(term->scrollback);
                /*
                 * We must add this line to the scrollback. We'll
                 * remove a line from the top of the scrollback if
                 * the scrollback is full.
                 */
                if (sblen == term->savelines) {
                    compressed_scrollback_line *cline;

                    sblen--;
                    cline = delpos234(term->scrollback, 0);
                    free_compressed_line(cline);
                } else
                    term->tempsblines += 1;

                addpos234(term->scrollback, compressline_no_free(line), sblen);

                /* now `line' itself can be reused as the bottom line */

                /*
                 * If the user is currently looking at part of the
                 * scrollback, and they haven't enabled any options
                 * that are going to reset the scrollback as a
                 * result of this movement, then the chances are
                 * they'd like to keep looking at the same line. So
                 * we move their viewpoint at the same rate as the
                 * scroll, at least until their viewpoint hits the
                 * top end of the scrollback buffer, at which point
                 * we don't have the choice any more.
                 *
                 * Thanks to Jan Holmen Holsten for the idea and
                 * initial implementation.
                 */
                if (term->disptop > -term->savelines && term->disptop < 0)
                    term->disptop--;

                /*
                 * We've just modified the data that the terminal's
                 * scrollbar is based on, so remember to update it.
                 */
                term->win_scrollbar_update_pending = true;
            }
            resizeline(term, line, term->cols);
            clear_line(term, line);
            line->trusted = false;
            addpos234(term->screen, line, botline);

            /*
             * If the selection endpoints move into the scrollback,
             * we keep them moving until they hit the top. However,
             * of course, if the line _hasn't_ moved into the
             * scrollback then we don't do this, and cut them off
             * at the top of the scroll region.
             *
             * This applies to selstart and selend (for an existing
             * selection), and also selanchor (for one being
             * selected as we speak).
             */
            seltop = sb ? -term->savelines : topline;

            if (term->selstate != NO_SELECTION) {
                if (term->selstart.y >= seltop &&
                    term->selstart.y <= botline) {
                    term->selstart.y--;
                    if (term->selstart.y < seltop) {
                        term->selstart.y = seltop;
                        term->selstart.x = 0;
                    }
                }
                if (term->selend.y >= seltop && term->selend.y <= botline) {
                    term->selend.y--;
                    if (term->selend.y < seltop) {
                        term->selend.y = seltop;
                        term->selend.x = 0;
                    }
                }
                if (term->selanchor.y >= seltop &&
                    term->selanchor.y <= botline) {
                    term->selanchor.y--;
                    if (term->selanchor.y < seltop) {
                        term->selanchor.y = seltop;
                        term->selanchor.x = 0;
                    }
                }
            }
        }
    }

    if (!term->alt_which)
        nemo_shell_marks_rows(&term->shell_marks,
            -count234(term->scrollback), term->rows-1, 0);
    seen_disp_event(term);
}

/*
 * Move the cursor to a given position, clipping at boundaries. We
 * may or may not want to clip at the scroll margin: marg_clip is 0
 * not to, 1 to disallow _passing_ the margins, and 2 to disallow
 * even _being_ outside the margins.
 */
static void move(Terminal *term, int x, int y, int marg_clip)
{
    if (x < 0)
        x = 0;
    if (x >= term->cols)
        x = term->cols - 1;
    if (marg_clip) {
        if ((term->curs.x >= term->marg_l || marg_clip == 2) && x < term->marg_l)
            x = term->marg_l;
        if ((term->curs.x <= term->marg_r || marg_clip == 2) && x > term->marg_r)
            x = term->marg_r;
        if ((term->curs.y >= term->marg_t || marg_clip == 2) &&
            y < term->marg_t)
            y = term->marg_t;
        if ((term->curs.y <= term->marg_b || marg_clip == 2) &&
            y > term->marg_b)
            y = term->marg_b;
    }
    if (y < 0)
        y = 0;
    if (y >= term->rows)
        y = term->rows - 1;
    term->curs.x = x;
    term->curs.y = y;
    term->wrapnext = false;
    seen_disp_event(term);
}

/*
 * Save or restore the cursor and SGR mode.
 */
/* BS/CUB count cells. Mode 45 crosses only a wrapped line; mode 1045 can
 * cross hard breaks and cycle inside the row margins. Neither may place our
 * cursor in history: a reference edge case above the margins reports row 0.
 * Cap the wire count like xterm, and reduce extended cycles arithmetically. */
static void nemo_cursor_back(Terminal *term, unsigned count)
{
    count = min(count ? count : 1, 65535u);
    bool reverse = term->wrap && term->reverse_wrap;
    bool extended = term->wrap && term->reverse_wrap_extended;
    int left = term->curs.x < term->marg_l ? 0 : term->marg_l;
    int right = term->marg_r;
    /* Xterm's CursorBack consumes an extra unit for a pending-wrap CUB;
     * BS(1) and CUB(2) both clear the pending state without moving. */
    if (term->wrapnext && (reverse || extended)) count = count > 1 ? count-2 : 0;
    term->wrapnext = false;
    while (count) {
        int x = term->curs.x, y = term->curs.y;
        if (extended && y >= term->marg_t && y <= term->marg_b && x <= right) {
            uint64_t width = right-left+1;
            uint64_t area = width*(term->marg_b-term->marg_t+1);
            uint64_t offset = (y-term->marg_t)*width+x-left;
            offset = (offset+area-count%area)%area;
            term->curs.x = left+(int)(offset%width);
            term->curs.y = term->marg_t+(int)(offset/width);
            break;
        }
        unsigned distance = min(count, (unsigned)(x-left));
        term->curs.x -= distance;
        count -= distance;
        if (!count || (!reverse && !extended)) break;
        int previous = extended && y == term->marg_t ? term->marg_b : y-1;
        if (previous < 0) break;
        if (!extended && !(scrlineptr(previous)->lattr & (LATTR_WRAPPED | LATTR_CURSOR_WRAPPED))) {
            /* Retain the reference's lower-margin boundary behavior. */
            if (previous >= term->marg_b) term->curs.y = previous;
            break;
        }
        term->curs.y = previous;
        term->curs.x = right;
        count--;
    }
    seen_disp_event(term);
}

static void save_cursor(Terminal *term, bool save)
{
    if (save) {
        term->savecurs = term->curs;
        term->save_attr = term->curr_attr;
        term->save_truecolour = term->curr_truecolour;
        term->save_hyperlink = term->curr_hyperlink;
        term->save_cset = term->cset;
        term->save_cset_gr = term->cset_gr;
        term->save_wnext = term->wrapnext;
        term->save_om = term->dec_om;
        memcpy(term->save_csattr, term->cset_attr, sizeof(term->save_csattr));
        term->save_upss_id = term->upss_id;
        term->save_sco_acs = term->sco_acs;
    } else {
        term->curs = term->savecurs;
        /* Make sure the window hasn't shrunk since the save */
        if (term->curs.x >= term->cols)
            term->curs.x = term->cols - 1;
        if (term->curs.y >= term->rows)
            term->curs.y = term->rows - 1;
        term->dec_om = term->save_om;
        if (term->dec_om) {
            term->curs.y = max(term->marg_t, min(term->marg_b, term->curs.y));
            term->curs.x = max(term->marg_l, min(term->marg_r, term->curs.x));
        }

        term->curr_attr = term->save_attr;
        term->curr_truecolour = term->save_truecolour;
        term->curr_hyperlink = term->save_hyperlink;
        /* A saved cursor must not bypass the current local charset policy.
         * XTerm saves all four designations and both locking-shift selectors;
         * its pending SS2/SS3 is live state, not part of the saved cursor. */
        if (!term->no_remote_charset) {
            term->cset = term->save_cset;
            term->cset_gr = term->save_cset_gr;
            memcpy(term->cset_attr, term->save_csattr, sizeof(term->cset_attr));
            term->upss_id = term->save_upss_id;
            term->sco_acs = term->save_sco_acs;
        }
        term->wrapnext = term->save_wnext;
        /*
         * wrapnext might reset to False if the x position is no
         * longer at the rightmost edge.
         */
        if (term->wrapnext && term->curs.x < nemo_write_right(term, scrlineptr(term->curs.y)))
            term->wrapnext = false;
        set_erase_char(term);
        seen_disp_event(term);
    }
}

/* DECSTR changes operating state without erasing either buffer or history.
 * Follow xterm's resource defaults for wrapping, application keys and cursor
 * style. Mouse/paste/keyboard transports, UTF-8, tab stops, images, the active
 * screen and current cursor position survive. Only its saved cursor is reset. */
static void nemo_soft_reset(Terminal *term)
{
    nemo_reset_ansi_colours(term);
    term->protection_mode = NEMO_PROTECT_NONE;
    term->cset_gr = 2;
    term->cset_ss = 0;
    term->checksum_flags = 0;
    term_set_grapheme_clustering(term, false);
    term->insert = term->dec_om = false;
    term->marg_t = 0;
    term->marg_b = max(0, term->rows - 1);
    term->marg_l = 0; term->marg_r = max(0, term->cols-1);
    term->lrmm = false;
    term->wrap = conf_get_bool(term->conf, CONF_wrap_mode);
    term->reverse_wrap = term->reverse_wrap_extended = false;
    term->app_cursor_keys = conf_get_bool(term->conf, CONF_app_cursor);
    term->app_keypad_keys = conf_get_bool(term->conf, CONF_app_keypad);
    nemo_mok_reset(&term->modify_keys, conf_get_int(term->conf, CONF_nemo_modify_other_keys),
                   conf_get_int(term->conf, CONF_nemo_format_other_keys));
    term->cset = term->sco_acs = 0;
    nemo_charset_reset(term);
    term->default_attr = term->curr_attr = ATTR_DEFAULT;
    term->curr_truecolour.fg = term->curr_truecolour.bg = optionalrgb_none;
    term->curr_truecolour.decoration = 0;
    term->curr_hyperlink = 0;
    set_erase_char(term);
    save_cursor(term, true);
    term->savecurs = (pos){0, 0};
    term->save_wnext = false;
    term->cursor_on = true;
    nemo_cursor_style(term, 7);
    term_schedule_update(term);
}

/*
 * This function is called before doing _anything_ which affects
 * only part of a line of text. It is used to mark the boundary
 * between two character positions, and it indicates that some sort
 * of effect is going to happen on only one side of that boundary.
 *
 * The effect of this function is to check whether a CJK
 * double-width character is straddling the boundary, and to remove
 * it and replace it with two spaces if so. (Of course, one or
 * other of those spaces is then likely to be replaced with
 * something else again, as a result of whatever happens next.)
 *
 * Also, if the boundary is at the right-hand _edge_ of the screen,
 * it implies something deliberate is being done to the rightmost
 * column position; hence we must clear LATTR_WRAPPED2.
 *
 * The input to the function is the coordinates of the _second_
 * character of the pair.
 */
static void check_boundary(Terminal *term, int x, int y)
{
    termline *ldata;

    /* Validate input coordinates, just in case. */
    if (x <= 0 || x > term->cols)
        return;

    ldata = scrlineptr(y);
    check_trust_status(term, ldata);
    check_line_size(term, ldata);
    if (x == term->cols) {
        ldata->lattr &= ~LATTR_WRAPPED2;
    } else {
        if (ldata->chars[x].chr == UCSWIDE) {
            clear_cc(ldata, x-1);
            clear_cc(ldata, x);
            ldata->chars[x-1].chr = ' ' | CSET_ASCII;
            ldata->chars[x-1].hyperlink = 0;
            ldata->chars[x] = ldata->chars[x-1];
        }
    }
}

/*
 * Erase a large portion of the screen: the whole screen, or the
 * whole line, or parts thereof.
 */
enum NemoEraseStyle { NEMO_ERASE_BCE, NEMO_ERASE_PRESERVE, NEMO_ERASE_CURRENT };

/* Erase complete, unprotected glyph runs. Expanding wide-cell boundaries
 * before testing protection avoids destroying a protected glyph's other half.
 * Images and selections are affected only in the runs actually erased. */
static bool nemo_erase_row(Terminal *term, int row, int left, int right,
                           bool respect_protection, enum NemoEraseStyle style)
{
    termline *line = scrlineptr(row);
    check_line_size(term, line);
    check_trust_status(term, line);
    left = max(0, min(left, term->cols));
    right = max(left, min(right, term->cols));
    if (left == right) return false;
    if (left > 0 && line->chars[left].chr == UCSWIDE) left--;
    if (right < term->cols && line->chars[right].chr == UCSWIDE) right++;
    int run = -1;
    bool erased = false;
    for (int x = left; x <= right;) {
        int next = x;
        bool protected = false;
        if (x < right) {
            next = x+1;
            if (next < right && line->chars[next].chr == UCSWIDE) next++;
            for (int col = x; col < next; col++)
                protected |= respect_protection &&
                    (line->chars[col].truecolour.decoration & CELL_PROTECTED);
        }
        if ((protected || x == right) && run >= 0) {
            erased = true;
            pos start = {row, run}, end = {row, x};
            check_selection(term, start, end);
            nemo_images_erase(term, start, end);
            for (int col = run; col < x; col++) {
                termchar fill = term->erase_char;
                /* As in xterm ClearInLine, interior erased spans count as
                 * drawn spaces; trailing spans remain undrawn. */
                if (style == NEMO_ERASE_BCE && x < term->cols)
                    fill.truecolour.decoration &= ~CELL_UNDRAWN;
                if (style == NEMO_ERASE_PRESERVE) {
                    fill.attr = line->chars[col].attr;
                    fill.truecolour = line->chars[col].truecolour;
                    fill.truecolour.decoration &= ~CELL_UNDRAWN;
                } else if (style == NEMO_ERASE_CURRENT) {
                    /* xterm DECERA uses current rendition, keeping each
                     * existing colour when that current colour is default. */
                    fill.attr = term->curr_attr;
                    fill.truecolour = term->curr_truecolour;
                    fill.truecolour.decoration &= ~CELL_PROTECTED;
                    if ((term->curr_attr & ATTR_FGMASK) == ATTR_DEFFG &&
                        !term->curr_truecolour.fg.enabled) {
                        fill.attr = (fill.attr & ~ATTR_FGMASK) |
                            (line->chars[col].attr & ATTR_FGMASK);
                        fill.truecolour.fg = line->chars[col].truecolour.fg;
                    }
                    if ((term->curr_attr & ATTR_BGMASK) == ATTR_DEFBG &&
                        !term->curr_truecolour.bg.enabled) {
                        fill.attr = (fill.attr & ~ATTR_BGMASK) |
                            (line->chars[col].attr & ATTR_BGMASK);
                        fill.truecolour.bg = line->chars[col].truecolour.bg;
                    }
                }
                copy_termchar(line, col, &fill);
            }
            run = -1;
        }
        if (x == right) break;
        if (!protected && run < 0) run = x;
        x = next;
    }
    return erased;
}

static void nemo_selective_erase(Terminal *term, bool line_only, unsigned mode)
{
    if (mode > 2) return;
    /* ED at either extreme is a whole-display erase in xterm, including
     * retiring a protection family when no protected cells remain. */
    if (!line_only && ((mode == 0 && term->curs.x == 0 && term->curs.y == 0) ||
                      (mode == 1 && term->curs.x == term->cols-1 &&
                       term->curs.y == term->rows-1)))
        mode = 2;
    bool erased = false;
    int top = line_only || mode == 0 ? term->curs.y : 0;
    int bottom = line_only || mode == 1 ? term->curs.y : term->rows-1;
    for (int row = top; row <= bottom; row++) {
        int left = row == term->curs.y && mode == 0 ? term->curs.x : 0;
        int right = row == term->curs.y && mode == 1 ? term->curs.x+1 : term->cols;
        erased |= nemo_erase_row(term, row, left, right,
                                term->protection_mode != NEMO_PROTECT_NONE,
                                NEMO_ERASE_BCE);
        if (mode == 0 && row == term->curs.y)
            scrlineptr(row)->lattr &= ~(LATTR_WRAPPED | LATTR_WRAPPED2 | LATTR_CURSOR_WRAPPED);
    }
    if (!line_only && mode == 2 && term->protection_mode != NEMO_PROTECT_NONE) {
        bool remains = false;
        for (int row = 0; row < term->rows && !remains; row++) {
            const termline *line = index234(term->screen, row);
            for (int col = 0; col < term->cols; col++)
                if (line->chars[col].truecolour.decoration & CELL_PROTECTED) {
                    remains = true;
                    break;
                }
        }
        if (!remains) term->protection_mode = NEMO_PROTECT_NONE;
    }
    /* Include the physical cell under a pending-wrap cursor. ClearRight
     * always ends pending wrap; other ranges do so only when cells erase. */
    if (mode == 0 || erased) term->wrapnext = false;
    if (term->scroll_on_disp) term->disptop = 0;
    seen_disp_event(term);
}

/* Half-open coordinates, relative to the origin region when DECOM is set.
 * The same parser is used by all DEC rectangle operations. No input-sized
 * allocation or unsigned-to-signed conversion occurs before clamping. */
struct NemoRect { int top, left, bottom, right; };
static bool nemo_rectangle(Terminal *term, unsigned first, unsigned count,
                           struct NemoRect *r)
{
    int base = term->dec_om ? term->marg_t : 0;
    unsigned height = (term->dec_om ? term->marg_b+1 : term->rows) - base;
    int xbase = term->dec_om ? term->marg_l : 0;
    unsigned width = (term->dec_om ? term->marg_r+1 : term->cols)-xbase;
    unsigned limits[] = {height, width, height, width}, coords[4];
    if (!height || term->cols <= 0) return false;
    for (unsigned i = 0; i < lenof(coords); i++) {
        unsigned value = i < count && first+i < (unsigned)term->esc_nargs ?
            term->esc_args[first+i] : 0;
        if (!value) value = i < 2 ? 1 : limits[i];
        coords[i] = min(value, limits[i]);
    }
    if (coords[0] > coords[2] || coords[1] > coords[3]) return false;
    *r = (struct NemoRect){base+coords[0]-1, xbase+coords[1]-1,
                          base+coords[2], xbase+coords[3]};
    return true;
}

static void nemo_report_rectangle_sgr(Terminal *term)
{
    if (!term->ldisc) return;
    struct NemoRect r;
    termchar common = term->basic_erase_char;
    bool first = true;
    if (nemo_rectangle(term, 0, 4, &r)) {
        bool bold_colours = conf_get_int(term->conf, CONF_bold_style) & BOLD_STYLE_COLOUR;
        for (int y = r.top; y < r.bottom; y++) {
            const termline *line = index234(term->screen, y);
            assert(line);
            for (int x = r.left; x < r.right; x++) {
                termchar cell = x < line->cols ? line->chars[x] : term->basic_erase_char;
                unsigned fg = (cell.attr & ATTR_FGMASK) >> ATTR_FGSHIFT;
                if (bold_colours && (cell.attr & ATTR_BOLD) && !cell.truecolour.fg.enabled && fg < 8)
                    cell.attr = (cell.attr & ~ATTR_FGMASK) | ((fg+8) << ATTR_FGSHIFT);
                if (first) { common = cell; first = false; }
                if ((common.attr & ATTR_FGMASK) != (cell.attr & ATTR_FGMASK) ||
                    !optionalrgb_equal(common.truecolour.fg, cell.truecolour.fg)) {
                    common.attr = (common.attr & ~ATTR_FGMASK) | ATTR_DEFFG;
                    common.truecolour.fg = optionalrgb_none;
                }
                if ((common.attr & ATTR_BGMASK) != (cell.attr & ATTR_BGMASK) ||
                    !optionalrgb_equal(common.truecolour.bg, cell.truecolour.bg)) {
                    common.attr = (common.attr & ~ATTR_BGMASK) | ATTR_DEFBG;
                    common.truecolour.bg = optionalrgb_none;
                }
                common.attr &= cell.attr | ATTR_COLOURS;
                if (UNDER_STYLE_RAW(common.truecolour) != UNDER_STYLE_RAW(cell.truecolour)) {
                    common.attr &= ~ATTR_UNDER;
                    common.truecolour.decoration &= ~UNDER_STYLE_MASK;
                }
                if ((common.truecolour.decoration & UNDER_COLOUR_MASK) !=
                    (cell.truecolour.decoration & UNDER_COLOUR_MASK))
                    common.truecolour.decoration &= ~UNDER_COLOUR_MASK;
                common.truecolour.decoration &= cell.truecolour.decoration |
                    ~(UNDER_DOUBLE_LEGACY | DECOR_OVERLINE | DECOR_ENCLOSURES |
                      DECOR_IDEOGRAMS);
            }
        }
    }
    strbuf *reply = strbuf_new();
    put_dataz(reply, "\033[0");
    if (common.attr & ATTR_BOLD) put_dataz(reply, ";1");
    if (common.attr & ATTR_UNDER) {
        unsigned style = UNDER_STYLE_RAW(common.truecolour);
        if (style <= 1) put_dataz(reply, ";4");
        else put_fmt(reply, ";4:%u", style);
    }
    static const struct { unsigned long bit; unsigned sgr; } flags[] = {
        {ATTR_BLINK, 5}, {ATTR_REVERSE, 7}, {ATTR_CONCEAL, 8},
        {ATTR_DIM, 2}, {ATTR_ITALIC, 3}, {ATTR_STRIKE, 9},
    };
    for (size_t i = 0; i < lenof(flags); i++)
        if (common.attr & flags[i].bit) put_fmt(reply, ";%u", flags[i].sgr);
    if (common.truecolour.decoration & UNDER_DOUBLE_LEGACY) put_dataz(reply, ";21");
    if (common.truecolour.decoration & DECOR_FRAMED) put_dataz(reply, ";51");
    if (common.truecolour.decoration & DECOR_ENCIRCLED) put_dataz(reply, ";52");
    if (common.truecolour.decoration & DECOR_OVERLINE) put_dataz(reply, ";53");
    for (unsigned i = 0; i < 5; i++)
        if (common.truecolour.decoration & (DECOR_IDEO_UNDERLINE << i))
            put_fmt(reply, ";%u", 60+i);
    nemo_report_sgr_colour(reply, 38, (common.attr & ATTR_FGMASK) >> ATTR_FGSHIFT,
                           common.truecolour.fg, true);
    nemo_report_sgr_colour(reply, 48, (common.attr & ATTR_BGMASK) >> ATTR_BGSHIFT,
                           common.truecolour.bg, true);
    uint32_t colour = common.truecolour.decoration & UNDER_COLOUR_MASK;
    if (colour & UNDER_RGB)
        put_fmt(reply, ";58:2::%u:%u:%u", (colour >> 16) & 255, (colour >> 8) & 255, colour & 255);
    else if (colour & UNDER_INDEXED) put_fmt(reply, ";58:5:%u", colour & 255);
    put_byte(reply, 'm');
    nemo_protocol_send(term, reply->s, reply->len);
    strbuf_free(reply);
}

static void nemo_erase_rectangle(Terminal *term, bool selective)
{
    struct NemoRect r;
    if (!nemo_rectangle(term, 0, 4, &r)) return;
    for (int row = r.top; row < r.bottom; row++)
        nemo_erase_row(term, row, r.left, r.right,
                       selective && term->protection_mode == NEMO_PROTECT_DEC,
                       selective ? NEMO_ERASE_PRESERVE : NEMO_ERASE_CURRENT);
    /* Rectangle operations leave cursor, pending wrap and line attributes. */
    seen_disp_event(term);
}

static void nemo_fill_rectangle(Terminal *term)
{
    unsigned ch = term->esc_args[0] ? term->esc_args[0] : ' ';
    if (ch < 32 || (ch >= 127 && ch < 160) || ch > 0x10ffff ||
        (ch >= 0xd800 && ch <= 0xdfff) || term_char_width(term, ch) <= 0) return;
    struct NemoRect r;
    if (!nemo_rectangle(term, 1, 4, &r)) return;
    uint64_t checksum = ch < 128 ?
        nemo_charset_checksum_metadata(term, term->cset_attr[term->cset], ch) : 0;
    /* DEC allows ASCII/Latin-1; xterm also accepts printable Unicode. Each
     * fill position is one cell, even for that Unicode extension. */
    if (ch < 128) {
        if (term->cset_attr[term->cset] < 0) {
            unsigned long mapped = nemo_charset_graphic(term, term->cset_attr[term->cset], ch);
            if (mapped == UCSINCOMPLETE) return;
            ch = mapped;
        } else if (term->cset_attr[term->cset] == CSET_GBCHR && ch == '#' &&
                   (term->nrc_mode || nemo_charset_level(term) == 1))
            ch = CSET_LINEDRW | '}';
        else if (term->cset_attr[term->cset] != CSET_GBCHR)
            ch |= term->cset_attr[term->cset];
    }
    for (int y = r.top; y < r.bottom; y++) {
        termline *line = scrlineptr(y);
        check_line_size(term, line); check_trust_status(term, line);
        check_boundary(term, r.left, y); check_boundary(term, r.right, y);
        check_selection(term, (pos){y,r.left}, (pos){y,r.right});
        nemo_images_erase(term, (pos){y,r.left}, (pos){y,r.right});
        for (int x = r.left; x < r.right; x++) {
            termchar fill = {.chr=ch, .attr=term->curr_attr,
                             .truecolour=term->curr_truecolour};
            if (checksum && ((checksum & CELL_CHECKSUM_BYTE_POUND) ||
                (checksum & CELL_CHECKSUM_VALUE) >> CELL_CHECKSUM_SHIFT !=
                nemo_checksum_legacy(ch))) fill.truecolour.decoration |= checksum;
            /* Like DECERA, default current colours retain the old cell's
             * colour. Protection comes from the current DECSCA setting. */
            if ((fill.attr & ATTR_FGMASK) == ATTR_DEFFG && !fill.truecolour.fg.enabled) {
                fill.attr = (fill.attr & ~ATTR_FGMASK) | (line->chars[x].attr & ATTR_FGMASK);
                fill.truecolour.fg = line->chars[x].truecolour.fg;
            }
            if ((fill.attr & ATTR_BGMASK) == ATTR_DEFBG && !fill.truecolour.bg.enabled) {
                fill.attr = (fill.attr & ~ATTR_BGMASK) | (line->chars[x].attr & ATTR_BGMASK);
                fill.truecolour.bg = line->chars[x].truecolour.bg;
            }
            copy_termchar(line, x, &fill);
        }
    }
    seen_disp_event(term);
}

static void nemo_copy_rectangle(Terminal *term)
{
    struct NemoRect src, dst;
    if (!nemo_rectangle(term, 0, 4, &src) || !nemo_rectangle(term, 5, 2, &dst)) return;
    int width = min(src.right-src.left, dst.right-dst.left);
    int height = min(src.bottom-src.top, dst.bottom-dst.top);
    if (width <= 0 || height <= 0) return;
    /* Like xterm, page numbers address the sole current page. Choose the
     * traversal direction for overlapping rows and snapshot only one row,
     * including its combining chains. Scratch space is O(columns), not area. */
    termline *scratch = newtermline(term, width, false);
    int step = dst.top > src.top ? -1 : 1;
    int start = step < 0 ? height-1 : 0;
    for (int i = start; i >= 0 && i < height; i += step) {
        termline *from = scrlineptr(src.top+i), *to = scrlineptr(dst.top+i);
        check_line_size(term, from); check_line_size(term, to);
        for (int x = 0; x < width; x++) {
            termchar *cell = &from->chars[src.left+x];
            if ((!x && cell->chr == UCSWIDE) ||
                (x == width-1 && src.left+width < term->cols &&
                 from->chars[src.left+width].chr == UCSWIDE)) {
                termchar blank = *cell;
                blank.chr = ' ' | CSET_ASCII; blank.cc_next = 0; blank.hyperlink = 0;
                copy_termchar(scratch, x, &blank);
            } else copy_termchar(scratch, x, cell);
        }
        check_trust_status(term, to);
        check_boundary(term, dst.left, dst.top+i);
        check_boundary(term, dst.left+width, dst.top+i);
        check_selection(term, (pos){dst.top+i,dst.left}, (pos){dst.top+i,dst.left+width});
        nemo_images_erase(term, (pos){dst.top+i,dst.left}, (pos){dst.top+i,dst.left+width});
        for (int x = 0; x < width; x++) {
            copy_termchar(to, dst.left+x, &scratch->chars[x]);
            to->chars[dst.left+x].truecolour.decoration &= ~CELL_UNDRAWN;
        }
    }
    freetermline(scratch);
    seen_disp_event(term);
}

static void nemo_rectangle_attributes(Terminal *term, bool reverse)
{
    struct NemoRect r;
    if (!nemo_rectangle(term, 0, 4, &r)) return;
    bool exact = term->rectangle_extent == 2;
    const unsigned all = ATTR_BOLD | ATTR_UNDER | ATTR_BLINK | ATTR_REVERSE;
    for (int y = r.top; y < r.bottom; y++) {
        termline *line = scrlineptr(y); check_line_size(term, line);
        /* Stream extent covers whole intervening physical lines, even when
         * DECOM made the two endpoint coordinates relative to margins. */
        int left = exact || y == r.top ? r.left : 0;
        int right = exact || y == r.bottom-1 ? r.right : term->cols;
        for (int x = left; x < right; x++) {
            termchar *cell = &line->chars[x];
            if (cell->truecolour.decoration & CELL_UNDRAWN) {
                if (!exact) continue;
                cell->truecolour.decoration &= ~CELL_UNDRAWN;
            }
            for (int n = 4; n < term->esc_nargs; n++) {
                unsigned value = term->esc_args[n], bits = 0;
                switch (value) {
                  case 0: bits = all; break;
                  case 1: case 22: bits = ATTR_BOLD; break;
                  case 4: case 24: bits = ATTR_UNDER; break;
                  case 5: case 25: bits = ATTR_BLINK; break;
                  case 7: case 27: bits = ATTR_REVERSE; break;
                  case 8: case 28: bits = ATTR_CONCEAL; break;
                }
                if (reverse) {
                    if (value >= 22) continue;
                    cell->attr ^= bits;
                } else if (!value || value >= 22) cell->attr &= ~bits;
                else cell->attr |= bits;
                if (bits & ATTR_UNDER) {
                    cell->truecolour.decoration &= ~UNDER_STYLE_MASK;
                    if (cell->attr & ATTR_UNDER)
                        cell->truecolour.decoration |= UINT32_C(1) << UNDER_STYLE_SHIFT;
                }
            }
        }
    }
    /* Attributes do not change text, its selection, links or raster graphics. */
    seen_disp_event(term);
}

static void erase_lots(Terminal *term,
                       bool line_only, bool from_begin, bool to_end)
{
    pos start, end;
    bool erase_lattr;
    bool erasing_lines_from_top = false;

    if (line_only) {
        start.y = term->curs.y;
        start.x = 0;
        end.y = term->curs.y + 1;
        end.x = 0;
        erase_lattr = false;
    } else {
        start.y = 0;
        start.x = 0;
        end.y = term->rows;
        end.x = 0;
        erase_lattr = true;
    }

    /* This is the endpoint of the clearing operation that is not
     * either the start or end of the line / screen. */
    pos boundary = term->curs;

    if (!from_begin) {
        /*
         * If we're erasing from the current char to the end of
         * line/screen, then we take account of wrapnext, so as to
         * maintain the invariant that writing a printing character
         * followed by ESC[K should not overwrite the character you
         * _just wrote_. That is, when wrapnext says the cursor is
         * 'logically' at the very rightmost edge of the screen
         * instead of just before the last printing char, ESC[K should
         * do nothing at all, and ESC[J should clear the next line but
         * leave this one unchanged.
         *
         * This adjusted position will also be the position we use for
         * check_boundary (i.e. the thing we ensure isn't in the
         * middle of a double-width printing char).
         */
        if (term->wrapnext)
            incpos(boundary);

        start = boundary;
    }
    if (!to_end) {
        /*
         * If we're erasing from the start of (at least) the line _to_
         * the current position, then that is taken to mean 'inclusive
         * of the cell under the cursor', which means we don't
         * consider wrapnext at all: whether it's set or not, we still
         * clear the cell under the cursor.
         *
         * Again, that incremented boundary position is where we
         * should be careful of a straddling wide character.
         */
        incpos(boundary);
        end = boundary;
    }
    if (!from_begin || !to_end)
        check_boundary(term, boundary.x, boundary.y);
    check_selection(term, start, end);
    nemo_images_erase(term, start, end);

    /* Clear screen also forces a full window redraw, just in case. */
    if (start.y == 0 && start.x == 0 && end.y == term->rows)
        term_invalidate(term);

    /* Lines scrolled away shouldn't be brought back on if the terminal
     * resizes. */
    if (start.y == 0 && start.x == 0 && end.x == 0 && erase_lattr)
        erasing_lines_from_top = true;

    if (term->erase_to_scrollback && erasing_lines_from_top) {
        /* If it's a whole number of lines, starting at the top, and
         * we're fully erasing them, erase by scrolling and keep the
         * lines in the scrollback. */
        int scrolllines = end.y;
        if (end.y == term->rows) {
            /* Shrink until we find a non-empty row.*/
            scrolllines = find_last_nonempty_line(term, term->screen) + 1;
        }
        if (scrolllines > 0)
            scroll(term, 0, scrolllines - 1, scrolllines, true);
    } else {
        termline *ldata = scrlineptr(start.y);
        check_trust_status(term, ldata);
        while (poslt(start, end)) {
            check_line_size(term, ldata);
            if (start.x == term->cols) {
                if (!erase_lattr)
                    ldata->lattr &= ~(LATTR_WRAPPED | LATTR_WRAPPED2 | LATTR_CURSOR_WRAPPED);
                else
                    ldata->lattr = LATTR_NORM;
            } else {
                copy_termchar(ldata, start.x, &term->erase_char);
            }
            if (incpos(start) && start.y < term->rows) {
                ldata = scrlineptr(start.y);
                check_trust_status(term, ldata);
            }
        }
    }

    /* After an erase of lines from the top of the screen, we shouldn't
     * bring the lines back again if the terminal enlarges (since the user or
     * application has explicitly thrown them away). */
    if (erasing_lines_from_top && !(term->alt_which))
        term->tempsblines = 0;

    seen_disp_event(term);
}

/*
 * Insert or delete characters within the current line. n is +ve if
 * insertion is desired, and -ve for deletion.
 */
static void insch(Terminal *term, int n)
{
    if (!nemo_in_lr(term)) return;
    int end = term->marg_r+1;
    term->wrapnext = false;
    int dir = (n < 0 ? -1 : +1);
    int m, j;
    pos eol;
    termline *ldata;

    nemo_images_erase(term, term->curs,
                      (pos){term->curs.y, end});
    n = (n < 0 ? -n : n);
    if (n > end - term->curs.x)
        n = end - term->curs.x;
    m = end - term->curs.x - n;

    /*
     * We must de-highlight the selection if it overlaps any part of
     * the region affected by this operation, i.e. the region from the
     * current cursor position to end-of-line, _unless_ the entirety
     * of the selection is going to be moved to the left or right by
     * this operation but otherwise unchanged, in which case we can
     * simply move the highlight with the text.
     */
    eol.y = term->curs.y;
    eol.x = end;
    if (poslt(term->curs, term->selend) && poslt(term->selstart, eol)) {
        pos okstart = term->curs;
        pos okend = eol;
        if (dir > 0) {
            /* Insertion: n characters at EOL will be splatted. */
            okend.x -= n;
        } else {
            /* Deletion: n characters at cursor position will be splatted. */
            okstart.x += n;
        }
        if (posle(okstart, term->selstart) && posle(term->selend, okend)) {
            /* Selection is contained entirely in the interval
             * [okstart,okend), so we need only adjust the selection
             * bounds. */
            term->selstart.x += dir * n;
            term->selend.x += dir * n;
            assert(term->selstart.x >= term->curs.x);
            assert(term->selstart.x < term->cols);
            assert(term->selend.x > term->curs.x);
            assert(term->selend.x <= term->cols);
        } else {
            /* Selection is not wholly contained in that interval, so
             * we must unhighlight it. */
            deselect(term);
        }
    }

    check_boundary(term, term->curs.x, term->curs.y);
    check_boundary(term, end, term->curs.y);
    if (dir < 0)
        check_boundary(term, term->curs.x + n, term->curs.y);
    ldata = scrlineptr(term->curs.y);
    check_trust_status(term, ldata);
    if (dir < 0) {
        for (j = 0; j < m; j++)
            move_termchar(ldata,
                          ldata->chars + term->curs.x + j,
                          ldata->chars + term->curs.x + j + n);
        while (n--)
            copy_termchar(ldata, term->curs.x + m++, &term->erase_char);
    } else {
        for (j = m; j-- ;)
            move_termchar(ldata,
                          ldata->chars + term->curs.x + j + n,
                          ldata->chars + term->curs.x + j);
        termchar blank = term->erase_char;
        blank.truecolour.decoration &= ~CELL_UNDRAWN;
        while (n--)
            copy_termchar(ldata, term->curs.x + n, &blank);
    }
}

/* SL/SR and DEC column editing share one bounded rectangle operation.
 * Unlike ICH/DCH, these controls preserve the cursor's pending wrap. */
static void nemo_scroll_columns(Terminal *term, unsigned count, bool to_left, int left)
{
    if (!nemo_in_lr(term) || term->curs.y < term->marg_t ||
        term->curs.y > term->marg_b) return;
    int right = term->marg_r+1;
    int n = min(count ? count : 1, (unsigned)(right-left));
    if (!n) return;
    if (!term->alt_which) {
        nemo_shell_marks_shift(&term->shell_marks, left, right,
                              term->marg_t, term->marg_b, to_left ? -n : n);
        nemo_shell_marks_rows(&term->shell_marks, -count234(term->scrollback), term->rows-1, 0);
    }
    nemo_images_shift(term, left, right, term->marg_t, term->marg_b, to_left ? -n : n);
    for (int y = term->marg_t; y <= term->marg_b; y++) {
        termline *line = scrlineptr(y);
        check_line_size(term, line);
        check_trust_status(term, line);
        int changed_left = left > 0 && line->chars[left].chr == UCSWIDE ? left-1 : left;
        int changed_right = right < term->cols && line->chars[right].chr == UCSWIDE ? right+1 : right;
        check_selection(term, (pos){y, changed_left}, (pos){y, changed_right});
        check_boundary(term, left, y);
        check_boundary(term, right, y);
        check_boundary(term, to_left ? left+n : right-n, y);
        if (to_left) {
            for (int x = left; x < right-n; x++)
                move_termchar(line, &line->chars[x], &line->chars[x+n]);
            for (int x = right-n; x < right; x++)
                copy_termchar(line, x, &term->erase_char);
        } else {
            for (int x = right; x-- > left+n;)
                move_termchar(line, &line->chars[x], &line->chars[x-n]);
            termchar blank = term->erase_char;
            blank.truecolour.decoration &= ~CELL_UNDRAWN;
            for (int x = left; x < left+n; x++)
                copy_termchar(line, x, &blank);
        }
    }
    seen_disp_event(term);
}

static void nemo_column_index(Terminal *term, bool backward)
{
    if (nemo_in_lr(term) && term->curs.x == (backward ? term->marg_l : term->marg_r)) {
        nemo_scroll_columns(term, 1, !backward, term->marg_l);
    } else {
        if (backward) nemo_cursor_back(term, 1);
        else {
            int right = min(nemo_right(term), nemo_line_columns(term, scrlineptr(term->curs.y))-1);
            move(term, min(term->curs.x+1, right), term->curs.y, 1);
        }
    }
    seen_disp_event(term);
}

static void term_update_raw_mouse_mode(Terminal *term)
{
    bool want_raw = (term->xterm_mouse != 0 && !term->xterm_mouse_forbidden);
    win_set_raw_mouse_mode(term->win, want_raw);
    term->win_pointer_shape_pending = true;
    term->win_pointer_shape_raw = want_raw;
    term_schedule_update(term);
}

static void term_request_resize(Terminal *term, int cols, int rows)
{
    if (term->cols == cols && term->rows == rows)
        return;                        /* don't need to do anything */

    term->win_resize_pending = WIN_RESIZE_NEED_SEND;
    term->win_resize_kind = WIN_SIZE_CELLS;
    term_end_synchronized_update(term);
    term->win_resize_pending_w = cols;
    term->win_resize_pending_h = rows;
    term_schedule_update(term);
}

static int nemo_window_parameter(Terminal *term, unsigned index)
{
    if (index >= (unsigned)term->esc_nargs ||
        !(term->esc_arg_present & (1u << index))) return -1;
    return min(term->esc_args[index], 65535);
}

static void nemo_request_window_size(Terminal *term, int w, int h, bool pixels)
{
    if (term->no_remote_resize) {
        if (term->backend) backend_size(term->backend, term->cols, term->rows);
        return;
    }
    if (!term->win->vt->request_window_resize) {
        /* Preserve ordinary character resizing on older frontends. */
        if (!pixels && w != 0 && h != 0 && term->win->vt->request_resize)
            term_request_resize(term, w < 0 ? term->cols : w,
                                h < 0 ? term->rows : h);
        return;
    }
    term->win_resize_pending = WIN_RESIZE_NEED_SEND;
    term->win_resize_kind = pixels ? WIN_SIZE_XT_PIXELS : WIN_SIZE_XT_CELLS;
    term->win_resize_pending_w = w;
    term->win_resize_pending_h = h;
    term->win_resize_old_cols = term->cols;
    term->win_resize_old_rows = term->rows;
    term_end_synchronized_update(term);
    term_schedule_update(term);
}

/*
 * Toggle terminal mode `mode' to state `state'. (`query' indicates
 * whether the mode is a DEC private one or a normal one.)
 */
static void toggle_mode(Terminal *term, int mode, int query, bool state)
{
    if (query == 1) {
        switch (mode) {
          case 1:                      /* DECCKM: application cursor keys */
            term->app_cursor_keys = state;
            break;
          case 2:                      /* DECANM: VT52 mode */
            term->vt52_mode = !state;
            if (term->vt52_mode) {
                term->blink_is_real = false;
                term->vt52_bold = false;
            } else {
                term->blink_is_real = term->blinktext;
            }
            term_schedule_tblink(term);
            break;
          case 3:                      /* DECCOLM: 80/132 columns */
            deselect(term);
            if (!term->no_remote_resize)
                term_request_resize(term, state ? 132 : 80, term->rows);
            term->reset_132 = state;
            term->marg_t = 0;
            term->marg_b = term->rows - 1;
            term->marg_l = 0; term->marg_r = term->cols-1;
            move(term, 0, 0, 0);
            erase_lots(term, false, true, true);
            break;
          case 5:                      /* DECSCNM: reverse video */
            /*
             * Toggle reverse video. If we receive an OFF within the
             * visual bell timeout period after an ON, we trigger an
             * effective visual bell, so that ESC[?5hESC[?5l will
             * always be an actually _visible_ visual bell.
             */
            if (term->rvideo && !state) {
                /* This is an OFF, so set up a vbell */
                term_schedule_vbell(term, true, term->rvbell_startpoint);
            } else if (!term->rvideo && state) {
                /* This is an ON, so we notice the time and save it. */
                term->rvbell_startpoint = GETTICKCOUNT();
            }
            nemo_set_reverse_video(term, state);
            seen_disp_event(term);
            break;
          case 6:                      /* DECOM: DEC origin mode */
            term->dec_om = state;
            move(term, state ? term->marg_l : 0, state ? term->marg_t : 0, 0);
            seen_disp_event(term);
            break;
          case 7:                      /* DECAWM: auto wrap */
            term->wrap = state;
            if (!term->wrap)
                term->wrapnext = false;
            break;
          case 8:                      /* DECARM: auto key repeat */
            term->repeat_off = !state;
            break;
          case 45: term->reverse_wrap = state; break;
          case 42:
            if (!term->no_remote_charset && has_compat(VT220)) {
                term->nrc_mode = state;
                term->utf8.state = 0;
            }
            break;
          case 1045: term->reverse_wrap_extended = state; break;
          case 12:                     /* cursor blinking (att610/xterm) */
            term->blink_cur = state;
            term->cblinker = true;
            term_schedule_cblink(term);
            term_invalidate(term);
            break;
          case 25:                     /* DECTCEM: enable/disable cursor */
            compatibility2(OTHER, VT220);
            term->cursor_on = state;
            seen_disp_event(term);
            break;
          case 66:                     /* DECNKM: numeric/application keypad */
            term->app_keypad_keys = state;
            break;
          case 69:                     /* DECLRMM: left/right margins */
            term->lrmm = state;
            if (!state) { term->marg_l = 0; term->marg_r = term->cols-1; }
            else for (int y = 0; y < term->rows; y++) {
                termline *line = scrlineptr(y);
                line->lattr &= ~LATTR_MODE;
            }
            seen_disp_event(term);
            break;
          case 47:                     /* alternate screen */
            compatibility(OTHER);
            deselect(term);
            swap_screen(term, term->no_alt_screen ? 0 : state, false, false);
            if (term->scroll_on_disp)
                term->disptop = 0;
            break;
          case 9:                      /* X10 press-only tracking */
          case 1000:                   /* press/release tracking */
          case 1001:                   /* application-assisted highlight */
          case 1002:                   /* button-event tracking */
          case 1003: {                 /* any-event tracking */
            int tracking = mode == 9 ? -1 : mode == 1000 ? 1 :
                mode == 1002 ? 2 : mode == 1001 ? MOUSE_TRACK_HIGHLIGHT : 3;
            nemo_highlight_cancel(term, false);
            /* Tracking modes and coordinate encodings are independent,
             * mutually exclusive groups: the last SET wins. */
            term->xterm_mouse = state ? tracking : 0;
            term->mouse_buttons = 0;
            term->raw_mouse_reported_code = -1;
            term_update_raw_mouse_mode(term);
            break;
          }
          case 1004:
            term->mouse_focus_reporting = state;
            break;
          case 1007:
            term->mouse_alternate_scroll = state;
            break;
          case 1005:                   /* UTF-8 coordinates */
          case 1006:                   /* SGR cell coordinates */
          case 1015:                   /* urxvt coordinates */
          case 1016:                   /* SGR pixel coordinates */
            if (state || term->mouse_encoding == mode) {
                nemo_highlight_cancel(term, true);
                term->mouse_encoding = state ? mode : 0;
                term->raw_mouse_reported_code = -1;
            }
            break;
          case 1047:                   /* alternate screen */
            compatibility(OTHER);
            deselect(term);
            swap_screen(term, term->no_alt_screen ? 0 : state, true, true);
            if (term->scroll_on_disp)
                term->disptop = 0;
            break;
          case 1048:                   /* save/restore cursor */
            if (!term->no_alt_screen)
                save_cursor(term, state);
            if (!state) seen_disp_event(term);
            break;
          case 1049:                   /* cursor & alternate screen */
            if (state && !term->no_alt_screen)
                save_cursor(term, state);
            if (!state) seen_disp_event(term);
            compatibility(OTHER);
            deselect(term);
            swap_screen(term, term->no_alt_screen ? 0 : state, true, false);
            if (!state && !term->no_alt_screen)
                save_cursor(term, state);
            if (term->scroll_on_disp)
                term->disptop = 0;
            break;
          case 80:                     /* DECSDM: set disables scrolling */
            term->sixel_display_mode = state;
            break;
          case 1070:                   /* private Sixel color registers */
            term->sixel_private_palette = state;
            break;
          case 8452:                   /* Sixel cursor to graphic right */
            term->sixel_scrolls_right = state;
            break;
          case 2026:                   /* synchronized presentation */
            if (state) term_start_synchronized_update(term);
            else term_end_synchronized_update(term);
            break;
          case 2027:                   /* Unicode grapheme cluster widths */
            if (term->win->vt->grapheme_clusters)
                term_set_grapheme_clustering(term, state);
            break;
          case 2004:                   /* xterm bracketed paste */
            term->bracketed_paste = state ? true : false;
            break;
          case 9001:                   /* Win32 KEY_EVENT_RECORD transport */
            if (term->win32_input != state) term->win32_input_epoch++;
            term->win32_input = state;
            break;
        }
    } else if (query == 0) {
        switch (mode) {
          case 4:                      /* IRM: set insert mode */
            compatibility(VT102);
            term->insert = state;
            break;
          case 12:                     /* SRM: set echo mode */
            term->srm_echo = !state;
            break;
          case 20:                     /* LNM: Return sends ... */
            term->cr_lf_return = state;
            break;
          case 34:                     /* WYULCURM: Make cursor BIG */
            compatibility2(OTHER, VT220);
            term->big_cursor = !state;
        }
    }
}

/* DECRQM reports implemented state, not a list of aspirational features.
 * 0=unknown, 1=set, 2=reset, 4=permanently reset by local configuration. */
static unsigned term_mode_status(Terminal *term, unsigned mode, bool dec)
{
    bool state;
    if (!dec) {
        switch (mode) {
          case 4: state = term->insert; break;
          case 12: state = !term->srm_echo; break;
          case 20: state = term->cr_lf_return; break;
          case 34: state = !term->big_cursor; break;
          default: return 0;
        }
    } else {
        switch (mode) {
          case 1:
            if (term->no_applic_c) return 4;
            state = term->app_cursor_keys; break;
          case 2: state = !term->vt52_mode; break;
          case 3:
            if (term->no_remote_resize) return 4;
            state = term->reset_132; break;
          case 5: state = term->rvideo; break;
          case 6: state = term->dec_om; break;
          case 7: state = term->wrap; break;
          case 8: state = !term->repeat_off; break;
          case 45: state = term->reverse_wrap; break;
          case 42:
            if (!has_compat(VT220)) return 0;
            if (term->no_remote_charset) return 4;
            state = term->nrc_mode; break;
          case 1045: state = term->reverse_wrap_extended; break;
          case 12: state = term->blink_cur; break;
          case 25: state = term->cursor_on; break;
          case 66:
            if (term->no_applic_k) return 4;
            state = term->app_keypad_keys; break;
          case 47: case 1047: case 1049:
            if (term->no_alt_screen) return 4;
            state = term->alt_which != 0; break;
          case 69: state = term->lrmm; break;
          case 80: state = term->sixel_display_mode; break;
          case 1070: state = term->sixel_private_palette; break;
          case 8452: state = term->sixel_scrolls_right; break;
          case 9: case 1000: case 1001: case 1002: case 1003:
            if (term->no_mouse_rep) return 4;
            state = term->xterm_mouse == (mode == 9 ? -1 : mode == 1000 ? 1 :
                                         mode == 1002 ? 2 : mode == 1001 ? MOUSE_TRACK_HIGHLIGHT : 3); break;
          case 1005: case 1006: case 1015: case 1016:
            state = term->mouse_encoding == (int)mode; break;
          case 1004:
            if (term->no_mouse_rep) return 4;
            state = term->mouse_focus_reporting; break;
          case 1007: state = term->mouse_alternate_scroll; break;
          case 2004:
            if (term->no_bracketed_paste) return 4;
            state = term->bracketed_paste; break;
          case 9001:
            if (!conf_get_bool(term->conf, CONF_nemo_win32_input)) return 4;
            state = term->win32_input; break;
          case 2026:
            if (!term->win->vt->set_synchronized_update) return 0;
            state = term->synchronized_update; break;
          case 2027:
            if (!term->win->vt->grapheme_clusters) return 0;
            state = term->grapheme_mode; break;
          default: return 0;
        }
    }
    return state ? 1 : 2;
}

static void nemo_saved_dec_mode(Terminal *term, unsigned mode, bool save)
{
    /* 1048 operates on DECSC/DECRC's cursor slot, not a Boolean mode. */
    if (mode == 1048) {
        if (!term->no_alt_screen) save_cursor(term, save);
        return;
    }
    switch (mode) {
      case 1001: case 1002: case 1003: mode = 1000; break;
      case 1006: case 1015: case 1016: mode = 1005; break;
      case 1047: case 1049: mode = 47; break;
    }
    static const unsigned modes[] = {
        1, 3, 5, 6, 7, 8, 9, 12, 25, 47, 66, 69, 80,
        1000, 1004, 1005, 1007, 1070, 2004, 2026, 2027, 8452, 9001, 45, 1045, 42
    };
    assert(lenof(modes) == lenof(term->saved_dec_modes));
    size_t i;
    for (i = 0; i < lenof(modes) && modes[i] != mode; i++);
    if (i == lenof(modes)) return;
    unsigned status = term_mode_status(term, mode, true);
    if (!status || status >= 3) return; /* local policy always wins */
    if (save) {
        term->saved_dec_modes[i] = mode == 9 || mode == 1000 ? term->xterm_mouse :
            mode == 1005 ? term->mouse_encoding : status == 1;
    } else {
        int value = term->saved_dec_modes[i];
        if (mode == 9 || mode == 1000) {
            unsigned tracking = value == -1 ? 9 : value == 2 ? 1002 : value == 3 ? 1003 :
                value == MOUSE_TRACK_HIGHLIGHT ? 1001 : 1000;
            toggle_mode(term, tracking, 1, value != 0);
        } else if (mode == 1005) {
            /* A single integer preserves the complete encoding, including
             * 1016. Do not narrow it through an 8-bit Boolean. */
            nemo_highlight_cancel(term, true);
            term->mouse_encoding = value;
            term->raw_mouse_reported_code = -1;
        } else {
            toggle_mode(term, mode, 1, value != 0);
        }
    }
}

/* Split the bounded OSC payload without allocations. */
static char *osc_token(char **next)
{
    char *token = *next;
    if (!token) return NULL;
    char *sep = strchr(token, ';');
    if (sep) { *sep = 0; *next = sep + 1; }
    else *next = NULL;
    return token;
}

static bool osc_colour_number(const char *s, unsigned maximum, unsigned *out)
{
    if (!s || !*s) return false;
    unsigned index = 0;
    for (; *s; s++) {
        if (*s < '0' || *s > '9') return false;
        unsigned digit = *s - '0';
        if (digit > maximum || index > (maximum - digit) / 10) return false;
        index = index * 10 + digit;
    }
    *out = index;
    return true;
}

static void osc_colour_reply(Terminal *term, unsigned command, unsigned index,
                             rgb colour, bool bel)
{
    if (!term->ldisc) return;
    char prefix[32], response[96];
    if (command == 4 || command == 5) sprintf(prefix, "%u;%u", command, index);
    else sprintf(prefix, "%u", command);
    int len = sprintf(response, "\033]%s;rgb:%04x/%04x/%04x%s", prefix,
                      colour.r * 0x0101, colour.g * 0x0101,
                      colour.b * 0x0101, bel ? "\007" : "\033\\");
    nemo_protocol_send(term, response, len);
}

static void osc_colour(Terminal *term, unsigned command, unsigned index,
                       const char *spec, bool bel)
{
    if (!strcmp(spec, "?")) {
        osc_colour_reply(term, command, index, term->palette[index], bel);
    } else {
        NemoColour colour;
        if (!nemo_colour_parse(spec, strlen(spec), &colour)) return;
        term->subpalettes[SUBPAL_SESSION].values[index] =
            (rgb){colour.r, colour.g, colour.b};
        term->subpalettes[SUBPAL_SESSION].present[index] = true;
        palette_rebuild(term); /* later queries in the same OSC see updates */
    }
}

static void osc_selection_colour(Terminal *term, unsigned command,
                                 const char *spec, bool bel)
{
    /* XTerm addresses the opposite highlight component while DECSCNM is set,
     * but labels the reply with the originally requested OSC number. */
    unsigned which = (command == 17 ? 0 : 1) ^ (term->rvideo ? 1 : 0);
    if (!strcmp(spec, "?")) {
        optionalrgb override = term->selection_colours[which].enabled ?
            term->selection_colours[which] : term->selection_defaults[which];
        /* The fallback is the configured inverse palette, not an OSC 10/11
         * override from a running application. Queries allocate nothing. */
        unsigned index = which ? OSC4_COLOUR_bg : OSC4_COLOUR_fg;
        unsigned layer = term->subpalettes[SUBPAL_PLATFORM].present[index] ?
            SUBPAL_PLATFORM : SUBPAL_CONF;
        rgb colour = override.enabled ? (rgb){override.r, override.g, override.b} :
            term->subpalettes[layer].values[index];
        osc_colour_reply(term, command, 0, colour, bel);
    } else {
        NemoColour colour;
        if (!nemo_colour_parse(spec, strlen(spec), &colour)) return;
        nemo_selection_colour_set(term, which,
            (optionalrgb){true, colour.r, colour.g, colour.b});
    }
}

static void osc_attribute_colour(Terminal *term, unsigned command,
                                  unsigned which, const char *spec, bool bel)
{
    if (!strcmp(spec, "?")) {
        osc_colour_reply(term, command, command == 4 ? which+256 : which,
                         nemo_attribute_colour(term, which), bel);
    } else {
        NemoColour c;
        if (nemo_colour_parse(spec, strlen(spec), &c))
            nemo_attribute_colour_set(term, which, (optionalrgb){true,c.r,c.g,c.b});
    }
}

static unsigned osc_dynamic_colour_index(Terminal *term, unsigned which)
{
    static const unsigned dynamic[] = {
        OSC4_COLOUR_fg, OSC4_COLOUR_bg, OSC4_COLOUR_cursor_bg
    };
    assert(which < lenof(dynamic));
    if (which < 2 && term->rvideo) which ^= 1;
    return dynamic[which];
}

static bool osc_colours(Terminal *term, bool bel)
{
    unsigned command = term->esc_args[0];
    if (!(command >= 4 && command <= 6) && !(command >= 104 && command <= 106) &&
        !(command >= 10 && command <= 19) &&
        !(command >= 110 && command <= 119)) return false;
    /* A truncated or binary colour command must never alter the palette. */
    if (term->osc_overflow || memchr(term->osc_string, 0, term->osc_strlen))
        return true;
    char *next = term->osc_string, *token;
    if (command == 4 || command == 5) {
        while ((token = osc_token(&next)) != NULL) {
            unsigned index;
            char *spec = osc_token(&next);
            if (!spec) break;
            if (osc_colour_number(token, command == 5 ? 4 : 260, &index)) {
                if (command == 5 || index >= 256)
                    osc_attribute_colour(term, command,
                        command == 5 ? index : index-256, spec, bel);
                else
                    osc_colour(term, 4, index, spec, bel);
            }
        }
    } else if (command == 6 || command == 106) {
        unsigned char modes = term->attribute_colour_modes;
        while ((token = osc_token(&next)) != NULL) {
            unsigned which, value;
            char *spec = osc_token(&next);
            if (!spec) break;
            /* A separator can represent zero; an absent final value cannot. */
            if (!*spec && !next) break;
            if (!osc_colour_number(*token ? token : "0", UINT_MAX, &which) ||
                !osc_colour_number(*spec ? spec : "0", UINT_MAX, &value)) break;
            if (which > 5) continue;
            if (value) modes |= 1u << which;
            else modes &= ~(1u << which);
        }
        if (modes != term->attribute_colour_modes) {
            term->attribute_colour_modes = modes;
            term_invalidate(term);
        }
    } else if (command == 104 || command == 105) {
        if (!*next) {
            if (command == 104)
                for (unsigned i = 0; i < 256; i++)
                    term->subpalettes[SUBPAL_SESSION].present[i] = false;
            for (unsigned i = 0; i < lenof(term->attribute_colours); i++)
                nemo_attribute_colour_set(term, i, optionalrgb_none);
        } else {
            while ((token = osc_token(&next)) != NULL) {
                unsigned index;
                if (osc_colour_number(token, command == 105 ? 4 : 260, &index)) {
                    if (command == 105 || index >= 256)
                        nemo_attribute_colour_set(term,
                            command == 105 ? index : index-256, optionalrgb_none);
                    else
                        term->subpalettes[SUBPAL_SESSION].present[index] = false;
                }
            }
        }
        palette_rebuild(term);
    } else if (command >= 110) {
        if (command == 117 || command == 119) {
            unsigned which = (command == 117 ? 0 : 1) ^ (term->rvideo ? 1 : 0);
            /* Like XTerm ResetColorsRequest, selection resets ignore payload. */
            nemo_selection_colour_set(term, which, optionalrgb_none);
        } else if (!*next) {
            if (command <= 112) {
                term->subpalettes[SUBPAL_SESSION].present[
                    osc_dynamic_colour_index(term, command-110)] = false;
                palette_rebuild(term);
            }
        }
    } else {
        for (; command <= 19 && (token = osc_token(&next)) != NULL; command++) {
            if (command <= 12)
                osc_colour(term, command, osc_dynamic_colour_index(term, command-10), token, bel);
            else if (command == 17 || command == 19)
                osc_selection_colour(term, command, token, bel);
            /* Preserve parameter positions across unsupported pointer/Tek
             * colours. They must never alias a supported colour slot. */
        }
    }
    return true;
}

/*
 * Process an OSC or similar sequence, with a whole embedded string,
 * like setting the window title or icon name.
 */
static void osc52_reply(Terminal *term, char target, const char *text, size_t length)
{
    term->osc52_query_pending = false;
    if (!term->ldisc || !conf_get_bool(term->conf, CONF_nemo_osc52_read) ||
        length > NEMO_OSC52_TEXT_MAX || !ldisc_send_queue_below(term->ldisc, 512*1024)) return;
    char header[] = "\033]52;c;", buffer[4096];
    header[5] = target == 's' ? 'c' : target;
    nemo_protocol_send(term, header, sizeof(header)-1);
    size_t used = 0;
    while (length) {
        int take = min(length, 3);
        base64_encode_atom((const unsigned char *)text, take, buffer+used);
        used += 4; text += take; length -= take;
        if (used == sizeof(buffer) || !length) {
            nemo_protocol_send(term, buffer, used); used = 0;
        }
    }
    const char *end = term->osc52_query_bel ? "\007" : "\033\\";
    nemo_protocol_send(term, end, strlen(end));
}

static char *osc52_primary(Terminal *term, size_t *length)
{
    if (!term->last_selected_text || term->last_selected_len > NEMO_OSC52_TEXT_MAX+1) return NULL;
    char *text = malloc(NEMO_OSC52_TEXT_MAX+1);
    if (!text) return NULL;
    size_t used = 0;
    for (size_t i = 0; i < term->last_selected_len && term->last_selected_text[i]; i++) {
        uint32_t ch = term->last_selected_text[i];
        if (sizeof(wchar_t) == 2 && IS_HIGH_SURROGATE(ch) && i+1 < term->last_selected_len &&
            IS_LOW_SURROGATE(term->last_selected_text[i+1])) {
            ch = FROM_SURROGATES(ch, term->last_selected_text[i+1]); i++;
        } else if (IS_SURROGATE(ch) || ch > 0x10ffff) ch = 0xfffd;
        unsigned count = ch < 128 ? 1 : ch < 0x800 ? 2 : ch < 0x10000 ? 3 : 4;
        if (count > NEMO_OSC52_TEXT_MAX-used) { free(text); return NULL; }
        if (count == 1) text[used++] = ch;
        else {
            unsigned rest = count-1;
            text[used++] = (rest == 1 ? 0xc0 : rest == 2 ? 0xe0 : 0xf0) | (ch >> (6*rest));
            while (rest) text[used++] = 0x80 | ((ch >> (6*--rest)) & 63);
        }
    }
    text[used] = 0; *length = used;
    return text;
}

static void osc52_query_next(Terminal *term)
{
    while (term->osc52_query_pending) {
        char target = term->osc52_query_targets[term->osc52_query_next++];
        if (!target) {
            osc52_reply(term, term->osc52_query_targets[0], "", 0);
            return;
        }
        if (target == 'c' || target == 's') {
            if (term->win->vt->osc52_read && term->win->vt->osc52_read(term->win, term->osc52_query_id)) return;
        } else if (target == 'p') {
            size_t length;
            char *text = osc52_primary(term, &length);
            if (text) { osc52_reply(term, target, text, length); free(text); return; }
        } else {
            const char *text; size_t length;
            if (nemo_osc52_get(term->osc52, target, &text, &length)) {
                osc52_reply(term, target, text, length); return;
            }
        }
    }
}

void term_osc52_read_result(Terminal *term, uint64_t id, const char *text,
                            size_t length, bool found)
{
    if (!term->osc52_query_pending || id != term->osc52_query_id) return;
    if (!conf_get_bool(term->conf, CONF_nemo_osc52_read)) {
        osc52_cancel_query(term); return;
    }
    if (found && text && length <= NEMO_OSC52_TEXT_MAX && nemo_osc52_utf8(text, length))
        osc52_reply(term, term->osc52_query_targets[term->osc52_query_next-1], text, length);
    else osc52_query_next(term);
}

static void osc52_finish(Terminal *term, bool bel)
{
    NemoOsc52Packet packet = nemo_osc52_finish(term->osc52);
    if (packet.action == NEMO_OSC52_QUERY) {
        if (term->osc52_query_pending || !conf_get_bool(term->conf, CONF_nemo_osc52_read) ||
            !term->ldisc || term->osc52_query_id == UINT64_MAX ||
            !ldisc_send_queue_below(term->ldisc, 512*1024)) return;
        term->osc52_query_id++;
        term->osc52_query_pending = true; term->osc52_query_bel = bel;
        term->osc52_query_next = 0;
        memcpy(term->osc52_query_targets, packet.targets, sizeof(packet.targets));
        osc52_query_next(term);
    } else if ((packet.action == NEMO_OSC52_WRITE || packet.action == NEMO_OSC52_CLEAR) &&
               conf_get_bool(term->conf, CONF_nemo_osc52_write)) {
        bool system = false, primary = false;
        unsigned mask = 0;
        for (const char *p = packet.targets; *p; p++) {
            system |= *p == 'c' || *p == 's'; primary |= *p == 'p';
            mask |= nemo_osc52_cache_mask(*p);
        }
        const char *text = packet.text ? packet.text : "";
        if (system && term->win->vt->osc52_write)
            term->win->vt->osc52_write(term->win, text, packet.length);
        if (primary) {
            wchar_t *wide = packet.length ? decode_utf8_to_wide_string(text) : NULL;
            sfree(term->last_selected_text); sfree(term->last_selected_attr); sfree(term->last_selected_tc);
            term->last_selected_text = wide;
            term->last_selected_attr = NULL; term->last_selected_tc = NULL;
            term->last_selected_len = wide ? wcslen(wide)+1 : 0;
            deselect(term); term_invalidate(term);
        }
        if (mask) nemo_osc52_store(term->osc52, mask, text, packet.length);
    }
    nemo_osc52_cancel(term->osc52);
}

/* Normalize titles before native display and query. UTF-8 decoding is strict:
 * unlike XTerm's legacy decoder we never return overlong encodings, surrogates
 * or values above U+10FFFF. Invalid sequences become '?'. */
static strbuf *nemo_title_normalize(const char *text, size_t len, int from, int to)
{
    strbuf *converted = strbuf_new(), *clean = strbuf_new();
    if (from == CP_UTF8) {
        put_data(converted, text, len);
    } else {
        strbuf *wide = strbuf_new();
        if (put_mb_to_wc(wide, from, text, len)) {
            /* Win32's cached font reverse mapping for CP_UTF8 is a
             * single-byte map, not a UTF-8 encoder. Encode scalars here. */
            const wchar_t *wc = (wchar_t *)wide->s;
            size_t count = wide->len / sizeof(wchar_t);
            for (size_t i = 0; i < count; i++) {
                unsigned c = wc[i];
                if (sizeof(wchar_t) == 2 && c >= 0xd800 && c < 0xdc00 &&
                    i+1 < count && wc[i+1] >= 0xdc00 && wc[i+1] < 0xe000) {
                    c = 0x10000 + ((c-0xd800) << 10) + (wc[i+1]-0xdc00);
                    i++;
                }
                if ((c >= 0xd800 && c < 0xe000) || c > 0x10ffff) c = '?';
                put_utf8_char(converted, c);
            }
        }
        strbuf_free(wide);
    }
    BinarySource src[1];
    BinarySource_BARE_INIT(src, converted->s, converted->len);
    while (get_avail(src)) {
        DecodeUTF8Failure err;
        unsigned c = decode_utf8(src, &err);
        if (!c) break;
        if (err != DUTF8_SUCCESS || (c < 32 && c != '\t' && c != '\n') ||
            (c >= 0x7f && c < 0xa0)) c = '?';
        put_utf8_char(clean, c);
    }
    strbuf_free(converted);
    if (to != CP_UTF8) {
        strbuf *wide = strbuf_new(), *encoded = strbuf_new();
        if (clean->len && put_mb_to_wc(wide, CP_UTF8, clean->s, clean->len))
            put_wc_to_mb(encoded, to, (wchar_t *)wide->s,
                         wide->len / sizeof(wchar_t), "?");
        strbuf_free(wide);
        strbuf_free(clean);
        clean = encoded;
    }
    return clean;
}

static int nemo_title_hex(unsigned char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    return -1;
}

static void nemo_set_title(Terminal *term, unsigned kind, const char *text,
                           size_t len, int codepage)
{
    if (term->no_remote_wintitle) return;
    strbuf *decoded = strbuf_new();
    if (term->title_modes & 1) {
        if (!len || len % 2) goto done;
        for (size_t i = 0; i < len; i += 2) {
            int hi = nemo_title_hex(text[i]), lo = nemo_title_hex(text[i+1]);
            if (hi < 0 || lo < 0) goto done;
            put_byte(decoded, (hi << 4) | lo);
        }
        text = decoded->s;
        len = decoded->len;
        for (size_t i = 0; i < len; i++) {
            if ((unsigned char)text[i] < 32) { len = i; break; }
        }
    }
    if (term->title_modes & 4) codepage = CP_UTF8;
    strbuf *clean = nemo_title_normalize(text, len, codepage, codepage);
    if (kind == 0 || kind == 1) {
        sfree(term->icon_title);
        term->icon_title = dupstr(clean->s);
        term->icontitle_codepage = codepage;
        term->win_icon_title_pending = true;
    }
    if (kind == 0 || kind == 2 || kind == 21) {
        sfree(term->window_title);
        term->window_title = dupstr(clean->s);
        term->wintitle_codepage = codepage;
        term->win_title_pending = true;
    }
    strbuf_free(clean);
    term_schedule_update(term);
  done:
    strbuf_free(decoded);
}

static void nemo_query_title(Terminal *term, bool icon)
{
    if (!term->ldisc || term->remote_qtitle_action == TITLE_NONE) return;
    const char *text = term->remote_qtitle_action == TITLE_REAL ?
        (icon ? term->icon_title : term->window_title) : "";
    int from = icon ? term->icontitle_codepage : term->wintitle_codepage;
    int to = (term->title_modes & 8) || in_utf(term) ?
        CP_UTF8 : term->ucsdata->line_codepage;
    size_t len;
    for (len = 0; len < TITLE_STACK_STRING_MAX && text[len]; len++);
    strbuf *clean = nemo_title_normalize(text, len, from, to);
    strbuf *reply = strbuf_new();
    put_dataz(reply, icon ? "\033]L" : "\033]l");
    if (term->title_modes & 2) {
        static const char hex[] = "0123456789ABCDEF";
        for (size_t i = 0; i < clean->len; i++) {
            unsigned char c = clean->s[i];
            put_byte(reply, hex[c >> 4]); put_byte(reply, hex[c & 15]);
        }
    } else put_data(reply, clean->s, clean->len);
    put_dataz(reply, "\033\\");
    nemo_protocol_send(term, reply->s, reply->len);
    strbuf_free(reply); strbuf_free(clean);
}

static bool nemo_osc_title(Terminal *term)
{
    return term->osc_type == OSCLIKE_OSC &&
        (term->esc_args[0] <= 2 || term->esc_args[0] == 21);
}

static void nemo_query_geometry(Terminal *term, unsigned command)
{
    if (!term->ldisc) return;
    TermWindowGeometry g = {
        .outer_x = term->winpos_x, .outer_y = term->winpos_y,
        .outer_width = term->winpixsize_x, .outer_height = term->winpixsize_y,
        .text_x = term->winpos_x, .text_y = term->winpos_y,
        .text_width = term->cols * term->cell_width,
        .text_height = term->rows * term->cell_height,
        .cell_width = term->cell_width, .cell_height = term->cell_height,
        .minimised = term->minimised,
    };
    if (term->win->vt->get_geometry) {
        TermWindowGeometry current;
        if (term->win->vt->get_geometry(term->win, &current)) g = current;
    }
    bool second = term->esc_nargs > 1 && term->esc_args[1] == 2;
    char reply[96];
    int n = 0;
    switch (command) {
      case 11: n = sprintf(reply, "\033[%dt", g.minimised ? 2 : 1); break;
      case 13:
        /* XTerm's UParmOf encodes signed positions as unsigned 16-bit CSI
         * parameters. A literal minus sign is not a CSI parameter byte and
         * ConPTY rejects that response instead of delivering it to the child. */
        n = sprintf(reply, "\033[3;%u;%ut", (unsigned)(uint16_t)(second ? g.text_x : g.outer_x),
                    (unsigned)(uint16_t)(second ? g.text_y : g.outer_y)); break;
      case 14:
        n = sprintf(reply, "\033[4;%d;%dt", second ? g.outer_height : g.text_height,
                    second ? g.outer_width : g.text_width); break;
      case 15:
        if (g.screen_width > 0 && g.screen_height > 0)
            n = sprintf(reply, "\033[5;%d;%dt", g.screen_height, g.screen_width);
        break;
      case 16:
        if (g.cell_width > 0 && g.cell_height > 0)
            n = sprintf(reply, "\033[6;%d;%dt", g.cell_height, g.cell_width);
        break;
      case 18: n = sprintf(reply, "\033[8;%d;%dt", term->rows, term->cols); break;
      case 19:
        if (g.screen_width > 0 && g.screen_height > 0 &&
            g.cell_width > 0 && g.cell_height > 0)
            n = sprintf(reply, "\033[9;%d;%dt", g.screen_height / g.cell_height,
                        g.screen_width / g.cell_width);
        break;
    }
    if (n) nemo_protocol_send(term, reply, n);
}

static void nemo_title_stack_op(Terminal *term, bool push)
{
    if (term->no_remote_wintitle) return;
    unsigned kind = term->esc_nargs >= 2 ? term->esc_args[1] : 0;
    unsigned which = term->esc_nargs >= 3 ? term->esc_args[2] : 0;
    struct nemo_title_stack *stack = term->title_stack;
    if (!push && (!stack || (!which && !stack->depth))) return;
    /* Count logical pushes while retaining only the ten ring slots. Refuse
     * a push at the counter limit instead of wrapping and losing its order. */
    if (push && !which && stack && stack->depth == UINT_MAX) return;

    struct nemo_saved_title saved = {0};
    if (push) {
        const char *text[] = {term->icon_title, term->window_title};
        int cp[] = {term->icontitle_codepage, term->wintitle_codepage};
        for (unsigned i = 0; i < 2; i++) {
            if (kind && kind != i+1) continue;
            size_t n;
            for (n = 0; n <= TITLE_STACK_STRING_MAX && text[i][n]; n++);
            if (n > TITLE_STACK_STRING_MAX) {
                nemo_saved_title_free(&saved);
                return;             /* reject the whole push, no partial save */
            }
            saved.text[i] = dupstr(text[i]);
            saved.codepage[i] = cp[i];
        }
        if (!stack) {
            stack = snew(struct nemo_title_stack);
            memset(stack, 0, sizeof(*stack));
            term->title_stack = stack;
        }
    }
    unsigned slot;
    if (which) {
        slot = (which-1) % TITLE_STACK_SLOTS;
    } else if (push) {
        slot = stack->next;
        stack->next = (slot+1) % TITLE_STACK_SLOTS;
        stack->depth++;
    } else {
        slot = (stack->next+TITLE_STACK_SLOTS-1) % TITLE_STACK_SLOTS;
        stack->next = slot;
        if (!--stack->depth) stack->next = 0;
    }
    if (push) {
        nemo_saved_title_free(&stack->slot[slot]);
        stack->slot[slot] = saved;
    } else {
        for (unsigned i = 0; i < 2; i++) {
            if (kind && kind != i+1) continue;
            for (unsigned distance = 0; distance < TITLE_STACK_SLOTS; distance++) {
                struct nemo_saved_title *source = &stack->slot[
                    (slot+TITLE_STACK_SLOTS-distance) % TITLE_STACK_SLOTS];
                if (!source->text[i]) continue;
                nemo_set_title(term, i+1, source->text[i],
                               strlen(source->text[i]), source->codepage[i]);
                break;
            }
        }
        if (!which) nemo_saved_title_free(&stack->slot[slot]);
    }
}

static int osc_string_limit(Terminal *term)
{
    if (term->osc_type == OSCLIKE_OSC &&
        (term->esc_args[0] == 7 || term->esc_args[0] == 9 || term->esc_args[0] == 133 ||
         term->esc_args[0] == 633 || term->esc_args[0] == 1337)) return NEMO_CWD_OSC_MAX;
    return term->osc_type == OSCLIKE_OSC && term->esc_args[0] == 8 ?
        NEMO_LINK_OSC_MAX : OSC_STR_MAX;
}

static void do_osc(Terminal *term, bool bel)
{
    switch (term->osc_type) {
      case OSCLIKE_OSC_W:
        while (term->osc_strlen--)
            term->wordness[(unsigned char)term->osc_string[term->osc_strlen]] =
                term->esc_args[0];
        break;
      case OSCLIKE_OSC:
        term->osc_string[term->osc_strlen] = '\0';
        if (osc_colours(term, bel)) break;
        switch (term->esc_args[0]) {
          case 7: case 9: case 133: case 633: case 1337:
            if (!term->osc_overflow) {
                nemo_cwd_update(&term->working_directory, term->esc_args[0],
                                term->osc_string, term->osc_strlen);
                if (!term->alt_which)
                    nemo_shell_marks_update(&term->shell_marks, term->esc_args[0],
                        term->osc_string, term->osc_strlen,
                        term->curs.x + term->wrapnext, term->curs.y);
            }
            break;
          case 8:
            term->curr_hyperlink =
                term->no_remote_hyperlinks || term->osc_overflow ? 0 :
                nemo_hyperlink_parse(&term->hyperlinks, term->osc_string,
                                     term->osc_strlen);
            break;
          case 52:
            if (!term->osc_overflow) osc52_finish(term, bel);
            break;
          case 0:
          case 1:
          case 2:
          case 21:
            if (!term->osc_overflow && term->osc_strlen <= TITLE_WIRE_MAX)
                nemo_set_title(term, term->esc_args[0], term->osc_string,
                               term->osc_strlen, in_utf(term) ?
                               CP_UTF8 : term->ucsdata->line_codepage);
            break;
        }
        break;
      default:
        /* DCS, APC, SOS and PM are recognised as control sequences but
         * ignored. PuTTY implements no support for any of them. */
        break;
    }
}

/*
 * ANSI printing routines.
 */
static void term_print_setup(Terminal *term, char *printer)
{
    bufchain_clear(&term->printer_buf);
    term->print_job = printer_start_job(printer);
}
static void term_print_flush(Terminal *term)
{
    size_t size;
    while ((size = bufchain_size(&term->printer_buf)) > 5) {
        ptrlen data = bufchain_prefix(&term->printer_buf);
        if (data.len > size-5)
            data.len = size-5;
        printer_job_data(term->print_job, data.ptr, data.len);
        bufchain_consume(&term->printer_buf, data.len);
    }
}
static void term_print_finish(Terminal *term)
{
    size_t size;
    char c;

    if (!term->printing && !term->only_printing)
        return;                        /* we need do nothing */

    term_print_flush(term);
    while ((size = bufchain_size(&term->printer_buf)) > 0) {
        ptrlen data = bufchain_prefix(&term->printer_buf);
        c = *(char *)data.ptr;
        if (c == '\033' || c == '\233') {
            bufchain_consume(&term->printer_buf, size);
            break;
        } else {
            printer_job_data(term->print_job, &c, 1);
            bufchain_consume(&term->printer_buf, 1);
        }
    }
    printer_finish_job(term->print_job);
    term->print_job = NULL;
    term->printing = term->only_printing = false;
}

void term_set_grapheme_clustering(Terminal *term, bool enabled)
{
    term->grapheme_mode = enabled && term->win->vt->grapheme_clusters;
    term->grapheme_pending = false;
    nemo_grapheme_reset(&term->grapheme);
    term->grapheme_width = (NemoGraphemeWidth){0};
    term->last_grapheme_len = 0;
}

static unsigned long nemo_grapheme_scalar(Terminal *term, unsigned long c)
{
    switch (c & CSET_MASK) {
      /* UTF-8 ASCII is tagged for legacy rendering; its font lookup table
       * can contain direct-font markers, not Unicode scalar values. */
      case CSET_ASCII: return c & 0xff;
      case CSET_LINEDRW: return term->ucsdata->unitab_xterm[c & 0xff];
      case CSET_SCOACS: return term->ucsdata->unitab_scoacs[c & 0xff];
      default: return c;
    }
}

/* Default legacy checksum for cells whose source code and charset did not
 * change this value. Exceptional mappings retain a compact per-cell override. */
static uint32_t nemo_checksum_legacy(unsigned long ch)
{
    static const uint32_t graphics[] = {
        0x10000, 0x14, 0x78, 0x0a, 0x0d, 0x0e, 0x0b, 0xb0,
        0xb1, 0x15, 0x0c, 0x16, 0x17, 0x18, 0x19, 0x1a,
        0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x80, 0x81, 0x82,
        0x83, 0x84, 0x85, 0x86, 0xc6, 0x87, 0xa3, 0xb7,
    };
    unsigned long cset = ch & CSET_MASK;
    if (ch == UCSWIDE) return ' ';
    if (cset == CSET_ASCII || cset == CSET_LINEDRW || cset == CSET_GBCHR)
        ch &= 0xff;
    if (ch < 32 || ch > 255 || ch == 160) return 27;
    if (ch == 127 || ch == 255) return 0;
    ch &= 127;
    if (cset == CSET_LINEDRW && ch >= 0x5f && ch <= 0x7e)
        return graphics[ch-0x5f];
    return (uint32_t)ch;
}

static uint32_t nemo_checksum_unicode(unsigned long ch)
{
    /* Protocol values, not unitab_xterm: the latter may contain font indices
     * and varies with the selected font/platform. Match DEC graphic codes
     * as interpreted by xterm (including its zero for the reserved '_'). */
    static const uint16_t graphics[] = {
        0, 0x25c6, 0x2592, 0x2409, 0x240c, 0x240d, 0x240a, 0x00b0,
        0x00b1, 0x2424, 0x240b, 0x2518, 0x2510, 0x250c, 0x2514, 0x253c,
        0x23ba, 0x23bb, 0x2500, 0x23bc, 0x23bd, 0x251c, 0x2524, 0x2534,
        0x252c, 0x2502, 0x2264, 0x2265, 0x03c0, 0x2260, 0x00a3, 0x00b7,
    };
    unsigned long cset = ch & CSET_MASK;
    if (cset == CSET_ASCII || cset == CSET_LINEDRW || cset == CSET_GBCHR) {
        ch &= 0xff;
        if (cset == CSET_LINEDRW && ch >= 0x5f && ch <= 0x7e)
            return graphics[ch-0x5f];
    }
    return (uint32_t)ch;
}

static void nemo_checksum_rectangle(Terminal *term)
{
    if (!term->ldisc || !conf_get_bool(term->conf, CONF_nemo_allow_checksum) ||
        (!term->esc_arg_present && term->esc_nargs == 1)) return;
    struct NemoRect r;
    unsigned mode = term->checksum_flags;
    uint32_t total = 0;
    bool first = true;
    /* xterm interprets the short one/two-parameter form as coordinates too.
     * The full form skips Pi/Pg; this terminal has one addressable page. */
    if (nemo_rectangle(term, term->esc_nargs > 2 ? 2 : 0, 4, &r)) {
        for (int row = r.top; row < r.bottom; row++) {
            const termline *line = index234(term->screen, row);
            assert(line);
            for (int col = r.left; col < r.right; col++) {
                const termchar *cell = col < line->cols ? &line->chars[col] :
                    &term->basic_erase_char;
                unsigned long attr = cell->attr;
                uint64_t decoration = cell->truecolour.decoration;
                bool drawn = !(decoration & CELL_UNDRAWN);
                uint32_t value;
                if (!drawn) {
                    if (!(mode & (4 | 8))) continue;
                    value = ' ';
                } else if (!(mode & 16)) {
                    value = decoration & CELL_CHECKSUM_VALID ?
                        (decoration & CELL_CHECKSUM_VALUE) >> CELL_CHECKSUM_SHIFT :
                        nemo_checksum_legacy(cell->chr);
                } else {
                    value = decoration & CELL_CHECKSUM_BYTE_POUND ? 30 :
                        nemo_checksum_unicode(cell->chr);
                    if (cell->chr == UCSWIDE || (value >= 0xfff0 && value <= 0xffff))
                        continue;
                }
                if (!(mode & 2)) {
                    if (decoration & CELL_PROTECTED) value += 4;
                    if (attr & ATTR_CONCEAL) value += 8;
                    if (attr & ATTR_UNDER) value += 16;
                    if (attr & ATTR_REVERSE) value += 32;
                    if (attr & ATTR_BLINK) value += 64;
                    if (attr & ATTR_BOLD) value += 128;
                }
                /* xterm counts explicit blanks and styled erased cells. Its
                 * bit 3 includes undrawn cells, despite the ctlseqs wording.
                 * Bits 2/4 also gate its legacy combining-mark summation. */
                bool styled = (attr & ~(ATTR_WIDE | ATTR_NARROW | DATTR_MASK)) != ATTR_DEFAULT ||
                    cell->truecolour.fg.enabled || cell->truecolour.bg.enabled ||
                    (decoration & ~(CELL_UNDRAWN | CELL_CHECKSUM_MASK));
                if ((mode & 4) || first || value != ' ' || drawn || styled)
                    total += value;
                if ((mode & (4 | 16)) == 4 && col < line->cols) {
                    for (const termchar *cc = cell; cc->cc_next;) {
                        cc += cc->cc_next;
                        total += nemo_checksum_unicode(cc->chr);
                    }
                }
                first = false;
            }
            first = false;
        }
    }
    if (!(mode & 1)) total = 0u - total;
    char reply[32];
    int length = sprintf(reply, "\033P%u!~%04X\033\\",
                         min(term->esc_args[0], 65535u), (unsigned)(total & 0xffff));
    nemo_protocol_send(term, reply, length);
}

static void nemo_grapheme_remember(Terminal *term, pos anchor, unsigned cells,
                                  NemoGraphemeState state, NemoGraphemeWidth width)
{
    term->grapheme = state;
    term->grapheme_width = width;
    term->grapheme_anchor = anchor;
    term->grapheme_cursor = term->curs;
    term->grapheme_wrapnext = term->wrapnext;
    term->grapheme_cells = cells;
    term->grapheme_pending = true;
    termchar *ch = &scrlineptr(anchor.y)->chars[anchor.x];
    term->last_grapheme_len = 0;
    do {
        assert(term->last_grapheme_len < lenof(term->last_grapheme));
        term->last_grapheme[term->last_grapheme_len++] = ch->chr;
        if (!ch->cc_next) break;
        ch += ch->cc_next;
    } while (true);
}

/* Attach any cluster member, not just zero-width scalars, to the existing
 * bounded cc chain. Late VS16 widening is a grid mutation, not just drawing. */
static void nemo_grapheme_append(Terminal *term, unsigned long scalar,
                                NemoGraphemeState state, NemoGraphemeWidth width)
{
    pos anchor = term->grapheme_anchor;
    unsigned cells = term->grapheme_cells;
    termline *line = scrlineptr(anchor.y);
    int right = nemo_write_right(term, line);
    check_selection(term, anchor, (pos){anchor.y, anchor.x+(int)cells});
    if (width.cells > cells) {
        if (anchor.x == right) {
            if (!term->wrap || right-term->marg_l+1 < 2) {
                clear_cc(line, anchor.x);
                line->chars[anchor.x].chr = 0xfffd;
                /* Keep the one available cell; subsequent extenders remain
                 * part of the same bounded replacement cluster. */
                goto finished;
            }
            termline *saved = newtermline(term, 2, false);
            copy_termchar(saved, 0, &line->chars[anchor.x]);
            nemo_images_erase(term, anchor, (pos){anchor.y, anchor.x+1});
            copy_termchar(line, anchor.x, &term->erase_char);
            if (!term->marg_l && term->marg_r == term->cols-1)
                line->lattr |= LATTR_WRAPPED | LATTR_WRAPPED2;
            else line->lattr |= LATTR_CURSOR_WRAPPED;
            nemo_linefeed(term);
            term->curs.x = term->marg_l;
            term->wrapnext = false;
            anchor = term->curs;
            line = scrlineptr(anchor.y);
            check_trust_status(term, line);
            right = nemo_write_right(term, line);
            unsigned available = min(2, right-anchor.x+1);
            check_boundary(term, anchor.x, anchor.y);
            check_boundary(term, anchor.x+available, anchor.y);
            if (term->insert) insch(term, available);
            copy_termchar(line, anchor.x, &saved->chars[0]);
            freetermline(saved);
            if (available < 2) {
                clear_cc(line, anchor.x);
                line->chars[anchor.x].chr = 0xfffd;
                cells = 1;
                term->curs.x = anchor.x;
                term->wrapnext = term->wrap;
                goto finished;
            }
        } else {
            if (term->insert) insch(term, 1);
            check_boundary(term, anchor.x+2, anchor.y);
        }
        check_selection(term, anchor, (pos){anchor.y, anchor.x+2});
        clear_cc(line, anchor.x+1);
        line->chars[anchor.x+1] = line->chars[anchor.x];
        line->chars[anchor.x+1].chr = UCSWIDE;
        line->chars[anchor.x+1].cc_next = 0;
        cells = 2;
        term->curs.x = min(anchor.x+2, right);
        term->wrapnext = term->wrap && anchor.x+2 > right;
    }
    add_cc(line, anchor.x, scalar);
  finished:
    nemo_images_erase(term, anchor, (pos){anchor.y, anchor.x+(int)cells});
    nemo_grapheme_remember(term, anchor, cells, state, width);
    seen_disp_event(term);
}

static void term_display_graphic_char(Terminal *term, unsigned long c, uint64_t checksum)
{
    if (((c & CSET_MASK) == CSET_ASCII ||
         (c & CSET_MASK) == 0) && term->logctx)
        logtraffic(term->logctx, (unsigned char) c, LGTYP_ASCII);
    termline *cline = scrlineptr(term->curs.y);
    int width = 0;
    if (DIRECT_CHAR(c))
        width = 1;
    if (!width)
        width = term_char_width(term, c);

    bool cluster = term->grapheme_mode && in_utf(term) && !term->vt52_mode;
    NemoGraphemeState cluster_state = {0};
    NemoGraphemeWidth cluster_width = {0};
    pos cluster_anchor = term->curs;
    if (cluster) {
        unsigned long scalar = nemo_grapheme_scalar(term, c);
        bool pending = term->grapheme_pending &&
            term->curs.x == term->grapheme_cursor.x &&
            term->curs.y == term->grapheme_cursor.y &&
            term->wrapnext == term->grapheme_wrapnext;
        if (pending) cluster_state = term->grapheme;
        bool boundary = nemo_grapheme_feed(&cluster_state, scalar);
        if (!boundary) cluster_width = term->grapheme_width;
        width = nemo_grapheme_cell_width(&cluster_width, scalar, width);
        if (!boundary) {
            nemo_grapheme_append(term, scalar, cluster_state, cluster_width);
            return;
        }
    } else {
        term->grapheme_pending = false;
    }

    if (term->wrapnext && term->wrap && width > 0) {
        if (!term->marg_l && term->marg_r == term->cols-1)
            cline->lattr |= LATTR_WRAPPED;
        else cline->lattr |= LATTR_CURSOR_WRAPPED;
        nemo_linefeed(term);
        term->curs.x = term->marg_l;
        term->wrapnext = false;
        cline = scrlineptr(term->curs.y);
    }
    /* Absolute positioning may address the hidden half of a double-size
     * row. Like xterm, ignore graphic output there until the cursor returns
     * to its visible cells; never write and then clamp it backwards. */
    if (width > 0 && term->curs.x >= nemo_line_columns(term, cline)) return;
    if (term->insert && width > 0)
        insch(term, width);
    if (term->selstate != NO_SELECTION) {
        pos cursplus = term->curs;
        incpos(cursplus);
        check_selection(term, term->curs, cursplus);
    }
    check_trust_status(term, cline);

    int linecols = nemo_write_right(term, cline)+1;

    /*
     * Before we switch on the character width, do a preliminary check for
     * cases where we might have no room at all to display a double-width
     * character. Our fallback is to substitute REPLACEMENT CHARACTER,
     * which is single-width, and it's easiest to do that _before_ having
     * to 'goto' from one switch case to another.
     */
    if (width == 2 && term->curs.x >= linecols-1) {
        /*
         * If we're in wrapping mode and the terminal is at least 2 cells
         * wide, it's OK, we have a fallback. But otherwise, substitute.
         */
        if (linecols < 2 || !term->wrap ||
            (cluster && linecols-term->marg_l < 2)) {
            width = 1;
            c = 0xFFFD;
        }
    }

    switch (width) {
      case 2:
        /*
         * If we're about to display a double-width character starting in
         * the rightmost column (and we're in wrapping mode - the other
         * case was disposed of above), then we do something special
         * instead. We must print a space in the last column of the screen,
         * then wrap; and we also set LATTR_WRAPPED2 which instructs
         * subsequent cut-and-pasting not only to splice this line to the
         * one after it, but to ignore the space in the last character
         * position as well. (Because what was actually output to the
         * terminal was presumably just a sequence of CJK characters, and
         * we don't want a space to be pasted in the middle of those just
         * because they had the misfortune to start in the wrong parity
         * column. xterm concurs.)
         */
        check_boundary(term, term->curs.x, term->curs.y);
        if (term->curs.x >= linecols-1) {
            assert(term->wrap);    /* we handled the non-wrapping case above */
            copy_termchar(cline, term->curs.x,
                          &term->erase_char);
            if (!term->marg_l && term->marg_r == term->cols-1)
                cline->lattr |= LATTR_WRAPPED | LATTR_WRAPPED2;
            else cline->lattr |= LATTR_CURSOR_WRAPPED;
            nemo_images_erase(term, term->curs, (pos){term->curs.y,term->curs.x+1});
            nemo_linefeed(term);
            term->curs.x = term->marg_l;
            cline = scrlineptr(term->curs.y);
            check_trust_status(term, cline);
            linecols = nemo_write_right(term, cline)+1;
            /* The destination can be a narrower double-size row. */
            if (linecols-term->curs.x < 2) {
                width = 1;
                c = 0xfffd;
                goto write_single_cell;
            }
            /* Now we must check_boundary again, of course. */
            check_boundary(term, term->curs.x, term->curs.y);
        }
        check_boundary(term, term->curs.x+2, term->curs.y);

        cluster_anchor = term->curs;

        nemo_images_erase(term, term->curs,
                          (pos){term->curs.y, term->curs.x + 2});
        /* FULL-TERMCHAR */
        clear_cc(cline, term->curs.x);
        cline->chars[term->curs.x].chr = c;
        cline->chars[term->curs.x].attr = term->curr_attr;
        cline->chars[term->curs.x].truecolour =
            term->curr_truecolour;
        cline->chars[term->curs.x].truecolour.decoration |= checksum;
        cline->chars[term->curs.x].hyperlink = term->curr_hyperlink;

        term->curs.x++;

        /* FULL-TERMCHAR */
        clear_cc(cline, term->curs.x);
        cline->chars[term->curs.x].chr = UCSWIDE;
        cline->chars[term->curs.x].attr = term->curr_attr;
        cline->chars[term->curs.x].truecolour =
            term->curr_truecolour;
        cline->chars[term->curs.x].hyperlink = term->curr_hyperlink;

        break;
      case 1:
      write_single_cell:
        cluster_anchor = term->curs;
        check_boundary(term, term->curs.x, term->curs.y);
        check_boundary(term, term->curs.x+1, term->curs.y);

        nemo_images_erase(term, term->curs,
                          (pos){term->curs.y, term->curs.x + 1});
        /* FULL-TERMCHAR */
        clear_cc(cline, term->curs.x);
        cline->chars[term->curs.x].chr = c;
        cline->chars[term->curs.x].attr = term->curr_attr;
        cline->chars[term->curs.x].truecolour =
            term->curr_truecolour;
        cline->chars[term->curs.x].truecolour.decoration |= checksum;
        cline->chars[term->curs.x].hyperlink = term->curr_hyperlink;

        break;
      case 0:
        if (term->curs.x > 0 || term->wrapnext) {
            int x = term->curs.x - 1;

            /* If we're in wrapnext state, the character to combine
             * with is _here_, not to our left. */
            if (term->wrapnext)
                x++;

            /*
             * If the previous character is UCSWIDE, back up another
             * one.
             */
            if (cline->chars[x].chr == UCSWIDE) {
                assert(x > 0);
                x--;
            }

            add_cc(cline, x, c);
            seen_disp_event(term);
        }
        return;
      default:
        return;
    }
    term->curs.x++;
    if (term->curs.x >= linecols) {
        term->curs.x = linecols - 1;

        if (term->wrap) {
            if (!term->vt52_mode) {
                /* Set the wrapnext flag, so that the next character
                 * wraps, but this one doesn't. */
                term->wrapnext = true;
            } else {
                /* VT52 mode expects simpler handling, and we just
                 * wrap straight away. */
                cline->lattr |= LATTR_WRAPPED;
                if (term->curs.y == term->marg_b)
                    scroll(term, term->marg_t, term->marg_b, 1, true);
                else if (term->curs.y < term->rows - 1)
                    term->curs.y++;
                term->curs.x = 0;
                term->wrapnext = false;
            }
        }
    }
    if (cluster)
        nemo_grapheme_remember(term, cluster_anchor, width, cluster_state, cluster_width);
    seen_disp_event(term);
}

static strbuf *term_input_data_from_unicode(
    Terminal *term, const wchar_t *widebuf, size_t len, bool paste)
{
    strbuf *buf = strbuf_new();

    if (paste && term->nrc_mode) {
        const NemoCharset *sets[2];
        int banks[2] = {term->cset, term->cset_gr};
        for (unsigned n=0; n<2; n++) {
            int attr=term->cset_attr[banks[n]];
            sets[n]=nemo_charset_descriptor(attr);
            if (!sets[n]) sets[n]=nemo_charset_designate(1, nemo_charset_level(term), true,
                attr==CSET_GBCHR ? "A" : attr==CSET_LINEDRW ? "0" : "B", 1);
            sets[n]=nemo_charset_resolve(sets[n],term->upss_id,nemo_charset_level(term));
        }
        bool unicode_nrc = nemo_charset_base_utf8(term);
        for (size_t i=0; i<len; i++) {
            uint32_t ch=widebuf[i];
            if (IS_SURROGATE(ch)) {
#ifdef PLATFORM_IS_UTF16
                if (i+1<len && IS_SURROGATE_PAIR(ch,widebuf[i+1])) {
                    ch=FROM_SURROGATES(ch,widebuf[i+1]); i++;
                } else
#endif
                    ch='.';
            }
            unsigned gl=nemo_charset_input(sets[0],ch,unicode_nrc);
            unsigned out=gl!=ch ? gl : nemo_charset_input(sets[1],ch,unicode_nrc);
            put_byte(buf,out);
        }
    } else if (in_utf(term)) {
        /*
         * Translate input wide characters into UTF-8 to go in the
         * terminal's input data queue.
         */
        for (size_t i = 0; i < len; i++) {
            unsigned long ch = widebuf[i];

            if (IS_SURROGATE(ch)) {
#ifdef PLATFORM_IS_UTF16
                if (i+1 < len) {
                    unsigned long ch2 = widebuf[i+1];
                    if (IS_SURROGATE_PAIR(ch, ch2)) {
                        ch = FROM_SURROGATES(ch, ch2);
                        i++;
                    }
                } else
#endif
                {
                    /* Unrecognised UTF-16 sequence */
                    ch = '.';
                }
            }

            put_utf8_char(buf, ch);
        }
    } else {
        /*
         * Call to the character-set subsystem to translate into
         * whatever charset the terminal is currently configured in.
         *
         * Since the terminal doesn't currently support any multibyte
         * character set other than UTF-8, we can assume here that
         * there will be at most one output byte per input wchar_t.
         * (But also we must allow space for the trailing NUL that
         * wc_to_mb will write.)
         */
        put_wc_to_mb(buf, term->ucsdata->line_codepage, widebuf, len, "");
        /* In byte-output mode XTerm filters C1 bytes in selection data after
         * locale conversion. This is separate from Unicode keyboard input. */
        if (paste && !conf_get_bool(term->conf, CONF_paste_controls)) {
            size_t used=0;
            for (size_t i=0; i<buf->len; i++) {
                unsigned char byte=buf->s[i];
                if (byte<0x80 || byte>=0xa0) buf->s[used++]=byte;
            }
            strbuf_shrink_to(buf,used);
        }
    }

    return buf;
}

static strbuf *term_input_data_from_charset(
    Terminal *term, int codepage, const char *str, size_t len)
{
    if (codepage < 0) {
        strbuf *buf = strbuf_new();
        put_data(buf, str, len);
        return buf;
    } else {
        strbuf *wide = strbuf_new();
        put_mb_to_wc(wide, codepage, str, len);
        strbuf *buf = term_input_data_from_unicode(
            term, (const wchar_t *)wide->s, wide->len / sizeof(wchar_t), false);
        strbuf_free(wide);
        return buf;
    }

}

static inline void term_bracketed_paste_start(Terminal *term)
{
    ptrlen seq = PTRLEN_LITERAL("\033[200~");
    if (term->ldisc)
        nemo_protocol_send(term, seq.ptr, seq.len);
    term->bracketed_paste_active = true;
}

static inline void term_bracketed_paste_stop(Terminal *term)
{
    if (!term->bracketed_paste_active)
        return;

    ptrlen seq = PTRLEN_LITERAL("\033[201~");
    if (term->ldisc)
        nemo_protocol_send(term, seq.ptr, seq.len);
    term->bracketed_paste_active = false;
}

static inline void term_keyinput_internal(
    Terminal *term, const void *buf, int len, bool interactive)
{
    if (term->srm_echo) {
        /*
         * Implement the terminal-level local echo behaviour that
         * ECMA-48 specifies when terminal mode 12 is configured off
         * (ESC[12l). In this mode, data input to the terminal via the
         * keyboard is also added to the output buffer. But this
         * doesn't apply to escape sequences generated as session
         * input _within_ the terminal, e.g. in response to terminal
         * query sequences, or the bracketing sequences of bracketed
         * paste mode. Those will be sent directly via
         * ldisc_send(term->ldisc, ...) and won't go through this
         * function.
         */

        /* Mimic the special case of negative length in ldisc_send */
        int true_len = len >= 0 ? len : strlen(buf);

        bufchain_add(&term->inbuf, buf, true_len);
        term_added_data(term, false);
    }
    if (interactive)
        term_bracketed_paste_stop(term);
    if (term->ldisc)
        ldisc_send(term->ldisc, buf, len, interactive);
    term_seen_key_event(term);
}

unsigned long term_translate(
    Terminal *term, struct term_utf8_decode *utf8, unsigned char c)
{
    int charset = term->cset_attr[term->cset_ss ? term->cset_ss : term->cset];
    if (in_utf(term)) {
        switch (utf8->state) {
          case 0:
            if (c < 0x80) {
                /* UTF-8 must be stateless so we ignore iso2022. */
                if (term->ucsdata->unitab_ctrl[c] != 0xFF)  {
                    return term->ucsdata->unitab_ctrl[c];
                } else if ((term->utf8linedraw) &&
                           (charset == CSET_LINEDRW)) {
                    /* Linedraw characters are explicitly enabled */
                    return c | CSET_LINEDRW;
                } else {
                    return c | CSET_ASCII;
                }
            } else if ((c & 0xe0) == 0xc0) {
                utf8->size = utf8->state = 1;
                utf8->chr = (c & 0x1f);
            } else if ((c & 0xf0) == 0xe0) {
                utf8->size = utf8->state = 2;
                utf8->chr = (c & 0x0f);
            } else if ((c & 0xf8) == 0xf0) {
                utf8->size = utf8->state = 3;
                utf8->chr = (c & 0x07);
            } else if ((c & 0xfc) == 0xf8) {
                utf8->size = utf8->state = 4;
                utf8->chr = (c & 0x03);
            } else if ((c & 0xfe) == 0xfc) {
                utf8->size = utf8->state = 5;
                utf8->chr = (c & 0x01);
            } else {
                return UCSINVALID;
            }
            return UCSINCOMPLETE;
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
            if ((c & 0xC0) != 0x80) {
                utf8->state = 0;
                return UCSTRUNCATED;   /* caller will then give us the
                                        * same byte again */
            }
            utf8->chr = (utf8->chr << 6) | (c & 0x3f);
            if (--utf8->state)
                return UCSINCOMPLETE;

            unsigned long t = utf8->chr;

            /* Is somebody trying to be evil! */
            if (t < 0x80 ||
                (t < 0x800 && utf8->size >= 2) ||
                (t < 0x10000 && utf8->size >= 3) ||
                (t < 0x200000 && utf8->size >= 4) ||
                (t < 0x4000000 && utf8->size >= 5))
                return UCSINVALID;

            /* Unicode line separator and paragraph separator are CR-LF */
            if (t == 0x2028 || t == 0x2029)
                return 0x85;

            /* High controls are probably a Baaad idea too. */
            if (t < 0xA0)
                return 0xFFFD;

            /* The UTF-16 surrogates are not nice either. */
            /*       The standard give the option of decoding these:
             *       I don't want to! */
            if (t >= 0xD800 && t < 0xE000)
                return UCSINVALID;

            /* ISO 10646 characters now limited to UTF-16 range. */
            if (t > 0x10FFFF)
                return UCSINVALID;

            /* U+FEFF is best seen as a null. */
            if (t == 0xFEFF)
                return UCSINCOMPLETE;
            /* But U+FFFE is an error. */
            if (t == 0xFFFE || t == 0xFFFF)
                return UCSINVALID;

            return t;
        }
    } else if (term->sco_acs &&
               (c!='\033' && c!='\012' && c!='\015' && c!='\b')) {
        /* Are we in the nasty ACS mode? Note: no sco in utf mode. */
        if (term->sco_acs == 2)
            c |= 0x80;

        return c | CSET_SCOACS;
    } else {
        if (c >= 0xa0) charset = term->cset_attr[term->cset_gr];
        if (charset < 0 && c >= 0x20 && (c < 0x80 || c >= 0xa0))
            return nemo_charset_graphic(term, charset, c);
        if (c == 0x7f) return UCSINCOMPLETE;
        if ((charset == CSET_GBCHR || charset == CSET_LINEDRW) &&
            c >= 0x20 && (c < 0x80 || c >= 0xa0)) {
            const NemoCharset *cs = nemo_charset_designate(1, nemo_charset_level(term),
                term->nrc_mode, charset == CSET_GBCHR ? "A" : "0", 1);
            uint32_t value = nemo_charset_map(cs, c, nemo_charset_level(term), term->nrc_mode);
            if (value == NEMO_CHARSET_NOCHAR) return UCSINCOMPLETE;
            /* Preserve existing line-graphics rendering and DEC checksums. */
            unsigned seven = c & 0x7f;
            if (charset == CSET_LINEDRW &&
                ((seven >= 0x60 && seven <= 0x7e) || c == 0x5f))
                return seven | CSET_LINEDRW;
            return value;
        }
        /* GR remains byte-codepage based for the default set; explicitly
         * designated line/UK sets map the corresponding right-half positions. */
        if (c >= 0xa0 && term->cset_attr[term->cset_gr] != CSET_ASCII) {
            charset = term->cset_attr[term->cset_gr];
            c &= 0x7f;
        }
        switch (charset) {
            /*
             * Linedraw characters are different from 'ESC ( B'
             * only for a small range. For ones outside that
             * range, make sure we use the same font as well as
             * the same encoding.
             */
          case CSET_LINEDRW:
            if (term->ucsdata->unitab_ctrl[c] != 0xFF)
                return term->ucsdata->unitab_ctrl[c];
            else
                return c | CSET_LINEDRW;
            break;

          case CSET_GBCHR:
            /* If UK-ASCII, make the '#' a LineDraw Pound */
            if (c == '#')
                return '}' | CSET_LINEDRW;
            /* fall through */

          case CSET_ASCII:
            if (term->ucsdata->unitab_ctrl[c] != 0xFF)
                return term->ucsdata->unitab_ctrl[c];
            else
                return c | CSET_ASCII;
            break;
          case CSET_SCOACS:
            if (c >= ' ')
                return c | CSET_SCOACS;
            break;
        }
    }
    return c;
}

/*
 * Remove everything currently in `inbuf' and stick it up on the
 * in-memory display. There's a big state machine in here to
 * process escape sequences...
 */
static void nemo_underline_style(Terminal *term, unsigned style)
{
    if (style > 5) return;
    if (style) term->curr_attr |= ATTR_UNDER;
    else term->curr_attr &= ~ATTR_UNDER;
    term->curr_truecolour.decoration =
        (term->curr_truecolour.decoration & ~(UNDER_STYLE_MASK | UNDER_DOUBLE_LEGACY)) |
        (style << UNDER_STYLE_SHIFT);
}

/* Consume one extended colour group. The colon form is self-contained;
 * the legacy semicolon form consumes its defined number of following fields,
 * even on error, so incomplete RGB does not turn into dim/italic/blink. */
static void nemo_sgr_colour(Terminal *term, int *argi)
{
    int i = *argi;
    unsigned command = term->esc_args[i], mode, count, present;
    const unsigned *values;
    bool colon = false;
    if (term->esc_sub_count[i]) {
        if (!(term->esc_sub_present[i] & 1)) return;
        mode = term->esc_subargs[i][0];
        values = term->esc_subargs[i] + 1;
        count = term->esc_sub_count[i] - 1;
        present = term->esc_sub_present[i] >> 1;
        colon = true;
    } else {
        if (++i >= term->esc_nargs) return;
        *argi = i;
        mode = term->esc_args[i];
        if (term->esc_sub_count[i]) {
            values = term->esc_subargs[i];
            count = term->esc_sub_count[i];
            present = term->esc_sub_present[i];
            colon = true;
        } else {
            unsigned need = mode == 2 ? 3 : mode == 5 ? 1 : 0;
            count = min(need, (unsigned)(term->esc_nargs-i-1));
            values = term->esc_args + i + 1;
            present = (1u << count)-1;
            *argi += count;
            for (unsigned j = 1; j <= count; j++)
                if (term->esc_sub_count[i+j]) return;
        }
    }
    if (mode == 2 && colon && count == 4) {
        /* ISO colour-space identifier is ignored, as in xterm. */
        values++; count--; present >>= 1;
    }
    unsigned need = mode == 2 ? 3 : mode == 5 ? 1 : 0;
    if (!need || count != need || (present & ((1u << need)-1)) != (1u << need)-1)
        return;
    for (unsigned j = 0; j < count; j++)
        if (values[j] > 255) return;

    if (command == 58) {
        uint32_t colour = mode == 5 ? UNDER_INDEXED | values[0] :
            UNDER_RGB | (values[0] << 16) | (values[1] << 8) | values[2];
        term->curr_truecolour.decoration =
            (term->curr_truecolour.decoration & ~UNDER_COLOUR_MASK) | colour;
    } else {
        optionalrgb *rgb = command == 38 ? &term->curr_truecolour.fg :
            &term->curr_truecolour.bg;
        if (mode == 2) {
            rgb->enabled = true;
            rgb->r = values[0]; rgb->g = values[1]; rgb->b = values[2];
        } else {
            unsigned mask = command == 38 ? ATTR_FGMASK : ATTR_BGMASK;
            unsigned shift = command == 38 ? ATTR_FGSHIFT : ATTR_BGSHIFT;
            *rgb = optionalrgb_none;
            term->curr_attr = (term->curr_attr & ~mask) | (values[0] << shift);
        }
    }
}

static void term_out(Terminal *term, bool called_from_term_data)
{
    unsigned long c;
    int unget;
    const unsigned char *chars;
    size_t nchars_got = 0, nchars_used = 0;

    /*
     * During drag-selects, we do not process terminal input, because
     * the user will want the screen to hold still to be selected.
     */
    if (term->selstate == DRAGGING)
        return;

    unget = -1;

    chars = NULL;                      /* placate compiler warnings */
    while (nchars_got < nchars_used ||
           unget != -1 ||
           bufchain_size(&term->inbuf) > 0) {
        pos cursor_before = term->curs;
        if (unget != -1) {
            /*
             * Handle a character we left in 'unget' the last time
             * round this loop. This happens if a UTF-8 sequence is
             * aborted early, by containing fewer continuation bytes
             * than its introducer expected: the non-continuation byte
             * that interrupted the sequence must now be processed
             * as a fresh piece of input in its own right.
             */
            c = unget;
            unget = -1;
        } else {
            /*
             * If we're waiting for a terminal resize triggered by an
             * escape sequence, we defer processing the terminal
             * output until we receive acknowledgment from the front
             * end that the resize has happened, so that further
             * output will be processed in the context of the new
             * size.
             *
             * This test goes inside the main while-loop, so that we
             * exit early if we encounter a resize escape sequence
             * part way through term->inbuf.
             *
             * It's also in the branch of this if statement that
             * doesn't deal with a character left in 'unget' by the
             * previous loop iteration, because if we break out of
             * this loop with an ungot character still pending, we'll
             * lose it. (And in any case, if the previous thing that
             * happened was a truncated UTF-8 sequence, then it won't
             * have scheduled a pending resize.)
             */
            if (term->win_resize_pending != WIN_RESIZE_NO)
                break;

            if (nchars_got == nchars_used) {
                /* Delete the previous chunk from the bufchain */
                bufchain_consume(&term->inbuf, nchars_used);
                nchars_used = 0;

                if (bufchain_size(&term->inbuf) == 0)
                    break;             /* no more data */

                ptrlen data = bufchain_prefix(&term->inbuf);
                chars = data.ptr;
                nchars_got = data.len;
                assert(chars != NULL);
                assert(nchars_used < nchars_got);
            }
            c = chars[nchars_used++];

            /*
             * Optionally log the session traffic to a file. Useful for
             * debugging and possibly also useful for actual logging.
             */
            if (term->logtype == LGTYP_DEBUG && term->logctx)
                logtraffic(term->logctx, (unsigned char) c, LGTYP_DEBUG);
        }

        /* Note only VT220+ are 8-bit VT102 is seven bit, it shouldn't even
         * be able to display 8-bit characters, but I'll let that go 'cause
         * of i18n.
         */

        /*
         * If we're printing, add the character to the printer
         * buffer.
         */
        if (term->printing) {
            bufchain_add(&term->printer_buf, &c, 1);

            /*
             * If we're in print-only mode, we use a much simpler
             * state machine designed only to recognise the ESC[4i
             * termination sequence.
             */
            if (term->only_printing) {
                if (c == '\033')
                    term->print_state = 1;
                else if (c == (unsigned char)'\233')
                    term->print_state = 2;
                else if (c == '[' && term->print_state == 1)
                    term->print_state = 2;
                else if (c == '4' && term->print_state == 2)
                    term->print_state = 3;
                else if (c == 'i' && term->print_state == 3)
                    term->print_state = 4;
                else
                    term->print_state = 0;
                if (term->print_state == 4) {
                    term_print_finish(term);
                }
                continue;
            }
        }

        /* Sixel payload is byte-oriented and never enters UTF-8 decoding. */
        if (term->termstate >= NEMO_DCS_HEADER &&
            nemo_dcs_byte(term, (unsigned char)c))
            continue;

        if ((c == 0x18 || c == 0x1a) && term->termstate != TOPLEVEL) {
            term->termstate = TOPLEVEL;
            term->esc_query = 0;
            continue;
        }

        uint64_t checksum = 0;
        /* Preserve the graphic byte before charset translation loses it. */
        if (term->termstate == TOPLEVEL && !in_utf(term) && !term->sco_acs &&
            c >= 0x20 && (c < 0x80 || c >= 0xa0)) {
            unsigned bank = c >= 0xa0 ? term->cset_gr :
                term->cset_ss ? term->cset_ss : term->cset;
            checksum = nemo_charset_checksum_metadata(term, term->cset_attr[bank], c);
        }
        /* Do character-set translation. */
        if (term->termstate == TOPLEVEL) {
            unsigned long t = term_translate(term, &term->utf8, c);
            switch (t) {
              case UCSINCOMPLETE:
                continue;       /* didn't complete a multibyte char */
              case UCSTRUNCATED:
                unget = c;
                /* fall through */
              case UCSINVALID:
                c = UCSERR;
                break;
              default:
                c = t;
                if (c >= ' ' && c != 0x7f && (c < 0x80 || c >= 0xa0))
                    term->cset_ss = 0;
                break;
            }
        }
        if (c == UCSERR) checksum = 0;
        if (checksum && !(checksum & CELL_CHECKSUM_BYTE_POUND) &&
            (checksum & CELL_CHECKSUM_VALUE) >> CELL_CHECKSUM_SHIFT ==
            nemo_checksum_legacy(c)) checksum = 0;

        /*
         * How about C1 controls?
         * Explicitly ignore SCI (0x9a), which we don't translate to DECID.
         */
        if ((c & -32) == 0x80 && term->termstate < DO_CTRLS &&
            !term->vt52_mode && has_compat(VT220)) {
            if (c == 0x9a)
                c = 0;
            else {
                term->termstate = SEEN_ESC;
                term->esc_query = 0;
                c = '@' + (c & 0x1F);
            }
        }

        /* A cluster can span transport batches, SGR and status queries.
         * Cursor/editing controls terminate attachment even when the command
         * happens to leave the cursor at the same coordinate. OSC metadata
         * keeps the first member's cell attributes and hyperlink. */
        if ((term->termstate < DO_CTRLS &&
             ((c < 0x20 && c != 0 && c != 5 && c != 7 && c != 0x1b) || c == 0x7f)) ||
            (term->termstate == SEEN_ESC && c >= '0' &&
             c != '[' && c != ']' && c != 'P' && c != '7') ||
            (term->termstate == SEEN_CSI && c >= '@' && c <= '~' &&
             c != 'm' && c != 'n' && c != 'c' &&
             !(c == 'y' && (term->esc_query == '*' || term->esc_query == '#')) &&
             !(term->esc_query == '#' && (c == '{' || c == '}' || c == 'p' || c == 'q' || c == '|')) &&
             !(term->esc_query == '$' && c == 'w') &&
             !(term->esc_query == '"' && c == 'v') &&
             !(c == 'p' && (term->esc_query == '$' || term->esc_query == 0x100+'$'))))
            term->grapheme_pending = false;

        /* Or the GL control. */
        if (c == '\177' && term->termstate < DO_CTRLS && has_compat(OTHER)) {
            if (term->curs.x && !term->wrapnext)
                term->curs.x--;
            term->wrapnext = false;
            /* destructive backspace might be disabled */
            if (!term->no_dbackspace) {
                check_boundary(term, term->curs.x, term->curs.y);
                check_boundary(term, term->curs.x+1, term->curs.y);
                copy_termchar(scrlineptr(term->curs.y),
                              term->curs.x, &term->erase_char);
            }
            seen_disp_event(term);
        } else
        /* Or normal C0 controls. */
        if ((c & ~0x1F) == 0 && term->termstate < DO_CTRLS) {
            switch (c) {
              case '\005':             /* ENQ: terminal type query */
                /*
                 * Strictly speaking this is VT100 but a VT100 defaults to
                 * no response. Other terminals respond at their option.
                 *
                 * Don't put a CR in the default string as this tends to
                 * upset some weird software.
                 */
                compatibility(ANSIMIN);
                if (term->ldisc) {
                    strbuf *buf = term_input_data_from_charset(
                        term, DEFAULT_CODEPAGE,
                        term->answerback->s, term->answerback->len);
                    ldisc_send(term->ldisc, buf->s, buf->len, false);
                    strbuf_free(buf);
                }
                break;
              case '\007': {            /* BEL: Bell */
                if (term->termstate == SEEN_OSC ||
                    term->termstate == SEEN_OSC_W) {
                    /*
                     * In an OSC context, BEL is one of the ways to terminate
                     * the whole sequence. We process it as such even if we
                     * haven't got into the final OSC_STRING state yet, so that
                     * OSC sequences without a string will be handled cleanly.
                     */
                    do_osc(term, c == 7);
                    term->termstate = TOPLEVEL;
                    break;
                }

                struct beeptime *newbeep;
                unsigned long ticks;

                ticks = GETTICKCOUNT();

                if (!term->beep_overloaded) {
                    newbeep = snew(struct beeptime);
                    newbeep->ticks = ticks;
                    newbeep->next = NULL;
                    if (!term->beephead)
                        term->beephead = newbeep;
                    else
                        term->beeptail->next = newbeep;
                    term->beeptail = newbeep;
                    term->nbeeps++;
                }

                /*
                 * Throw out any beeps that happened more than
                 * t seconds ago.
                 */
                while (term->beephead &&
                       term->beephead->ticks < ticks - term->bellovl_t) {
                    struct beeptime *tmp = term->beephead;
                    term->beephead = tmp->next;
                    sfree(tmp);
                    if (!term->beephead)
                        term->beeptail = NULL;
                    term->nbeeps--;
                }

                if (term->bellovl && term->beep_overloaded &&
                    ticks - term->lastbeep >= (unsigned)term->bellovl_s) {
                    /*
                     * If we're currently overloaded and the
                     * last beep was more than s seconds ago,
                     * leave overload mode.
                     */
                    term->beep_overloaded = false;
                } else if (term->bellovl && !term->beep_overloaded &&
                           term->nbeeps >= term->bellovl_n) {
                    /*
                     * Now, if we have n or more beeps
                     * remaining in the queue, go into overload
                     * mode.
                     */
                    term->beep_overloaded = true;
                }
                term->lastbeep = ticks;

                /*
                 * Perform an actual beep if we're not overloaded.
                 */
                if (!term->bellovl || !term->beep_overloaded) {
                    win_bell(term->win, term->beep);

                    if (term->beep == BELL_VISUAL) {
                        term_schedule_vbell(term, false, 0);
                    }
                }
                seen_disp_event(term);
                break;
              }
              case '\b':              /* BS: Back space */
                nemo_cursor_back(term, 1);
                break;
              case '\016':            /* LS1: Locking-shift one */
                compatibility(VT100);
                term->cset = 1;
                break;
              case '\017':            /* LS0: Locking-shift zero */
                compatibility(VT100);
                term->cset = 0;
                break;
              case '\033':            /* ESC: Escape */
                if (term->vt52_mode)
                    term->termstate = VT52_ESC;
                else if (term->termstate == SEEN_OSC ||
                         term->termstate == SEEN_OSC_W) {
                    /* Be prepared to terminate an OSC early */
                    term->termstate = OSC_MAYBE_ST;
                } else {
                    compatibility(ANSIMIN);
                    term->termstate = SEEN_ESC;
                    term->esc_query = 0;
                }
                break;
              case '\015':            /* CR: Carriage return */
                term->curs.x = nemo_cr_x(term);
                term->wrapnext = false;
                seen_disp_event(term);

                if (term->crhaslf) {
                    nemo_linefeed(term);
                }
                if (term->logctx)
                    logtraffic(term->logctx, (unsigned char) c, LGTYP_ASCII);
                break;
              case '\014':            /* FF: Form feed */
                if (has_compat(SCOANSI)) {
                    move(term, 0, 0, 0);
                    erase_lots(term, false, false, true);
                    if (term->scroll_on_disp)
                        term->disptop = 0;
                    term->wrapnext = false;
                    seen_disp_event(term);
                    break;
                }
              case '\013':            /* VT: Line tabulation */
                compatibility(VT100);
              case '\012':            /* LF: Line feed */
                nemo_linefeed(term);
                if (term->lfhascr)
                    term->curs.x = nemo_cr_x(term);
                term->wrapnext = false;
                seen_disp_event(term);
                if (term->logctx)
                    logtraffic(term->logctx, (unsigned char) c, LGTYP_ASCII);
                break;
              case '\t':              /* HT: Character tabulation */
                nemo_tabulate(term, 1, true);
                break;
            }
        } else
            switch (term->termstate) {
              case TOPLEVEL:
                /* Only graphic characters get this far;
                 * ctrls are stripped above */
                term_display_graphic_char(term, c, checksum);
                term->last_graphic_char = c;
                term->last_graphic_checksum = checksum;
                break;

              case OSC_MAYBE_ST:
                /*
                 * This state is virtually identical to SEEN_ESC, with the
                 * exception that we have an OSC sequence in the pipeline,
                 * and _if_ we see a backslash, we process it.
                 */
                if (c == '\\') {
                    do_osc(term, c == 7);
                    term->termstate = TOPLEVEL;
                    break;
                }
                nemo_osc52_cancel(term->osc52);
                /* else fall through */
              case SEEN_ESC:
                if (c >= ' ' && c <= '/') {
                    if (((term->esc_query >= '(' && term->esc_query <= '+') ||
                         (term->esc_query >= '-' && term->esc_query <= '/')) &&
                        (c == '%' || c == '&' || c == '"'))
                        term->esc_query |= c << 8;
                    else if (term->esc_query)
                        term->esc_query = -1;
                    else
                        term->esc_query = c;
                    break;
                }
                term->termstate = TOPLEVEL;
                if (nemo_charset_escape(term, c)) break;
                switch (ANSI(c, term->esc_query)) {
                  case '[':             /* enter CSI mode */
                    term->termstate = SEEN_CSI;
                    term->esc_nargs = 1;
                    term->esc_args[0] = ARG_DEFAULT;
                    term->esc_arg_present = 0;
                    memset(term->esc_sub_count, 0, sizeof(term->esc_sub_count));
                    memset(term->esc_sub_present, 0, sizeof(term->esc_sub_present));
                    term->esc_overflow = term->esc_has_subargs = false;
                    term->esc_query = 0;
                    break;
                  case ']':             /* OSC: xterm escape sequences */
                    /* Compatibility is nasty here, xterm, linux, decterm yuk! */
                    compatibility(OTHER);
                    nemo_osc52_cancel(term->osc52);
                    term->termstate = SEEN_OSC;
                    term->osc_type = OSCLIKE_OSC;
                    term->osc_strlen = 0;
                    term->osc_overflow = false;
                    term->esc_args[0] = 0;
                    term->esc_nargs = 1;
                    break;
                  case 'P':             /* DCS: streamed Sixel or bounded query */
                    nemo_presentation_cancel(term);
                    nemo_sixel_cancel(term);
                    memset(term->sixel_header, 0, sizeof(term->sixel_header));
                    term->sixel_header_index = 0;
                    term->dcs_header_params = term->dcs_query_active = term->dcs_query_invalid = false;
                    term->dcs_upss_header_valid = true;
                    term->dcs_query_type = 0;
                    term->dcs_query_len = 0;
                    term->dcs_query[0] = '\0';
                    term->termstate = NEMO_DCS_HEADER;
                    break;
                  case 'X':             /* SOS: Start of String */
                  case '^':             /* PM: privacy message */
                  case '_':             /* APC: application program command */
                    /* DCS, SOS, PM, and APC sequences are just a string, terminated
                     * by ST or (I've observed in practice for APC) ^G. That
                     * is, they have the same termination convention as OSC. So
                     * we handle them by going straight into OSC_STRING state
                     * and setting a flag indicating that it's not really an
                     * OSC. */
                    compatibility(OTHER);
                    term->termstate = SEEN_OSC;
                    term->osc_type = (c == 'P' ? OSCLIKE_DCS :
                                      c == 'X' ? OSCLIKE_SOS :
                                      c == '^' ? OSCLIKE_PM : OSCLIKE_APC);
                    term->osc_strlen = 0;
                    term->osc_overflow = false;
                    term->esc_args[0] = 0;
                    term->esc_nargs = 1;
                    break;
                  case '6': case '9':    /* DECBI / DECFI */
                    compatibility(VT420);
                    nemo_column_index(term, c == '6');
                    break;
                  case '7':             /* DECSC: save cursor */
                    compatibility(VT100);
                    save_cursor(term, true);
                    break;
                  case '8':             /* DECRC: restore cursor */
                    compatibility(VT100);
                    save_cursor(term, false);
                    break;
                  case 'V':             /* SPA: start ISO guarded area */
                    compatibility(ANSIMIN);
                    term->protection_mode = NEMO_PROTECT_ISO;
                    term->curr_truecolour.decoration |= CELL_PROTECTED;
                    break;
                  case 'W':             /* EPA: end future guarded writes */
                    compatibility(ANSIMIN);
                    term->curr_truecolour.decoration &= ~CELL_PROTECTED;
                    break;
                  case '=':             /* DECKPAM: Keypad application mode */
                    compatibility(VT100);
                    term->app_keypad_keys = true;
                    break;
                  case '>':             /* DECKPNM: Keypad numeric mode */
                    compatibility(VT100);
                    term->app_keypad_keys = false;
                    break;
                  case 'D':            /* IND: exactly equivalent to LF */
                    compatibility(VT100);
                    nemo_linefeed(term);
                    term->wrapnext = false;
                    seen_disp_event(term);
                    break;
                  case 'E':            /* NEL: exactly equivalent to CR-LF */
                    compatibility(VT100);
                    nemo_linefeed(term);
                    term->curs.x = nemo_cr_x(term);
                    term->wrapnext = false;
                    seen_disp_event(term);
                    break;
                  case 'M':            /* RI: reverse index - backwards LF */
                    compatibility(VT100);
                    if (term->curs.y == term->marg_t) {
                        if (nemo_in_lr(term)) scroll(term, term->marg_t, term->marg_b, -1, true);
                    }
                    else if (term->curs.y > 0)
                        term->curs.y--;
                    term->wrapnext = false;
                    seen_disp_event(term);
                    break;
                  case 'Z':            /* DECID: terminal type query */
                    compatibility(VT100);
                    if (term->ldisc)
                        nemo_protocol_send(term, term->id_string,
                                   strlen(term->id_string));
                    break;
                  case 'c':            /* RIS: restore power-on settings */
                    compatibility(VT100);
                    power_on(term, true, true);
                    if (term->ldisc)   /* cause ldisc to notice changes */
                        ldisc_echoedit_update(term->ldisc);
                    if (term->reset_132) {
                        if (!term->no_remote_resize)
                            term_request_resize(term, 80, term->rows);
                        term->reset_132 = false;
                    }
                    if (term->scroll_on_disp)
                        term->disptop = 0;
                    seen_disp_event(term);
                    break;
                  case 'H':            /* HTS: set a tab */
                    compatibility(VT100);
                    term->tabs[term->curs.x] = true;
                    break;

                  case ANSI('8', '#'): { /* DECALN: fills screen with Es :-) */
                    compatibility(VT100);
                    termline *ldata;
                    int i, j;
                    pos scrtop, scrbot;

                    /* DECALN resets layout and rendition, while preserving
                     * the current colours, protection and other mode state.
                     * The E cells themselves use the default rendition. */
                    term->dec_om = false;
                    term->wrapnext = false;
                    term->marg_t = term->marg_l = 0;
                    term->marg_b = term->rows - 1;
                    term->marg_r = term->cols - 1;
                    term->curs.x = term->curs.y = 0;
                    unsigned fg = (term->curr_attr & ATTR_FGMASK) >> ATTR_FGSHIFT;
                    if ((term->curr_attr & ATTR_BOLD) &&
                        (conf_get_int(term->conf, CONF_bold_style) & BOLD_STYLE_COLOUR) &&
                        !term->curr_truecolour.fg.enabled && fg < 8)
                        term->curr_attr = (term->curr_attr & ~ATTR_FGMASK) |
                            ((fg + 8) << ATTR_FGSHIFT);
                    term->curr_attr &= ATTR_COLOURS;
                    term->curr_truecolour.decoration &= CELL_PROTECTED;
                    set_erase_char(term);
                    nemo_images_erase(term, (pos){0, 0}, (pos){term->rows, 0});

                    for (i = 0; i < term->rows; i++) {
                        ldata = scrlineptr(i);
                        check_line_size(term, ldata);
                        for (j = 0; j < term->cols; j++) {
                            copy_termchar(ldata, j,
                                          &term->basic_erase_char);
                            ldata->chars[j].chr = 'E';
                            ldata->chars[j].truecolour.decoration &= ~CELL_UNDRAWN;
                        }
                        ldata->lattr = LATTR_NORM;
                    }
                    if (term->scroll_on_disp)
                        term->disptop = 0;
                    seen_disp_event(term);
                    scrtop.x = scrtop.y = 0;
                    scrbot.x = 0;
                    scrbot.y = term->rows;
                    check_selection(term, scrtop, scrbot);
                    break;
                  }

                  case ANSI('3', '#'):
                  case ANSI('4', '#'):
                  case ANSI('5', '#'):
                  case ANSI('6', '#'): {
                    compatibility(VT100);
                    if (term->lrmm) break;
                    int nlattr;
                    termline *ldata;

                    switch (ANSI(c, term->esc_query)) {
                      case ANSI('3', '#'): /* DECDHL: 2*height, top */
                        nlattr = LATTR_TOP;
                        break;
                      case ANSI('4', '#'): /* DECDHL: 2*height, bottom */
                        nlattr = LATTR_BOT;
                        break;
                      case ANSI('5', '#'): /* DECSWL: normal */
                        nlattr = LATTR_NORM;
                        break;
                      default: /* case ANSI('6', '#'): DECDWL: 2*width */
                        nlattr = LATTR_WIDE;
                        break;
                    }
                    ldata = scrlineptr(term->curs.y);
                    check_line_size(term, ldata);
                    check_trust_status(term, ldata);
                    if ((ldata->lattr & LATTR_MODE) != nlattr && nlattr != LATTR_NORM)
                        term->curs.x = min(term->curs.x, min(term->cols-1, term->cols/2));
                    ldata->lattr = (ldata->lattr & ~LATTR_MODE) | nlattr;
                    seen_disp_event(term);
                    break;
                  }
                  case 'N': case 'O': /* SS2 / SS3 */
                    compatibility(VT220);
                    if (!term->no_remote_charset) term->cset_ss = c == 'N' ? 2 : 3;
                    break;
                  case 'n': case 'o': /* LS2 / LS3 */
                    compatibility(VT220);
                    if (!term->no_remote_charset) term->cset = c == 'n' ? 2 : 3;
                    break;
                  case '~': case '}': case '|': /* LS1R / LS2R / LS3R */
                    compatibility(VT220);
                    if (!term->no_remote_charset)
                        term->cset_gr = c == '~' ? 1 : c == '}' ? 2 : 3;
                    break;
                  case ANSI('A', '*'): case ANSI('B', '*'): case ANSI('0', '*'):
                  case ANSI('A', '+'): case ANSI('B', '+'): case ANSI('0', '+'):
                    compatibility(VT220);
                    if (!term->no_remote_charset)
                        term->cset_attr[term->esc_query == '*' ? 2 : 3] = nemo_charset_code(c);
                    break;
                  case ANSI('U', '*'): case ANSI('U', '+'):
                    compatibility(OTHER);
                    if (!term->no_remote_charset)
                        term->cset_attr[term->esc_query == '*' ? 2 : 3] = CSET_SCOACS;
                    break;
                  /* GZD4: G0 designate 94-set */
                  case ANSI('A', '('):
                    compatibility(VT100);
                    if (!term->no_remote_charset)
                        term->cset_attr[0] = CSET_GBCHR;
                    break;
                  case ANSI('B', '('):
                    compatibility(VT100);
                    if (!term->no_remote_charset)
                        term->cset_attr[0] = CSET_ASCII;
                    break;
                  case ANSI('0', '('):
                    compatibility(VT100);
                    if (!term->no_remote_charset)
                        term->cset_attr[0] = CSET_LINEDRW;
                    break;
                  case ANSI('U', '('):
                    compatibility(OTHER);
                    if (!term->no_remote_charset)
                        term->cset_attr[0] = CSET_SCOACS;
                    break;
                  /* G1D4: G1-designate 94-set */
                  case ANSI('A', ')'):
                    compatibility(VT100);
                    if (!term->no_remote_charset)
                        term->cset_attr[1] = CSET_GBCHR;
                    break;
                  case ANSI('B', ')'):
                    compatibility(VT100);
                    if (!term->no_remote_charset)
                        term->cset_attr[1] = CSET_ASCII;
                    break;
                  case ANSI('0', ')'):
                    compatibility(VT100);
                    if (!term->no_remote_charset)
                        term->cset_attr[1] = CSET_LINEDRW;
                    break;
                  case ANSI('U', ')'):
                    compatibility(OTHER);
                    if (!term->no_remote_charset)
                        term->cset_attr[1] = CSET_SCOACS;
                    break;
                  case ANSI('F', ' '): /* S7C1T */
                  case ANSI('G', ' '): /* S8C1T */
                    compatibility(VT220);
                    term->c1_8bit = c == 'G';
                    break;
                  /* DOCS: Designate other coding system */
                  case ANSI('8', '%'):  /* Old Linux code */
                  case ANSI('G', '%'):
                    compatibility(OTHER);
                    nemo_charset_docs(term, true);
                    break;
                  case ANSI('@', '%'):
                    compatibility(OTHER);
                    nemo_charset_docs(term, false);
                    break;
                }
                break;
              case SEEN_CSI:
                term->termstate = TOPLEVEL;  /* default */
                if (isdigit(c)) {
                    if (!term->esc_overflow) {
                        unsigned i = term->esc_nargs - 1;
                        term->esc_arg_present |= 1u << i;
                        unsigned sub = term->esc_sub_count[i];
                        unsigned *value = sub ? &term->esc_subargs[i][sub-1] :
                            &term->esc_args[i];
                        if (sub) term->esc_sub_present[i] |= 1u << (sub-1);
                        unsigned digit = c - '0';
                        *value = *value <= (UINT_MAX-digit)/10 ?
                            *value*10+digit : UINT_MAX;
                    }
                    term->termstate = SEEN_CSI;
                } else if (c == ';') {
                    if (!term->esc_overflow && term->esc_nargs < ARGS_MAX)
                        term->esc_args[term->esc_nargs++] = ARG_DEFAULT;
                    else
                        term->esc_overflow = true;
                    term->termstate = SEEN_CSI;
                } else if (c == ':') {
                    unsigned i = term->esc_nargs - 1;
                    term->esc_has_subargs = true;
                    if (!term->esc_overflow && term->esc_sub_count[i] < SUBARGS_MAX)
                        term->esc_subargs[i][term->esc_sub_count[i]++] = 0;
                    else
                        term->esc_overflow = true;
                    term->termstate = SEEN_CSI;
                } else if (c < '@') {
                    if (c == '$' && term->esc_query == 1)
                        term->esc_query = 0x100 + '$';
                    else if (term->esc_query)
                        term->esc_query = -1;
                    else if (c == '?')
                        term->esc_query = 1;
                    else
                        term->esc_query = c;
                    term->termstate = SEEN_CSI;
                } else if (term->esc_overflow ||
                           (term->esc_has_subargs &&
                            !((c == 'm' && (!term->esc_query || term->esc_query == '>')) ||
                              (c == 'c' && (!term->esc_query || term->esc_query == '>' ||
                               (term->esc_query == '=' && term->compatibility_level != TM_SCOANSI))) ||
                              ((c == 'q' || c == 't' || c == 'T') && term->esc_query == '>')))) {
                    /* Reject the complete overflowing sequence, and never
                     * reinterpret colon values as unrelated CSI parameters.
                     * Xterm discards the whole parameter list on unexpected
                     * subparameters, then still dispatches identity queries. */
                } else
#define CLAMP(arg, lim) ((arg) = ((arg) > (lim)) ? (lim) : (arg))
                    switch (ANSI(c, term->esc_query)) {
                      case ANSI('t', '>'): case ANSI('T', '>'):
                        if (term->esc_has_subargs) term->title_modes = 0;
                        else for (int i = 0; i < term->esc_nargs; i++) {
                            if (!(term->esc_arg_present & (1u << i)) ||
                                term->esc_args[i] > 3) continue;
                            unsigned bit = 1u << term->esc_args[i];
                            if (c == 't') term->title_modes |= bit;
                            else term->title_modes &= ~bit;
                        }
                        break;
                      case ANSI('p', '!'): /* DECSTR; parameters are ignored */
                        nemo_soft_reset(term);
                        break;
                      case ANSI('p', '$'):
                      case ANSI('p', 0x100 + '$'): {
                        bool dec = term->esc_query != '$';
                        unsigned mode = term->esc_args[0];
                        if (term->ldisc) {
                            char response[64];
                            int len = sprintf(response, "\033[%s%u;%u$y",
                                              dec ? "?" : "", mode,
                                              term_mode_status(term, mode, dec));
                            nemo_protocol_send(term, response, len);
                        }
                        break;
                      }
                      case 'A':       /* CUU: move up N lines */
                        CLAMP(term->esc_args[0], term->rows);
                        move(term, term->curs.x,
                             term->curs.y - def(term->esc_args[0], 1), 1);
                        seen_disp_event(term);
                        break;
                      case 'e':         /* VPR: move down N lines */
                        compatibility(ANSI);
                        CLAMP(term->esc_args[0], term->rows);
                        /* Position-relative controls follow CUP's origin
                         * clipping, unlike CUD/CUF's scrolling boundaries. */
                        move(term, term->curs.x,
                             term->curs.y + def(term->esc_args[0], 1),
                             term->dec_om ? 2 : 0);
                        break;
                      case 'B':         /* CUD: Cursor down */
                        CLAMP(term->esc_args[0], term->rows);
                        move(term, term->curs.x,
                             term->curs.y + def(term->esc_args[0], 1), 1);
                        seen_disp_event(term);
                        break;
                      case 'b':        /* REP: repeat previous grap */
                        term->esc_args[0] = def(term->esc_args[0], 1);
                        CLAMP(term->esc_args[0], term->rows * term->cols);
                        if (term->grapheme_mode && in_utf(term) &&
                            !term->vt52_mode && term->last_grapheme_len) {
                            uint32_t saved[CC_LIMIT + 1];
                            unsigned n = term->last_grapheme_len;
                            memcpy(saved, term->last_grapheme, n * sizeof(*saved));
                            for (unsigned i = 0; i < term->esc_args[0]; i++) {
                                /* Each repeat is a new cluster, including RI
                                 * and leading-mark clusters. Display updates
                                 * last_grapheme, so iterate a local snapshot. */
                                term->grapheme_pending = false;
                                for (unsigned j = 0; j < n; j++)
                                    term_display_graphic_char(term, saved[j], 0);
                            }
                        } else if (term->last_graphic_char) {
                            unsigned i;
                            for (i = 0; i < term->esc_args[0]; i++)
                                term_display_graphic_char(
                                    term, term->last_graphic_char, term->last_graphic_checksum);
                        }
                        break;
                      case ANSI('c', '>'):      /* DA2: compatibility identity */
                        compatibility(OTHER);
                        /* this reports xterm version 136 so that VIM can
                           use the drag messages from the mouse reporting */
                        if (term->ldisc &&
                            (term->esc_has_subargs || term->esc_args[0] == 0))
                            nemo_protocol_send(term, "\033[>0;136;0c", 11);
                        break;
                      case ANSI('q', '>'): {    /* XTVERSION */
                        compatibility(OTHER);
                        static const char reply[] =
                            "\033P>|Nemoterm(PuTTY 0.85)\033\\";
                        if (term->ldisc &&
                            (term->esc_has_subargs || term->esc_args[0] == 0))
                            nemo_protocol_send(term, reply, sizeof(reply)-1);
                        break;
                      }
                      case 'a':         /* HPR: move right N cols */
                        compatibility(ANSI);
                        CLAMP(term->esc_args[0], term->cols);
                        /* Keep the logical column bounded by the physical
                         * grid, including double-width rows. The writer
                         * already ignores text beyond a row's visible cells. */
                        move(term, term->curs.x + def(term->esc_args[0], 1),
                             term->curs.y, term->dec_om ? 2 : 0);
                        break;
                      case 'C':         /* CUF: Cursor right */
                        CLAMP(term->esc_args[0], term->cols);
                        move(term, min(term->curs.x + def(term->esc_args[0], 1),
                             nemo_line_columns(term, scrlineptr(term->curs.y))-1),
                             term->curs.y, 1);
                        seen_disp_event(term);
                        break;
                      case 'D':       /* CUB: move left N cols */
                        nemo_cursor_back(term, term->esc_args[0]);
                        break;
                      case 'E':       /* CNL: move down N lines and CR */
                        compatibility(ANSI);
                        CLAMP(term->esc_args[0], term->rows);
                        move(term, 0,
                             term->curs.y + def(term->esc_args[0], 1), 1);
                        seen_disp_event(term);
                        break;
                      case 'F':       /* CPL: move up N lines and CR */
                        compatibility(ANSI);
                        CLAMP(term->esc_args[0], term->rows);
                        move(term, 0,
                             term->curs.y - def(term->esc_args[0], 1), 1);
                        seen_disp_event(term);
                        break;
                      case 'G':       /* CHA */
                      case '`':       /* HPA: set horizontal posn */
                        compatibility(ANSI);
                        CLAMP(term->esc_args[0], term->cols);
                        move(term, (term->dec_om ? term->marg_l : 0) + def(term->esc_args[0], 1) - 1,
                             term->curs.y, term->dec_om ? 2 : 0);
                        seen_disp_event(term);
                        break;
                      case 'd':       /* VPA: set vertical posn */
                        compatibility(ANSI);
                        CLAMP(term->esc_args[0], term->rows);
                        move(term, term->curs.x,
                             ((term->dec_om ? term->marg_t : 0) +
                              def(term->esc_args[0], 1) - 1),
                             (term->dec_om ? 2 : 0));
                        seen_disp_event(term);
                        break;
                      case 'H':      /* CUP */
                      case 'f':      /* HVP: set horz and vert posns at once */
                        if (term->esc_nargs < 2)
                            term->esc_args[1] = ARG_DEFAULT;
                        CLAMP(term->esc_args[0], term->rows);
                        CLAMP(term->esc_args[1], term->cols);
                        move(term, (term->dec_om ? term->marg_l : 0) + def(term->esc_args[1], 1) - 1,
                             ((term->dec_om ? term->marg_t : 0) +
                              def(term->esc_args[0], 1) - 1),
                             (term->dec_om ? 2 : 0));
                        seen_disp_event(term);
                        break;
                      case 'J': {       /* ED: erase screen or parts of it */
                        unsigned int i = def(term->esc_args[0], 0);
                        if (i == 3) {
                            /* Erase Saved Lines (xterm)
                             * This follows Thomas Dickey's xterm. */
                            if (!term->no_remote_clearscroll)
                                term_clrsb(term);
                        } else if (i <= 2) {
                            if (term->protection_mode & NEMO_PROTECT_ISO)
                                nemo_selective_erase(term, false, i);
                            else {
                                i++;
                                erase_lots(term, false, !!(i & 2), !!(i & 1));
                            }
                        }
                        if (term->scroll_on_disp)
                            term->disptop = 0;
                        seen_disp_event(term);
                        break;
                      }
                      case 'K': {       /* EL: erase line or parts of it */
                        unsigned int i = term->esc_args[0];
                        if (i > 2) break;
                        if (term->protection_mode & NEMO_PROTECT_ISO) {
                            nemo_selective_erase(term, true, i);
                            break;
                        }
                        i++;
                        erase_lots(term, true, !!(i & 2), !!(i & 1));
                        seen_disp_event(term);
                        break;
                      }
                      case ANSI_QUE('J'): /* DECSED */
                      case ANSI_QUE('K'): /* DECSEL */
                        if (c == 'J' && term->esc_args[0] == 3) {
                            if (!term->no_remote_clearscroll) term_clrsb(term);
                        } else {
                            nemo_selective_erase(term, c == 'K', term->esc_args[0]);
                        }
                        break;
                      case ANSI('z', '$'): /* DECERA */
                      case ANSI('{', '$'): /* DECSERA */
                        nemo_erase_rectangle(term, c == '{');
                        break;
                      case ANSI('x', '$'): /* DECFRA */
                        nemo_fill_rectangle(term); break;
                      case ANSI('v', '$'): /* DECCRA */
                        nemo_copy_rectangle(term); break;
                      case ANSI('r', '$'): /* DECCARA */
                      case ANSI('t', '$'): /* DECRARA */
                        nemo_rectangle_attributes(term, c == 't'); break;
                      case ANSI('x', '*'): /* DECSACE; xterm retains any value */
                        term->rectangle_extent = term->esc_args[0]; break;
                      case ANSI('y', '*'): /* DECRQCRA */
                        compatibility(VT420);
                        nemo_checksum_rectangle(term); break;
                      case ANSI('y', '#'): /* XTCHECKSUM */
                        compatibility(VT420);
                        if (conf_get_bool(term->conf, CONF_nemo_allow_checksum))
                            term->checksum_flags = term->esc_args[0] & 31;
                        break;
                      case ANSI('{', '#'): case ANSI('p', '#'): /* XTPUSHSGR */
                        nemo_push_sgr(term); break;
                      case ANSI('}', '#'): case ANSI('q', '#'): /* XTPOPSGR */
                        nemo_pop_sgr(term); break;
                      case ANSI('|', '#'): /* XTREPORTSGR */
                        nemo_report_rectangle_sgr(term); break;
                      case ANSI('P', '#'): /* XTPUSHCOLORS */
                        nemo_palette_stack_op(term, true); break;
                      case ANSI('Q', '#'): /* XTPOPCOLORS */
                        nemo_palette_stack_op(term, false); break;
                      case ANSI('R', '#'): /* XTREPORTCOLORS */
                        nemo_report_palette_stack(term); break;
                      case ANSI('S', '#'): /* XTTITLEPOS */
                        if (term->ldisc) {
                            char reply[48];
                            int n = sprintf(reply, "\033[%u;%u#S",
                                term->title_stack ? term->title_stack->depth : 0,
                                TITLE_STACK_SLOTS);
                            nemo_protocol_send(term, reply, n);
                        }
                        break;
                      case ANSI('w', '$'): /* DECRQPSR */
                        compatibility(VT320);
                        nemo_presentation_report(term); break;
                      case ANSI('v', '"'): /* DECRQDE */
                        compatibility(VT320);
                        if (term->ldisc) {
                            char reply[80];
                            int len = sprintf(reply, "\033[%d;%d;1;1;1\"w", term->rows, term->cols);
                            nemo_protocol_send(term, reply, len);
                        }
                        break;
                      case ANSI('q', '"'): /* DECSCA, independent of SGR */
                        term->protection_mode = NEMO_PROTECT_DEC;
                        if (term->esc_args[0] <= 2) {
                            term->curr_truecolour.decoration &= ~CELL_PROTECTED;
                            if (term->esc_args[0] == 1)
                                term->curr_truecolour.decoration |= CELL_PROTECTED;
                        }
                        break;
                      case 'L':       /* IL: insert lines */
                        compatibility(VT102);
                        CLAMP(term->esc_args[0], term->rows);
                        if (term->curs.y >= term->marg_t && term->curs.y <= term->marg_b && nemo_in_lr(term)) {
                            scroll(term, term->curs.y, term->marg_b,
                                   -def(term->esc_args[0], 1), false);
                            term->curs.x = term->marg_l; term->wrapnext = false;
                        }
                        seen_disp_event(term);
                        break;
                      case 'M':       /* DL: delete lines */
                        compatibility(VT102);
                        CLAMP(term->esc_args[0], term->rows);
                        if (term->curs.y >= term->marg_t && term->curs.y <= term->marg_b && nemo_in_lr(term)) {
                            scroll(term, term->curs.y, term->marg_b,
                                   def(term->esc_args[0], 1),
                                   true);
                            term->curs.x = term->marg_l; term->wrapnext = false;
                        }
                        seen_disp_event(term);
                        break;
                      case ANSI('@', ' '): case ANSI('A', ' '): /* SL / SR */
                        compatibility(OTHER);
                        nemo_scroll_columns(term, term->esc_args[0], c == '@', term->marg_l);
                        break;
                      case ANSI('~', '\''): case ANSI('}', '\''): /* DECDC / DECIC */
                        compatibility(VT420);
                        nemo_scroll_columns(term, term->esc_args[0], c == '~', term->curs.x);
                        break;
                      case '@':       /* ICH: insert chars */
                        /* XXX VTTEST says this is vt220, vt510 manual says vt102 */
                        compatibility(VT102);
                        CLAMP(term->esc_args[0], term->cols);
                        insch(term, def(term->esc_args[0], 1));
                        seen_disp_event(term);
                        break;
                      case 'P':       /* DCH: delete chars */
                        compatibility(VT102);
                        CLAMP(term->esc_args[0], term->cols);
                        insch(term, -def(term->esc_args[0], 1));
                        seen_disp_event(term);
                        break;
                      case 'c':       /* DA: terminal type query */
                        compatibility(VT100);
                        /* Report the configured identity only for a request. */
                        if (term->ldisc &&
                            (term->esc_has_subargs || term->esc_args[0] == 0))
                            nemo_protocol_send(term, term->id_string,
                                       strlen(term->id_string));
                        break;
                      case 'n':       /* DSR / CPR */
                      case ANSI_QUE('n'): /* DEC-specific DSR / DECXCPR */
                        nemo_status_query(term, term->esc_query == 1);
                        break;
                      case 'h':       /* SM: toggle modes to high */
                      case ANSI_QUE('h'):
                        compatibility(VT100);
                        for (int i = 0; i < term->esc_nargs; i++)
                            toggle_mode(term, term->esc_args[i],
                                        term->esc_query, true);
                        break;
                      case 'i':         /* MC: Media copy */
                      case ANSI_QUE('i'): {
                        compatibility(VT100);
                        char *printer;
                        if (term->esc_nargs != 1) break;
                        if (term->esc_args[0] == 5 &&
                            (printer = conf_get_str(term->conf,
                                                    CONF_printer))[0]) {
                            term->printing = true;
                            term->only_printing = !term->esc_query;
                            term->print_state = 0;
                            term_print_setup(term, printer);
                        } else if (term->esc_args[0] == 4 &&
                                   term->printing) {
                            term_print_finish(term);
                        }
                        break;
                      }
                      case 'l':       /* RM: toggle modes to low */
                      case ANSI_QUE('l'):
                        compatibility(VT100);
                        for (int i = 0; i < term->esc_nargs; i++)
                            toggle_mode(term, term->esc_args[i],
                                        term->esc_query, false);
                        break;
                      case 'g':       /* TBC: clear tabs */
                        compatibility(VT100);
                        if (term->esc_args[0] == 0)
                            term->tabs[term->curs.x] = false;
                        else if (term->esc_args[0] == 3)
                            memset(term->tabs, 0, term->tabs_size);
                        break;
                      case ANSI_QUE('W'): /* DECST8C: restore eight-column tabs */
                        compatibility(VT510);
                        if (term->esc_args[0] == 0 || term->esc_args[0] == 5)
                            for (int i = 0; i < term->tabs_size; i++)
                                term->tabs[i] = i > 0 && i % 8 == 0;
                        break;
                      case ANSI('q', ' '): /* DECSCUSR */
                        if (term->esc_nargs == 1)
                            nemo_cursor_style(term, def(term->esc_args[0], 0));
                        break;
                      case 'r':       /* DECSTBM: set scroll margins */
                        compatibility(VT100);
                        if (term->esc_nargs <= 2) {
                            int top, bot;
                            CLAMP(term->esc_args[0], term->rows);
                            CLAMP(term->esc_args[1], term->rows);
                            top = def(term->esc_args[0], 1) - 1;
                            bot = (term->esc_nargs <= 1
                                   || term->esc_args[1] == 0 ?
                                   term->rows :
                                   def(term->esc_args[1], term->rows)) - 1;
                            if (bot >= term->rows)
                                bot = term->rows - 1;
                            /* VTTEST Bug 9 - if region is less than 2 lines
                             * don't change region.
                             */
                            if (bot - top > 0) {
                                term->marg_t = top;
                                term->marg_b = bot;
                                term->curs.x = term->dec_om ? term->marg_l : 0;
                                term->wrapnext = false;
                                /*
                                 * I used to think the cursor should be
                                 * placed at the top of the newly marginned
                                 * area. Apparently not: VMS TPU falls over
                                 * if so.
                                 *
                                 * Well actually it should for
                                 * Origin mode - RDB
                                 */
                                term->curs.y = (term->dec_om ?
                                                term->marg_t : 0);
                                seen_disp_event(term);
                            }
                        }
                        break;
                      case 'm':       /* SGR: set graphics rendition */
                        /*
                         * A VT100 without the AVO only had one
                         * attribute, either underline or reverse
                         * video depending on the cursor type, this
                         * was selected by CSI 7m.
                         *
                         * case 2:
                         *  This is sometimes DIM, eg on the GIGI and
                         *  Linux
                         * case 8:
                         *  This is sometimes INVIS various ANSI.
                         * case 21:
                         *  This like 22 disables BOLD, DIM and INVIS
                         *
                         * The ANSI colours appear on any terminal
                         * that has colour (obviously) but the
                         * interaction between sgr0 and the colours
                         * varies but is usually related to the
                         * background colour erase item. The
                         * interaction between colour attributes and
                         * the mono ones is also very implementation
                         * dependent.
                         *
                         * The 39 and 49 attributes are likely to be
                         * unimplemented.
                         */
                        for (int i = 0; i < term->esc_nargs; i++) {
                        if (term->esc_sub_count[i] &&
                            term->esc_args[i] != 4 && term->esc_args[i] != 38 &&
                            term->esc_args[i] != 48 && term->esc_args[i] != 58)
                            continue;
                        switch (def(term->esc_args[i], 0)) {
                          case 0: {     /* restore visual defaults */
                            uint32_t protected = term->curr_truecolour.decoration & CELL_PROTECTED;
                            term->curr_attr = term->default_attr;
                            term->curr_truecolour =
                                term->basic_erase_char.truecolour;
                            term->curr_truecolour.decoration = protected;
                            break;
                          }
                          case 1:       /* enable bold */
                            compatibility(VT100AVO);
                            term->curr_attr |= ATTR_BOLD;
                            break;
                          case 2:       /* enable dim */
                            compatibility(OTHER);
                            term->curr_attr |= ATTR_DIM;
                            break;
                          case 3:
                            term->curr_attr |= ATTR_ITALIC;
                            break;
                          case 21:      /* double underline */
                            compatibility(OTHER);
                            term->curr_truecolour.decoration |= UNDER_DOUBLE_LEGACY;
                            break;
                          case 4:       /* enable underline */
                            compatibility(VT100AVO);
                            if (!term->esc_sub_count[i]) {
                                term->curr_attr |= ATTR_UNDER;
                                term->curr_truecolour.decoration =
                                    (term->curr_truecolour.decoration & ~UNDER_STYLE_MASK) |
                                    (UINT32_C(1) << UNDER_STYLE_SHIFT);
                            }
                            else if (term->esc_sub_count[i] == 1 &&
                                     (term->esc_sub_present[i] & 1))
                                nemo_underline_style(term, term->esc_subargs[i][0]);
                            break;
                          case 5:       /* enable blink */
                            compatibility(VT100AVO);
                            term->curr_attr |= ATTR_BLINK;
                            break;
                          case 6:       /* SCO light bkgrd */
                            compatibility(SCOANSI);
                            term->blink_is_real = false;
                            term->curr_attr |= ATTR_BLINK;
                            term_schedule_tblink(term);
                            break;
                          case 7:       /* enable reverse video */
                            term->curr_attr |= ATTR_REVERSE;
                            break;
                          case 8:
                            term->curr_attr |= ATTR_CONCEAL;
                            break;
                          case 9:       /* enable strikethrough */
                            term->curr_attr |= ATTR_STRIKE;
                            break;
                          case 10:      /* SCO acs off */
                            compatibility(SCOANSI);
                            if (term->no_remote_charset) break;
                            term->sco_acs = 0; break;
                          case 11:      /* SCO acs on */
                            compatibility(SCOANSI);
                            if (term->no_remote_charset) break;
                            term->sco_acs = 1; break;
                          case 12:      /* SCO acs on, |0x80 */
                            compatibility(SCOANSI);
                            if (term->no_remote_charset) break;
                            term->sco_acs = 2; break;
                          case 22:      /* disable bold and dim */
                            compatibility2(OTHER, VT220);
                            term->curr_attr &= ~(ATTR_BOLD | ATTR_DIM);
                            break;
                          case 24:      /* disable underline */
                            compatibility2(OTHER, VT220);
                            nemo_underline_style(term, 0);
                            break;
                          case 23:
                            term->curr_attr &= ~ATTR_ITALIC;
                            break;
                          case 28:
                            term->curr_attr &= ~ATTR_CONCEAL;
                            break;
                          case 25:      /* disable blink */
                            compatibility2(OTHER, VT220);
                            term->curr_attr &= ~ATTR_BLINK;
                            break;
                          case 27:      /* disable reverse video */
                            compatibility2(OTHER, VT220);
                            term->curr_attr &= ~ATTR_REVERSE;
                            break;
                          case 29:      /* disable strikethrough */
                            term->curr_attr &= ~ATTR_STRIKE;
                            break;
                          case 51:      /* ECMA-48 framed */
                            term->curr_truecolour.decoration |= DECOR_FRAMED;
                            break;
                          case 52:      /* ECMA-48 encircled */
                            term->curr_truecolour.decoration |= DECOR_ENCIRCLED;
                            break;
                          case 54:
                            term->curr_truecolour.decoration &= ~DECOR_ENCLOSURES;
                            break;
                          case 53:      /* ECMA-48 overline */
                            term->curr_truecolour.decoration |= DECOR_OVERLINE;
                            break;
                          case 55:
                            term->curr_truecolour.decoration &= ~DECOR_OVERLINE;
                            break;
                          case 60: case 61: case 62: case 63: case 64:
                            /* ECMA-48 ideogram aspects are independent. */
                            term->curr_truecolour.decoration |=
                                DECOR_IDEO_UNDERLINE << (term->esc_args[i]-60);
                            break;
                          case 65:
                            term->curr_truecolour.decoration &= ~DECOR_IDEOGRAMS;
                            break;
                          case 30:
                          case 31:
                          case 32:
                          case 33:
                          case 34:
                          case 35:
                          case 36:
                          case 37:
                            /* foreground */
                            term->curr_truecolour.fg.enabled = false;
                            term->curr_attr &= ~ATTR_FGMASK;
                            term->curr_attr |=
                                (term->esc_args[i] - 30)<<ATTR_FGSHIFT;
                            break;
                          case 90:
                          case 91:
                          case 92:
                          case 93:
                          case 94:
                          case 95:
                          case 96:
                          case 97:
                            /* aixterm-style bright foreground */
                            term->curr_truecolour.fg.enabled = false;
                            term->curr_attr &= ~ATTR_FGMASK;
                            term->curr_attr |=
                                ((term->esc_args[i] - 90 + 8)
                                 << ATTR_FGSHIFT);
                            break;
                          case 39:      /* default-foreground */
                            term->curr_truecolour.fg.enabled = false;
                            term->curr_attr &= ~ATTR_FGMASK;
                            term->curr_attr |= ATTR_DEFFG;
                            break;
                          case 40:
                          case 41:
                          case 42:
                          case 43:
                          case 44:
                          case 45:
                          case 46:
                          case 47:
                            /* background */
                            term->curr_truecolour.bg.enabled = false;
                            term->curr_attr &= ~ATTR_BGMASK;
                            term->curr_attr |=
                                (term->esc_args[i] - 40)<<ATTR_BGSHIFT;
                            break;
                          case 100:
                          case 101:
                          case 102:
                          case 103:
                          case 104:
                          case 105:
                          case 106:
                          case 107:
                            /* aixterm-style bright background */
                            term->curr_truecolour.bg.enabled = false;
                            term->curr_attr &= ~ATTR_BGMASK;
                            term->curr_attr |=
                                ((term->esc_args[i] - 100 + 8)
                                 << ATTR_BGSHIFT);
                            break;
                          case 49:      /* default-background */
                            term->curr_truecolour.bg.enabled = false;
                            term->curr_attr &= ~ATTR_BGMASK;
                            term->curr_attr |= ATTR_DEFBG;
                            break;

                            /*
                             * 256-colour and true-colour
                             * sequences. A 256-colour
                             * foreground is selected by a
                             * sequence of 3 arguments in the
                             * form 38;5;n, where n is in the
                             * range 0-255. A true-colour RGB
                             * triple is selected by 5 args of
                             * the form 38;2;r;g;b. Replacing
                             * the initial 38 with 48 in both
                             * cases selects the same colour
                             * as the background.
                             */
                          case 38:
                          case 48:
                          case 58:
                            nemo_sgr_colour(term, &i);
                            break;
                          case 59:
                            term->curr_truecolour.decoration &= ~UNDER_COLOUR_MASK;
                            break;
                        }
                        }
                        set_erase_char(term);
                        break;
                      case 's':       /* DECSLRM, or ANSI cursor save */
                        if (!term->lrmm) save_cursor(term, true);
                        else {
                            unsigned l = def(term->esc_args[0], 1);
                            unsigned r = term->esc_nargs < 2 ? term->cols : def(term->esc_args[1], term->cols);
                            l = min(l, (unsigned)term->cols); r = min(r, (unsigned)term->cols);
                            if (l < r) {
                                term->marg_l = l-1; term->marg_r = r-1;
                                move(term, term->dec_om ? term->marg_l : 0,
                                     term->dec_om ? term->marg_t : 0, 0);
                                seen_disp_event(term);
                            }
                        }
                        break;
                      case ANSI_QUE('s'): /* XTSAVE */
                      case ANSI_QUE('r'): /* XTRESTORE */
                        for (int i = 0; i < term->esc_nargs; i++)
                            nemo_saved_dec_mode(term, term->esc_args[i], c == 's');
                        break;
                      case ANSI('u', '&'): /* DECRQUPSS */
                        compatibility(VT320);
                        nemo_charset_report_preferred(term);
                        break;
                      case 'u':       /* restore cursor */
                        save_cursor(term, false);
                        break;
                      case ANSI('m', '>'):
                        nemo_modify_keys_setting(term, false);
                        break;
                      case ANSI('f', '>'):
                        nemo_modify_keys_setting(term, true);
                        break;
                      case ANSI('m', 1):
                        nemo_modify_keys_query(term, false);
                        break;
                      case ANSI('g', 1): /* documented XTQFMTKEYS */
                      case ANSI('g', '>'): /* current xterm parser's spelling */
                        nemo_modify_keys_query(term, true);
                        break;
                      case ANSI('n', '>'):
                        if (term->esc_nargs == 1 && term->esc_args[0] == 4) {
                            term->modify_keys.level = -1;
                            term->modify_keys.ignore = 0;
                        }
                        break;
                      case ANSI('u', 1): /* kitty keyboard flags query */
                        if (term->esc_nargs == 1 && !term->esc_arg_present && term->ldisc) {
                            char reply[24];
                            int n = sprintf(reply, "\033[?%uu", nemo_keyboard_flags(
                                &term->keyboard[term->alt_which != 0]));
                            nemo_protocol_send(term, reply, n);
                        }
                        break;
                      case ANSI('u', '='):
                        if (term->esc_nargs <= 2)
                            nemo_keyboard_set(&term->keyboard[term->alt_which != 0],
                                term->esc_args[0], term->esc_arg_present & 2 ? term->esc_args[1] : 1);
                        break;
                      case ANSI('u', '>'):
                        if (term->esc_nargs == 1)
                            nemo_keyboard_push(&term->keyboard[term->alt_which != 0], term->esc_args[0]);
                        break;
                      case ANSI('u', '<'):
                        if (term->esc_nargs == 1)
                            nemo_keyboard_pop(&term->keyboard[term->alt_which != 0],
                                term->esc_arg_present & 1 ? term->esc_args[0] : 1);
                        break;
                      case 't': /* DECSLPP: set page size - ie window height */
                        /*
                         * VT340/VT420 sequence DECSLPP, DEC only allows values
                         *  24/25/36/48/72/144 other emulators (eg dtterm) use
                         * illegal values (eg first arg 1..9) for window changing
                         * and reports.
                         */
                        if (term->esc_has_subargs || term->esc_overflow) break;
                        if (term->esc_args[0] >= 24) {
                            compatibility(VT340TEXT);
                            nemo_request_window_size(term, -1,
                                nemo_window_parameter(term, 0), false);
                            deselect(term);
                        } else if (term->esc_nargs >= 1 &&
                                   term->esc_args[0] >= 1 &&
                                   term->esc_args[0] < 24) {
                            compatibility(OTHER);

                            switch (term->esc_args[0]) {
                              case 1:
                                term->win_minimise_pending = true;
                                term->win_minimise_enable = false;
                                term_schedule_update(term);
                                break;
                              case 2:
                                term->win_minimise_pending = true;
                                term->win_minimise_enable = true;
                                term_schedule_update(term);
                                break;
                              case 3:
                                if (term->esc_nargs >= 3) {
                                    if (!term->no_remote_resize) {
                                        term->win_move_pending = true;
                                        term->win_move_pending_x =
                                            def(term->esc_args[1], 0);
                                        term->win_move_pending_y =
                                            def(term->esc_args[2], 0);
                                        term_schedule_update(term);
                                    }
                                }
                                break;
                              case 4:
                                nemo_request_window_size(term,
                                    nemo_window_parameter(term, 2),
                                    nemo_window_parameter(term, 1), true);
                                break;
                              case 5:
                                /* move to top */
                                term->win_zorder_pending = true;
                                term->win_zorder_top = true;
                                term_schedule_update(term);
                                break;
                              case 6:
                                /* move to bottom */
                                term->win_zorder_pending = true;
                                term->win_zorder_top = false;
                                term_schedule_update(term);
                                break;
                              case 7:
                                term->win_refresh_pending = true;
                                term_schedule_update(term);
                                break;
                              case 8:
                                nemo_request_window_size(term,
                                    nemo_window_parameter(term, 2),
                                    nemo_window_parameter(term, 1), false);
                                break;
                              case 9:
                                if (term->esc_nargs >= 2) {
                                    term->win_maximise_pending = true;
                                    term->win_maximise_enable =
                                        term->esc_args[1];
                                    term_schedule_update(term);
                                }
                                break;
                              case 11: case 13: case 14: case 15:
                              case 16: case 18: case 19:
                                nemo_query_geometry(term, term->esc_args[0]);
                                break;
                              case 20:
                                nemo_query_title(term, true);
                                break;
                              case 21:
                                nemo_query_title(term, false);
                                break;
                              case 22: case 23:
                                nemo_title_stack_op(term, term->esc_args[0] == 22);
                                break;
                            }
                        }
                        break;
                      case ANSI_QUE('S'): /* XTSMGRAPHICS */
                        nemo_graphics_query(term);
                        break;
                      case 'S':         /* SU: Scroll up */
                        CLAMP(term->esc_args[0], term->rows);
                        compatibility(SCOANSI);
                        scroll(term, term->marg_t, term->marg_b,
                               def(term->esc_args[0], 1), true);
                        break;
                      case '^':         /* SD alias, no mouse handshake */
                      case 'T':         /* highlight handshake or SD */
                        if (c == 'T' && (term->esc_nargs > 1 ||
                            (term->mouse_highlight == HIGHLIGHT_WAIT && !term->esc_args[0]))) {
                            nemo_highlight_request(term);
                            break;
                        }
                        CLAMP(term->esc_args[0], term->rows);
                        compatibility(SCOANSI);
                        scroll(term, term->marg_t, term->marg_b,
                               -def(term->esc_args[0], 1), true);
                        break;
                      case ANSI('|', '*'): /* DECSNLS */
                        /*
                         * Set number of lines on screen
                         * VT420 uses VGA like hardware and can
                         * support any size in reasonable range
                         * (24..49 AIUI) with no default specified.
                         */
                        compatibility(VT420);
                        if (term->esc_nargs == 1 && term->esc_args[0] > 0) {
                            if (!term->no_remote_resize)
                                term_request_resize(
                                    term,
                                    term->cols,
                                    def(term->esc_args[0], term->conf_height));
                            deselect(term);
                        }
                        break;
                      case ANSI('|', '$'): /* DECSCPP */
                        /*
                         * Set number of columns per page
                         * Docs imply range is only 80 or 132, but
                         * I'll allow any.
                         */
                        compatibility(VT340TEXT);
                        if (term->esc_nargs <= 1) {
                            if (!term->no_remote_resize)
                                term_request_resize(
                                    term,
                                    def(term->esc_args[0], term->conf_width),
                                    term->rows);
                            deselect(term);
                        }
                        break;
                      case 'X': {   /* ECH: write N spaces w/o moving cursor */
                        /* XXX VTTEST says this is vt220, vt510 manual
                         * says vt100 */
                        compatibility(ANSIMIN);
                        CLAMP(term->esc_args[0], term->cols);
                        int n = def(term->esc_args[0], 1);
                        if (term->protection_mode & NEMO_PROTECT_ISO) {
                            nemo_erase_row(term, term->curs.y, term->curs.x,
                                           term->curs.x + min(n, term->cols-term->curs.x),
                                           true, NEMO_ERASE_BCE);
                            scrlineptr(term->curs.y)->lattr &=
                                ~(LATTR_WRAPPED | LATTR_WRAPPED2 | LATTR_CURSOR_WRAPPED);
                            term->wrapnext = false;
                            seen_disp_event(term);
                            break;
                        }
                        pos cursplus;
                        int p = term->curs.x;
                        termline *cline = scrlineptr(term->curs.y);

                        check_trust_status(term, cline);
                        if (n > term->cols - term->curs.x)
                            n = term->cols - term->curs.x;
                        cursplus = term->curs;
                        cursplus.x += n;
                        check_boundary(term, term->curs.x, term->curs.y);
                        check_boundary(term, term->curs.x+n, term->curs.y);
                        check_selection(term, term->curs, cursplus);
                        nemo_images_erase(term, term->curs, cursplus);
                        termchar blank = term->erase_char;
                        blank.truecolour.decoration &= ~CELL_UNDRAWN;
                        while (n--)
                            copy_termchar(cline, p++, &blank);
                        seen_disp_event(term);
                        break;
                      }
                      case 'x':       /* DECREQTPARM: report terminal characteristics */
                        compatibility(VT100);
                        if (term->ldisc) {
                            char buf[32];
                            int i = def(term->esc_args[0], 0);
                            if (i == 0 || i == 1) {
                                strcpy(buf, "\033[2;1;1;112;112;1;0x");
                                buf[2] += i;
                                nemo_protocol_send(term, buf, 20);
                            }
                        }
                        break;
                      case 'I':           /* CHT */
                      case 'Z':           /* CBT */
                        compatibility(OTHER);
                        nemo_tabulate(term, term->esc_args[0], c == 'I');
                        break;
                      case ANSI('c', '='):      /* DA3, or legacy SCO cursor */
                        /* The default PuTTY superset includes SCO, whose
                         * cursor control collides with DA3. Only explicit
                         * SCO mode (DECSCL 42) keeps that legacy meaning. */
                        if (term->compatibility_level != TM_SCOANSI) {
                            compatibility(VT420);
                            static const char reply[] = "\033P!|00000000\033\\";
                            if (term->ldisc &&
                                (term->esc_has_subargs || term->esc_args[0] == 0))
                                nemo_protocol_send(term, reply, sizeof(reply)-1);
                            break;
                        }
                        compatibility(SCOANSI);
                        switch(term->esc_args[0]) {
                          case 0:  /* hide cursor */
                            term->cursor_on = false;
                            break;
                          case 1:  /* restore cursor */
                            term->big_cursor = false;
                            term->cursor_on = true;
                            break;
                          case 2:  /* block cursor */
                            term->big_cursor = true;
                            term->cursor_on = true;
                            break;
                        }
                        break;
                      case ANSI('C', '='):
                        /*
                         * set cursor start on scanline esc_args[0] and
                         * end on scanline esc_args[1].If you set
                         * the bottom scan line to a value less than
                         * the top scan line, the cursor will disappear.
                         */
                        compatibility(SCOANSI);
                        if (term->esc_nargs >= 2) {
                            if (term->esc_args[0] > term->esc_args[1])
                                term->cursor_on = false;
                            else
                                term->cursor_on = true;
                        }
                        break;
                      case ANSI('D', '='):
                        compatibility(SCOANSI);
                        term->blink_is_real = false;
                        term_schedule_tblink(term);
                        if (term->esc_args[0]>=1)
                            term->curr_attr |= ATTR_BLINK;
                        else
                            term->curr_attr &= ~ATTR_BLINK;
                        break;
                      case ANSI('E', '='):
                        compatibility(SCOANSI);
                        term->blink_is_real = (term->esc_args[0] >= 1);
                        term_schedule_tblink(term);
                        break;
                      case ANSI('F', '='):      /* set normal foreground */
                        compatibility(SCOANSI);
                        if (term->esc_args[0] < 16) {
                            long colour =
                                (sco2ansicolour[term->esc_args[0] & 0x7] |
                                 (term->esc_args[0] & 0x8)) <<
                                ATTR_FGSHIFT;
                            term->curr_attr &= ~ATTR_FGMASK;
                            term->curr_attr |= colour;
                            term->curr_truecolour.fg = optionalrgb_none;
                            term->default_attr &= ~ATTR_FGMASK;
                            term->default_attr |= colour;
                            set_erase_char(term);
                        }
                        break;
                      case ANSI('G', '='):      /* set normal background */
                        compatibility(SCOANSI);
                        if (term->esc_args[0] < 16) {
                            long colour =
                                (sco2ansicolour[term->esc_args[0] & 0x7] |
                                 (term->esc_args[0] & 0x8)) <<
                                ATTR_BGSHIFT;
                            term->curr_attr &= ~ATTR_BGMASK;
                            term->curr_attr |= colour;
                            term->curr_truecolour.bg = optionalrgb_none;
                            term->default_attr &= ~ATTR_BGMASK;
                            term->default_attr |= colour;
                            set_erase_char(term);
                        }
                        break;
                      case ANSI('L', '='):
                        compatibility(SCOANSI);
                        term->use_bce = (term->esc_args[0] <= 0);
                        set_erase_char(term);
                        break;
                      case ANSI('p', '"'): /* DECSCL: set compat level */
                        if (term->esc_args[0] >= 61 && term->esc_args[0] <= 65) {
                            nemo_soft_reset(term);
                            /* Level 1 preserves transmission mode. Invalid Pc
                             * preserves it too, even when the level changes. */
                            unsigned pc = term->esc_nargs > 1 ? term->esc_args[1] : 0;
                            if (term->esc_args[0] > 61 && pc <= 2)
                                term->c1_8bit = pc != 1;
                        }
                        /*
                         * Allow the host to make this emulator a
                         * 'perfect' VT102. This first appeared in
                         * the VT220, but we do need to get back to
                         * PuTTY mode so I won't check it.
                         *
                         * The arg in 40..42,50 are a PuTTY extension.
                         * The 2nd arg selects protocol transmission above.
                         *
                         * Setting VT102 mode should also change
                         * the Fkeys to generate PF* codes as a
                         * real VT102 has no Fkeys. The VT220 does
                         * this, F11..F13 become ESC,BS,LF other
                         * Fkeys send nothing.
                         *
                         * Note ESC c will NOT change this!
                         */

                        switch (term->esc_args[0]) {
                          case 61:
                            term->compatibility_level &= ~TM_VTXXX;
                            term->compatibility_level |= TM_VT102;
                            break;
                          case 62:
                            term->compatibility_level &= ~TM_VTXXX;
                            term->compatibility_level |= TM_VT220;
                            break;
                          case 63:
                            term->compatibility_level &= ~TM_VTXXX;
                            term->compatibility_level |= TM_VT340;
                            break;
                          case 64:
                            term->compatibility_level &= ~TM_VTXXX;
                            term->compatibility_level |= TM_VT420;
                            break;

                          case 65:
                            term->compatibility_level |= TM_VTXXX;
                            break;
                          default:
                            break;

                          case 40:
                            term->compatibility_level &= TM_VTXXX;
                            break;
                          case 41:
                            term->compatibility_level = TM_PUTTY;
                            break;
                          case 42:
                            term->compatibility_level = TM_SCOANSI;
                            break;

                          case ARG_DEFAULT:
                            term->compatibility_level = TM_PUTTY;
                            break;
                          case 50:
                            break;
                        }

                        /* Change the response to CSI c */
                        if (term->esc_args[0] == 50) {
                            int i;
                            char lbuf[64];
                            strcpy(term->id_string, "\033[?");
                            for (i = 1; i < term->esc_nargs; i++) {
                                if (i != 1)
                                    strcat(term->id_string, ";");
                                sprintf(lbuf, "%u", term->esc_args[i]);
                                strcat(term->id_string, lbuf);
                            }
                            strcat(term->id_string, "c");
                        }
#if 0
                        /* Is this a good idea ?
                         * Well we should do a soft reset at this point ...
                         */
                        if (!has_compat(VT420) && has_compat(VT100)) {
                            if (!term->no_remote_resize)
                                term_request_resize(term,
                                                    term->reset_132 ? 132 : 80,
                                                    24);
                        }
#endif
                        break;
                    }
                break;
              case SEEN_OSC:
                switch (c) {
                  case 'P':            /* Linux palette sequence */
                    term->termstate = SEEN_OSC_P;
                    term->osc_strlen = 0;
                    term->osc_overflow = false;
                    break;
                  case 'R':            /* Linux palette reset */
                    palette_reset(term, false);
                    term_invalidate(term);
                    term->termstate = TOPLEVEL;
                    break;
                  case 'W':            /* word-set */
                    term->termstate = SEEN_OSC_W;
                    term->osc_type = OSCLIKE_OSC_W;
                    break;
                  case '0':
                  case '1':
                  case '2':
                  case '3':
                  case '4':
                  case '5':
                  case '6':
                  case '7':
                  case '8':
                  case '9':
                    if (term->esc_args[term->esc_nargs-1] <= UINT_MAX / 10 &&
                        term->esc_args[term->esc_nargs-1] * 10 <= UINT_MAX - c - '0')
                        term->esc_args[term->esc_nargs-1] =
                            10 * term->esc_args[term->esc_nargs-1] + c - '0';
                    else
                        term->esc_args[term->esc_nargs-1] = UINT_MAX;
                    break;
                  case 0x9C:
                    /* Terminate even though we aren't in OSC_STRING yet */
                    do_osc(term, c == 7);
                    term->termstate = TOPLEVEL;
                    break;
                  case 0xC2:
                    if (in_utf(term)) {
                        /* Or be prepared for the UTF-8 version of that */
                        term->termstate = OSC_MAYBE_ST_UTF8;
                    }
                    break;
                  default:
                    /*
                     * _Most_ other characters here terminate the
                     * immediate parsing of the OSC sequence and go
                     * into OSC_STRING state, but we deal with a
                     * couple of exceptions first.
                     */
                    if (c == 'L' && term->esc_args[0] == 2) {
                        /*
                         * Grotty hack to support xterm and DECterm title
                         * sequences concurrently.
                         */
                        term->esc_args[0] = 1;
                    } else {
                        term->termstate = OSC_STRING;
                        term->osc_strlen = 0;
                        /* OSC 8 requires the separator after its number.
                         * Preserve PuTTY's permissive title parsing otherwise. */
                        term->osc_overflow = (term->esc_args[0] == 8 || term->esc_args[0] == 52) && c != ';';
                        if (term->esc_args[0] == 52 && c == ';')
                            nemo_osc52_begin(&term->osc52,
                                conf_get_bool(term->conf, CONF_nemo_osc52_write),
                                conf_get_bool(term->conf, CONF_nemo_osc52_read));
                    }
                }
                break;
              case OSC_STRING:
                /*
                 * OSC sequences can be terminated or aborted in
                 * various ways.
                 *
                 * The official way to terminate an OSC, per written
                 * standards, is the String Terminator, SC. That can
                 * appear in a 7-bit two-character form ESC \, or as
                 * an 8-bit C1 control 0x9C.
                 *
                 * We only accept 0x9C in circumstances where it
                 * doesn't interfere with our main character set
                 * processing: so in ISO 8859-1, for example, the byte
                 * 0x9C is interpreted as ST, but in CP437 it's
                 * interpreted as an ordinary printing character (as
                 * it happens, the pound sign), because you might
                 * perfectly well want to put it in the window title
                 * like any other printing character.
                 *
                 * In particular, in UTF-8 mode, 0x9C is a perfectly
                 * valid continuation byte for an ordinary printing
                 * character, so we don't accept the C1 control form
                 * of ST unless it appears as a full UTF-8 character
                 * in its own right, i.e. bytes 0xC2 0x9C.
                 *
                 * BEL is also treated as a clean termination of OSC,
                 * which I believe was a behaviour introduced by
                 * xterm.
                 *
                 * To prevent run-on storage of OSC data forever if
                 * emission of a control sequence is interrupted, we
                 * also treat various control characters as illegal,
                 * so that they abort the OSC without processing it
                 * and return to TOPLEVEL state. These are CR, LF, and
                 * any ESC that is *not* followed by \.
                 */

                if ((!nemo_osc_title(term) && (c == '\012' || c == '\015')) ||
                    (nemo_osc_title(term) && (c == 0x18 || c == 0x1a)) ||
                    (term->osc_type == OSCLIKE_OSC && term->esc_args[0] == 52 &&
                     (c == 0x18 || c == 0x1a))) {
                    /* CR or LF aborts */
                    nemo_osc52_cancel(term->osc52);
                    term->termstate = TOPLEVEL;
                    break;
                }

                if (c == '\033') {
                    /* ESC goes into a state where we wait to see if
                     * the next character is \ */
                    term->termstate = OSC_MAYBE_ST;
                    break;
                }

                if (c == '\007' || (c == 0x9C && !in_utf(term) &&
                                    term->ucsdata->unitab_ctrl[c] != 0xFF)) {
                    /* BEL, or the C1 ST appearing as a one-byte
                     * encoding, cleanly terminates the OSC right here */
                    do_osc(term, c == 7);
                    term->termstate = TOPLEVEL;
                    break;
                }

                if (c == 0xC2 && in_utf(term) && !nemo_osc_title(term)) {
                    /* 0xC2 is the UTF-8 character that might
                     * introduce the encoding of C1 ST */
                    term->termstate = OSC_MAYBE_ST_UTF8;
                    break;
                }

                /* Anything else gets added to the string */
                if (term->osc_type == OSCLIKE_OSC && term->esc_args[0] == 52) {
                    nemo_osc52_feed(term->osc52, (unsigned char)c);
                } else if (term->osc_strlen < osc_string_limit(term))
                    term->osc_string[term->osc_strlen++] = (char)c;
                else
                    term->osc_overflow = true;
                break;
              case OSC_MAYBE_ST_UTF8:
                /* In UTF-8 mode, we've seen C2, so are we now seeing
                 * 9C? */
                if (c == 0x9C) {
                    /* Yes, so cleanly terminate the OSC */
                    do_osc(term, c == 7);
                    term->termstate = TOPLEVEL;
                    break;
                }
                /* No, so append the pending C2 byte to the OSC string
                 * followed by the current character, and go back to
                 * OSC string accumulation */
                if (term->osc_type == OSCLIKE_OSC && term->esc_args[0] == 52) {
                    nemo_osc52_feed(term->osc52, 0xc2);
                    if (c == '\012' || c == '\015' || c == 0x18 || c == 0x1a) {
                        nemo_osc52_cancel(term->osc52);
                        term->termstate = TOPLEVEL;
                    } else if (c == '\033') term->termstate = OSC_MAYBE_ST;
                    else if (c == '\007') {
                        do_osc(term, true);
                        term->termstate = TOPLEVEL;
                    } else if (c != 0xc2) {
                        nemo_osc52_feed(term->osc52, (unsigned char)c);
                        term->termstate = OSC_STRING;
                    }
                    break;
                }
                if (term->osc_strlen < osc_string_limit(term))
                    term->osc_string[term->osc_strlen++] = 0xC2;
                else
                    term->osc_overflow = true;
                if (term->osc_strlen < osc_string_limit(term))
                    term->osc_string[term->osc_strlen++] = (char)c;
                else
                    term->osc_overflow = true;
                term->termstate = OSC_STRING;
                break;
              case SEEN_OSC_P: {
                int max = (term->osc_strlen == 0 ? 21 : 15);
                int val;
                if ((int)c >= '0' && (int)c <= '9')
                    val = c - '0';
                else if ((int)c >= 'A' && (int)c <= 'A' + max - 10)
                    val = c - 'A' + 10;
                else if ((int)c >= 'a' && (int)c <= 'a' + max - 10)
                    val = c - 'a' + 10;
                else {
                    term->termstate = TOPLEVEL;
                    break;
                }
                term->osc_string[term->osc_strlen++] = val;
                if (term->osc_strlen >= 7) {
                    unsigned oscp_index = term->osc_string[0];
                    assert(oscp_index < OSCP_NCOLOURS);
                    unsigned osc4_index =
                        colour_indices_oscp_to_osc4[oscp_index];

                    rgb *value = &term->subpalettes[SUBPAL_SESSION].values[
                        osc4_index];
                    value->r = term->osc_string[1] * 16 + term->osc_string[2];
                    value->g = term->osc_string[3] * 16 + term->osc_string[4];
                    value->b = term->osc_string[5] * 16 + term->osc_string[6];
                    term->subpalettes[SUBPAL_SESSION].present[
                        osc4_index] = true;

                    palette_rebuild(term);

                    term->termstate = TOPLEVEL;
                }
                break;
              }
              case SEEN_OSC_W:
                switch (c) {
                  case '0':
                  case '1':
                  case '2':
                  case '3':
                  case '4':
                  case '5':
                  case '6':
                  case '7':
                  case '8':
                  case '9':
                    if (term->esc_args[0] <= UINT_MAX / 10 &&
                        term->esc_args[0] * 10 <= UINT_MAX - c - '0')
                        term->esc_args[0] = 10 * term->esc_args[0] + c - '0';
                    else
                        term->esc_args[0] = UINT_MAX;
                    break;
                  case 0x9C:
                    /* Terminate even though we aren't in OSC_STRING yet */
                    do_osc(term, c == 7);
                    term->termstate = TOPLEVEL;
                    break;
                  case 0xC2:
                    if (in_utf(term)) {
                        /* Or be prepared for the UTF-8 version of that */
                        term->termstate = OSC_MAYBE_ST_UTF8;
                    }
                    break;
                  default:
                    term->termstate = OSC_STRING;
                    term->osc_strlen = 0;
                    term->osc_overflow = false;
                }
                break;
              case VT52_ESC:
                term->termstate = TOPLEVEL;
                switch (c) {
                  case 'A':
                    move(term, term->curs.x, term->curs.y - 1, 1);
                    break;
                  case 'B':
                    move(term, term->curs.x, term->curs.y + 1, 1);
                    break;
                  case 'C':
                    move(term, term->curs.x + 1, term->curs.y, 1);
                    break;
                  case 'D':
                    move(term, term->curs.x - 1, term->curs.y, 1);
                    break;
                    /*
                     * From the VT100 Manual
                     * NOTE: The special graphics characters in the VT100
                     *       are different from those in the VT52
                     *
                     * From VT102 manual:
                     *       137 _  Blank             - Same
                     *       140 `  Reserved          - Humm.
                     *       141 a  Solid rectangle   - Similar
                     *       142 b  1/                - Top half of fraction for the
                     *       143 c  3/                - subscript numbers below.
                     *       144 d  5/
                     *       145 e  7/
                     *       146 f  Degrees           - Same
                     *       147 g  Plus or minus     - Same
                     *       150 h  Right arrow
                     *       151 i  Ellipsis (dots)
                     *       152 j  Divide by
                     *       153 k  Down arrow
                     *       154 l  Bar at scan 0
                     *       155 m  Bar at scan 1
                     *       156 n  Bar at scan 2
                     *       157 o  Bar at scan 3     - Similar
                     *       160 p  Bar at scan 4     - Similar
                     *       161 q  Bar at scan 5     - Similar
                     *       162 r  Bar at scan 6     - Same
                     *       163 s  Bar at scan 7     - Similar
                     *       164 t  Subscript 0
                     *       165 u  Subscript 1
                     *       166 v  Subscript 2
                     *       167 w  Subscript 3
                     *       170 x  Subscript 4
                     *       171 y  Subscript 5
                     *       172 z  Subscript 6
                     *       173 {  Subscript 7
                     *       174 |  Subscript 8
                     *       175 }  Subscript 9
                     *       176 ~  Paragraph
                     *
                     */
                  case 'F':
                    term->cset_attr[term->cset = 0] = CSET_LINEDRW;
                    break;
                  case 'G':
                    term->cset_attr[term->cset = 0] = CSET_ASCII;
                    break;
                  case 'H':
                    move(term, 0, 0, 0);
                    break;
                  case 'I':
                    if (term->curs.y == 0) {
                        scroll(term, 0, term->rows - 1, -1, true);
                    } else if (term->curs.y > 0) {
                        term->curs.y--;
                        seen_disp_event(term);
                    }
                    term->wrapnext = false;
                    break;
                  case 'J':
                    erase_lots(term, false, false, true);
                    if (term->scroll_on_disp)
                        term->disptop = 0;
                    break;
                  case 'K':
                    erase_lots(term, true, false, true);
                    break;
#if 0
                  case 'V':
                    /* XXX Print cursor line */
                    break;
                  case 'W':
                    /* XXX Start controller mode */
                    break;
                  case 'X':
                    /* XXX Stop controller mode */
                    break;
#endif
                  case 'Y':
                    term->termstate = VT52_Y1;
                    break;
                  case 'Z':
                    if (term->ldisc)
                        nemo_protocol_send(term, "\033/Z", 3);
                    break;
                  case '=':
                    term->app_keypad_keys = true;
                    break;
                  case '>':
                    term->app_keypad_keys = false;
                    break;
                  case '<':
                    /* XXX This should switch to VT100 mode not current or default
                     *     VT mode. But this will only have effect in a VT220+
                     *     emulation.
                     */
                    term->vt52_mode = false;
                    term->blink_is_real = term->blinktext;
                    term_schedule_tblink(term);
                    break;
#if 0
                  case '^':
                    /* XXX Enter auto print mode */
                    break;
                  case '_':
                    /* XXX Exit auto print mode */
                    break;
                  case ']':
                    /* XXX Print screen */
                    break;
#endif

#ifdef VT52_PLUS
                  case 'E':
                    /* compatibility(ATARI) */
                    move(term, 0, 0, 0);
                    erase_lots(term, false, false, true);
                    if (term->scroll_on_disp)
                        term->disptop = 0;
                    break;
                  case 'L':
                    /* compatibility(ATARI) */
                    if (term->curs.y <= term->marg_b)
                        scroll(term, term->curs.y, term->marg_b, -1, false);
                    break;
                  case 'M':
                    /* compatibility(ATARI) */
                    if (term->curs.y <= term->marg_b)
                        scroll(term, term->curs.y, term->marg_b, 1, true);
                    break;
                  case 'b':
                    /* compatibility(ATARI) */
                    term->termstate = VT52_FG;
                    break;
                  case 'c':
                    /* compatibility(ATARI) */
                    term->termstate = VT52_BG;
                    break;
                  case 'd':
                    /* compatibility(ATARI) */
                    erase_lots(term, false, true, false);
                    if (term->scroll_on_disp)
                        term->disptop = 0;
                    break;
                  case 'e':
                    /* compatibility(ATARI) */
                    term->cursor_on = true;
                    seen_disp_event(term);
                    break;
                  case 'f':
                    /* compatibility(ATARI) */
                    term->cursor_on = false;
                    seen_disp_event(term);
                    break;
                    /* case 'j': Save cursor position - broken on ST */
                    /* case 'k': Restore cursor position */
                  case 'l':
                    /* compatibility(ATARI) */
                    erase_lots(term, true, true, true);
                    term->curs.x = 0;
                    term->wrapnext = false;
                    break;
                  case 'o':
                    /* compatibility(ATARI) */
                    erase_lots(term, true, true, false);
                    break;
                  case 'p':
                    /* compatibility(ATARI) */
                    term->curr_attr |= ATTR_REVERSE;
                    break;
                  case 'q':
                    /* compatibility(ATARI) */
                    term->curr_attr &= ~ATTR_REVERSE;
                    break;
                  case 'v':            /* wrap Autowrap on - Wyse style */
                    /* compatibility(ATARI) */
                    term->wrap = true;
                    break;
                  case 'w':            /* Autowrap off */
                    /* compatibility(ATARI) */
                    term->wrap = false;
                    term->wrapnext = false;
                    break;

                  case 'R':
                    /* compatibility(OTHER) */
                    term->vt52_bold = false;
                    term->curr_attr = ATTR_DEFAULT;
                    term->curr_truecolour.fg = optionalrgb_none;
                    term->curr_truecolour.bg = optionalrgb_none;
                    term->curr_truecolour.decoration = 0;
                    set_erase_char(term);
                    break;
                  case 'S':
                    /* compatibility(VI50) */
                    nemo_underline_style(term, 1);
                    break;
                  case 'W':
                    /* compatibility(VI50) */
                    nemo_underline_style(term, 0);
                    break;
                  case 'U':
                    /* compatibility(VI50) */
                    term->vt52_bold = true;
                    term->curr_attr |= ATTR_BOLD;
                    break;
                  case 'T':
                    /* compatibility(VI50) */
                    term->vt52_bold = false;
                    term->curr_attr &= ~ATTR_BOLD;
                    break;
#endif
                }
                break;
              case VT52_Y1:
                term->termstate = VT52_Y2;
                move(term, term->curs.x, c - ' ', 0);
                break;
              case VT52_Y2:
                term->termstate = TOPLEVEL;
                move(term, c - ' ', term->curs.y, 0);
                break;

#ifdef VT52_PLUS
              case VT52_FG:
                term->termstate = TOPLEVEL;
                term->curr_attr &= ~ATTR_FGMASK;
                term->curr_attr &= ~ATTR_BOLD;
                term->curr_attr |= (c & 0xF) << ATTR_FGSHIFT;
                set_erase_char(term);
                break;
              case VT52_BG:
                term->termstate = TOPLEVEL;
                term->curr_attr &= ~ATTR_BGMASK;
                term->curr_attr &= ~ATTR_BLINK;
                term->curr_attr |= (c & 0xF) << ATTR_BGSHIFT;
                set_erase_char(term);
                break;
#endif
              default: break;          /* placate gcc warning about enum use */
            }
        /* Cell writers/erasers invalidate affected selections themselves.
         * Only cursor movement needs this extra point check. Otherwise every
         * byte of an incoming query clears a selection covering the cursor. */
        if (term->selstate != NO_SELECTION && !poseq(cursor_before, term->curs)) {
            pos cursplus = term->curs;
            incpos(cursplus);
            check_selection(term, term->curs, cursplus);
        }
    }

    bufchain_consume(&term->inbuf, nchars_used);

    if (!called_from_term_data)
        win_unthrottle(term->win, bufchain_size(&term->inbuf));

    term_print_flush(term);
    if (term->logflush && term->logctx)
        logflush(term->logctx);
}

/* Wrapper on term_out with the right prototype to be a toplevel callback */
void term_out_cb(void *ctx)
{
    term_out((Terminal *)ctx, false);
}

/*
 * To prevent having to run the reasonably tricky bidi algorithm
 * too many times, we maintain a cache of the last lineful of data
 * fed to the algorithm on each line of the display.
 */
static void term_bidi_cache_clear_line(Terminal *term, size_t line)
{
    struct bidi_cache_entry *pre=&term->pre_bidi_cache[line];
    struct bidi_cache_entry *post=&term->post_bidi_cache[line];
    assert(term->bidi_cache_bytes>=post->bytes);
    term->bidi_cache_bytes-=post->bytes;
    sfree(pre->chars);sfree(post->chars);
    sfree(post->forward);sfree(post->backward);
    *pre=(struct bidi_cache_entry){.width=-1};
    *post=(struct bidi_cache_entry){.width=-1};
}

static bool term_bidi_cache_hit(Terminal *term, int line,
                                termchar *lbefore, int width, bool trusted)
{
    int i;

    if (!term->pre_bidi_cache)
        return false;                  /* cache doesn't even exist yet! */

    if (line >= term->bidi_cache_size)
        return false;                  /* cache doesn't have this many lines */

    if (!term->pre_bidi_cache[line].chars)
        return false;                  /* cache doesn't contain _this_ line */

    if (term->pre_bidi_cache[line].width != width)
        return false;                  /* line is wrong width */

    if (term->pre_bidi_cache[line].trusted != trusted)
        return false;                  /* line has wrong trust state */

    for (i = 0; i < width; i++)
        if (!termchars_equal(term->pre_bidi_cache[line].chars+i, lbefore+i))
            return false;              /* line doesn't match cache */

    term->post_bidi_cache[line].used=++term->bidi_cache_tick;
    return true;
}

static void term_bidi_cache_store(Terminal *term, int line, termchar *lbefore,
                                  termchar *lafter, bidi_char *wcTo,
                                  int width, int size, bool trusted)
{
    size_t i, j;

    if (!term->pre_bidi_cache || term->bidi_cache_size <= line) {
        j = term->bidi_cache_size;
        sgrowarray(term->pre_bidi_cache, term->bidi_cache_size, line);
        term->post_bidi_cache = sresize(term->post_bidi_cache,
                                        term->bidi_cache_size,
                                        struct bidi_cache_entry);
        while (j < term->bidi_cache_size) {
            term->pre_bidi_cache[j]=(struct bidi_cache_entry){.width=-1};
            term->post_bidi_cache[j]=(struct bidi_cache_entry){.width=-1};
            j++;
        }
    }

    term_bidi_cache_clear_line(term, line);
    size_t bytes=2*(size_t)size*TSIZE+2*(size_t)width*sizeof(int);
    /* Keep exact row/cell comparisons, but bound retained copies and maps.
     * An evicted row is recomputed for painting, cursor or mouse lookup.
     * A single unusually wide row may exceed the budget while in use. */
    while (term->bidi_cache_bytes &&
           (bytes>NEMO_BIDI_CACHE_BYTES ||
            term->bidi_cache_bytes>NEMO_BIDI_CACHE_BYTES-bytes)) {
        size_t oldest=SIZE_MAX;
        for (i=0;i<term->bidi_cache_size;i++)
            if (term->post_bidi_cache[i].bytes &&
                (oldest==SIZE_MAX || term->post_bidi_cache[i].used<term->post_bidi_cache[oldest].used)) oldest=i;
        assert(oldest!=SIZE_MAX);
        term_bidi_cache_clear_line(term, oldest);
    }

    term->pre_bidi_cache[line].width = width;
    term->pre_bidi_cache[line].trusted = trusted;
    term->pre_bidi_cache[line].chars = snewn(size, termchar);
    term->post_bidi_cache[line].width = width;
    term->post_bidi_cache[line].trusted = trusted;
    term->post_bidi_cache[line].chars = snewn(size, termchar);
    term->post_bidi_cache[line].forward = snewn(width, int);
    term->post_bidi_cache[line].backward = snewn(width, int);
    term->post_bidi_cache[line].bytes=bytes;
    term->post_bidi_cache[line].used=++term->bidi_cache_tick;
    term->bidi_cache_bytes+=bytes;

    memcpy(term->pre_bidi_cache[line].chars, lbefore, size * TSIZE);
    memcpy(term->post_bidi_cache[line].chars, lafter, size * TSIZE);
    memset(term->post_bidi_cache[line].forward, 0, width * sizeof(int));
    memset(term->post_bidi_cache[line].backward, 0, width * sizeof(int));

    for (i = j = 0; j < width; j += wcTo[i].nchars, i++) {
        int p = wcTo[i].index;

        if (p != BIDI_CHAR_INDEX_NONE) {
            assert(0 <= p && p < width);

            for (int x = 0; x < wcTo[i].nchars; x++) {
                term->post_bidi_cache[line].backward[j+x] = p+x;
                term->post_bidi_cache[line].forward[p+x] = j+x;
            }
        }
    }
}

/*
 * Prepare the bidi information for a screen line. Returns the
 * transformed list of termchars, or NULL if no transformation at
 * all took place (because bidi is disabled). If return was
 * non-NULL, auxiliary information such as the forward and reverse
 * mappings of permutation position are available in
 * term->post_bidi_cache[scr_y].*.
 */
static termchar *term_bidi_line(Terminal *term, struct termline *ldata,
                                int scr_y)
{
    termchar *lchars;
    int it;

    /* Do Arabic shaping and bidi. */
    if (!term->no_bidi || !term->no_arabicshaping ||
        (ldata->trusted && term->cols > TRUST_SIGIL_WIDTH)) {

        if (!term_bidi_cache_hit(term, scr_y, ldata->chars, term->cols,
                                 ldata->trusted)) {

            if (term->wcFromTo_size < term->cols) {
                term->wcFromTo_size = term->cols;
                term->wcFrom = sresize(term->wcFrom, term->wcFromTo_size,
                                       bidi_char);
                term->wcTo = sresize(term->wcTo, term->wcFromTo_size,
                                     bidi_char);
            }

            bool needs_processing=ldata->trusted && term->cols>TRUST_SIGIL_WIDTH;
            for (it=0; it<term->cols ; it++) {
                unsigned long uc = (ldata->chars[it].chr);

                switch (uc & CSET_MASK) {
                  case CSET_LINEDRW:
                    if (!term->rawcnp) {
                        uc = term->ucsdata->unitab_xterm[uc & 0xFF];
                        break;
                    }
                  case CSET_ASCII:
                    uc = term->ucsdata->unitab_line[uc & 0xFF];
                    break;
                  case CSET_SCOACS:
                    uc = term->ucsdata->unitab_scoacs[uc&0xFF];
                    break;
                }
                switch (uc & CSET_MASK) {
                  case CSET_ACP:
                    uc = term->ucsdata->unitab_font[uc & 0xFF];
                    break;
                  case CSET_OEMCP:
                    uc = term->ucsdata->unitab_oemcp[uc & 0xFF];
                    break;
                }

                term->wcFrom[it].origwc = term->wcFrom[it].wc =
                    (unsigned int)uc;
                term->wcFrom[it].index = it;
                term->wcFrom[it].nchars = 1;
                needs_processing |= is_rtl(uc);
            }

            /* is_rtl also covers every Arabic shaping character and bidi
             * control. Identity rows need neither two complete cell/cluster
             * copies nor forward/backward maps. Drop any older transformed
             * row so a subsequent mouse hit cannot use stale mappings. */
            if (!needs_processing) {
                if (scr_y>=0 && scr_y<term->bidi_cache_size) {
                    term_bidi_cache_clear_line(term, scr_y);
                }
                return NULL;
            }

            if (ldata->trusted && term->cols > TRUST_SIGIL_WIDTH) {
                memmove(
                    term->wcFrom + TRUST_SIGIL_WIDTH, term->wcFrom,
                    (term->cols - TRUST_SIGIL_WIDTH) * sizeof(*term->wcFrom));
                for (it = 0; it < TRUST_SIGIL_WIDTH; it++) {
                    term->wcFrom[it].origwc = term->wcFrom[it].wc =
                        (it == 0 ? TRUST_SIGIL_CHAR :
                         it == 1 ? UCSWIDE : ' ');
                    term->wcFrom[it].index = BIDI_CHAR_INDEX_NONE;
                    term->wcFrom[it].nchars = 1;
                }
            }

            int nbc = 0;
            for (it = 0; it < term->cols; it++) {
                term->wcFrom[nbc] = term->wcFrom[it];
                if (it+1 < term->cols && term->wcFrom[it+1].wc == UCSWIDE) {
                    term->wcFrom[nbc].nchars++;
                    it++;
                }
                nbc++;
            }

            if (!term->no_bidi)
                do_bidi(term->bidi_ctx, term->wcFrom, nbc);

            if (!term->no_arabicshaping) {
                do_shape(term->wcFrom, term->wcTo, nbc);
            } else {
                /* If we're not calling do_shape, we must copy the
                 * data into wcTo anyway, unchanged */
                memcpy(term->wcTo, term->wcFrom, nbc * sizeof(*term->wcTo));
            }

            if (term->ltemp_size < ldata->size) {
                term->ltemp_size = ldata->size;
                term->ltemp = sresize(term->ltemp, term->ltemp_size,
                                      termchar);
            }

            memcpy(term->ltemp, ldata->chars, ldata->size * TSIZE);

            int opos = 0;
            for (it=0; it<nbc; it++) {
                int ipos = term->wcTo[it].index;
                for (int j = 0; j < term->wcTo[it].nchars; j++) {
                    if (ipos != BIDI_CHAR_INDEX_NONE) {
                        term->ltemp[opos] = ldata->chars[ipos];
                        if (term->ltemp[opos].cc_next)
                            term->ltemp[opos].cc_next -= opos - ipos;

                        if (j > 0)
                            term->ltemp[opos].chr = UCSWIDE;
                        else if (term->wcTo[it].origwc != term->wcTo[it].wc)
                            term->ltemp[opos].chr = term->wcTo[it].wc;
                    } else {
                        term->ltemp[opos] = term->basic_erase_char;
                        term->ltemp[opos].chr =
                            j > 0 ? UCSWIDE : term->wcTo[it].origwc;
                    }
                    opos++;
                }
            }
            assert(opos == term->cols);
            term_bidi_cache_store(term, scr_y, ldata->chars,
                                  term->ltemp, term->wcTo,
                                  term->cols, ldata->size, ldata->trusted);

            lchars = term->ltemp;
        } else {
            lchars = term->post_bidi_cache[scr_y].chars;
        }
    } else {
        lchars = NULL;
    }

    return lchars;
}

static void do_paint_draw(Terminal *term, termline *ldata, int x, int y,
                          wchar_t *ch, int ccount,
                          unsigned long attr, truecolour tc)
{
    if (ch[0] == TRUST_SIGIL_CHAR) {
        assert(ldata->trusted);
        assert(ccount == 1);
        assert(attr & ATTR_WIDE);
        wchar_t tch[2];
        tch[0] = tch[1] = L' ';
        win_draw_text(term->win, x, y, tch, 2, term->basic_erase_char.attr,
                      ldata->lattr, term->basic_erase_char.truecolour);
        win_draw_trust_sigil(term->win, x, y);
    } else {
        if (ccount == 2 &&
            IS_REGIONAL_INDICATOR_LETTER(ch[0]) &&
            IS_REGIONAL_INDICATOR_LETTER(ch[1]))
            attr |= ATTR_WIDE | TATTR_COMBINING;
        win_draw_text(term->win, x, y, ch, ccount, attr, ldata->lattr, tc);
        if (attr & (ATTR_ACTCURS | ATTR_PASCURS))
            win_draw_cursor(term->win, x, y, ch, ccount,
                            attr, ldata->lattr, tc);
    }
}

/*
 * Update the window.
 */
static void nemo_paint_attribute_colours(Terminal *term, const rgb colours[5],
                                         bool bold_colours,
                                         unsigned long *attr, truecolour *tc)
{
    static const struct { unsigned mode; unsigned long attr; } order[] = {
        {2, ATTR_BLINK}, {0, ATTR_BOLD}, {1, ATTR_UNDER}, {4, ATTR_ITALIC}
    };
    unsigned modes = term->attribute_colour_modes;
    unsigned keep = term->attribute_keep_styles;
    bool override = (modes & (1u << 5)) != 0;
    if (!term->ansi_colour || !modes) return;
    /* Resolve before screen reverse and selection. Only display records
     * change; stored SGR, copy, checksums and scrollback retain their values. */
    if (override || (!tc->fg.enabled && (*attr & ATTR_FGMASK) == ATTR_DEFFG)) {
        for (unsigned i = 0; i < lenof(order); i++) {
            unsigned mode = order[i].mode;
            if ((modes & (1u << mode)) && (*attr & order[i].attr)) {
                rgb c = colours[mode];
                tc->fg = (optionalrgb){true, c.r, c.g, c.b};
                if (mode == 2 && !(keep & (1u << 2))) *attr &= ~ATTR_BLINK;
                break;
            }
        }
    }
    /* XTerm's default veryBoldColors=0 suppresses these font attributes
     * whenever their colour modes are enabled, even if explicit SGR wins.
     * Preserve ANSI brightening separately from the suppressed bold font. */
    if ((modes & 1u) && !(keep & 1u)) {
        unsigned fg = (*attr & ATTR_FGMASK) >> ATTR_FGSHIFT;
        if (bold_colours && (*attr & ATTR_BOLD) && !tc->fg.enabled && fg < 8)
            *attr = (*attr & ~ATTR_FGMASK) | ((fg+8) << ATTR_FGSHIFT);
        *attr &= ~ATTR_BOLD;
    }
    if ((modes & (1u << 1)) && !(keep & (1u << 1))) {
        *attr &= ~ATTR_UNDER;
        tc->decoration &= ~(UNDER_STYLE_MASK | UNDER_DOUBLE_LEGACY);
    }
    if ((modes & (1u << 4)) && !(keep & (1u << 4))) *attr &= ~ATTR_ITALIC;
    if ((modes & (1u << 3)) && (*attr & ATTR_REVERSE)) {
        if (override || (!tc->bg.enabled && (*attr & ATTR_BGMASK) == ATTR_DEFBG)) {
            rgb c = colours[3];
            tc->bg = (optionalrgb){true, c.r, c.g, c.b};
        }
        if (!(keep & (1u << 3))) *attr &= ~ATTR_REVERSE;
    }
}

static void do_paint(Terminal *term)
{
    int i, j, our_curs_y, our_curs_x;
    int rv, cursor;
    pos scrpos;
    wchar_t *ch;
    size_t chlen;
    termchar *newline;
    optionalrgb selection[2];
    rgb attribute_colours[5];
    bool attribute_bold_colours = (term->attribute_colour_modes & 1) &&
        (conf_get_int(term->conf, CONF_bold_style) & BOLD_STYLE_COLOUR);
    if (term->attribute_colour_modes & 31)
        for (unsigned c = 0; c < lenof(attribute_colours); c++)
            attribute_colours[c] = nemo_attribute_colour(term, c);
    for (unsigned c = 0; c < lenof(selection); c++)
        selection[c] = term->selection_colours[c].enabled ?
            term->selection_colours[c] : term->selection_defaults[c];

    chlen = 1024;
    ch = snewn(chlen, wchar_t);

    newline = snewn(term->cols, termchar);

    rv = (!term->rvideo ^ !term->in_vbell ? ATTR_REVERSE : 0);

    /* Depends on:
     * screen array, disptop, scrtop,
     * selection, rv,
     * blinkpc, blink_is_real, tblinker,
     * curs.y, curs.x, cblinker, blink_cur, cursor_on, has_focus, wrapnext
     */

    /* Has the cursor position or type changed ? */
    if (term->cursor_on) {
        if (term->has_focus) {
            if (term->cblinker || !term->blink_cur)
                cursor = ATTR_ACTCURS;
            else
                cursor = 0;
        } else
            cursor = ATTR_PASCURS;
        if (term->wrapnext)
            cursor |= ATTR_RIGHTCURS;
    } else
        cursor = 0;
    our_curs_y = term->curs.y - term->disptop;
    {
        /*
         * Adjust the cursor position:
         *  - for bidi
         *  - in the case where it's resting on the right-hand half
         *    of a CJK wide character. xterm's behaviour here,
         *    which seems adequate to me, is to display the cursor
         *    covering the _whole_ character, exactly as if it were
         *    one space to the left.
         */
        termline *ldata = lineptr(term->curs.y);
        termchar *lchars;

        our_curs_x = term->curs.x;

        if ( (lchars = term_bidi_line(term, ldata, our_curs_y)) != NULL) {
            our_curs_x = term->post_bidi_cache[our_curs_y].forward[our_curs_x];
        } else
            lchars = ldata->chars;

        if (our_curs_x > 0 &&
            lchars[our_curs_x].chr == UCSWIDE)
            our_curs_x--;

        unlineptr(ldata);
    }


    /* The normal screen data */
    for (i = 0; i < term->rows; i++) {
        termline *ldata;
        termchar *lchars;
        bool dirty_line, dirty_run, selected;
        unsigned long attr = 0, cset = 0;
        int start = 0;
        int ccount = 0;
        bool last_run_dirty = false;
        int laststart;
        bool dirtyrect;
        int *backward;
        truecolour tc;
        int preedit_start = 0, preedit_end = 0;

        scrpos.y = i + term->disptop;
        ldata = lineptr(scrpos.y);

        /* Do Arabic shaping and bidi. */
        lchars = term_bidi_line(term, ldata, i);
        if (lchars) {
            backward = term->post_bidi_cache[i].backward;
        } else {
            lchars = ldata->chars;
            backward = NULL;
        }

        /* Work out if and where to display pre-edit text. */
        if (i == our_curs_y && term->preedit_termline != NULL) {
            preedit_start = our_curs_x;
            preedit_end = preedit_start + term->preedit_termline->cols;
            if (preedit_end > term->cols) {
                preedit_end = term->cols;
                preedit_start = preedit_end - term->preedit_termline->cols;
            }
            /* Show the cursor at the right end of the pre-edit text. */
            if (term->preedit_termline->chars[term->preedit_termline->cols - 1]
                .chr == UCSWIDE)
                our_curs_x = preedit_end - 2;
            else
                our_curs_x = preedit_end - 1;
            cursor |= ATTR_RIGHTCURS;
        }

        /*
         * First loop: work along the line deciding what we want
         * each character cell to look like.
         */
        for (j = 0; j < term->cols; j++) {
            unsigned long tattr, tchar;
            termchar *d = lchars + j;
            bool in_preedit = j >= preedit_start && j < preedit_end;
            scrpos.x = backward ? backward[j] : j;

            if (in_preedit)
                d = term->preedit_termline->chars + j - preedit_start;

            tchar = d->chr;
            tattr = d->attr;
            if (d->truecolour.decoration & UNDER_DOUBLE_LEGACY)
                tattr |= ATTR_UNDER;
            if (d->hyperlink && d->hyperlink == term->hover_hyperlink &&
                term_hyperlink_uri(term, d->hyperlink))
                tattr |= ATTR_UNDER;

            if (!term->ansi_colour)
                tattr = (tattr & ~(ATTR_FGMASK | ATTR_BGMASK)) |
                    ATTR_DEFFG | ATTR_DEFBG;

            if (!term->xterm_256_colour) {
                int colour;
                colour = (tattr & ATTR_FGMASK) >> ATTR_FGSHIFT;
                if (colour >= 16 && colour < 256)
                    tattr = (tattr &~ ATTR_FGMASK) | ATTR_DEFFG;
                colour = (tattr & ATTR_BGMASK) >> ATTR_BGSHIFT;
                if (colour >= 16 && colour < 256)
                    tattr = (tattr &~ ATTR_BGMASK) | ATTR_DEFBG;
            }

            if (term->true_colour) {
                tc = d->truecolour;
            } else {
                tc.fg = tc.bg = optionalrgb_none;
                tc.decoration = d->truecolour.decoration;
                if (tc.decoration & UNDER_RGB)
                    tc.decoration &= ~UNDER_COLOUR_MASK;
            }
            if (!term->ansi_colour ||
                (!term->xterm_256_colour && (tc.decoration & UNDER_INDEXED) &&
                 (tc.decoration & 255) >= 16))
                tc.decoration &= ~UNDER_COLOUR_MASK;

            tc.decoration &= ~CELL_CHECKSUM_MASK;

            if (term->attribute_colour_modes & 31)
                nemo_paint_attribute_colours(term, attribute_colours,
                                             attribute_bold_colours, &tattr, &tc);

            switch (tchar & CSET_MASK) {
              case CSET_ASCII:
                tchar = term->ucsdata->unitab_line[tchar & 0xFF];
                break;
              case CSET_LINEDRW:
                tchar = term->ucsdata->unitab_xterm[tchar & 0xFF];
                break;
              case CSET_SCOACS:
                tchar = term->ucsdata->unitab_scoacs[tchar&0xFF];
                break;
            }
            if (j < (in_preedit ? preedit_end : term->cols) - 1
                && d[1].chr == UCSWIDE)
                tattr |= ATTR_WIDE;

            /* Video reversing things */
            if (term->selstate == DRAGGING || term->selstate == SELECTED) {
                if (term->seltype == LEXICOGRAPHIC)
                    selected = (posle(term->selstart, scrpos) &&
                                poslt(scrpos, term->selend));
                else
                    selected = (posPle(term->selstart, scrpos) &&
                                posPle_left(scrpos, term->selend));
            } else
                selected = false;
            if (term->mouse_highlight == HIGHLIGHT_ACTIVE) {
                int scale = (ldata->lattr & LATTR_MODE) == LATTR_NORM ? 1 : 2;
                pos visual = {.x = j * scale, .y = i};
                selected |= posle(term->highlight_start, visual) &&
                            poslt(visual, term->highlight_end);
            }
            tattr = (tattr ^ rv
                     ^ (selected ? ATTR_REVERSE : 0));
            if (selected) {
                /* Render overrides only: saved cells and copied SGR remain
                 * unchanged. The frontend swaps truecolour with ATTR_REVERSE,
                 * so assign each override to its final displayed component. */
                bool reverse = (tattr & ATTR_REVERSE) != 0;
                if (selection[0].enabled) {
                    if (reverse) tc.fg = selection[0];
                    else tc.bg = selection[0];
                }
                if (selection[1].enabled) {
                    if (reverse) tc.bg = selection[1];
                    else tc.fg = selection[1];
                }
            }

            /* 'Real' blinking ? */
            if (term->blink_is_real && (tattr & ATTR_BLINK)) {
                if (term->has_focus && term->tblinker) {
                    tchar = term->ucsdata->unitab_line[(unsigned char)' '];
                }
                tattr &= ~ATTR_BLINK;
            }

            /*
             * Check the font we'll _probably_ be using to see if
             * the character is wide when we don't want it to be.
             */
            if (tchar != term->disptext[i]->chars[j].chr ||
                tattr != (term->disptext[i]->chars[j].attr &~
                          (ATTR_NARROW | DATTR_MASK))) {
                if ((tattr & ATTR_WIDE) == 0 &&
                    win_char_width(term->win, tchar) == 2)
                    tattr |= ATTR_NARROW;
            } else if (term->disptext[i]->chars[j].attr & ATTR_NARROW)
                tattr |= ATTR_NARROW;

            if (i == our_curs_y && j == our_curs_x)
                tattr |= cursor;

            /* FULL-TERMCHAR */
            newline[j].attr = tattr;
            newline[j].chr = tchar;
            newline[j].truecolour = tc;
            newline[j].hyperlink = d->hyperlink;
            /* Combining characters are still read from lchars */
            newline[j].cc_next = 0;
        }

        /*
         * Now loop over the line again, noting where things have
         * changed.
         *
         * During this loop, we keep track of where we last saw
         * DATTR_STARTRUN. Any mismatch automatically invalidates
         * _all_ of the containing run that was last printed: that
         * is, any rectangle that was drawn in one go in the
         * previous update should be either left completely alone
         * or overwritten in its entirety. This, along with the
         * expectation that front ends clip all text runs to their
         * bounding rectangle, should solve any possible problems
         * with fonts that overflow their character cells.
         */
        laststart = 0;
        dirtyrect = false;
        for (j = 0; j < term->cols; j++) {
            if (term->disptext[i]->chars[j].attr & DATTR_STARTRUN) {
                laststart = j;
                dirtyrect = false;
            }

            if (term->disptext[i]->chars[j].hyperlink != newline[j].hyperlink ||
                term->disptext[i]->chars[j].chr != newline[j].chr ||
                (term->disptext[i]->chars[j].attr &~ DATTR_MASK)
                != newline[j].attr) {
                int k;

                if (!dirtyrect) {
                    for (k = laststart; k < j; k++)
                        term->disptext[i]->chars[k].attr |= ATTR_INVALID;

                    dirtyrect = true;
                }
            }

            if (dirtyrect)
                term->disptext[i]->chars[j].attr |= ATTR_INVALID;
        }

        /*
         * Finally, loop once more and actually do the drawing.
         */
        dirty_run = dirty_line = (ldata->lattr !=
                                  term->disptext[i]->lattr);
        term->disptext[i]->lattr = ldata->lattr;

        tc = term->erase_char.truecolour;
        for (j = 0; j < term->cols; j++) {
            unsigned long tattr, tchar;
            bool break_run, do_copy, next_run_dirty = false;
            termchar *d = lchars + j;
            bool in_preedit = j >= preedit_start && j < preedit_end;

            if (in_preedit)
                d = term->preedit_termline->chars + j - preedit_start;

            tattr = newline[j].attr;
            tchar = newline[j].chr;

            if ((term->disptext[i]->chars[j].attr ^ tattr) & ATTR_WIDE)
                dirty_line = true;

            break_run = ((tattr ^ attr) & term->attr_mask) != 0;

            if (!truecolour_equal(newline[j].truecolour, tc))
                break_run = true;

#ifdef USES_VTLINE_HACK
            /* Special hack for VT100 Linedraw glyphs */
            if ((tchar >= 0x23BA && tchar <= 0x23BD) ||
                (j > 0 && (newline[j-1].chr >= 0x23BA &&
                           newline[j-1].chr <= 0x23BD)))
                break_run = true;
#endif

            /*
             * Separate out sequences of characters that have the
             * same CSET, if that CSET is a magic one.
             */
            if (CSET_OF(tchar) != cset)
                break_run = true;

            /*
             * Break on both sides of any combined-character cell.
             */
            if (d->cc_next != 0 ||
                (j > 0 && d[-1].cc_next != 0))
                break_run = true;

            /*
             * Break on both sides of a regional indicator letter.
             */
            if (IS_REGIONAL_INDICATOR_LETTER(tchar)) {
                break_run = true;
                if (j+1 < term->cols) {
                    /* Also, check if there are any changes to whether or
                     * not we're drawing this and the next character as a
                     * single flag glyph. */
                    bool flag_now = IS_REGIONAL_INDICATOR_LETTER(d[1].chr);
                    bool flag_before = (
                        IS_REGIONAL_INDICATOR_LETTER(
                            term->disptext[i]->chars[j].chr) &&
                        IS_REGIONAL_INDICATOR_LETTER(
                            term->disptext[i]->chars[j+1].chr) &&
                        (term->disptext[i]->chars[j].attr & DATTR_STARTRUN));
                    if (flag_now != flag_before)
                        next_run_dirty = true; /* must redraw this flag */
                }
            } else if (j>0 && IS_REGIONAL_INDICATOR_LETTER(d[-1].chr)) {
                break_run = true;
            }

            /*
             * Break on both sides of a trust sigil.
             */
            if (d->chr == TRUST_SIGIL_CHAR ||
                (j >= 2 && d[-1].chr == UCSWIDE &&
                 d[-2].chr == TRUST_SIGIL_CHAR))
                break_run = true;

            if (!term->ucsdata->dbcs_screenfont && !dirty_line) {
                if (term->disptext[i]->chars[j].chr == tchar &&
                    (term->disptext[i]->chars[j].attr &~ DATTR_MASK)==tattr &&
                    truecolour_equal(
                        term->disptext[i]->chars[j].truecolour, tc))
                    break_run = true;
                else if (!dirty_run && ccount == 1)
                    break_run = true;
            }

            if (break_run) {
                if ((dirty_run || last_run_dirty) && ccount > 0)
                    do_paint_draw(term, ldata, start, i, ch, ccount, attr, tc);
                start = j;
                ccount = 0;
                attr = tattr;
                tc = newline[j].truecolour;
                cset = CSET_OF(tchar);
                if (term->ucsdata->dbcs_screenfont)
                    last_run_dirty = dirty_run;
                dirty_run = dirty_line || next_run_dirty;
            }

            do_copy = false;
            if (!termchars_equal_override(&term->disptext[i]->chars[j],
                                          d, tchar, tattr)) {
                do_copy = true;
                dirty_run = true;
            }

            sgrowarrayn(ch, chlen, ccount, 2);

#ifdef PLATFORM_IS_UTF16
            if (tchar > 0x10000 && tchar < 0x110000) {
                ch[ccount++] = (wchar_t) HIGH_SURROGATE_OF(tchar);
                ch[ccount++] = (wchar_t) LOW_SURROGATE_OF(tchar);
            } else
#endif /* PLATFORM_IS_UTF16 */
            ch[ccount++] = (wchar_t) tchar;

            if (d->cc_next) {
                termchar *dd = d;

                while (dd->cc_next) {
                    unsigned long schar;

                    dd += dd->cc_next;

                    schar = dd->chr;
                    switch (schar & CSET_MASK) {
                      case CSET_ASCII:
                        schar = term->ucsdata->unitab_line[schar & 0xFF];
                        break;
                      case CSET_LINEDRW:
                        schar = term->ucsdata->unitab_xterm[schar & 0xFF];
                        break;
                      case CSET_SCOACS:
                        schar = term->ucsdata->unitab_scoacs[schar&0xFF];
                        break;
                    }

                    sgrowarrayn(ch, chlen, ccount, 2);

#ifdef PLATFORM_IS_UTF16
                    if (schar > 0x10000 && schar < 0x110000) {
                        ch[ccount++] = (wchar_t) HIGH_SURROGATE_OF(schar);
                        ch[ccount++] = (wchar_t) LOW_SURROGATE_OF(schar);
                    } else
#endif /* PLATFORM_IS_UTF16 */
                    ch[ccount++] = (wchar_t) schar;
                }

                attr |= TATTR_COMBINING;
            }

            if (do_copy) {
                copy_termchar(term->disptext[i], j, d);
                term->disptext[i]->chars[j].chr = tchar;
                term->disptext[i]->chars[j].attr = tattr;
                term->disptext[i]->chars[j].truecolour = tc;
                if (start == j)
                    term->disptext[i]->chars[j].attr |= DATTR_STARTRUN;
            }

            /* If it's a wide char step along to the next one. */
            if (tattr & ATTR_WIDE) {
                if (++j < term->cols) {
                    d++;
                    /*
                     * By construction above, the cursor should not
                     * be on the right-hand half of this character.
                     * Ever.
                     */
                    assert(!(i == our_curs_y && j == our_curs_x));
                    if (!termchars_equal(&term->disptext[i]->chars[j], d))
                        dirty_run = true;
                    copy_termchar(term->disptext[i], j, d);
                }
            }

            /* If it's a regional indicator letter, and so is the next
             * one, then also step to the next one, keeping the flag
             * sequence together. */
            if (IS_REGIONAL_INDICATOR_LETTER(d->chr) &&
                (j+1 < term->cols && IS_REGIONAL_INDICATOR_LETTER(d[1].chr))) {
                j++;
                d++;

                /* Set ATTR_WIDE, so that the pair is displayed as one */
                attr |= ATTR_WIDE;

                /* Include the second letter in the text buffer */
                unsigned long rchar = d->chr;
#ifdef PLATFORM_IS_UTF16
                sgrowarrayn(ch, chlen, ccount, 2);
                ch[ccount++] = (wchar_t)HIGH_SURROGATE_OF(rchar);
                ch[ccount++] = (wchar_t)LOW_SURROGATE_OF(rchar);
#else
                sgrowarrayn(ch, chlen, ccount, 1);
                ch[ccount++] = (wchar_t)rchar;
#endif

                /* Display the cursor, if it's on the right half */
                if (i == our_curs_y && j == our_curs_x) {
                    attr |= cursor;
                    term->disptext[i]->chars[j-1].attr |= cursor;
                }

                if (!termchars_equal_override(
                        &term->disptext[i]->chars[j],
                        d, rchar, term->disptext[i]->chars[j-1].attr))
                    dirty_run = true;

                copy_termchar(term->disptext[i], j, d);
                term->disptext[i]->chars[j].attr =
                    term->disptext[i]->chars[j-1].attr & ~DATTR_STARTRUN;
            }
        }
        if (dirty_run && ccount > 0)
            do_paint_draw(term, ldata, start, i, ch, ccount, attr, tc);

        unlineptr(ldata);
    }

    sfree(newline);
    sfree(ch);
}

/*
 * Invalidate the whole screen so it will be repainted in full.
 */
void term_invalidate(Terminal *term)
{
    int i, j;

    for (i = 0; i < term->rows; i++)
        for (j = 0; j < term->cols; j++)
            term->disptext[i]->chars[j].attr |= ATTR_INVALID;

    term_schedule_update(term);
}

const char *term_hyperlink_uri(Terminal *term, uint32_t handle)
{
    return term->no_remote_hyperlinks ? NULL :
        nemo_hyperlink_lookup(term->hyperlinks, handle);
}

uint32_t term_hyperlink_at(Terminal *term, int x, int y)
{
    if (x < 0 || y < 0 || x >= term->cols || y >= term->rows || !term->disptext)
        return 0;
    termline *line = term->disptext[y];
    if ((line->lattr & LATTR_MODE) != LATTR_NORM) x /= 2;
    uint32_t handle = line->chars[x].hyperlink;
    return term_hyperlink_uri(term, handle) ? handle : 0;
}

void term_hyperlink_hover(Terminal *term, uint32_t handle)
{
    if (!term_hyperlink_uri(term, handle)) handle = 0;
    if (term->hover_hyperlink != handle) {
        term->hover_hyperlink = handle;
        term_invalidate(term);
    }
}

/* Paint the window in response to a WM_PAINT message. */
void term_paint(Terminal *term,
                int left, int top, int right, int bottom, bool immediately)
{
    int i, j;
    if (left < 0) left = 0;
    if (top < 0) top = 0;
    if (right >= term->cols) right = term->cols-1;
    if (bottom >= term->rows) bottom = term->rows-1;

    for (i = top; i <= bottom && i < term->rows; i++) {
        if ((term->disptext[i]->lattr & LATTR_MODE) == LATTR_NORM)
            for (j = left; j <= right && j < term->cols; j++)
                term->disptext[i]->chars[j].attr |= ATTR_INVALID;
        else
            for (j = left / 2; j <= right / 2 + 1 && j < term->cols; j++)
                term->disptext[i]->chars[j].attr |= ATTR_INVALID;
    }

    if (immediately && !term->synchronized_update) {
        do_paint(term);
    } else {
        term_schedule_update(term);
    }
}

/*
 * Attempt to scroll the scrollback. The second parameter gives the
 * position we want to scroll to; the first is +1 to denote that
 * this position is relative to the beginning of the scrollback, -1
 * to denote it is relative to the end, and 0 to denote that it is
 * relative to the current position.
 */
void term_scroll(Terminal *term, int rel, int where)
{
    term->shell_mark_selected = 0;
    nemo_highlight_cancel(term, true);
    term_end_synchronized_update(term);
    int sbtop = -sblines(term);

    term->disptop = (rel < 0 ? 0 : rel > 0 ? sbtop : term->disptop) + where;
    if (term->disptop < sbtop)
        term->disptop = sbtop;
    if (term->disptop > 0)
        term->disptop = 0;
    term->win_scrollbar_update_pending = true;
    term_schedule_update(term);
}

bool term_shell_mark_navigate(Terminal *term, int direction)
{
    if (term->alt_which || !direction) return false;
    NemoShellPoint from = { .x = term->disptop ? 0 : term->curs.x + term->wrapnext,
        .y = term->disptop ? term->disptop : term->curs.y, .valid = true }, target;
    const NemoShellCommand *c = nemo_shell_marks_lookup(
        &term->shell_marks, term->shell_mark_selected);
    if (c) for (int i = 0; i < 3; i++) {
        if (c->point[i].valid && !c->point[i].truncated) {
            from = c->point[i]; break;
        }
    }
    uint64_t id = nemo_shell_marks_neighbour(&term->shell_marks, direction,
        from.x, from.y, -count234(term->scrollback), term->rows-1, &target);
    if (!id) return false;
    term_scroll(term, -1, target.y);
    term->shell_mark_selected = id;
    return true;
}

/*
 * Scroll the scrollback to centre it on the beginning or end of the
 * current selection, if any.
 */
void term_scroll_to_selection(Terminal *term, int which_end)
{
    pos target;
    int y;
    int sbtop = -sblines(term);

    if (term->selstate != SELECTED)
        return;
    if (which_end)
        target = term->selend;
    else
        target = term->selstart;

    y = target.y - term->rows/2;
    if (y < sbtop)
        y = sbtop;
    else if (y > 0)
        y = 0;
    term_scroll(term, -1, y);
}

/*
 * Helper routine for clipme(): growing buffer.
 */
typedef struct {
    size_t bufsize;         /* amount of allocated space in textbuf/attrbuf */
    size_t bufpos;          /* amount of actual data */
    wchar_t *textbuf;       /* buffer for copied text */
    wchar_t *textptr;       /* = textbuf + bufpos (current insertion point) */
    int *attrbuf;           /* buffer for copied attributes */
    int *attrptr;           /* = attrbuf + bufpos */
    truecolour *tcbuf;      /* buffer for copied colours */
    truecolour *tcptr;      /* = tcbuf + bufpos */
} clip_workbuf;

static void clip_addchar(clip_workbuf *b, wchar_t chr, int attr, truecolour tc)
{
    if (b->bufpos >= b->bufsize) {
        sgrowarray(b->textbuf, b->bufsize, b->bufpos);
        b->textptr = b->textbuf + b->bufpos;
        b->attrbuf = sresize(b->attrbuf, b->bufsize, int);
        b->attrptr = b->attrbuf + b->bufpos;
        b->tcbuf = sresize(b->tcbuf, b->bufsize, truecolour);
        b->tcptr = b->tcbuf + b->bufpos;
    }
    *b->textptr++ = chr;
    *b->attrptr++ = attr;
    *b->tcptr++ = tc;
    b->bufpos++;
}

static void clipme(Terminal *term, pos top, pos bottom, bool rect, bool desel,
                   const int *clipboards, int n_clipboards)
{
    clip_workbuf buf;
    int old_top_x;
    int attr;
    truecolour tc;

    buf.bufsize = 5120;
    buf.bufpos = 0;
    buf.textptr = buf.textbuf = snewn(buf.bufsize, wchar_t);
    buf.attrptr = buf.attrbuf = snewn(buf.bufsize, int);
    buf.tcptr = buf.tcbuf = snewn(buf.bufsize, truecolour);

    old_top_x = top.x;                 /* needed for rect==1 */

    while (poslt(top, bottom)) {
        bool nl = false;
        termline *ldata = lineptr(top.y);
        pos nlpos;

        /*
         * nlpos will point at the maximum position on this line we
         * should copy up to. So we start it at the end of the
         * line...
         */
        nlpos.y = top.y;
        nlpos.x = term->cols;

        /*
         * ... move it backwards if there's unused space at the end
         * of the line (and also set `nl' if this is the case,
         * because in normal selection mode this means we need a
         * newline at the end)...
         */
        if (!(ldata->lattr & LATTR_WRAPPED)) {
            while (nlpos.x &&
                   IS_SPACE_CHR(ldata->chars[nlpos.x - 1].chr) &&
                   !ldata->chars[nlpos.x - 1].cc_next &&
                   poslt(top, nlpos))
                decpos(nlpos);
            if (poslt(nlpos, bottom))
                nl = true;
        } else {
            if (ldata->trusted) {
                /* A wrapped line with a trust sigil on it terminates
                 * a few characters earlier. */
                nlpos.x = (nlpos.x < TRUST_SIGIL_WIDTH ? 0 :
                           nlpos.x - TRUST_SIGIL_WIDTH);
            }
            if (ldata->lattr & LATTR_WRAPPED2) {
                /* Ignore the last char on the line in a WRAPPED2 line. */
                decpos(nlpos);
            }
        }

        /*
         * ... and then clip it to the terminal x coordinate if
         * we're doing rectangular selection. (In this case we
         * still did the above, so that copying e.g. the right-hand
         * column from a table doesn't fill with spaces on the
         * right.)
         */
        if (rect) {
            if (nlpos.x > bottom.x)
                nlpos.x = bottom.x;
            nl = (top.y < bottom.y);
        }

        while (poslt(top, bottom) && poslt(top, nlpos)) {
            wchar_t cbuf[16], *p;
            int c;
            int x = top.x;

            if (ldata->chars[x].chr == UCSWIDE) {
                top.x++;
                continue;
            }

            while (1) {
                int uc = ldata->chars[x].chr;
                attr = ldata->chars[x].attr;
                tc = ldata->chars[x].truecolour;

                switch (uc & CSET_MASK) {
                  case CSET_LINEDRW:
                    if (!term->rawcnp) {
                        uc = term->ucsdata->unitab_xterm[uc & 0xFF];
                        break;
                    }
                  case CSET_ASCII:
                    uc = term->ucsdata->unitab_line[uc & 0xFF];
                    break;
                  case CSET_SCOACS:
                    uc = term->ucsdata->unitab_scoacs[uc&0xFF];
                    break;
                }
                switch (uc & CSET_MASK) {
                  case CSET_ACP:
                    uc = term->ucsdata->unitab_font[uc & 0xFF];
                    break;
                  case CSET_OEMCP:
                    uc = term->ucsdata->unitab_oemcp[uc & 0xFF];
                    break;
                }

                c = (uc & ~CSET_MASK);
#ifdef PLATFORM_IS_UTF16
                if (uc > 0x10000 && uc < 0x110000) {
                    cbuf[0] = 0xD800 | ((uc - 0x10000) >> 10);
                    cbuf[1] = 0xDC00 | ((uc - 0x10000) & 0x3FF);
                    cbuf[2] = 0;
                } else
#endif
                {
                    cbuf[0] = uc;
                    cbuf[1] = 0;
                }

                if (DIRECT_FONT(uc)) {
                    if (c >= ' ' && c != 0x7F) {
                        char buf[2];
                        buffer_sink bs[1];
                        buffer_sink_init(bs, cbuf,
                                         sizeof(cbuf) - sizeof(wchar_t));
                        if (is_dbcs_leadbyte(term->ucsdata->font_codepage, (BYTE) c)) {
                            buf[0] = c;
                            buf[1] = (char) (0xFF & ldata->chars[top.x + 1].chr);
                            put_mb_to_wc(bs, term->ucsdata->font_codepage,
                                         buf, 2);
                            top.x++;
                        } else {
                            buf[0] = c;
                            put_mb_to_wc(bs, term->ucsdata->font_codepage,
                                         buf, 1);
                        }

                        assert(!bs->overflowed);
                        *(wchar_t *)bs->out = L'\0';
                    }
                }

                for (p = cbuf; *p; p++)
                    clip_addchar(&buf, *p, attr, tc);

                if (ldata->chars[x].cc_next)
                    x += ldata->chars[x].cc_next;
                else
                    break;
            }
            top.x++;
        }
        if (nl) {
            int i;
            for (i = 0; i < sel_nl_sz; i++)
                clip_addchar(&buf, sel_nl[i], 0, term->basic_erase_char.truecolour);
        }
        top.y++;
        top.x = rect ? old_top_x : 0;

        unlineptr(ldata);
    }
#if SELECTION_NUL_TERMINATED
    clip_addchar(&buf, 0, 0, term->basic_erase_char.truecolour);
#endif
    /* Finally, transfer all that to the clipboard(s). */
    {
        int i;
        bool clip_local = false;
        for (i = 0; i < n_clipboards; i++) {
            if (clipboards[i] == CLIP_LOCAL) {
                clip_local = true;
            } else if (clipboards[i] != CLIP_NULL) {
                win_clip_write(
                    term->win, clipboards[i], buf.textbuf, buf.attrbuf,
                    buf.tcbuf, buf.bufpos, desel);
            }
        }
        if (clip_local) {
            sfree(term->last_selected_text);
            sfree(term->last_selected_attr);
            sfree(term->last_selected_tc);
            term->last_selected_text = buf.textbuf;
            term->last_selected_attr = buf.attrbuf;
            term->last_selected_tc = buf.tcbuf;
            term->last_selected_len = buf.bufpos;
        } else {
            sfree(buf.textbuf);
            sfree(buf.attrbuf);
            sfree(buf.tcbuf);
        }
    }
}

uint64_t term_shell_mark_range(Terminal *term, bool output,
                               NemoShellPoint *start, NemoShellPoint *end)
{
    if (term->alt_which) return 0;
    uint64_t selected = nemo_shell_marks_lookup(&term->shell_marks, term->shell_mark_selected) ?
        term->shell_mark_selected : 0;
    int first = -count234(term->scrollback);
    for (size_t i = term->shell_marks.count; i-- > 0;) {
        const NemoShellCommand *candidate = &term->shell_marks.commands[i];
        if (selected && candidate->id != selected)
            continue;
        if (nemo_shell_marks_range(candidate, output, first, term->rows-1, start, end)) {
            if (start->x > term->cols) { start->x = term->cols; start->truncated = true; }
            if (end->x > term->cols) { end->x = term->cols; end->truncated = true; }
            if (start->y < end->y || (start->y == end->y && start->x < end->x))
                return candidate->id;
        }
    }
    return 0;
}

bool term_shell_mark_select(Terminal *term, bool output)
{
    NemoShellPoint start, end;
    uint64_t id = term_shell_mark_range(term, output, &start, &end);
    if (!id) return false;
    nemo_highlight_cancel(term, true);
    term_end_synchronized_update(term);
    term->selstart = (pos){ .x = min(start.x, term->cols), .y = start.y };
    term->selend = (pos){ .x = min(end.x, term->cols), .y = end.y };
    if (!poslt(term->selstart, term->selend)) return false;
    term->selanchor = term->selstart;
    term->selstate = SELECTED;
    term->seltype = LEXICOGRAPHIC;
    term->selmode = SM_CHAR;
    /* Selection fills the private clipboard; an explicit Copy action writes
     * to the system clipboard, matching normal local mouse selection. */
    int clipboard = CLIP_LOCAL;
    clipme(term, term->selstart, term->selend, false, false, &clipboard, 1);
    term_scroll_to_selection(term, 0);
    term->shell_mark_selected = id;
    term_invalidate(term);
    return true;
}

void term_copyall(Terminal *term, const int *clipboards, int n_clipboards)
{
    pos top;
    pos bottom;
    tree234 *screen = term->screen;
    top.y = -sblines(term);
    top.x = 0;
    bottom.y = find_last_nonempty_line(term, screen);
    bottom.x = term->cols;
    clipme(term, top, bottom, false, true, clipboards, n_clipboards);
}

static void paste_from_clip_local(void *vterm)
{
    Terminal *term = (Terminal *)vterm;
    term_do_paste(term, term->last_selected_text, term->last_selected_len);
}

void term_request_copy(Terminal *term, const int *clipboards, int n_clipboards)
{
    int i;
    for (i = 0; i < n_clipboards; i++) {
        assert(clipboards[i] != CLIP_LOCAL);
        if (clipboards[i] != CLIP_NULL) {
            win_clip_write(term->win, clipboards[i],
                           term->last_selected_text, term->last_selected_attr,
                           term->last_selected_tc, term->last_selected_len,
                           false);
        }
    }
}

void term_request_paste(Terminal *term, int clipboard)
{
    switch (clipboard) {
      case CLIP_NULL:
        /* Do nothing: CLIP_NULL never has data in it. */
        break;
      case CLIP_LOCAL:
        queue_toplevel_callback(paste_from_clip_local, term);
        break;
      default:
        win_clip_request_paste(term->win, clipboard);
        break;
    }
}

/*
 * The wordness array is mainly for deciding the disposition of the
 * US-ASCII characters.
 */
static int wordtype(Terminal *term, int uc)
{
    struct ucsword {
        int start, end, ctype;
    };
    static const struct ucsword ucs_words[] = {
        {128, 160, 0},
        {161, 191, 1},
        {215, 215, 1},
        {247, 247, 1},
        {0x037e, 0x037e, 1},           /* Greek question mark */
        {0x0387, 0x0387, 1},           /* Greek ano teleia */
        {0x055a, 0x055f, 1},           /* Armenian punctuation */
        {0x0589, 0x0589, 1},           /* Armenian full stop */
        {0x0700, 0x070d, 1},           /* Syriac punctuation */
        {0x104a, 0x104f, 1},           /* Myanmar punctuation */
        {0x10fb, 0x10fb, 1},           /* Georgian punctuation */
        {0x1361, 0x1368, 1},           /* Ethiopic punctuation */
        {0x166d, 0x166e, 1},           /* Canadian Syl. punctuation */
        {0x17d4, 0x17dc, 1},           /* Khmer punctuation */
        {0x1800, 0x180a, 1},           /* Mongolian punctuation */
        {0x2000, 0x200a, 0},           /* Various spaces */
        {0x2070, 0x207f, 2},           /* superscript */
        {0x2080, 0x208f, 2},           /* subscript */
        {0x200b, 0x27ff, 1},           /* punctuation and symbols */
        {0x3000, 0x3000, 0},           /* ideographic space */
        {0x3001, 0x3020, 1},           /* ideographic punctuation */
        {0x303f, 0x309f, 3},           /* Hiragana */
        {0x30a0, 0x30ff, 3},           /* Katakana */
        {0x3300, 0x9fff, 3},           /* CJK Ideographs */
        {0xac00, 0xd7a3, 3},           /* Hangul Syllables */
        {0xf900, 0xfaff, 3},           /* CJK Ideographs */
        {0xfe30, 0xfe6b, 1},           /* punctuation forms */
        {0xff00, 0xff0f, 1},           /* half/fullwidth ASCII */
        {0xff1a, 0xff20, 1},           /* half/fullwidth ASCII */
        {0xff3b, 0xff40, 1},           /* half/fullwidth ASCII */
        {0xff5b, 0xff64, 1},           /* half/fullwidth ASCII */
        {0xfff0, 0xffff, 0},           /* half/fullwidth ASCII */
        {0, 0, 0}
    };
    const struct ucsword *wptr;

    switch (uc & CSET_MASK) {
      case CSET_LINEDRW:
        uc = term->ucsdata->unitab_xterm[uc & 0xFF];
        break;
      case CSET_ASCII:
        uc = term->ucsdata->unitab_line[uc & 0xFF];
        break;
      case CSET_SCOACS:
        uc = term->ucsdata->unitab_scoacs[uc&0xFF];
        break;
    }
    switch (uc & CSET_MASK) {
      case CSET_ACP:
        uc = term->ucsdata->unitab_font[uc & 0xFF];
        break;
      case CSET_OEMCP:
        uc = term->ucsdata->unitab_oemcp[uc & 0xFF];
        break;
    }

    /* For DBCS fonts I can't do anything useful. Even this will sometimes
     * fail as there's such a thing as a double width space. :-(
     */
    if (term->ucsdata->dbcs_screenfont &&
        term->ucsdata->font_codepage == term->ucsdata->line_codepage)
        return (uc != ' ');

    if (uc < 0x80)
        return term->wordness[uc];

    for (wptr = ucs_words; wptr->start; wptr++) {
        if (uc >= wptr->start && uc <= wptr->end)
            return wptr->ctype;
    }

    return 2;
}

static int line_cols(Terminal *term, termline *ldata)
{
    int cols = term->cols;
    if (ldata->trusted) {
        cols -= TRUST_SIGIL_WIDTH;
    }
    if (ldata->lattr & LATTR_WRAPPED2)
        cols--;
    if (cols < 0)
        cols = 0;
    return cols;
}

/*
 * Spread the selection outwards according to the selection mode.
 */
static pos sel_spread_half(Terminal *term, pos p, int dir)
{
    termline *ldata;
    short wvalue;
    int topy = -sblines(term);

    ldata = lineptr(p.y);

    switch (term->selmode) {
      case SM_CHAR:
        /*
         * In this mode, every character is a separate unit, except
         * for runs of spaces at the end of a non-wrapping line.
         */
        if (!(ldata->lattr & LATTR_WRAPPED)) {
            termchar *q = ldata->chars + line_cols(term, ldata);
            while (q > ldata->chars &&
                   IS_SPACE_CHR(q[-1].chr) && !q[-1].cc_next)
                q--;
            if (q == ldata->chars + term->cols)
                q--;
            if (p.x >= q - ldata->chars)
                p.x = (dir == -1 ? q - ldata->chars : term->cols - 1);
        }
        break;
      case SM_WORD:
        /*
         * In this mode, the units are maximal runs of characters
         * whose `wordness' has the same value.
         */
        wvalue = wordtype(term, UCSGET(ldata->chars, p.x));
        if (dir == +1) {
            while (1) {
                int maxcols = line_cols(term, ldata);
                if (p.x < maxcols-1) {
                    if (wordtype(term, UCSGET(ldata->chars, p.x+1)) == wvalue)
                        p.x++;
                    else
                        break;
                } else {
                    if (p.y+1 < term->rows &&
                        (ldata->lattr & LATTR_WRAPPED)) {
                        termline *ldata2;
                        ldata2 = lineptr(p.y+1);
                        if (wordtype(term, UCSGET(ldata2->chars, 0))
                            == wvalue) {
                            p.x = 0;
                            p.y++;
                            unlineptr(ldata);
                            ldata = ldata2;
                        } else {
                            unlineptr(ldata2);
                            break;
                        }
                    } else
                        break;
                }
            }
        } else {
            while (1) {
                if (p.x > 0) {
                    if (wordtype(term, UCSGET(ldata->chars, p.x-1)) == wvalue)
                        p.x--;
                    else
                        break;
                } else {
                    termline *ldata2;
                    int maxcols;
                    if (p.y <= topy)
                        break;
                    ldata2 = lineptr(p.y-1);
                    maxcols = line_cols(term, ldata2);
                    if (ldata2->lattr & LATTR_WRAPPED) {
                        if (wordtype(term, UCSGET(ldata2->chars, maxcols-1))
                            == wvalue) {
                            p.x = maxcols-1;
                            p.y--;
                            unlineptr(ldata);
                            ldata = ldata2;
                        } else {
                            unlineptr(ldata2);
                            break;
                        }
                    } else
                        break;
                }
            }
        }
        break;
      case SM_LINE:
        /*
         * In this mode, every line is a unit.
         */
        p.x = (dir == -1 ? 0 : term->cols - 1);
        break;
    }

    unlineptr(ldata);
    return p;
}

static void sel_spread(Terminal *term)
{
    if (term->seltype == LEXICOGRAPHIC) {
        term->selstart = sel_spread_half(term, term->selstart, -1);
        decpos(term->selend);
        term->selend = sel_spread_half(term, term->selend, +1);
        incpos(term->selend);
    }
}

static void term_paste_callback(void *vterm)
{
    Terminal *term = (Terminal *)vterm;

    if (term->paste_len == 0)
        return;

    while (term->paste_pos < term->paste_len) {
        size_t n = 0;
        while (n + term->paste_pos < term->paste_len) {
            if (term->paste_buffer[term->paste_pos + n++] == '\015')
                break;
        }
        if (term->ldisc) {
            strbuf *buf = term_input_data_from_unicode(
                term, term->paste_buffer + term->paste_pos, n, true);
            term_keyinput_internal(term, buf->s, buf->len, false);
            strbuf_free(buf);
        }
        term->paste_pos += n;

        if (term->paste_pos < term->paste_len) {
            queue_toplevel_callback(term_paste_callback, term);
            return;
        }
    }
    term_bracketed_paste_stop(term);
    sfree(term->paste_buffer);
    term->paste_buffer = NULL;
    term->paste_len = 0;
}

/*
 * Specialist string compare function. Returns true if the buffer of
 * alen wide characters starting at a has as a prefix the buffer of
 * blen characters starting at b.
 */
static bool wstartswith(const wchar_t *a, size_t alen,
                        const wchar_t *b, size_t blen)
{
    return alen >= blen && !wcsncmp(a, b, blen);
}

void term_do_paste(Terminal *term, const wchar_t *data, size_t len)
{
    const wchar_t *p;
    bool paste_controls = conf_get_bool(term->conf, CONF_paste_controls);

    /*
     * Pasting data into the terminal counts as a keyboard event (for
     * purposes of the 'Reset scrollback on keypress' config option),
     * unless the paste is zero-length.
     */
    if (len == 0)
        return;
    term_seen_key_event(term);

    if (term->paste_buffer)
        sfree(term->paste_buffer);
    term->paste_pos = term->paste_len = 0;
    term->paste_buffer = snewn(len + 12, wchar_t);

    if (term->bracketed_paste && !term->no_bracketed_paste)
        term_bracketed_paste_start(term);

    p = data;
    while (p < data + len) {
        wchar_t wc = *p++;

        if (wc == sel_nl[0] &&
            wstartswith(p-1, data+len-(p-1), sel_nl, sel_nl_sz)) {
            /*
             * This is the (platform-dependent) sequence that the host
             * OS uses to represent newlines in clipboard data.
             * Normalise it to a press of CR.
             */
            p += sel_nl_sz - 1;
            wc = '\015';
        }

        if ((wc & ~(wint_t)0x9F) == 0) {
            /*
             * This is a control code, either in the range 0x00-0x1F
             * or 0x80-0x9F. We reject all of these in pastecontrols
             * mode, except for a small set of permitted ones.
             */
            if (!paste_controls) {
                /* In line with xterm 292, accepted control chars are:
                 * CR, LF, tab, backspace. (And DEL, i.e. 0x7F, but
                 * that's permitted by virtue of not matching the bit
                 * mask that got us into this if statement, so we
                 * don't have to permit it here. */
                static const unsigned mask =
                    (1<<13) | (1<<10) | (1<<9) | (1<<8);

                if (wc > 15 || !((mask >> wc) & 1))
                    continue;
            }

            if (wc == '\033' && term->bracketed_paste &&
                wstartswith(p-1, data+len-(p-1), L"\033[201~", 6)) {
                /*
                 * Also, in bracketed-paste mode, reject the ESC
                 * character that begins the end-of-paste sequence.
                 */
                continue;
            }
        }

        term->paste_buffer[term->paste_len++] = wc;
    }

    /* Assume a small paste will be OK in one go. */
    if (term->paste_len < 256) {
        if (term->ldisc) {
            strbuf *buf = term_input_data_from_unicode(
                term, term->paste_buffer, term->paste_len, true);
            assert(buf->len <= INT_MAX); /* because paste_len was also small */
            term_keyinput_internal(term, buf->s, buf->len, false);
            strbuf_free(buf);
        }
        if (term->paste_buffer)
            sfree(term->paste_buffer);
        term_bracketed_paste_stop(term);
        term->paste_buffer = NULL;
        term->paste_pos = term->paste_len = 0;
    }

    queue_toplevel_callback(term_paste_callback, term);
}

/* Coordinates sent to applications describe the viewport, before bidi,
 * double-width-line and scrollback transforms used for local selection. */
static int mouse_coord(int value, int count, int size)
{
    int64_t limit = (int64_t)count * max(size, 1);
    return (int)max(0, min((int64_t)value, min(limit, INT_MAX)-1));
}

static bool mouse_report(Terminal *term, Mouse_Button button, Mouse_Action a,
                         int x, int y, int px, int py, bool ctrl, bool alt)
{
    int code;
    unsigned bit = 0;
    bool wheel = false;
    switch (button) {
      case MBT_LEFT: code = 0; bit = 1; break;
      case MBT_MIDDLE: code = 1; bit = 2; break;
      case MBT_RIGHT: code = 2; bit = 4; break;
      case MBT_X1: code = 128; bit = 8; break;
      case MBT_X2: code = 129; bit = 16; break;
      case MBT_WHEEL_UP: code = 64; wheel = true; break;
      case MBT_WHEEL_DOWN: code = 65; wheel = true; break;
      case MBT_WHEEL_LEFT: code = 66; wheel = true; break;
      case MBT_WHEEL_RIGHT: code = 67; wheel = true; break;
      case MBT_NOTHING: code = 3; break;
      default: return false;
    }
    if (!term->ldisc || !term->xterm_mouse || term->no_mouse_rep)
        return false;
    if (term->xterm_mouse == -1) {
        if (a != MA_CLICK || !bit) return false;
        ctrl = alt = false;
    }
    if (wheel) {
        if (a != MA_CLICK) return false;
    } else if (a == MA_RELEASE) {
        if (!(term->mouse_buttons & bit)) return false;
        if (term->mouse_encoding != 1006 && term->mouse_encoding != 1016)
            code = 3;
    } else if (a == MA_CLICK) {
        if (!bit || (term->mouse_buttons & bit)) return false;
    } else if (a == MA_DRAG) {
        if ((term->xterm_mouse != 2 && term->xterm_mouse != 3) ||
            !(term->mouse_buttons & bit)) return false;
        code += 32;
    } else if (a == MA_MOVE) {
        if (term->xterm_mouse != 3 || bit) return false;
        code += 32;
    } else {
        return false;
    }
    code += (ctrl ? 16 : 0) + (alt ? 8 : 0);
    x = mouse_coord(x, term->cols, 1);
    y = mouse_coord(y, term->rows, 1);
    px = mouse_coord(px, term->cols, term->cell_width);
    py = mouse_coord(py, term->rows, term->cell_height);
    int c = (term->mouse_encoding == 1016 ? px : x) + 1;
    int r = (term->mouse_encoding == 1016 ? py : y) + 1;
    if ((a == MA_DRAG || a == MA_MOVE) &&
        term->raw_mouse_reported_x == c && term->raw_mouse_reported_y == r &&
        (term->raw_mouse_reported_code & ~32) == (code & ~32))
        return false;

    char response[64];
    size_t len = 0;
    if (term->mouse_encoding == 1006 || term->mouse_encoding == 1016) {
        len = sprintf(response, "\033[<%d;%d;%d%c", code, c, r,
                      a == MA_RELEASE ? 'm' : 'M');
    } else if (term->mouse_encoding == 1015) {
        len = sprintf(response, "\033[%d;%d;%dM", code+32, c, r);
    } else {
        int limit = term->mouse_encoding == 1005 ? 2015 : 223;
        if (c > limit || r > limit) return false;
        memcpy(response, "\033[M", 3);
        len = 3;
        unsigned values[] = { code+32, c+32, r+32 };
        for (size_t i = 0; i < lenof(values); i++) {
            unsigned v = values[i];
            if (term->mouse_encoding == 1005 && v >= 128) {
                response[len++] = 0xC0 | (v >> 6);
                response[len++] = 0x80 | (v & 63);
            } else {
                response[len++] = v;
            }
        }
    }
    nemo_protocol_send(term, response, len);
    if (!wheel && term->xterm_mouse != -1) {
        if (a == MA_CLICK) term->mouse_buttons |= bit;
        if (a == MA_RELEASE) term->mouse_buttons &= ~bit;
    }
    term->raw_mouse_reported_x = c;
    term->raw_mouse_reported_y = r;
    term->raw_mouse_reported_code = code;
    term->mouse_last_x = x; term->mouse_last_y = y;
    term->mouse_last_px = px; term->mouse_last_py = py;
    term->mouse_last_ctrl = ctrl; term->mouse_last_alt = alt;
    return true;
}

/* Highlight positions are viewport cells, not logical bidi indices. Snap to
 * complete rendered glyphs, including CJK and double-width terminal lines. */
static unsigned nemo_highlight_cell(Terminal *term, pos *p, int *width)
{
    termline *line = lineptr(p->y + term->disptop);
    int scale = (line->lattr & LATTR_MODE) == LATTR_NORM ? 1 : 2;
    termchar *chars = term_bidi_line(term, line, p->y);
    if (!chars) chars = line->chars;
    int x = min(p->x / scale, max(0, (term->cols-1) / scale));
    if (x > 0 && chars[x].chr == UCSWIDE) x--;
    p->x = x * scale;
    *width = scale * (x+1 < term->cols && chars[x+1].chr == UCSWIDE ? 2 : 1);
    unsigned chr = chars[x].chr;
    unlineptr(line);
    return chr;
}

static pos nemo_highlight_point(Terminal *term, int x, int y, int first, int last)
{
    pos p = {.x = max(0, min(x, term->cols)), .y = max(first, min(y, last))};
    int width;
    if (p.x < term->cols) nemo_highlight_cell(term, &p, &width);
    return p;
}

static bool nemo_highlight_wrapped(Terminal *term, int row)
{
    termline *line = lineptr(row + term->disptop);
    bool wrapped = line->lattr & LATTR_WRAPPED;
    unlineptr(line);
    return wrapped;
}

static void nemo_highlight_word(Terminal *term, pos p, pos *lo, pos *hi)
{
    int width;
    int type = wordtype(term, nemo_highlight_cell(term, &p, &width));
    *lo = p;
    *hi = (pos){.x = min(term->cols, p.x + width), .y = p.y};
    for (;;) {
        pos prev = *lo;
        if (prev.x) prev.x--;
        else if (prev.y > term->highlight_first && nemo_highlight_wrapped(term, prev.y-1)) {
            prev.y--; prev.x = term->cols-1;
        } else break;
        if (wordtype(term, nemo_highlight_cell(term, &prev, &width)) != type) break;
        *lo = prev;
    }
    for (;;) {
        pos next = *hi;
        if (next.x >= term->cols) {
            if (next.y >= term->highlight_last || !nemo_highlight_wrapped(term, next.y)) break;
            next.y++; next.x = 0;
        }
        if (wordtype(term, nemo_highlight_cell(term, &next, &width)) != type) break;
        *hi = (pos){.x = min(term->cols, next.x + width), .y = next.y};
    }
}

static void nemo_highlight_update(Terminal *term, int x, int y)
{
    pos anchor = term->highlight_anchor;
    pos mouse = nemo_highlight_point(term, x, y, term->highlight_first, term->highlight_last);
    term->highlight_mouse = mouse;
    pos start = poslt(anchor, mouse) ? anchor : mouse;
    pos end = poslt(anchor, mouse) ? mouse : anchor;
    if (term->highlight_unit == SM_WORD) {
        pos a, b, c, d;
        nemo_highlight_word(term, anchor, &a, &b);
        nemo_highlight_word(term, mouse, &c, &d);
        start = poslt(a, c) ? a : c;
        end = poslt(b, d) ? d : b;
    } else if (term->highlight_unit == SM_LINE) {
        start.x = 0;
        end.x = term->cols;
    }
    term->highlight_start = start;
    term->highlight_end = end;
    term_schedule_update(term);
}

static void nemo_highlight_emit(Terminal *term)
{
    if (!term->ldisc || poseq(term->highlight_start, term->highlight_end)) return;
    bool simple = poseq(term->highlight_anchor, term->highlight_start) &&
                  poseq(term->highlight_mouse, term->highlight_end);
    pos points[3] = {term->highlight_start, term->highlight_end, term->highlight_mouse};
    if (simple) points[0] = term->highlight_end;
    int count = simple ? 1 : 3;
    bool decimal = term->mouse_encoding == 1006 || term->mouse_encoding == 1015 ||
                   term->mouse_encoding == 1016;
    char reply[96], final = simple ? 't' : 'T';
    size_t len = 0;
    memcpy(reply, "\033[", 2); len = 2;
    if (decimal) {
        if (term->mouse_encoding != 1015) reply[len++] = '<';
    } else reply[len++] = final;
    /* In xterm's 1016 mode the press is pixel-based, but the highlight
     * completion still describes character selection boundaries. */
    for (int i = 0; i < count; i++) {
        int coords[] = {points[i].x+1, points[i].y+1};
        for (int j = 0; j < 2; j++) {
            int v = coords[j];
            if (decimal) {
                if (i || j) reply[len++] = ';';
                len += sprintf(reply+len, "%d", v);
            } else {
                int limit = term->mouse_encoding == 1005 ? 2015 : 223;
                if (v > limit) return; /* never wrap an unencodable coordinate */
                v += 32;
                if (term->mouse_encoding == 1005 && v >= 128) {
                    reply[len++] = 0xc0 | (v >> 6);
                    reply[len++] = 0x80 | (v & 63);
                } else reply[len++] = v;
            }
        }
    }
    if (decimal) reply[len++] = final;
    nemo_protocol_send(term, reply, len);
}

static void nemo_highlight_cancel(Terminal *term, bool report)
{
    if (term->mouse_highlight == HIGHLIGHT_OFF) return;
    if (report) {
        if (term->mouse_highlight == HIGHLIGHT_ACTIVE) {
            term_end_synchronized_update(term);
            nemo_highlight_emit(term);
        }
        else mouse_report(term, MBT_LEFT, MA_RELEASE,
                          term->mouse_last_x, term->mouse_last_y,
                          term->mouse_last_px, term->mouse_last_py,
                          term->mouse_last_ctrl, term->mouse_last_alt);
    }
    term->mouse_highlight = HIGHLIGHT_OFF;
    term->mouse_buttons &= ~1U;
    term->raw_mouse_reported_code = -1;
    term_schedule_update(term);
}

static void nemo_highlight_request(Terminal *term)
{
    if (term->mouse_highlight != HIGHLIGHT_WAIT) return;
    if (!term->esc_args[0]) {
        nemo_highlight_cancel(term, false);
        term->mouse_buttons |= 1; /* the physical release still belongs to the host */
        return;
    }
    if (term->esc_nargs != 5) return;
    /* Lastrow is exclusive and all protocol coordinates are one-based. */
    int first = (int)max(0, min((int64_t)term->esc_args[3]-1, term->rows-1));
    int last = (int)max(0, min((int64_t)term->esc_args[4]-2, term->rows-1));
    if (last < first) {
        nemo_highlight_cancel(term, false);
        term->mouse_buttons |= 1;
        return;
    }
    int x = (int)max(0, min((int64_t)term->esc_args[1]-1, term->cols));
    int y = (int)max(0, min((int64_t)term->esc_args[2]-1, term->rows-1));
    term->highlight_first = first;
    term->highlight_last = last;
    term->highlight_anchor = nemo_highlight_point(term, x, y, 0, term->rows-1);
    term->highlight_unit = SM_CHAR;
    term->mouse_highlight = HIGHLIGHT_ACTIVE;
    term_end_synchronized_update(term);
    nemo_highlight_update(term, term->highlight_mouse.x, term->highlight_mouse.y);
}

static bool nemo_highlight_mouse(Terminal *term, Mouse_Button b, Mouse_Action a,
                                 int x, int y, int px, int py, bool ctrl, bool alt)
{
    if (term->xterm_mouse != MOUSE_TRACK_HIGHLIGHT || b != MBT_LEFT) return false;
    if (a == MA_CLICK || a == MA_2CLK || a == MA_3CLK) {
        if (term->mouse_buttons & 1) return true;
        term_end_synchronized_update(term);
        deselect(term);
        term->highlight_first = 0;
        term->highlight_last = term->rows-1;
        term->highlight_mouse = nemo_highlight_point(term, x, y, 0, term->rows-1);
        if (a == MA_CLICK) {
            if (mouse_report(term, b, a, x, y, px, py, ctrl, alt)) {
                term->mouse_highlight = HIGHLIGHT_WAIT;
                term->mouse_highlight_deadline = schedule_timer(TICKSPERSEC, term_timer, term);
            }
        } else {
            term->mouse_buttons |= 1;
            term->mouse_highlight = HIGHLIGHT_ACTIVE;
            term->highlight_anchor = term->highlight_mouse;
            term->highlight_unit = a == MA_2CLK ? SM_WORD : SM_LINE;
            nemo_highlight_update(term, x, y);
        }
    } else if (term->mouse_highlight != HIGHLIGHT_OFF) {
        if (a == MA_DRAG || a == MA_RELEASE) {
            if (term->mouse_highlight == HIGHLIGHT_ACTIVE) {
                term_end_synchronized_update(term);
                nemo_highlight_update(term, x, y);
            }
            else {
                term->highlight_mouse = nemo_highlight_point(term, x, y, 0, term->rows-1);
                if (a == MA_RELEASE) {
                    bool sent = mouse_report(term, b, a, x, y, px, py, ctrl, alt);
                    nemo_highlight_cancel(term, !sent);
                    return true;
                }
            }
            if (a == MA_RELEASE) nemo_highlight_cancel(term, true);
        }
    } else if (a == MA_RELEASE) {
        mouse_report(term, b, a, x, y, px, py, ctrl, alt);
    }
    return true;
}

void term_mouse_cancel(Terminal *term)
{
    nemo_highlight_cancel(term, true);
    static const Mouse_Button buttons[] = {
        MBT_LEFT, MBT_MIDDLE, MBT_RIGHT, MBT_X1, MBT_X2
    };
    for (size_t i = 0; i < lenof(buttons); i++)
        if (term->mouse_buttons & (1U << i))
            mouse_report(term, buttons[i], MA_RELEASE,
                         term->mouse_last_x, term->mouse_last_y,
                         term->mouse_last_px, term->mouse_last_py,
                         term->mouse_last_ctrl, term->mouse_last_alt);
    term->mouse_buttons = 0;
    term->raw_mouse_reported_code = -1;
}

bool term_mouse_wheel(Terminal *term, Mouse_Button button,
                      bool shift, bool ctrl, bool alt)
{
    if (shift || term->xterm_mouse || !term->mouse_alternate_scroll ||
        !term->alt_which || !term->ldisc)
        return false;
    int key;
    switch (button) {
      case MBT_WHEEL_UP: key = 'A'; break;
      case MBT_WHEEL_DOWN: key = 'B'; break;
      case MBT_WHEEL_RIGHT: key = 'C'; break;
      case MBT_WHEEL_LEFT: key = 'D'; break;
      default: return false;
    }
    char buf[32];
    bool consumed_alt = false;
    int len = format_arrow_key(buf, term, key, false, ctrl, alt, &consumed_alt);
    if (alt && !consumed_alt)
        term_keyinput(term, -1, "\033", 1);
    term_keyinput(term, -1, buf, len);
    return true;
}

void term_mouse(Terminal *term, Mouse_Button braw, Mouse_Button bcooked,
                Mouse_Action a, int x, int y, bool shift, bool ctrl, bool alt)
{
    int px = (int)max(0, min((int64_t)max(x, 0) * term->cell_width, INT_MAX-1));
    int py = (int)max(0, min((int64_t)max(y, 0) * term->cell_height, INT_MAX-1));
    term_mouse_pixels(term, braw, bcooked, a, x, y, px, py, shift, ctrl, alt);
}

void term_mouse_pixels(Terminal *term, Mouse_Button braw, Mouse_Button bcooked,
                       Mouse_Action a, int x, int y, int px, int py,
                       bool shift, bool ctrl, bool alt)
{
    pos selpoint;
    termline *ldata;
    int default_seltype;
    if (term->rows <= 0 || term->cols <= 0) return;
    if (term->synchronized_update && (shift || !term->xterm_mouse) &&
        (a == MA_CLICK || a == MA_DRAG || a == MA_2CLK || a == MA_3CLK)) {
        term_end_synchronized_update(term);
        term_update(term); /* local selection must match visible character cells */
    }
    if (shift && term->mouse_buttons) {
        term_mouse_cancel(term);
        if (a == MA_DRAG && bcooked == MBT_SELECT)
            a = MA_CLICK; /* Shift takes over a gesture in progress. */
    }
    bool raw_mouse = term->xterm_mouse && !term->no_mouse_rep && !shift &&
        term->selstate != ABOUT_TO && term->selstate != DRAGGING;
    if (raw_mouse) {
        if (nemo_highlight_mouse(term, braw, a, x, y, px, py, ctrl, alt)) return;
        mouse_report(term, braw, a, x, y, px, py, ctrl, alt);
        return;
    }
    if (braw == MBT_WHEEL_UP || braw == MBT_WHEEL_DOWN ||
        braw == MBT_WHEEL_LEFT || braw == MBT_WHEEL_RIGHT) {
        if (a == MA_CLICK) term_mouse_wheel(term, braw, shift, ctrl, alt);
        return;
    }
    if (a == MA_MOVE) return;
    /* Side buttons have no local selection, paste or scrolling binding. */
    if (braw == MBT_X1 || braw == MBT_X2) return;

    /* The configured modifier requests a block explicitly. Mouse reporting takes
     * precedence above; Shift is the local-selection override in that mode.
     * Repeated Ctrl clicks must not turn the block into a word/line gesture. */
    bool block = nemo_rectangle_binding(conf_get_int(term->conf, CONF_nemo_rectangle_modifiers),
                                        shift, ctrl, alt);
    default_seltype = block || term->rect_select ?
        RECTANGULAR : LEXICOGRAPHIC;
    if (block && bcooked == MBT_SELECT && (a == MA_2CLK || a == MA_3CLK))
        a = MA_CLICK;
    if (term->selstate == NO_SELECTION ||
        (bcooked == MBT_SELECT && a == MA_CLICK))
        term->seltype = default_seltype;

    if (y < 0) {
        y = 0;
        if (a == MA_DRAG && !raw_mouse)
            term_scroll(term, 0, -1);
    }
    if (y >= term->rows) {
        y = term->rows - 1;
        if (a == MA_DRAG && !raw_mouse)
            term_scroll(term, 0, +1);
    }
    if (x < 0) {
        if (y > 0 && !raw_mouse && term->seltype != RECTANGULAR) {
            /*
             * When we're using the mouse for normal raster-based
             * selection, dragging off the left edge of a terminal row
             * is treated the same as the right-hand end of the
             * previous row, in that it's considered to identify a
             * point _before_ the first character on row y.
             *
             * But if the mouse action is going to be used for
             * anything else - rectangular selection, or xterm mouse
             * tracking - then we disable this special treatment.
             */
            x = term->cols - 1;
            y--;
        } else
            x = 0;
    }
    if (x >= term->cols)
        x = term->cols - 1;

    selpoint.y = y + term->disptop;
    ldata = lineptr(selpoint.y);

    if ((ldata->lattr & LATTR_MODE) != LATTR_NORM)
        x /= 2;

    /*
     * Transform x through the bidi algorithm to find the _logical_
     * click point from the physical one.
     */
    if (term_bidi_line(term, ldata, y) != NULL) {
        x = term->post_bidi_cache[y].backward[x];
    }

    selpoint.x = x;
    unlineptr(ldata);

    if (bcooked == MBT_SELECT && a == MA_CLICK) {
        deselect(term);
        term->selstate = ABOUT_TO;
        term->seltype = default_seltype;
        term->selanchor = selpoint;
        term->selmode = SM_CHAR;
    } else if (bcooked == MBT_SELECT && (a == MA_2CLK || a == MA_3CLK)) {
        deselect(term);
        term->selmode = (a == MA_2CLK ? SM_WORD : SM_LINE);
        term->selstate = DRAGGING;
        term->selstart = term->selanchor = selpoint;
        term->selend = term->selstart;
        incpos(term->selend);
        sel_spread(term);
    } else if ((bcooked == MBT_SELECT && a == MA_DRAG) ||
               (bcooked == MBT_EXTEND && a != MA_RELEASE)) {
        if (a == MA_DRAG &&
            (term->selstate == NO_SELECTION || term->selstate == SELECTED)) {
            /*
             * This can happen if a front end has passed us a MA_DRAG
             * without a prior MA_CLICK. OS X GTK does so, for
             * example, if the initial button press was eaten by the
             * WM when it activated the window in the first place. The
             * nicest thing to do in this situation is to ignore
             * further drags, and wait for the user to click in the
             * window again properly if they want to select.
             */
            return;
        }
        if (term->selstate == ABOUT_TO && poseq(term->selanchor, selpoint))
            return;
        if (bcooked == MBT_EXTEND && a != MA_DRAG &&
            term->selstate == SELECTED) {
            if (term->seltype == LEXICOGRAPHIC) {
                /*
                 * For normal selection, we extend by moving
                 * whichever end of the current selection is closer
                 * to the mouse.
                 */
                if (posdiff(selpoint, term->selstart) <
                    posdiff(term->selend, term->selstart) / 2) {
                    term->selanchor = term->selend;
                    decpos(term->selanchor);
                } else {
                    term->selanchor = term->selstart;
                }
            } else {
                /*
                 * For rectangular selection, we have a choice of
                 * _four_ places to put selanchor and selpoint: the
                 * four corners of the selection.
                 */
                if (2*selpoint.x < term->selstart.x + term->selend.x)
                    term->selanchor.x = term->selend.x-1;
                else
                    term->selanchor.x = term->selstart.x;

                if (2*selpoint.y < term->selstart.y + term->selend.y)
                    term->selanchor.y = term->selend.y;
                else
                    term->selanchor.y = term->selstart.y;
            }
            term->selstate = DRAGGING;
        }
        if (term->selstate != ABOUT_TO && term->selstate != DRAGGING)
            term->selanchor = selpoint;
        term->selstate = DRAGGING;
        if (term->seltype == LEXICOGRAPHIC) {
            /*
             * For normal selection, we set (selstart,selend) to
             * (selpoint,selanchor) in some order.
             */
            if (poslt(selpoint, term->selanchor)) {
                term->selstart = selpoint;
                term->selend = term->selanchor;
                incpos(term->selend);
            } else {
                term->selstart = term->selanchor;
                term->selend = selpoint;
                incpos(term->selend);
            }
        } else {
            /*
             * For rectangular selection, we may need to
             * interchange x and y coordinates (if the user has
             * dragged in the -x and +y directions, or vice versa).
             */
            term->selstart.x = min(term->selanchor.x, selpoint.x);
            term->selend.x = 1+max(term->selanchor.x, selpoint.x);
            term->selstart.y = min(term->selanchor.y, selpoint.y);
            term->selend.y =   max(term->selanchor.y, selpoint.y);
        }
        sel_spread(term);
    } else if ((bcooked == MBT_SELECT || bcooked == MBT_EXTEND) &&
               a == MA_RELEASE) {
        if (term->selstate == DRAGGING) {
            /*
             * We've completed a selection. We now transfer the
             * data to the clipboard.
             */
            clipme(term, term->selstart, term->selend,
                   (term->seltype == RECTANGULAR), false,
                   term->mouse_select_clipboards,
                   term->n_mouse_select_clipboards);
            term->selstate = SELECTED;
        } else
            term->selstate = NO_SELECTION;
    } else if (bcooked == MBT_PASTE
               && (a == MA_CLICK
#if MULTICLICK_ONLY_EVENT
                   || a == MA_2CLK || a == MA_3CLK
#endif
                   )) {
        term_request_paste(term, term->mouse_paste_clipboard);
    }

    /*
     * Since terminal output is suppressed during drag-selects, we
     * should make sure to write any pending output if one has just
     * finished.
     */
    term_out(term, false);
    term_schedule_update(term);
}

void term_cancel_selection_drag(Terminal *term)
{
    /*
     * In unusual circumstances, a mouse drag might be interrupted by
     * something that steals the rest of the mouse gesture. An example
     * is the GTK popup menu appearing. In that situation, we'll never
     * receive the MA_RELEASE that finishes the DRAGGING state, which
     * means terminal output could be suppressed indefinitely. Call
     * this function from the front end in such situations to restore
     * sensibleness.
     */
    if (term->selstate == DRAGGING || term->selstate == ABOUT_TO)
        term->selstate = NO_SELECTION;
    term_out(term, false);
    term_schedule_update(term);
}

static int shift_bitmap(bool shift, bool ctrl, bool alt, bool *consumed_alt)
{
    int bitmap = (shift ? 1 : 0) + (alt ? 2 : 0) + (ctrl ? 4 : 0);
    if (bitmap)
        bitmap++;
    if (alt && consumed_alt)
        *consumed_alt = true;
    return bitmap;
}

int format_arrow_key(char *buf, Terminal *term, int xkey,
                     bool shift, bool ctrl, bool alt, bool *consumed_alt)
{
    char *p = buf;

    if (term->vt52_mode)
        p += sprintf(p, "\x1B%c", xkey);
    else {
        bool app_flg = (term->app_cursor_keys && !term->no_applic_c);
#if 0
        /*
         * RDB: VT100 & VT102 manuals both state the app cursor
         * keys only work if the app keypad is on.
         *
         * SGT: That may well be true, but xterm disagrees and so
         * does at least one application, so I've #if'ed this out
         * and the behaviour is back to PuTTY's original: app
         * cursor and app keypad are independently switchable
         * modes. If anyone complains about _this_ I'll have to
         * put in a configurable option.
         */
        if (!term->app_keypad_keys)
            app_flg = 0;
#endif

        int bitmap = 0;

        /* Adjustment based on Shift, Ctrl and/or Alt */
        switch (term->sharrow_type) {
          case SHARROW_APPLICATION:
            if (ctrl)
                app_flg = !app_flg;
            break;
          case SHARROW_BITMAP:
            bitmap = shift_bitmap(shift, ctrl, alt, consumed_alt);
            break;
        }

        if (bitmap)
            p += sprintf(p, "\x1B[1;%d%c", bitmap, xkey);
        else if (app_flg)
            p += sprintf(p, "\x1BO%c", xkey);
        else
            p += sprintf(p, "\x1B[%c", xkey);
    }

    return term_format_c1_key(term, buf, p - buf);
}

int format_function_key(char *buf, Terminal *term, int key_number,
                        bool shift, bool ctrl, bool alt, bool *consumed_alt)
{
    char *p = buf;

    static const int key_number_to_tilde_code[] = {
        -1,                 /* no such key as F0 */
        11, 12, 13, 14, 15, /*gap*/ 17, 18, 19, 20, 21, /*gap*/
        23, 24, 25, 26, /*gap*/ 28, 29, /*gap*/ 31, 32, 33, 34,
    };

    if (key_number < 1 || key_number > 63 ||
        (key_number > 20 && term->funky_type != FUNKY_XTERM_216))
        return 0;

    int index = key_number;
    if (term->funky_type != FUNKY_XTERM_216 && term->funky_type != FUNKY_SCO) {
        if (shift && index <= 10) {
            shift = false;
            index += 10;
        }
    }

    int code = index <= 20 ? key_number_to_tilde_code[index] : 42 + index-21;

    if (term->funky_type == FUNKY_SCO) {
        /* SCO function keys */
        static const char sco_codes[] =
            "MNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz@[\\]^_`{";
        index = (key_number >= 1 && key_number <= 12) ? key_number - 1 : 0;
        if (shift) index += 12;
        if (ctrl) index += 24;
        p += sprintf(p, "\x1B[%c", sco_codes[index]);
    } else if ((term->vt52_mode || term->funky_type == FUNKY_VT100P) &&
               code >= 11 && code <= 24) {
        int offt = 0;
        if (code > 15)
            offt++;
        if (code > 21)
            offt++;
        if (term->vt52_mode)
            p += sprintf(p, "\x1B%c", code + 'P' - 11 - offt);
        else
            p += sprintf(p, "\x1BO%c", code + 'P' - 11 - offt);
    } else if (term->funky_type == FUNKY_LINUX && code >= 11 && code <= 15) {
        p += sprintf(p, "\x1B[[%c", code + 'A' - 11);
    } else if ((term->funky_type == FUNKY_XTERM ||
                term->funky_type == FUNKY_XTERM_216) &&
               code >= 11 && code <= 14) {
        if (term->vt52_mode)
            p += sprintf(p, "\x1B%c", code + 'P' - 11);
        else {
            int bitmap = 0;
            if (term->funky_type == FUNKY_XTERM_216)
                bitmap = shift_bitmap(shift, ctrl, alt, consumed_alt);
            if (bitmap)
                p += sprintf(p, "\x1B[1;%d%c", bitmap, code + 'P' - 11);
            else
                p += sprintf(p, "\x1BO%c", code + 'P' - 11);
        }
    } else {
        int bitmap = 0;
        if (term->funky_type == FUNKY_XTERM_216)
            bitmap = shift_bitmap(shift, ctrl, alt, consumed_alt);
        if (bitmap)
            p += sprintf(p, "\x1B[%d;%d~", code, bitmap);
        else
            p += sprintf(p, "\x1B[%d~", code);
    }

    return term_format_c1_key(term, buf, p - buf);
}

int format_small_keypad_key(char *buf, Terminal *term, SmallKeypadKey key,
                            bool shift, bool ctrl, bool alt,
                            bool *consumed_alt)
{
    char *p = buf;

    int code;
    switch (key) {
      case SKK_HOME: code = 1; break;
      case SKK_INSERT: code = 2; break;
      case SKK_DELETE: code = 3; break;
      case SKK_END: code = 4; break;
      case SKK_PGUP: code = 5; break;
      case SKK_PGDN: code = 6; break;
      case SKK_FIND: code = 1; break;
      case SKK_SELECT: code = 4; break;
      case SKK_HELP: code = 28; break;
      default: unreachable("bad small keypad key enum value");
    }

    if (term->funky_type == FUNKY_XTERM_216 &&
        (key == SKK_HOME || key == SKK_END))
        return format_arrow_key(buf, term, key == SKK_HOME ? 'H' : 'F',
                                shift, ctrl, alt, consumed_alt);
    if (term->funky_type == FUNKY_SCO && key == SKK_HELP)
        return 0;

    /* Reorder edit keys to physical order */
    if (term->funky_type == FUNKY_VT400 && code <= 6)
        code = "\0\2\1\4\5\3\6"[code];

    if (term->vt52_mode && code > 0 && code <= 6) {
        p += sprintf(p, "\x1B%c", " HLMEIG"[code]);
    } else if (term->funky_type == FUNKY_SCO) {
        static const char codes[] = "HL.FIG";
        if (code == 3) {
            *p++ = '\x7F';
        } else {
            p += sprintf(p, "\x1B[%c", codes[code-1]);
        }
    } else if ((key == SKK_HOME || key == SKK_END) && term->rxvt_homeend) {
        p += sprintf(p, code == 1 ? "\x1B[H" : "\x1BOw");
    } else {
        if (term->vt52_mode) {
	    p += sprintf(p, "\x1B[%d~", code);
        } else {
            int bitmap = 0;
            if (term->funky_type == FUNKY_XTERM_216)
                bitmap = shift_bitmap(shift, ctrl, alt, consumed_alt);
            if (bitmap)
                p += sprintf(p, "\x1B[%d;%d~", code, bitmap);
            else
                p += sprintf(p, "\x1B[%d~", code);
        }
    }

    return term_format_c1_key(term, buf, p - buf);
}

int format_numeric_keypad_key(char *buf, Terminal *term, char key,
                              bool shift, bool ctrl)
{
    char *p = buf;
    bool app_keypad = (term->app_keypad_keys && !term->no_applic_k);
    bool xterm_keypad = term->funky_type == FUNKY_XTERM ||
                       term->funky_type == FUNKY_XTERM_216;

    if (term->nethack_keypad && (key >= '1' && key <= '9')) {
        static const char nh_base[] = "bjnh.lyku";
        char c = nh_base[key - '1'];
        if (ctrl && c != '.')
            c &= 0x1F;
        else if (shift && c != '.')
            c += 'A'-'a';
        *p++ = c;
    } else {
        int xkey = 0;

        if (term->funky_type == FUNKY_VT400 ||
            (term->funky_type <= FUNKY_LINUX && app_keypad)) {
            switch (key) {
              case 'G': xkey = 'P'; break;
              case '/': xkey = 'Q'; break;
              case '*': xkey = 'R'; break;
              case '-': xkey = 'S'; break;
            }
        }

        if (app_keypad) {
            switch (key) {
              case '0': xkey = 'p'; break;
              case '1': xkey = 'q'; break;
              case '2': xkey = 'r'; break;
              case '3': xkey = 's'; break;
              case '4': xkey = 't'; break;
              case '5': xkey = 'u'; break;
              case '6': xkey = 'v'; break;
              case '7': xkey = 'w'; break;
              case '8': xkey = 'x'; break;
              case '9': xkey = 'y'; break;
              case '.': xkey = 'n'; break;
              case ',': xkey = 'l'; break;
              case '\r': xkey = 'M'; break;

              case '+':
                /*
                 * Keypad + is tricky. It covers a space that would
                 * be taken up on the VT100 by _two_ keys; so we
                 * let Shift select between the two. Worse still,
                 * in xterm function key mode we change which two...
                 */
                if (xterm_keypad)
                    xkey = shift ? 'l' : 'k';
                else
                    xkey = shift ? 'm' : 'l';
                break;

              case '/':
                if (xterm_keypad)
                    xkey = 'o';
                break;
              case '*':
                if (xterm_keypad)
                    xkey = 'j';
                break;
              case '-':
                if (xterm_keypad)
                    xkey = 'm';
                break;
            }
        }

        if (xkey) {
            if (term->vt52_mode) {
                if (xkey >= 'P' && xkey <= 'S')
                    p += sprintf(p, "\x1B%c", xkey);
                else
                    p += sprintf(p, "\x1B?%c", xkey);
            } else
                p += sprintf(p, "\x1BO%c", xkey);
        }
    }

    return term_format_c1_key(term, buf, p - buf);
}

void term_keyinputw(Terminal *term, const wchar_t *widebuf, int len)
{
    strbuf *buf = term_input_data_from_unicode(term, widebuf, len, false);
    if (buf->len)
        term_keyinput_internal(term, buf->s, buf->len, true);
    strbuf_free(buf);
}

void term_keyinput(Terminal *term, int codepage, const void *str, int len)
{
    if (codepage < 0 || codepage ==
        (in_utf(term) ? CP_UTF8 : term->ucsdata->line_codepage)) {
        /*
         * This text needs no translation, either because it's already
         * in the right character set, or because we got the special
         * codepage value -1 from our caller which means 'this data
         * should be charset-agnostic, just send it raw' (for really
         * simple things like control characters).
         */
        term_keyinput_internal(term, str, len, true);
    } else {
        strbuf *buf = term_input_data_from_charset(term, codepage, str, len);
        if (buf->len)
            term_keyinput_internal(term, buf->s, buf->len, true);
        strbuf_free(buf);
    }
}

void term_nopaste(Terminal *term)
{
    if (term->paste_len == 0)
        return;
    sfree(term->paste_buffer);
    term_bracketed_paste_stop(term);
    term->paste_buffer = NULL;
    term->paste_len = 0;
}

static void deselect(Terminal *term)
{
    term->selstate = NO_SELECTION;
    term->selstart.x = term->selstart.y = term->selend.x = term->selend.y = 0;
}

void term_lost_clipboard_ownership(Terminal *term, int clipboard)
{
    if (!(term->n_mouse_select_clipboards > 1 &&
          clipboard == term->mouse_select_clipboards[1]))
        return;

    deselect(term);
    term_update(term);

    /*
     * Since terminal output is suppressed during drag-selects, we
     * should make sure to write any pending output if one has just
     * finished.
     */
    term_out(term, false);
}

static void term_added_data(Terminal *term, bool called_from_term_data)
{
    if (!term->in_term_out) {
        term->in_term_out = true;
        term_out(term, called_from_term_data);
        term->in_term_out = false;
    }
}

size_t term_data(Terminal *term, const void *data, size_t len)
{
    bufchain_add(&term->inbuf, data, len);
    term_added_data(term, true);
    return bufchain_size(&term->inbuf);
}

void term_provide_logctx(Terminal *term, LogContext *logctx)
{
    term->logctx = logctx;
}

void term_set_focus(Terminal *term, bool has_focus)
{
    if (term->has_focus == has_focus) return;
    if (!has_focus) term_mouse_cancel(term);
    term->has_focus = has_focus;
    if (term->mouse_focus_reporting && !term->no_mouse_rep && term->ldisc)
        nemo_protocol_send(term, has_focus ? "\033[I" : "\033[O", 3);
    term_schedule_cblink(term);
}

/*
 * Provide "auto" settings for remote tty modes, suitable for an
 * application with a terminal window.
 */
char *term_get_ttymode(Terminal *term, const char *mode)
{
    const char *val = NULL;
    if (strcmp(mode, "ERASE") == 0) {
        val = term->bksp_is_delete ? "^?" : "^H";
    } else if (strcmp(mode, "IUTF8") == 0) {
        val = (term->ucsdata->line_codepage == CP_UTF8) ? "yes" : "no";
    }
    /* FIXME: perhaps we should set ONLCR based on lfhascr as well? */
    /* FIXME: or ECHO and friends based on local echo state? */
    return dupstr(val);
}

struct term_userpass_state {
    prompts_t *prompts;
    size_t curr_prompt;
    enum TermUserpassPromptState {
        TUS_INITIAL,         /* haven't even printed the prompt yet */
        TUS_ACTIVE,          /* prompt is currently receiving user input */
        TUS_ABORTED,         /* user pressed ^C or ^D to cancel prompt */
    } prompt_state;
    Terminal *term;
    TermLineEditor *le;
    TermLineEditorCallbackReceiver le_rcv;
};

static void term_userpass_next_prompt(struct term_userpass_state *s);

/*
 * Signal that a prompts_t is done. This involves sending a
 * notification to the caller, and also turning off our own callback
 * that listens for more data arriving in the ldisc's input queue.
 */
static inline SeatPromptResult signal_prompts_t(Terminal *term, prompts_t *p,
                                                SeatPromptResult spr)
{
    assert(p->callback && "Asynchronous userpass input requires a callback");
    queue_toplevel_callback(p->callback, p->callback_ctx);
    if (term->ldisc)
        ldisc_provide_userpass_le(term->ldisc, NULL);
    p->spr = spr;
    if (p->data) {
        term_userpass_state_free(p->data);
        p->data = NULL;
    }
    return spr;
}

/* Tiny wrapper to make it easier to write lots of little strings */
static inline void term_write(Terminal *term, ptrlen data)
{
    term_data(term, data.ptr, data.len);
}

static void term_lineedit_to_terminal(
    TermLineEditorCallbackReceiver *rcv, ptrlen data)
{
    struct term_userpass_state *s = container_of(
        rcv, struct term_userpass_state, le_rcv);
    prompt_t *pr = s->prompts->prompts[s->curr_prompt];
    if (pr->echo)
        term_write(s->term, data);
}

static void term_lineedit_to_backend(
    TermLineEditorCallbackReceiver *rcv, ptrlen data)
{
    struct term_userpass_state *s = container_of(
        rcv, struct term_userpass_state, le_rcv);
    prompt_t *pr = s->prompts->prompts[s->curr_prompt];
    put_datapl(pr->result, data);
}

static void term_lineedit_newline(TermLineEditorCallbackReceiver *rcv)
{
    struct term_userpass_state *s = container_of(
        rcv, struct term_userpass_state, le_rcv);

    prompt_t *pr = s->prompts->prompts[s->curr_prompt];
    if (!pr->echo) {
        /* If echo is disabled, we won't have printed the newline in
         * term_lineedit_to_terminal, so print it now */
        term_write(s->term, PTRLEN_LITERAL("\x0D\x0A"));
    }

    ldisc_provide_userpass_le(s->term->ldisc, NULL);
    s->curr_prompt++;
    s->prompt_state = TUS_INITIAL;
    term_userpass_next_prompt(s);
}

static void term_lineedit_special(
    TermLineEditorCallbackReceiver *rcv, SessionSpecialCode code, int arg)
{
    struct term_userpass_state *s = container_of(
        rcv, struct term_userpass_state, le_rcv);
    switch (code) {
      case SS_IP:
      case SS_EOF:
        ldisc_provide_userpass_le(s->term->ldisc, NULL);
        s->prompt_state = TUS_ABORTED;
        signal_prompts_t(s->term, s->prompts, SPR_USER_ABORT);
      default:
        break;
    }
}

static const TermLineEditorCallbackReceiverVtable
term_userpass_lineedit_receiver_vt = {
    .to_terminal = term_lineedit_to_terminal,
    .to_backend = term_lineedit_to_backend,
    .special = term_lineedit_special,
    .newline = term_lineedit_newline,
};

static struct term_userpass_state *term_userpass_state_new(
    Terminal *term, prompts_t *prompts)
{
    struct term_userpass_state *s = snew(struct term_userpass_state);
    s->prompts = prompts;
    s->curr_prompt = 0;
    s->prompt_state = TUS_INITIAL;
    s->term = term;
    s->le_rcv.vt = &term_userpass_lineedit_receiver_vt;
    s->le = lineedit_new(term, LE_INTERRUPT | LE_EOF_ALWAYS | LE_ESC_ERASES,
                         &s->le_rcv);
    assert(!term->userpass_state);
    term->userpass_state = s;
    return s;
}

static void term_userpass_state_free(struct term_userpass_state *s)
{
    assert(s->term->userpass_state == s);
    s->term->userpass_state = NULL;
    lineedit_free(s->le);
    sfree(s);
}

static void term_userpass_next_prompt(struct term_userpass_state *s)
{
    if (s->prompt_state != TUS_INITIAL)
        return;
    if (s->curr_prompt < s->prompts->n_prompts) {
        prompt_t *pr = s->prompts->prompts[s->curr_prompt];
        term_write(s->term, ptrlen_from_asciz(pr->prompt));
        s->prompt_state = TUS_ACTIVE;
        ldisc_provide_userpass_le(s->term->ldisc, s->le);
    } else {
        /* This triggers the callback provided by the userpass client,
         * which will call term_userpass_state to fetch the result
         * we're storing here */
        signal_prompts_t(s->term, s->prompts, SPR_OK);
    }
}

static bool terminal_use_utf8 = true;
bool set_legacy_charset_handling(bool newvalue)
{
    terminal_use_utf8 = !newvalue;
    return true;
}

/*
 * Process some terminal data in the course of username/password
 * input.
 */
SeatPromptResult term_get_userpass_input(Terminal *term, prompts_t *p)
{
    if (!term->ldisc) {
        /* Can't handle interactive prompts without an ldisc */
        return signal_prompts_t(term, p, SPR_SW_ABORT(
            "Terminal not prepared for interactive prompts"));
    }

    if (p->spr.kind != SPRK_INCOMPLETE) {
        /* We've already finished these prompts, so return the same
         * result again */
        return p->spr;
    }

    struct term_userpass_state *s = (struct term_userpass_state *)p->data;

    if (!s) {
        /*
         * First call. Set some stuff up.
         */
        p->data = s = term_userpass_state_new(term, p);
        p->spr = SPR_INCOMPLETE;
        term->userpass_utf8_override = p->utf8 && terminal_use_utf8;
        /* We only print the `name' caption if we have to... */
        if (p->name_reqd && p->name) {
            ptrlen plname = ptrlen_from_asciz(p->name);
            term_write(term, plname);
            if (!ptrlen_endswith(plname, PTRLEN_LITERAL("\n"), NULL))
                term_write(term, PTRLEN_LITERAL("\r\n"));
        }
        /* ...but we always print any `instruction'. */
        if (p->instruction) {
            ptrlen plinst = ptrlen_from_asciz(p->instruction);
            term_write(term, plinst);
            if (!ptrlen_endswith(plinst, PTRLEN_LITERAL("\n"), NULL))
                term_write(term, PTRLEN_LITERAL("\r\n"));
        }
        /*
         * Zero all the results, in case we abort half-way through.
         */
        {
            int i;
            for (i = 0; i < (int)p->n_prompts; i++)
                prompt_set_result(p->prompts[i], "");
        }
        /* And print the first prompt. */
        term_userpass_next_prompt(s);
    }

    return SPR_INCOMPLETE;
}

void term_notify_minimised(Terminal *term, bool minimised)
{
    term->minimised = minimised;
}

void term_notify_palette_changed(Terminal *term)
{
    palette_reset(term, true);
}

void term_notify_window_pos(Terminal *term, int x, int y)
{
    term->winpos_x = x;
    term->winpos_y = y;
}

void term_notify_window_size_pixels(Terminal *term, int x, int y)
{
    term->winpixsize_x = x;
    term->winpixsize_y = y;
}

/*
 * Set the pre-edit text as required by an input method.  preedit_text
 * is expected to be in UTF-8.  It's NULL if no pre-edit text is
 * required.  It's owned by the caller and must not be freed here.
 */
void term_set_preedit_text(Terminal *term, char *preedit_text)
{
    freetermline(term->preedit_termline);
    term->preedit_termline = NULL;
    if (preedit_text != NULL) {
        BinarySource src[1];
        int width = 0;

        term->preedit_termline = newtermline(term, 0, false);
        BinarySource_BARE_INIT(src, preedit_text, strlen(preedit_text));
        while (get_avail(src)) {
            unsigned int c = decode_utf8(src, NULL);
            switch (term_char_width(term, c)) {
              case -1:
                /* Ignore control characters. */
                break;
              case 0:
                if (width == 0) {
                    width = 1;
                    resizeline(term, term->preedit_termline, width);
                }
                if (term->preedit_termline->chars[width - 1].chr == UCSWIDE)
                    add_cc(term->preedit_termline, width - 2, c);
                else
                    add_cc(term->preedit_termline, width - 1, c);
                break;
              case 1:
                width += 1;
                resizeline(term, term->preedit_termline, width);
                term->preedit_termline->chars[width - 1].chr = c;
                break;
              case 2:
                width += 2;
                resizeline(term, term->preedit_termline, width);
                term->preedit_termline->chars[width - 2].chr = c;
                term->preedit_termline->chars[width - 1].chr = UCSWIDE;
                break;
            }
        }
    }
    seen_disp_event(term);
}
