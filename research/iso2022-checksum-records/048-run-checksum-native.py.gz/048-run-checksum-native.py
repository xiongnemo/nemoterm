from pathlib import Path
import shutil,subprocess,sys
root=Path(__file__).resolve().parents[1]
dest=root/'build/checksum-native-01';dest.mkdir(exist_ok=False)
for name in ['dist','tools','build','research']:(dest/name).mkdir()
shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('__pycache__'))
shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools/nemoterm_debug.py')
shutil.copy2(root/'build/charset-checksum-single-01/nemoterm.exe',dest/'dist/nemoterm.exe')
runner=root.parent/'rtl-worktree/build/run-owned-check.py'
with (dest/'outer.log').open('w',encoding='utf-8') as log:
    run=subprocess.run([sys.executable,str(runner),str(dest),'iso2022'],
        cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=210)
print('native exit',run.returncode,flush=True)
print((dest/'outer.log').read_text(encoding='utf-8')[-4500:])
raise SystemExit(run.returncode)
