from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];project=root.parents[1]
fixtures=project/'build/tab-api-worktree'
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=fixtures,text=True).strip()
assert revision=='6ab186d687e48ac977e82e87b9acd11ad2b2bf8b'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=fixtures,text=True).strip()
assert json.loads((root/'build/checksum-native-01/research/iso2022-controller.json').read_text())['completed']
base=root/'build/checksum-memory-01';base.mkdir(exist_ok=False)
accepted=project/'dist/nemoterm.exe';candidate=root/'build/charset-checksum-single-01/nemoterm.exe'
assert hashlib.sha256(accepted.read_bytes()).hexdigest()=='c110843b1fd5a551d654df094fa716c1ea1c48383d90e642b964d7dfb3d15e26'
assert hashlib.sha256(candidate.read_bytes()).hexdigest()=='9f224f62babece3cbaf225d9a9bbce38c15256a2c4a1385846e7b6479fd5aa90'
results=[]
for renderer,side in [('gdi','top'),('directx','left')]:
    name='candidate-'+renderer;dest=base/name
    for directory in ('dist','research','build','tools'):(dest/directory).mkdir(parents=True)
    shutil.copytree(fixtures/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
    shutil.copy2(fixtures/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(candidate,dest/'dist/nemoterm.exe')
    print('Starting '+name,flush=True)
    with (dest/'controller.log').open('w') as log:
        run=subprocess.run([sys.executable,str(project/'build/rtl-worktree/build/run-owned-check.py'),
            str(dest),'tabs','--renderer',renderer,'--side',side,'--cols','160','--rows','48',
            '--font','SarasaTermSC Nerd Font Light','--workload-memory'],stdout=log,stderr=subprocess.STDOUT,timeout=210)
    observed_path=dest/'research'/f'workload-tabs-{renderer}-{side}-observed.json'
    observed=json.loads(observed_path.read_text()) if observed_path.exists() else {}
    controller=json.loads((dest/'research/tabs-controller.json').read_text())
    record=dict(name=name,fixture_revision=revision,executable_sha256=hashlib.sha256(candidate.read_bytes()).hexdigest(),
        exit_code=run.returncode,checks=len(observed.get('checks',[])),actual=observed.get('actual_renderer'),
        phase=observed.get('phase'),error=observed.get('error'),seconds=controller['seconds'],
        memory_limit_passed=observed.get('memory_limit_passed'),cleanup=controller['cleanup'])
    memory=dest/'research'/f'workload-tabs-{renderer}-{side}-memory.json'
    if memory.exists():
        data=json.loads(memory.read_text());record.update(samples=data['sample_count'],
            peaks=data['peaks']['frontend'],injected=data['injected'])
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    if run.returncode:print((dest/'controller.log').read_text()[-1800:],flush=True)
raise SystemExit(0 if all(x['exit_code']==0 for x in results) else 1)
