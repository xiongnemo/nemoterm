Ten same-image agent sessions. Executed on GitHub runners; see source and wide-selected PNGs in artifact 14617302843 and receipts in 14616673170. Crops use nearest neighbour scaling.
