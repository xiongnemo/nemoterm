"""Retain completed sampling and the unchanged failed DX memory gate."""
from pathlib import Path
import hashlib,json,tarfile
root=Path(__file__).resolve().parents[1]
stage=root/'build/local-gdi-single-product-continuation-12ee33b-01'
research=root/'build/gdi-dense-memory-worktree/research'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p):
    with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
identity=load(stage/'IDENTITY.json');sha=identity['executable_sha256']
assert sha==digest(stage/'dist/nemoterm.exe')=='64195969a8f2e6653f854d598f169810107ee808d66eaa1088cf9e3ced6b259f'
results=load(stage/'logs/results.json');assert len(results)==18
assert all(r.get('exit_code')==0 for r in results[:-1])
assert results[-1]['name']=='unicode-kitty-memory-directx' and results[-1]['exit_code']==1
paths={};memory=[]
for result in results:
    name=result['name']
    if '-memory-' not in name:continue
    for record in result['observations']:
        path=stage/record['path']
        assert path.stat().st_size==record['bytes'] and digest(path)==record['sha256']
        paths[path]=record['path']
    paths[stage/'logs'/f'{name}.log']=f'logs/{name}.log'
    reports=list((stage/'case-evidence'/name/'research').glob('*observed.json'));assert len(reports)==1
    path=reports[0];d=load(path);samples=load(path.with_name(path.name.replace('-observed.json','-memory.json')))
    assert d['executable_sha256']==sha and not d['memory_instrumented']
    assert d['actual_grid']==[160,48] and d['font']=='SarasaTermSC Nerd Font Light'
    assert not samples['injected'] and not samples['errors'] and samples['sample_count']==len(samples['samples'])
    for key in ('private_ws','total_ws','private_commit'):
        assert samples['peaks']['frontend'][key]==max(s['groups']['frontend'][key] for s in samples['samples'])
    assert d['process_tree_memory']['peaks']==samples['peaks']
    assert not d['owned_job_cleanup']['terminated_remaining'] and d['owned_job_cleanup']['after']['active']==0
    assert d['host_close']['exit_code']==0 and len(d['checks'])==(10 if 'kitty' in name else 9)
    dx=d['renderer']=='directx';limit=25_000_000 if dx else 20_000_000
    assert d['actual_renderer']==(3 if dx else 1) and d['memory_limit_required']
    assert d['memory_limit_bytes']==limit and d['memory_limit_inclusive']==dx
    expected=d['peak_private_ws']<=limit if dx else d['peak_private_ws']<limit
    assert d['memory_limit_passed']==expected
    pixels=0
    if name=='unicode-kitty-memory-directx':
        assert not d['completed'] and not expected and d['phase']=='memory-acceptance'
        assert d['peak_private_ws']==27_107_328
        assert len(d['post_memory_kitty_unicode'])==4
        for capture in d['post_memory_kitty_unicode']:
            assert capture['matched'] and capture['after_memory_sampling'] and not capture['injected']
            assert capture['grid']==[160,48] and all(row['matched'] for row in capture['rows'])
            pixels+=capture['cells_verified']
        assert pixels==29072
    else:assert d['completed'] and expected
    memory.append(dict(name=name,passed=expected,peaks=samples['peaks'],sample_count=samples['sample_count'],
                       verified_image_cells=pixels,checks=d['checks'],cleanup=d['owned_job_cleanup']))
assert len(memory)==11 and sum(m['passed'] for m in memory)==10
for name in ('IDENTITY.json','cases.json','controller.py','continuation.json','logs/results.json'):
    paths[stage/name]=name
paths[Path(__file__)]='retainer.py'
archive=research/'gdi-image-cache-product-memory-continuation.tar.gz';records=[]
with archive.open('xb') as raw,tarfile.open(fileobj=raw,mode='w:gz') as bundle:
    for path,name in sorted(paths.items(),key=lambda pair:pair[1]):
        records.append(dict(path=name,bytes=path.stat().st_size,sha256=digest(path)));bundle.add(path,arcname=name,recursive=False)
manifest=dict(identity=identity,completed=False,scope='Ten independent memory cases pass; dense DX fails the unchanged 25 MB gate after all pixels and lifecycle checks. No promotion or DX optimization.',
    memory=memory,archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=digest(archive)),records=records)
with (research/'gdi-image-cache-product-memory-continuation-validation.json').open('x',encoding='utf-8') as stream:
    json.dump(manifest,stream,indent=2);stream.write('\n')
print(json.dumps(dict(passing_memory_groups=10,failed='unicode-kitty-memory-directx',archive=manifest['archive'],records=len(records)),indent=2))
