#!/bin/sh
set -eu
compiler=$1
case "$compiler" in gcc|clang) ;; *) exit 2;; esac
root=/mnt/c/Users/nemo/Documents/Projects/nemoterm
source="$root/build/gdi-dense-memory-worktree"
evidence="$root/build/${2:-legacy-modifiers-checks-01}/$compiler"
test ! -e "$evidence"
mkdir -p "$evidence"
build=$(cat "$root/build/answerback-nul-linux-$compiler-03/build-directory.txt")
printf '%s\n' "$build" > "$evidence/build-directory.txt"
GIT_DIR="$root/.git/worktrees/gdi-dense-memory-worktree"
GIT_WORK_TREE="$source"
export GIT_DIR GIT_WORK_TREE
"$compiler" --version > "$evidence/compiler.txt"
sha256sum "$source/vendor/putty-0.85/terminal/terminal.c" "$source/vendor/putty-0.85/terminal/terminal.h" "$source/vendor/putty-0.85/test/test_mok.c" "$source/tests/special_keys_reference.h" "$source/tests/legacy_modifiers_reference.h" "$source/vendor/putty-0.85/terminal/nemo_mok.h" "$source/vendor/putty-0.85/terminal/nemo_udk_terminal.inc" "$source/vendor/putty-0.85/conf-enums.h" "$source/vendor/putty-0.85/config.c" "$source/vendor/putty-0.85/putty.h" > "$evidence/sources.sha256"
cmake --build "$build" --target test_mok test_keyboard test_udk_terminal test_queries test_state_control test_win32_input test_tcap test_conf --parallel 2 > "$evidence/build.log" 2>&1
sha256sum "$source/vendor/putty-0.85/unix/unicode.c" >> "$evidence/sources.sha256"
sha256sum "$source/vendor/putty-0.85/terminal/nemo_tcap.c" "$source/vendor/putty-0.85/test/test_tcap.c" "$source/vendor/putty-0.85/test/test_conf.c" >> "$evidence/sources.sha256"
for target in test_mok test_keyboard test_udk_terminal test_queries test_state_control test_win32_input test_tcap test_conf; do
    ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1 timeout 120 "$build/$target" > "$evidence/$target.log" 2>&1
    printf '%s %s passed\n' "$compiler" "$target"
done
