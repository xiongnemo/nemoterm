from pathlib import Path
import hashlib,json,subprocess,sys
root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
stage=root/'build'/sys.argv[1]
stage.mkdir(exist_ok=False)
sources={}
changed=subprocess.check_output(['git','diff','--name-only'],cwd=work,text=True).splitlines()
for name in changed+['tests/legacy_modifiers_reference.h','tests/legacy_modifiers_reference.json']:
    path=work/name
    if path.is_file(): sources[name]=hashlib.sha256(path.read_bytes()).hexdigest()
(stage/'source-hashes.json').write_text(json.dumps(sources,indent=2)+'\n')
(stage/'source.patch').write_bytes(subprocess.check_output(['git','diff'],cwd=work))
results=[]
for target in sys.argv[2:] or ['test_mok','test_udk_terminal','test_conf']:
    executable=root/'build/gdi-dense-memory-build'/(target+'.exe')
    with (stage/(target+'.log')).open('wb') as log:
        p=subprocess.run([str(executable)],stdout=log,stderr=subprocess.STDOUT)
    results.append(dict(target=target,exit_code=p.returncode,sha256=hashlib.sha256(executable.read_bytes()).hexdigest()))
(stage/'results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
sys.exit(0 if all(r['exit_code']==0 for r in results) else 1)
