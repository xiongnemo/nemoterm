from pathlib import Path
import hashlib,json,subprocess,sys
root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
stage=root/'build'/(sys.argv[1] if len(sys.argv)>1 else 'legacy-modifiers-checks-01')/'mingw'
stage.mkdir(parents=True,exist_ok=False)
targets=['test_mok','test_keyboard','test_udk_terminal','test_queries','test_state_control','test_win32_input','test_tcap','test_conf']
with (stage/'build.log').open('w') as log:
    subprocess.run([str(root/'tools/python/cmake/data/bin/cmake.exe'),'--build',str(root/'build/gdi-dense-memory-build'),
        '--target','pterm',*targets,'--parallel','4'],stdout=log,stderr=subprocess.STDOUT,check=True)
results=[]
for target in targets:
    exe=root/'build/gdi-dense-memory-build'/(target+'.exe')
    with (stage/(target+'.log')).open('w') as log:
        subprocess.run([str(exe)],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    results.append(dict(target=target,sha256=hashlib.sha256(exe.read_bytes()).hexdigest()))
    print(target,'passed',flush=True)
(stage/'results.json').write_text(json.dumps(results,indent=2)+'\n')
sources={p.relative_to(work).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in [
    work/'vendor/putty-0.85/terminal/terminal.c',work/'vendor/putty-0.85/terminal/terminal.h',
    work/'vendor/putty-0.85/windows/nemo_key_input.c',work/'vendor/putty-0.85/test/test_mok.c',
    work/'vendor/putty-0.85/test/test_mok_win.c',work/'tests/special_keys_reference.h',work/'tests/extended_keys_reference.h',work/'vendor/putty-0.85/putty.h',work/'vendor/putty-0.85/terminal/nemo_mok.h',work/'vendor/putty-0.85/terminal/nemo_udk_terminal.inc',work/'vendor/putty-0.85/windows/window.c',work/'vendor/putty-0.85/config.c',work/'vendor/putty-0.85/conf-enums.h',work/'tests/legacy_modifiers_reference.h',work/'tests/legacy_modifiers_reference.json']}
for name in ('vendor/putty-0.85/terminal/nemo_tcap.c','vendor/putty-0.85/test/test_tcap.c',
             'vendor/putty-0.85/test/test_conf.c','vendor/putty-0.85/unix/unicode.c'):
    sources[name]=hashlib.sha256((work/name).read_bytes()).hexdigest()
(stage/'source-hashes.json').write_text(json.dumps(sources,indent=2)+'\n')
