from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
destination=root/'build'/sys.argv[1]
destination.mkdir(exist_ok=False)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
images={'negative':root/'build/extended-key-resources-native-01/fixed/dist/nemoterm.exe',
        'fixed':root/'build/gdi-dense-memory-build/nemoterm.exe'}
old=json.loads((root/'build/extended-key-resources-native-01/IDENTITY.json').read_text())
assert digest(images['negative'])==old['variants']['fixed']['dist/nemoterm.exe']
hashes=json.loads((root/'build/legacy-modifiers-checks-04/mingw/source-hashes.json').read_text())
for name,checksum in hashes.items():assert digest(work/name)==checksum,name
identity=dict(base_source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),
    physical_input=False,clipboard_access=False,source_hashes=hashes,variants={})
(destination/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','vendor'],cwd=work))
shutil.copy2(__file__,destination/'controller.py')
for variant,image in images.items():
    stage=destination/variant
    for folder in ('dist','research','build','logs','tools'):(stage/folder).mkdir(parents=True,exist_ok=False)
    shutil.copytree(work/'tests',stage/'tests',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    shutil.copy2(work/'tools/nemoterm_debug.py',stage/'tools/nemoterm_debug.py')
    shutil.copy2(image,stage/'dist/nemoterm.exe')
    for name,checksum in [('OpenConsole.exe','e3f4f7ef4a8c8105bdf8dea84bb4d135d7e0e9cfc477c2c0ca11d2489b39ed68'),
                          ('conpty.dll','feeef341d891643c62d30b6b07800bc70f0bc148f44cb8c3bee84aa557ae805a')]:
        p=root/'build/ci-host-restore-d914972/unverified-mingw'/name
        assert digest(p)==checksum
        shutil.copy2(p,stage/'dist'/name)
    identity['variants'][variant]={p.relative_to(stage).as_posix():digest(p) for p in sorted(stage.rglob('*')) if p.is_file()}
(destination/'IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n')
results=[]
for variant in images:
    stage=destination/variant
    with (stage/'logs/native.log').open('w') as log:
        result=subprocess.run([sys.executable,'tests/legacy_modifiers_window_smoke.py'],cwd=stage,
            env=dict(os.environ,NEMOTERM_TEST_EXE=str(stage/'dist/nemoterm.exe')),
            stdout=log,stderr=subprocess.STDOUT,timeout=2800)
    report=json.loads((stage/'research/legacy-modifiers-observed.json').read_text())
    assert all(v['cleanup']['after']['active']==0 for v in report['profiles'].values())
    results.append(dict(variant=variant,exit_code=result.returncode,completed=report['completed'],
        streams=len(report['cases']),excluded=len(report['excluded']),profiles=report['profiles']))
    (destination/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps({k:v for k,v in results[-1].items() if k!='profiles'}),flush=True)
    if variant=='negative':
        assert result.returncode!=0 and not report['completed']
        assert report['profiles']['6']['last_snapshot']['phase']=='control-resource0/0'
        assert report['profiles']['6']['last_snapshot']['hex']=='1b5b306e'
        assert report['cases']['control-default-function/0']=='1b5b306e1b4f501b5b306e'
    else:
        assert result.returncode==0 and report['completed']
        assert all(not p['cleanup']['terminated_remaining'] for p in report['profiles'].values())
