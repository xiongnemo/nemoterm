from pathlib import Path
import json,subprocess
root=Path(__file__).resolve().parents[1];dest=root/'build/charset-cmake';dest.mkdir()
commands=[['cmake','-S',str(root/'vendor/putty-0.85'),'-B',str(dest),'-G','Ninja',
           '-DPUTTY_GTK_VERSION=NONE','-DPUTTY_GSSAPI=OFF'],
          ['cmake','--build',str(dest),'--target','test_iso2022_charset','--parallel','2'],
          [str(dest/'test_iso2022_charset')]]
results=[]
for i,command in enumerate(commands):
    with (dest/f'{i}.log').open('w') as log:
        run=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    results.append(dict(command=command,exit_code=run.returncode))
    (dest/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(i,run.returncode,flush=True)
    if run.returncode:print((dest/f'{i}.log').read_text()[-2000:]);raise SystemExit(run.returncode)
