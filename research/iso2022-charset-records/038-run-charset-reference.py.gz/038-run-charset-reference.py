from pathlib import Path
import json,subprocess,sys
root=Path(__file__).resolve().parents[1]
for batch in range(4):
    output=root/f'build/reference/charsets-canonical-{batch}.json'
    assert not output.exists()
    with output.with_suffix('.log').open('w') as log:
        subprocess.run([sys.executable,str(root/'tests/xterm_charsets_oracle.py'),
            '--batch',str(batch),'--output',str(output)],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
    d=json.loads(output.read_text());print(batch,len(d['cases']),flush=True)
