from pathlib import Path
import json,os,subprocess
root=Path(__file__).resolve().parents[1];dest=root/'build/charset-linux';dest.mkdir(exist_ok=True)
results=[]
for kind,flags in [('normal',[]),('sanitizers',['-fsanitize=address,undefined','-fno-omit-frame-pointer'])]:
    image=dest/('test_charset-'+kind)
    command=['gcc','-std=c11','-Wall','-Wextra','-Werror','-O1','-g',*flags,
        '-I',str(root/'vendor/putty-0.85/terminal'),str(root/'tests/test_charset.c'),
        str(root/'vendor/putty-0.85/terminal/nemo_charset.c'),'-o',str(image)]
    with (dest/(kind+'-build.log')).open('w') as log:
        run=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
    if run.returncode:print((dest/(kind+'-build.log')).read_text());raise SystemExit(run.returncode)
    with (dest/(kind+'-test.log')).open('w') as log:
        run=subprocess.run([str(image)],cwd=root,stdout=log,stderr=subprocess.STDOUT,
            env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1'))
    print(kind,run.returncode,(dest/(kind+'-test.log')).read_text(),flush=True)
    results.append(dict(kind=kind,command=command,exit_code=run.returncode))
    (dest/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    if run.returncode:raise SystemExit(run.returncode)
