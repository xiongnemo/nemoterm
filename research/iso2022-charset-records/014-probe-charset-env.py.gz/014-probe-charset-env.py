from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tests'))
from xterm_state_oracle import run_cases
q=b'\x1b[31#y'+b''.join(f'\x1b[{x};1;1;{x};1;{x}*y'.encode() for x in range(1,5))
start=b'\x1bc\x1b[65;1"p'
cases={
    'utf8-on':start+b'\x1b%G'+bytes.fromhex('e4b8ad')+b'X'+q,
    'utf8-off':start+b'\x1b%@'+bytes.fromhex('e4b8ad')+b'X'+q,
    'nrc-before-utf':start+b'\x1b[?42h\x1b%G\x1b(4#['+q,
    'utf-before-nrc':start+b'\x1b%G\x1b[?42h\x1b(4#['+q,
}
for name,args in [('default',[]),('toggle',['-xrm','*locale: false','-xrm','*utf8: 1','-xrm','*wideChars: true'])]:
    run_cases('/tmp/nemoterm-xterm-reference/xterm','build/reference/charset-environment-'+name+'.json',cases,
              ['-ti','vt525','-xrm','*allowWindowOps: true',*args],raw_replies=True,utf8_command_line=False)
