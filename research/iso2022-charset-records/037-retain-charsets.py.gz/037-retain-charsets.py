from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path(__file__).resolve().parents[1];dest=root/'research/iso2022-charset-records';dest.mkdir()
paths=list((root/'build/reference').glob('*'))
paths += [p for folder in ('charset-linux','charset-msvc','charset-cmake')
          for p in (root/'build'/folder).glob('*') if p.suffix in ('.log','.json')]
paths += [root/'build'/n for n in ('probe-charset-env.py','run-charset-reference.py',
          'generate-charset-reference.py','check-charset-linux.py','check-charset-cmake.py')]
paths += [Path(__file__),root/'tools/generate_charset_tables.py']
paths += [root/'tests'/n for n in ('xterm_state_oracle.py','xterm_charsets_oracle.py','test_charset.c','charset_reference.h')]
paths += [root/'vendor/putty-0.85/terminal'/n for n in ('nemo_charset.c','nemo_charset.h','nemo_charset_data.h')]
manifest=dict(source_base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    scope='Mapping/descriptor component only; not yet connected to terminal parser or advertised as runtime support',
    reference=dict(version='XTerm(412)',sha256='089de40f5a47b2ee07ddb778e7e031116673c7c20a55facbd9caf8d78978573c',
                   captured_streams=320,verified_mapping_streams=160,verified_cells=15360,
                   earlier_forced_utf8_capture='not mapping acceptance'),
    linux=json.loads((root/'build/charset-linux/results.json').read_text()),
    cmake=json.loads((root/'build/charset-cmake/results.json').read_text()),
    existing_reference_regression=dict(cases=44,exact_match=True),records=[])
for i,p in enumerate(sorted(set(paths))):
    data=p.read_bytes();archive=dest/f'{i:03d}-{p.name}.gz';archive.write_bytes(gzip.compress(data,mtime=0))
    assert gzip.decompress(archive.read_bytes())==data
    manifest['records'].append(dict(path=p.relative_to(root).as_posix(),archive=archive.relative_to(root).as_posix(),
                                   bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(root/'research/iso2022-charsets-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(dict(records=len(manifest['records']),compressed_bytes=sum(p.stat().st_size for p in dest.iterdir())))
