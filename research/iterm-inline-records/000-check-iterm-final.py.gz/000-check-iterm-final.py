import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path.cwd();base=root/'build/iterm-final-local';base.mkdir(exist_ok=False)
exe=root/'build/iterm-single-03/nemoterm.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='6c1bfae51422477abe5a87c3a2e44bb0843ba2d27d75d33cea68cba3ae97711b'
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
cases=[('images-'+renderer,'iterm_image',['--renderer',renderer]) for renderer in ['gdi','opengl','directx']]
cases += [('renderer','renderer',[]),('sixel','sixel',[])]
for renderer,side in [('gdi','top'),('directx','left')]:
    for inline in [False,True]:
        cases.append(('memory-'+renderer+('-images' if inline else ''),'tabs',['--renderer',renderer,'--side',side,'--cols','160','--rows','48','--workload-memory']+(['--inline-images'] if inline else [])))
results=[]
for label,test,args in cases:
    dest=base/label
    for folder in ['dist','research','build','tools']:(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
    shutil.copy2(exe,dest/'dist');shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    with (dest/'controller.log').open('w') as log:
        result=subprocess.run([sys.executable,str(controller),str(dest),test,*args],stdout=log,stderr=subprocess.STDOUT)
    record=dict(label=label,exit_code=result.returncode)
    for p in (dest/'research').glob('*-memory.json'):
        d=json.loads(p.read_text());record.update(samples=d['sample_count'],peaks=d['peaks']['frontend'])
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(record,flush=True)
    if result.returncode:
        print((dest/'controller.log').read_text()[-2600:],flush=True)
        raise SystemExit(result.returncode)
