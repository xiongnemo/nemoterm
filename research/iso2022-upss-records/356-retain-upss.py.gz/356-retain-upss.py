from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path(__file__).resolve().parents[1];project=root.parents[1]
dest=root/'research/iso2022-upss-records'
files=set((root/'build').glob('upss-*.log'))
for folder in ('charset-upss-linux','upss-final-linux'):
    files.update((root/'build'/folder).glob('*.log'))
    files.add(root/'build'/folder/'results.json')
for path in (root/'build/reference').glob('upss-*'):
    if path.is_dir():files.update(path.glob('*.json'))
    else:files.add(path)
for folder in ('upss-native-01','upss-memory-01'):
    for path in (root/'build'/folder).rglob('*'):
        if 'research' in path.parts or path.suffix=='.log' or path.name=='results.json':files.add(path)
for path in ['tests/xterm_upss_oracle.py','tests/upss_reference.h',
    'tests/charset_input_reference.h','tests/upss_input_reference.h',
    'tests/xterm_charset_input_oracle.py','tests/iso2022_window_smoke.py',
    'tools/generate_upss_reference.py','tools/generate_charset_input_reference.py',
    'vendor/putty-0.85/terminal/nemo_charset.c','vendor/putty-0.85/terminal/nemo_charset.h',
    'vendor/putty-0.85/terminal/terminal.c','vendor/putty-0.85/terminal/terminal.h',
    'vendor/putty-0.85/test/test_state_control.c','build/check-charset-upss.py',
    'build/check-upss-final-linux.py','build/check-upss-memory.py','build/run-upss-native.py',
    'build/link-charset-upss.py','build/link-charset-upss-final.py','build/retain-upss.py']:
    files.add(root/path)
for folder in ('charset-upss-single-01','charset-upss-single-02'):
    for name in ('link.log','link.rsp','image.json'):files.add(root/'build'/folder/name)
for name in ('charsets.c','charsets.h','misc.c','charproc.c','cursor.c','ptydata.c','ctlseqs.txt'):
    files.add(Path('//wsl.localhost/Debian/tmp/nemoterm-xterm-reference')/name)
for name in ('native_test_utils.py','owned_job.py','automation_capture.py','protocol_oracle_window.py','fixture_io.py','mouse_fixture.py'):
    files.add(root/'build/upss-native-01/tests'/name)
files.add(root/'build/upss-native-01/tools/nemoterm_debug.py')
for name in ('tabs_window_smoke.py','native_test_utils.py','owned_job.py','automation_capture.py',
             'memory_limits.py','tab_workload_memory.py','resource_settle.py','fixture_io.py'):
    files.add(root/'build/upss-memory-01/candidate-directx/tests'/name)
files={path for path in files if not path.is_dir()}
for path in files:assert path.is_file(),path
dest.mkdir(exist_ok=False);records=[]
for i,path in enumerate(sorted(files,key=str)):
    content=path.read_bytes();name=f'{i:03}-{path.name}.gz'
    packed=gzip.compress(content,mtime=0);(dest/name).write_bytes(packed)
    assert gzip.decompress(packed)==content
    records.append(dict(source=str(path.relative_to(root)) if path.is_relative_to(root) else str(path),
        archive=f'{dest.name}/{name}',bytes=len(content),sha256=hashlib.sha256(content).hexdigest()))
def identity(path):
    content=path.read_bytes()
    return dict(path=str(path),bytes=len(content),sha256=hashlib.sha256(content).hexdigest())
linux=json.loads((root/'build/upss-final-linux/results.json').read_text())
assert len(linux)==18 and all(r['exit_code']==0 for r in linux)
memory=json.loads((root/'build/upss-memory-01/results.json').read_text())
assert len(memory)==2 and all(r['exit_code']==0 and r['memory_limit_passed'] and not r['injected'] for r in memory)
native=json.loads((root/'build/upss-native-01/research/iso2022-observed.json').read_text())
assert native['completed'] and all(r['completed'] and not r['fallback'] for r in native['modes'])
report=dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    state='upss-development-checkpoint-not-promoted',records=records,
    reference=dict(streams=112,mapping_streams=56,cells=5376,transport_shapes=['whole','single-byte'],
        paste_cases=28,paste_codepoints=586),
    built_single=identity(root/'build/charset-upss-single-02/nemoterm.exe'),
    first_single_before_final_header_guard=identity(root/'build/charset-upss-single-01/nemoterm.exe'),
    accepted_unchanged=identity(project/'dist/nemoterm.exe'),memory_runs=memory,
    native=dict(renderers=[m['actual_renderer'] for m in native['modes']],scenes_per_renderer=7,
        requested_grid=native['requested_grid'],font=native['font'],capture='public automation API'),
    validation=['8 final Linux suites normal and ASan/UBSan/leak checks passed',
        '8 final MSVC suites passed; frontend and integrated single image built',
        'W4 WX standalone mapper and 15360 prior reference cells passed',
        'actual GDI/OpenGL/DirectX pixels, UPSS query and ConPTY paste passed',
        'unchanged GDI and DirectX finite-workload memory/resource gates passed'],
    limitations=['full CI for new checkpoint pending','no all-agent memory acceptance',
        'DirectX total working set still above approximately 50 MB','prior native tab-close crash unresolved',
        'broader lower-level output matrix and extended legacy checksums pending',
        'not every encoding or malformed-input combination tested'])
assert report['accepted_unchanged']['sha256']=='c110843b1fd5a551d654df094fa716c1ea1c48383d90e642b964d7dfb3d15e26'
(root/'research/iso2022-upss-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(records=len(records),archive_bytes=sum(p.stat().st_size for p in dest.glob('*.gz')),
    built=report['built_single'],accepted=report['accepted_unchanged']),indent=2))
