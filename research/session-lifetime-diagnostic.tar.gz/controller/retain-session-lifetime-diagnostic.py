from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1]
work=root/'build/tab-callback-diagnostic-worktree'
failed=root/'build/ci-legacy-parameter-69496bb'
passed=root/'build/ci-answerback-config-23c90fe'
controls=root/'build/session-lifetime-controls-01'
diagnostic=root/'build/ci-session-lifetime-db05692'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
run=load(diagnostic/'tabs-run.json')
assert run['databaseId']==43760193865 and run['headSha']=='db05692dd96b4edf40cf13a80aacf1d8b916f6b4' and run['status']=='completed'
name='unicode-kitty-workload-tabs-gdi-top'
failed_research=failed/'single-evidence/build/single-exe-check/research'
passed_research=passed/'single-evidence/build/single-exe-check/research'
original=load(failed_research/(name+'-observed.json'))
assert original['executable_sha256']=='4a50a382545ef40ffe06d2950e75bd71ff57a06558f3a6d518fd5653ba48319a'
assert not original['completed'] and original['memory_limit_passed'] and original['session_seconds']==300
assert original['process_before_cleanup']['exit_code']==0 and original['owned_job_cleanup']['after']['active']==0
control=load(controls/'results.json');assert len(control['results'])==2
assert [r['exit_receipt']['reason'] for r in control['results']]==['deadline','control-stop']
assert all(r['frontend_exit']==0 and not r['cleanup']['terminated_remaining'] for r in control['results'])
comparison=load(passed_research/(name+'-observed.json'))
validation=load(passed_research/'single-exe-validation.json')
assert comparison['completed'] and comparison['memory_limit_passed'] and comparison['session_seconds']==300
assert len(validation['passed_checks'])==163 and validation['executable_directory_files']==['nemoterm.exe']
assert validation['executable_sha256']==comparison['executable_sha256']==sha(passed/'product/nemoterm.exe')
identity=load(diagnostic/'diagnostic/identity.json')
assert identity['executable_sha256']==original['executable_sha256'] and identity['source_run']=='43754577320'
observed=load(diagnostic/'diagnostic/replay-1-observed.json')
assert observed['executable_sha256']==original['executable_sha256'] and observed['session_seconds']==300
files=[]
def add(p,n):files.append(dict(path=n,source=p,bytes=p.stat().st_size,sha256=sha(p)))
for label,base in [('original',failed),('comparison',passed)]:
    for item in ('single-run.json','single-run.log','single-artifacts.json'):
        add(base/item,label+'/'+item)
    research=base/'single-evidence/build/single-exe-check/research'
    for p in research.glob(name+'*'):
        if p.is_file():add(p,label+'/research/'+p.name)
    add(base/'single-evidence/build/single-exe-check/logs'/(name+'.log'),label+'/'+name+'.log')
add(failed/'unverified-product/nemoterm.exe','original/nemoterm.exe')
add(failed/'unverified-product-download.json','original/product-download.json')
add(passed/'product-download.json','comparison/product-download.json')
add(passed_research/'single-exe-validation.json','comparison/single-exe-validation.json')
for name in ('results.json','controller.py'):add(controls/name,'controls/'+name)
for name in ('session_fixture.py','mouse_fixture.py','tabs_window_smoke.py','owned_job.py','fixture_io.py'):
    add(controls/'tests'/name,'controls/tests/'+name)
for p in diagnostic.rglob('*'):
    if p.is_file():add(p,'hosted/'+p.relative_to(diagnostic).as_posix())
add(Path(__file__),'controller/retain-session-lifetime-diagnostic.py')
archive=work/'research/session-lifetime-diagnostic.tar.gz';assert not archive.exists()
with tarfile.open(archive,'x:gz') as tar:
    for f in files:tar.add(f['source'],arcname=f['path'],recursive=False)
with tarfile.open(archive,'r:gz') as tar:
    for f in files:assert hashlib.sha256(tar.extractfile(f['path']).read()).hexdigest()==f['sha256']
result=dict(scope='Exact-image fixture lifetime diagnosis; retains the original failure and later independent single-image success without promoting either as current product acceptance.',
    original_run=43754577320,original_source='69496bb888ec96dc620978689e8d0ae7f1711a34',
    original_executable_sha256=original['executable_sha256'],
    original=dict(completed=False,frontend_exit=0,session_seconds=300,phase=original['phase'],
        peak_private_ws=original['peak_private_ws'],actual_grid=original['actual_grid'],
        cause='Expired child lifetime is a hypothesis; the original run has no exit receipt.'),
    local_controls=control['results'],comparison_run=43755825357,comparison_checks=163,
    diagnostic_run=run['databaseId'],diagnostic_conclusion=run['conclusion'],
    diagnostic_artifact=load(diagnostic/'diagnostic-download.json')['artifact_id'],
    replay={k:observed.get(k) for k in ('completed','phase','elapsed_seconds','actual_grid','probe_attach','session_exits','process_before_cleanup','owned_job_cleanup')},
    archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive)),
    files=[{k:v for k,v in f.items() if k!='source'} for f in files])
(work/'research/session-lifetime-diagnostic-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))
