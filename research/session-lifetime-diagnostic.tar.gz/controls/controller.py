"""Verify deadline and requested-stop receipts using two owned terminal jobs."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tempfile,time,uuid,winreg
root=Path(__file__).resolve().parents[1]
work=root/'build/tab-callback-diagnostic-worktree'
stage=root/'build/session-lifetime-controls-01';assert not stage.exists()
stage.mkdir();shutil.copytree(work/'tests',stage/'tests',ignore=shutil.ignore_patterns('__pycache__'))
(stage/'dist').mkdir();(stage/'research').mkdir()
source=root/'build/ci-legacy-parameter-69496bb/unverified-product/nemoterm.exe'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected='4a50a382545ef40ffe06d2950e75bd71ff57a06558f3a6d518fd5653ba48319a'
assert digest(source)==expected
shutil.copy2(source,stage/'dist/nemoterm.exe');shutil.copy2(__file__,stage/'controller.py')
sys.path.insert(0,str(stage/'tests'))
os.environ['NEMOTERM_TEST_EXE']=str(stage/'dist/nemoterm.exe')
from owned_job import OwnedJob
from fixture_io import read_snapshot,write_snapshot
from native_test_utils import wait_for
profile='lifetime-control-'+uuid.uuid4().hex
keypath='Software\\Nemo\\Nemoterm\\Sessions\\'+profile
results=[]
with winreg.CreateKey(winreg.HKEY_CURRENT_USER,keypath) as key:
    for name,value in dict(WarnOnClose=0,CloseOnExit=1,NemoRenderer=0,NemoTabs=0).items():
        winreg.SetValueEx(key,name,0,winreg.REG_DWORD,value)
try:
    for reason,seconds in [('deadline',2),('control-stop',30)]:
        row=dict(expected_reason=reason,lifetime_seconds=seconds)
        with tempfile.TemporaryDirectory(prefix='nemoterm-lifetime-') as tmp,OwnedJob() as job:
            tmp=Path(tmp)
            process=job.spawn([str(stage/'dist/nemoterm.exe'),'-load',profile,'--cols','20','--rows','6','-e',
                sys.executable,str(stage/'tests/session_fixture.py'),str(tmp),str(seconds)],
                creationflags=subprocess.CREATE_NO_WINDOW,env=dict(os.environ,NEMOTERM_CONPTY='bundled'))
            try:
                launch=wait_for(lambda:next((read_snapshot(p) for p in tmp.glob('*.launch.json') if read_snapshot(p)),None))
                pid=launch['pid'];assert launch['lifetime_seconds']==seconds
                wait_for(lambda:read_snapshot(tmp/f'{pid}.report.json'))
                if reason=='control-stop':write_snapshot(tmp/f'{pid}.control.json',dict(stop=True))
                row['frontend_exit']=process.wait(timeout=15);assert row['frontend_exit']==0
                row['exit_receipt']=read_snapshot(tmp/f'{pid}.exit.json')
                receipt=row['exit_receipt'];assert receipt['pid']==pid and receipt['reason']==reason
                assert receipt['deadline_reached']==(reason=='deadline')
                assert (receipt['elapsed_seconds']>=seconds)==(reason=='deadline')
                row['cleanup']=job.finish();assert not row['cleanup']['terminated_remaining'] and row['cleanup']['after']['active']==0
                results.append(row)
            finally:job.finish(grace=0)
finally:
    winreg.DeleteKey(winreg.HKEY_CURRENT_USER,keypath)
    record=dict(executable_sha256=expected,source_commit='69496bb888ec96dc620978689e8d0ae7f1711a34',
        fixture_hashes={n:digest(stage/'tests'/n) for n in ('session_fixture.py','mouse_fixture.py','tabs_window_smoke.py')},
        scope='Owned-process receipt controls only; not a replay or explanation of the original CI failure.',results=results)
    (stage/'results.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
