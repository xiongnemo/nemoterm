from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path.cwd();base=root/'build/after';base.mkdir(parents=True)
project=root.parents[1]
images=[('failed-ci',project/'build/iterm-images-worktree/build/ci-iterm-3a60e4f/unverified-product/nemoterm.exe','3160d72182db4c1760f664d75293837f34ddc49315fe44d75d0c36732c6c37c3'),('main-ci',project/'build/ci-main-8264b27/product/nemoterm.exe','11041b9d7b1ee3107827dd53336de6d46cd5f8db8f606915e936a0efdf070e8b')]
results=[]
for label,exe,digest in images:
    assert hashlib.sha256(exe.read_bytes()).hexdigest()==digest
    for side in ['top','bottom','left','right']:
        dest=base/(label+'-'+side)
        for name in ('dist','research','build','tools'):(dest/name).mkdir(parents=True)
        shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
        shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(exe,dest/'dist/nemoterm.exe')
        with (dest/'controller.log').open('w') as log:
            result=subprocess.run([sys.executable,str(project/'build/rtl-worktree/build/run-owned-check.py'),str(dest),'tabs_overflow','--side',side],stdout=log,stderr=subprocess.STDOUT)
        observed=dest/f'research/tabs-overflow-{side}-observed.json'
        d=json.loads(observed.read_text()) if observed.exists() else {}
        record=dict(image=label,side=side,exit_code=result.returncode,completed=d.get('completed'),close_seconds=d.get('close_seconds'),error=d.get('error'))
        results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2));print(record,flush=True)
        if result.returncode:
            print((dest/'controller.log').read_text()[-2800:]);raise SystemExit(result.returncode)
