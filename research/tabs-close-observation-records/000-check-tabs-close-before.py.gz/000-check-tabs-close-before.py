from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path.cwd();work=root/'build/tabs-close-worktree';base=work/'build/before';base.mkdir(parents=True)
exe=root/'build/iterm-images-worktree/build/ci-iterm-3a60e4f/unverified-product/nemoterm.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='3160d72182db4c1760f664d75293837f34ddc49315fe44d75d0c36732c6c37c3'
original=subprocess.check_output(['git','show','3a60e4fb29ed64515c0792a61c8b88d8e89c909c:tests/tabs_overflow_window_smoke.py'],cwd=root)
(base/'original-fixture.py').write_bytes(original)
text=original.decode();text=text.replace('import frida\n','import frida\nfrom thread_snapshot import OwnedThreadSnapshot\n')
line='            u.PostMessageW(host,0x10,0,0);assert process.wait(timeout=15)==0'
assert text.count(line)==1
text=text.replace(line,'''            close_started=time.monotonic()
            u.PostMessageW(host,0x10,0,0)
            try:
                assert process.wait(timeout=15)==0
                evidence['close_seconds']=time.monotonic()-close_started
            except subprocess.TimeoutExpired:
                evidence['close_seconds']=time.monotonic()-close_started
                evidence['host_still_exists']=bool(u.IsWindow(host))
                try:evidence['timeout_threads']=OwnedThreadSnapshot(process,job).snapshot('close-timeout')
                except Exception as error:evidence['snapshot_error']=repr(error)
                raise''')
results=[]
for i in range(3):
    dest=base/f'run-{i+1}'
    for name in ('dist','research','build','tools'):(dest/name).mkdir(parents=True)
    shutil.copytree(work/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
    shutil.copy2(work/'tools/nemoterm_debug.py',dest/'tools')
    (dest/'tests/tabs_overflow_window_smoke.py').write_text(text)
    shutil.copy2(exe,dest/'dist/nemoterm.exe')
    with (dest/'controller.log').open('w') as log:
        result=subprocess.run([sys.executable,str(root/'build/rtl-worktree/build/run-owned-check.py'),str(dest),'tabs_overflow','--side','bottom'],stdout=log,stderr=subprocess.STDOUT)
    observed=dest/'research/tabs-overflow-bottom-observed.json'
    d=json.loads(observed.read_text()) if observed.exists() else {}
    record=dict(run=i+1,exit_code=result.returncode,completed=d.get('completed'),close_seconds=d.get('close_seconds'),error=d.get('error'))
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2));print(record,flush=True)
