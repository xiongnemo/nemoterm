"""Retain successful native bell replies and observed Windows API effects."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/bell-modes-worktree'
base=root/'build/ci-bell-complete-5a1bcdb'
source='5a1bcdbf4636b6062a08af77d9791a9ebdbb1221'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'bell-window-run.json').read_bytes())
assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(43725655349,source,'completed','failure')
artifacts=json.loads((base/'bell-window-artifacts.json').read_bytes())['artifacts']
receipt=json.loads((base/'diagnostic-download.json').read_bytes())
artifact=next(a for a in artifacts if a['id']==receipt['artifact_id'])
assert artifact['name']=='bell-native-'+source and receipt['source']==source
d=base/'diagnostic'
image=d/'build/single-exe-dist/nemoterm.exe';image_sha=sha(image.read_bytes())
data=json.loads((d/'research/bell-modes-window-observed.json').read_bytes())
assert data['completed'] and data['executable_sha256']==image_sha
assert data['reference_sha256']=='c5a87d9f9ee75d637293e3a6767d86102be622271720e8ee4b704e5727c9b6b4'
with tarfile.open(work/'research/bell-modes-reference.tar.gz') as tar:
    reference=json.loads(tar.extractfile('reference/bell-modes-xterm.json').read())
streams=0
for name,steps in data['cases'].items():
    for i,step in enumerate(steps):
        expected=reference['cases'][name]['steps'][i]
        for key in ('sequence_hex','reply_hex','wire_with_barrier_hex'):assert step[key]==expected[key]
        assert step['native_before']['foreground']==step['native_after']['foreground']
        assert step['native_before']['topmost']==step['native_after']['topmost']
        for event in step['api']:
            if event['api']=='SetWindowPos':
                assert event['flags']==19 and event['result']==1
                assert step['native_after']['above_other']
        streams+=1
assert len(data['cases'])==112 and streams==192
assert len(data['cleanup'])==4
assert all(not c['terminated_remaining'] and c['after']['active']==0 for c in data['cleanup'])
assert image_sha==json.loads((d/'bell-image.json').read_text(encoding='utf-8-sig'))['Hash'].lower()
for mode in (0,1,2):
    sound=json.loads((d/f'research/bell-mode-{mode}-observed.json').read_bytes())
    assert sound['completed'] and sound['executable_sha256']==image_sha
visual=json.loads((d/'research/visual-bell-observed.json').read_bytes())
assert visual['executable_sha256']==image_sha and len(visual['modes'])==4
assert all(m['completed'] for m in visual['modes'])

states=json.loads((d/'research/bell-window-state-observed.json').read_bytes())
assert not states['completed'] and states['executable_sha256']==image_sha and len(states['checks'])==19
assert all(x['renderer']==0 for x in states['checks'])
assert states['checks'][-2]['name']=='inactive-host-active-tab-close'
assert states['checks'][-2]['focus_input_hex']=='1b5b306e'
assert states['checks'][-1]['name']=='new-active-notice-clears-on-foreground'
assert states['checks'][-1]['api']==[]
assert all(a['after']==a['window'] for a in data['focus_actions']+states['focus_actions'])

entries={'source/retainer.py':Path(__file__).read_bytes()}
for name in ['tests/bell_window_state_smoke.py','tests/owned_window_focus.py','tests/session_fixture.py','tests/fixture_io.py','vendor/putty-0.85/windows/nemo_tabs_host.inc','tests/bell_modes_window_smoke.py','tests/bell_window_smoke.py','tests/bell_visual_window_smoke.py',
             'tests/native_test_utils.py','tests/owned_job.py','tests/protocol_oracle_window.py',
             'tests/mouse_fixture.py','vendor/putty-0.85/windows/window.c','.github/workflows/ansi-conformance.yml']:
    entries['source/'+name]=subprocess.check_output(['git','show',source+':'+name],cwd=work)
for p in d.rglob('*'):
    if p.is_file():entries[p.relative_to(base).as_posix()]=p.read_bytes()
for p in base.glob('bell-window-*'):entries[p.name]=p.read_bytes()
entries['diagnostic-download.json']=(base/'diagnostic-download.json').read_bytes()
archive=work/'research/bell-activation-native.tar.gz';records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,raw in sorted(entries.items()):
        info=tarfile.TarInfo(name);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        records.append(dict(path=name,raw_bytes=len(raw),raw_sha256=sha(raw)))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path'] and sha(tar.extractfile(member).read())==record['raw_sha256']
manifest=dict(source=source,run=43725655349,conclusion='failure',artifact_id=artifact['id'],
    image=dict(bytes=image.stat().st_size,sha256=image_sha,accepted=False),cases=112,exact_reply_streams=streams,natural_child_cleanup=True,
    scope='Overall failure retained: 192 standalone replies and existing bell/visual fixtures pass, but the nineteenth GDI state still lacks notification acknowledgement on actual host reactivation. DirectX states are not reached. No full-product or local acceptance.',
    bundle=dict(path=archive.relative_to(work).as_posix(),bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),records=records))
(work/'research/bell-activation-native-validation.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Retained',len(records),'records,',archive.stat().st_size,'bytes;',streams,'exact native reply streams')
