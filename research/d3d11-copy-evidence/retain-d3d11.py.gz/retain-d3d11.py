import datetime,gzip,hashlib,json,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
out=root/'research/d3d11-copy-evidence';assert not out.exists();out.mkdir()
files=[];images={};runs={}
def retain(path,name):
    raw=path.read_bytes();data=gzip.compress(raw,mtime=0);dest=out/(name+'.gz');assert not dest.exists(),dest
    dest.write_bytes(data);files.append(dict(path=dest.relative_to(root).as_posix(),bytes=len(data),sha256=sha(data),raw_bytes=len(raw),raw_sha256=sha(raw),encoding='gzip'))
for name in ('control','copy','dynamic','batched','sequential'):
    folder=root/'build'/(name+'-single');identity=read(folder/'image.json');exe=folder/'nemoterm.exe'
    assert sha(exe.read_bytes())==identity['sha256'] and exe.stat().st_size==identity['bytes']
    images[name]=identity
    for p in sorted(folder.iterdir()):
        if p.suffix in ('.json','.rsp','.log','.txt','.c','.h','.patch'):retain(p,name+'-'+p.name)
for name in ('control-workload','copy-pixels','copy-workload','copy-resource-diagnostic',
             'dynamic-pixels','dynamic-workload','batched-pixels','batched-workload','batched-resource-diagnostic',
             'sequential-pixels','sequential-workload','sequential-resource-diagnostic'):
    folder=root/'build'/name;r=folder/'research';kind='renderer' if name.endswith('pixels') else 'tabs'
    controller=read(r/(kind+'-controller.json'))
    assert controller['executable_sha256']==images[name.split('-')[0]]['sha256']
    assert controller['cleanup']['after']['active']==0
    value=dict(controller=controller,fixture_class_change_only=kind=='tabs' and not name.endswith('diagnostic') and not name.startswith('control'),
               acceptance=False,diagnostic=name.endswith('diagnostic'))
    if kind=='renderer':
        v=read(r/'renderer-observed.json')
        assert v['completed'] and controller['completed']
        assert [m['active'] for m in v['modes']]==['GDI','OpenGL','DirectX']
        value.update(completed=True,modes=v['modes'],memory_acceptance=False)
    else:
        p=r/'workload-tabs-directx-left-observed.json'
        v=read(p) if p.exists() else None
        mem=read(r/'workload-tabs-directx-left-memory.json')
        assert not mem['errors'] and not mem['injected']
        if v:
            assert v['font']=='SarasaTermSC Nerd Font Light' and v['actual_grid']==[160,48] and v['actual_renderer']==3
            assert not v['completed']
        value.update(observed_result_present=v is not None,completed=False,functional_groups=len(v['checks']) if v else None,
            error=v.get('error') if v else 'Controller deadline; final fixture result missing',
            inner_cleanup=v.get('owned_job_cleanup') if v else None,
            peaks=mem['peaks'],samples=mem['sample_count'],seconds=mem['seconds'],last_phase=mem['samples'][-1]['phase'],
            baseline=v.get('two_tabs') if v else None,cycles=v.get('cycles') if v else None,
            resource_violations=v.get('resource_violations') if v else None,
            diagnostic_completed=v.get('diagnostic_completed',False) if v else False,
            memory_policy_evaluated=bool(v and v.get('memory_limit_passed') is not None),
            memory_assertion_reached=name=='control-workload',
            memory_policy_evaluation=v.get('memory_limit_passed') if v else None)
        retain(folder/'tests/tabs_window_smoke.py',name+'-tabs_window_smoke.py')
    runs[name]=value
    for p in sorted(r.iterdir()):
        if p.suffix in ('.json','.png','.txt'):retain(p,name+'-'+p.name)
    for p in (folder/'controller.log',folder/(kind+'.log')):retain(p,name+'-'+p.name)
for p in sorted((root/'build').iterdir()):
    if p.is_file() and (p.name in ('link-image.py','run-copy-checks.py','run-copy-diagnostic.py','run-dynamic-checks.py','run-batched-checks.py','run-batched-diagnostic.py','run-sequential-checks.py','run-sequential-diagnostic.py') or p.name.endswith('-frontend.log') or p.name in ('control-configure.log','batched-frontend-name-collision.log') or p.name.endswith('-check-results.json')):
        retain(p,p.name)
retain(root.parent/'rtl-worktree/build/run-owned-check.py','run-owned-check.py')
tests=['tabs_window_smoke.py','renderer_window_smoke.py','native_test_utils.py','gpu_capture.py','gpu_capture.js','tab_workload_memory.py','owned_job.py','memory_limits.py']
m=dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_base_commit='e70ddf7eedc23b3c1ece2cf32328ca3a71c8af7d',
    distribution='Local MSVC /MT frontend libraries linked against retained same-image OpenConsole objects; not a remote CI artifact',
    reused_host_source_checkpoint='37ef26dae839319f7bf703bb648038c343c357f1',host_overlay_unchanged_from_source_base=True,
    source_hash_format='UTF-8 with CRLF normalized to LF',test_sources={p:sha((root/'tests'/p).read_bytes().replace(b'\r\n',b'\n')) for p in tests},
    images=images,runs=runs,all_candidates_accepted=False,accepted_distribution_replaced=False,files=files)
for f in files:
    data=(root/f['path']).read_bytes();assert sha(data)==f['sha256'] and sha(gzip.decompress(data))==f['raw_sha256']
(root/'research/d3d11-copy-validation.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(files=len(files),images=images,workloads={k:dict(peak=v.get('peaks',{}).get('frontend'),groups=v.get('functional_groups'),seconds=v.get('seconds')) for k,v in runs.items() if 'peaks' in v})))
