import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
results=[]
for label,image,fixture,args in [
    ('control-workload','control-single','tabs',['--renderer','directx','--side','left','--cols','160','--rows','48','--workload-memory']),
    ('copy-pixels','copy-single','renderer',[]),
    ('copy-workload','copy-single','tabs',['--renderer','directx','--side','left','--cols','160','--rows','48','--workload-memory'])]:
    dest=root/'build'/label;assert not dest.exists(),dest
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    shutil.copy2(root/'build'/image/'nemoterm.exe',dest/'dist')
    if image=='copy-single':
        p=dest/'tests/tabs_window_smoke.py';original=p.read_text(encoding='utf-8')
        assert original.count("3:'NemotermDirect2D'")==1
        p.write_text(original.replace("3:'NemotermDirect2D'","3:'NemotermDirect3D11'"),encoding='utf-8')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),fixture,*args],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    result=dict(label=label,controller_exit_code=code,controller=json.loads((dest/'research'/f'{fixture}-controller.json').read_text(encoding='utf-8')))
    results.append(result)
    (root/'build/copy-check-results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result),flush=True)
    if code and fixture=='renderer':
        print((dest/'controller.log').read_text(encoding='utf-8')[-4000:],flush=True)
        raise SystemExit(code)
