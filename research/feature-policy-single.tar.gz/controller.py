"""Retain the complete successful single-image checkpoint, streaming large evidence."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/feature-policy-worktree'
base=root/'build/ci-feature-policy-complete-846b525';source='846b525bd0c7cbeacf71d12596d0a264d82eb5c6'
component_source='846b525bd0c7cbeacf71d12596d0a264d82eb5c6'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'single-run.json').read_text())
assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(43731283079,source,'completed','success')
assert len(run['jobs'])==1 and run['jobs'][0]['conclusion']=='success'
research=base/'single-evidence/build/single-exe-check/research'
validation=json.loads((research/'single-exe-validation.json').read_text(encoding='utf-8-sig'))
image=base/'product/nemoterm.exe';image_sha=digest(image)
assert image_sha==validation['executable_sha256']
assert image.stat().st_size==validation['executable_bytes']
assert len(validation['passed_checks'])==len(set(validation['passed_checks']))==160
assert validation['executable_directory_files']==['nemoterm.exe']
native_checkpoint=json.loads((work/'research/feature-policy-components-native-validation.json').read_bytes())
assert native_checkpoint['component_run']==43731038939 and native_checkpoint['source']==component_source
assert native_checkpoint['native_cases']==72 and native_checkpoint['formatter_original_replies']==1780
paths=['vendor/putty-0.85/terminal','vendor/putty-0.85/windows','vendor/putty-0.85/putty.h','native','scripts/build-single-exe.ps1','scripts/prepare-single-exe.py']
subprocess.run(['git','diff','--exit-code',component_source,source,'--',*paths],cwd=work,check=True)
native=json.loads((research/'control-cancellation-observed.json').read_text(encoding='utf-8'))
assert native['completed'] and native['executable_sha256']==image_sha and native['reference_case_count']==413
marker=b'\x1bP>|Nemoterm(PuTTY 0.85)\x1b\\'
for prefix,name,count in [('ansi','ansi_conformance_native_cases.py',177),('cancel','control_cancellation_native_cases.py',236)]:
    import ast
    tree=ast.parse(subprocess.check_output(['git','show',f'{source}:tests/{name}'],cwd=work).decode('utf-8'))
    values={node.targets[0].id:ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign)}
    assert len(values['CASES'])==count
    for case,sequence,expected in values['CASES']:
        assert bytes.fromhex(native['cases'][prefix+'-'+case])==expected+marker,case
assert len(native['exercise']['pixel_pairs'])==3
for pair in native['exercise']['pixel_pairs'].values():assert pair['literal_sha256']==pair['control_sha256']
assert not native['cleanup']['terminated_remaining'] and native['cleanup']['after']['active']==0
workloads=[]
for path in sorted(research.glob('*workload-tabs-*-observed.json')):
    data=json.loads(path.read_text())
    assert data['completed'] and data['memory_limit_passed'] and data['executable_sha256']==image_sha
    assert not data['memory_instrumented'] and not data['process_tree_memory']['injected']
    assert data['memory_limit_required'] and not data['process_tree_memory']['errors']
    dx=data['renderer']=='directx';limit=25000000 if dx else 20000000
    assert data['memory_limit_bytes']==limit and data['memory_limit_inclusive']==dx
    assert data['peak_private_ws']<=limit if dx else data['peak_private_ws']<limit
    cleanup=data['owned_job_cleanup']
    assert not cleanup['terminated_remaining'] and cleanup['after']['active']==0
    record=dict(path=path.relative_to(base).as_posix(),renderer=data['renderer'],actual_renderer=data['actual_renderer'],
        font=data['font'],grid=data['actual_grid'],frontend_peaks=data['process_tree_memory']['peaks']['frontend'],
        process_tree_peaks=data['process_tree_memory']['peaks'],private_limit_bytes=limit,passed=True,natural_cleanup=True)
    if path.name.startswith('unicode-'):
        samples=data['post_memory_kitty_unicode']
        assert len(samples)==4 and all(x['matched'] and x['after_memory_sampling'] and not x['injected'] for x in samples)
        record['post_memory_cells']=sum(x['cells_verified'] for x in samples)
    workloads.append(record)
assert len(workloads)==12 and sum(x.get('post_memory_cells',0) for x in workloads)==25048
drops=[]
for renderer in ('gdi','directx'):
    data=json.loads((research/f'drop-{renderer}-observed.json').read_text())
    assert data['completed'] and data['exe_sha256']==image_sha and len(data['checks'])==50
    assert all(not c['terminated_remaining'] and c['after']['active']==0 for c in data['cleanup'])
    parsers=data['shell_parser_processes']
    assert all(p['completed'] and p['timeout_seconds']==20 for p in parsers)
    drops.append(dict(renderer=renderer,checks=50,external_shell_seconds={p['shell']:p['elapsed_seconds'] for p in parsers}))
artifacts=json.loads((base/'single-artifacts.json').read_text())['artifacts']
receipt=json.loads((base/'product-download.json').read_bytes())
assert receipt['source']==source
product=next(a for a in artifacts if a['id']==receipt['artifact_id'])
assert product['name']=='nemoterm-single-exe-x64-'+source and not product['expired']
locator=json.loads((research/'locator-window-observed.json').read_text())
assert locator['completed'] and locator['physical_input'] and locator['executable_sha256']==image_sha
assert len(locator['checks'])==27 and not locator['cleanup']['terminated_remaining'] and locator['cleanup']['after']['active']==0
for name,check in locator['checks'].items():
    prefix=bytes.fromhex(check['reply_hex'])+b'\x1b[0n'
    assert bytes.fromhex(check['wire_with_barrier_hex'])==prefix,name
    if 'event_reply_hex' in check:
        assert bytes.fromhex(check['event_wire_with_barriers_hex'])==prefix+bytes.fromhex(check['event_reply_hex'])+b'\x1b[0n',name
assert locator['shift_selection_pixels']['before_sha256']!=locator['shift_selection_pixels']['after_sha256']
udk_path=research/'udk-window-observed.json'
udk=json.loads(udk_path.read_text())
assert udk['completed'] and udk['physical_input'] and udk['executable_sha256']==image_sha
assert len(udk['cases'])==89 and sum(len(v) for v in udk['cases'].values())==232
with tarfile.open(work/'research/dec-udk-reference.tar.gz') as tar:
    expected=json.loads(tar.extractfile('9b798e2/reference/dec-udk-xterm.json').read())
for name,steps in udk['cases'].items():
    assert len(steps)==len(expected['cases'][name]['steps'])
    for actual,reference in zip(steps,expected['cases'][name]['steps']):
        for key in ('sequence_hex','reply_hex','actions','wire_with_barriers_hex'):
            assert actual[key]==reference[key],(name,key)
assert all(not c['terminated_remaining'] and c['after']['active']==0 for c in udk['cleanup'])
assert udk['udk_after_kitty_wire'].endswith('411b5b306e')
bell_path=research/'bell-modes-window-observed.json'
bell=json.loads(bell_path.read_text())
assert bell['completed'] and bell['executable_sha256']==image_sha
assert len(bell['cases'])==112 and sum(len(v) for v in bell['cases'].values())==192
with tarfile.open(work/'research/bell-modes-reference.tar.gz') as tar:
    expected_bell=json.loads(tar.extractfile('reference/bell-modes-xterm.json').read())
for name,steps in bell['cases'].items():
    assert len(steps)==len(expected_bell['cases'][name]['steps'])
    for actual,reference in zip(steps,expected_bell['cases'][name]['steps']):
        for key in ('sequence_hex','reply_hex','wire_with_barrier_hex'):assert actual[key]==reference[key],(name,key)
        assert actual['native_before']['foreground']==actual['native_after']['foreground']
        assert actual['native_before']['topmost']==actual['native_after']['topmost']
        for event in actual['api']:
            if event['api']=='SetWindowPos':assert event['flags']==19 and event['result'] and actual['native_after']['above_other']
assert all(not c['terminated_remaining'] and c['after']['active']==0 for c in bell['cleanup'])

states=json.loads((bell_path.parent/'bell-window-state-observed.json').read_bytes())
assert states['completed'] and states['executable_sha256']==image_sha and len(states['checks'])==38
assert len(states['cleanup'])==2 and all(not c['terminated_remaining'] and c['after']['active']==0 for c in states['cleanup'])
for renderer in (0,2):
    checks={x['name']:x for x in states['checks'] if x['renderer']==renderer};assert len(checks)==19
    assert any(e['api']=='FlashWindowEx' and e['flags']==0 for e in checks['notifying-background-close']['api'])
    assert not any(e['api']=='FlashWindowEx' and e['flags']==0 for e in checks['one-notice-owner-close-preserves-other']['api'])
    closed=checks['inactive-host-active-tab-close'];focused=checks['new-active-notice-clears-on-foreground']
    assert closed['focus_input_hex']=='1b5b306e' and focused['focus_input_hex']=='1b5b306e1b5b49'
    assert not any(e['api']=='FlashWindowEx' and e['flags']==0 for e in closed['api'])
    assert any(e['api']=='FlashWindowEx' and e['flags']==0 for e in focused['api'])
    for check in checks.values():
        if 'before' in check:
            assert check['wire_hex']=='1b5b306e'
            for key in ('foreground','active','topmost','minimized'):assert check['before'][key]==check['after'][key]
focus_actions=bell['focus_actions']+states['focus_actions']
assert focus_actions and all(a['after']==a['window'] for a in focus_actions)


# Recheck original native bytes against the exact source fixture's authored
# expectations without importing Windows helpers or launching any application.
import ast
fixture_source=subprocess.check_output(['git','show',source+':tests/feature_policy_window_smoke.py'],cwd=work).decode('utf-8')
fixture_tree=ast.parse(fixture_source)
imports=[n for n in fixture_tree.body if isinstance(n,(ast.Import,ast.ImportFrom))]
assert len(imports)==1 and isinstance(imports[0],ast.ImportFrom) and imports[0].module=='protocol_oracle_window'
fixture_tree.body=[n for n in fixture_tree.body if n not in imports]
expected_profiles={}
def collect_policy(name,cases,*,extra_cases,profile,source_reference):
    assert not cases and name not in expected_profiles
    expected_profiles[name]=(extra_cases,profile)
exec(compile(fixture_tree,'retained-policy-expectations','exec'),{'run':collect_policy})
assert len(expected_profiles)==3
feature_records=[]
for name,(cases,profile) in expected_profiles.items():
    path=next(research.rglob(name+'-observed.json'))
    data=json.loads(path.read_text(encoding='utf-8'))
    assert data['completed'] and data['executable_sha256']==image_sha
    assert data['profile_values']==profile and len(data['cases'])==len(cases)==24
    assert not data['cleanup']['terminated_remaining'] and data['cleanup']['after']['active']==0
    for case,sequence,expected in cases:
        assert bytes.fromhex(data['cases'][case])==expected.encode()+b'\x1bP0$r\x1b\\',(name,case)
    feature_records.append(dict(profile=name,cases=24,exact_replies=True,natural_cleanup=True))

entries={'controller.py':Path(__file__)}
for name in ('single-run.json','single-run.log','single-artifacts.json','single-observed-at.txt','product-download.json','single-evidence-download.json'):
    entries[name]=base/name
for folder in ('product','single-evidence'):
    for path in (base/folder).rglob('*'):
        if path.is_file():entries[path.relative_to(base).as_posix()]=path
for name in ('vendor/putty-0.85/terminal/nemo_feature_policy.c','vendor/putty-0.85/terminal/nemo_feature_policy.h','vendor/putty-0.85/terminal/nemo_feature_policy_terminal.inc','vendor/putty-0.85/test/test_feature_policy.c','tests/feature_policy_reference.h','scripts/generate-feature-policy-reference.py','tests/feature_policy_window_smoke.py','vendor/putty-0.85/CMakeLists.txt','vendor/putty-0.85/windows/CMakeLists.txt','vendor/putty-0.85/unix/CMakeLists.txt','tests/bell_window_state_smoke.py','tests/owned_window_focus.py','tests/session_fixture.py','tests/fixture_io.py','vendor/putty-0.85/windows/nemo_tabs_host.inc','tests/bell_modes_window_smoke.py','tests/bell_modes_reference.h','scripts/generate-bell-reference.py','vendor/putty-0.85/conf.h','vendor/putty-0.85/test/test_bell_modes.c','tests/udk_window_smoke.py','tests/udk_reference.h','vendor/putty-0.85/terminal/nemo_udk_terminal.inc','vendor/putty-0.85/test/test_udk_terminal.c','tests/locator_window_smoke.py','tests/mouse_fixture.py','tests/locator_reference.h','scripts/generate-locator-reference.py','vendor/putty-0.85/terminal/nemo_locator_terminal.inc','vendor/putty-0.85/test/test_locator_terminal.c','vendor/putty-0.85/putty.h','vendor/putty-0.85/windows/window.c','.github/workflows/single-exe.yml','scripts/build-single-exe.ps1','scripts/test-single-exe.ps1',
             'scripts/prepare-single-exe.py','native/single_exe/entry.cpp','tests/drop_window_smoke.py',
             'tests/tabs_window_smoke.py','tests/tab_workload_memory.py','tests/memory_limits.py',
             'tests/native_test_utils.py','tests/owned_job.py','scripts/generate-ansi-reference.py','tests/ansi_conformance_reference.h','tests/ansi_conformance_native_cases.py','tests/control_cancellation_native_cases.py','tests/control_cancellation_window_smoke.py','tests/protocol_oracle_window.py','scripts/generate-cancellation-reference.py','vendor/putty-0.85/test/test_cancellation_terminal.c','vendor/putty-0.85/terminal/terminal.c','vendor/putty-0.85/terminal/terminal.h','vendor/putty-0.85/test/test_ansi_terminal.c'):
    entries['source/'+name]=subprocess.check_output(['git','show',f'{source}:{name}'],cwd=work)
archive=work/'research/feature-policy-single.tar.gz';archive.parent.mkdir(exist_ok=True);records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,value in sorted(entries.items()):
        info=tarfile.TarInfo(name)
        if isinstance(value,bytes):
            info.size=len(value);checksum=sha(value);tar.addfile(info,io.BytesIO(value))
        else:
            info.size=value.stat().st_size;checksum=digest(value)
            with value.open('rb') as stream:tar.addfile(info,stream)
        records.append(dict(path=name,raw_bytes=info.size,raw_sha256=checksum))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path'] and hashlib.file_digest(tar.extractfile(member),'sha256').hexdigest()==record['raw_sha256']
manifest=dict(feature_policy_native=feature_records,source=source,run=43731283079,conclusion='success',validation=validation,
    bell_window_states=dict(checks=38,renderers=['gdi','directx'],natural_cleanup=True,focus_reports_checked=True,caption_clicks=sum(a['method']=='owned-caption-click' for a in focus_actions)),
    bell_native=dict(cases=112,streams=192,exact_wire_checked=True,actual_window_state_checked=True,natural_cleanup=True),
    udk_native=dict(cases=89,streams=232,exact_wire_checked=True,physical_input=True,natural_cleanup=True),
    locator_native=dict(phases=27,shift_selection_pixels=locator['shift_selection_pixels'],resized_grid=locator['resized_grid'],exact_wire_checked=True,natural_cleanup=True),production_equivalence=dict(source=component_source,paths=paths,git_diff_exit=0,
        scope='Same production and single-image build inputs as the feature-policy component/native checkpoint; these are separately linked binaries.'),
    product_artifact=dict(id=product['id'],name=product['name'],expires_at=product['expires_at'],
        url=f"https://github.com/xiongnemo/nemoterm/actions/runs/43731283079/artifacts/{product['id']}"),
    workloads=workloads,drops=drops,native_comparison=dict(reference_streams=413,ansi=177,cancellation=236,binary_only_core=84,pixel_pairs=native['exercise']['pixel_pairs'],natural_cleanup=True),
    limits='Includes corrected bell notification ownership and actual host activation. Remote Consolas grids; not local 160x48 Sarasa acceptance. The GDI total target is approximately 50 MB. Current DX memory is accepted by the user; no further DX optimization is required. The ordinary workflow has a separate checkpoint and archive. This image includes UDK with 232 native streams, Locator, CAN/SUB parity and all 413 earlier native reference streams.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
        archive_sha256=digest(archive),records=records))
(work/'research/feature-policy-single-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,checks=len(validation['passed_checks']),
    artifact_id=product['id'],expires_at=product['expires_at'],drops=drops)))
