"""Observe owned window stacking preparation without foreground input."""
import os
from native_test_utils import root,c,w,u,json,subprocess,sys,tempfile,Path,time,read_snapshot,write_snapshot,wait_for,find_window,terminal_host
from protocol_oracle_window import saved_profile
from owned_job import OwnedJob

u.GetWindowLongPtrW.argtypes,u.GetWindowLongPtrW.restype=[w.HWND,c.c_int],c.c_ssize_t
u.SetWindowPos.argtypes=[w.HWND,w.HWND,c.c_int,c.c_int,c.c_int,c.c_int,w.UINT]
u.GetForegroundWindow.restype=w.HWND
records=[]
with saved_profile(dict(Beep=0,BeepInd=0,NemoBellRaise=0,NemoBellOnReset=0,BellOverload=0,WarnOnClose=0,CloseOnExit=1,NemoRenderer=0)) as args, tempfile.TemporaryDirectory() as directory,OwnedJob() as job:
    folder=Path(directory);processes=[];windows=[];controls=[]
    for label,tabs in [('host',['--tabs']),('other',[])]:
        report,control=folder/(label+'.json'),folder/(label+'-control.json')
        process=job.spawn([os.environ['NEMOTERM_TEST_EXE'],*args,*tabs,'--cols','80','--rows','24','-e',sys.executable,str(root/'tests/mouse_fixture.py'),str(report),str(control),'60'],env=dict(os.environ,NEMOTERM_CONPTY='bundled',NEMOTERM_TEST_EXACT_OUTPUT='1'),creationflags=subprocess.CREATE_NO_WINDOW)
        processes.append(process);controls.append(control)
        window=terminal_host(wait_for(lambda:find_window(process.pid)));windows.append(window)
        wait_for(lambda:read_snapshot(report).get('columns')==80)
    def state(label,result=None):
        records.append(dict(label=label,result=result,foreground=u.GetForegroundWindow(),windows=[dict(hwnd=h,exstyle=int(u.GetWindowLongPtrW(h,-20)),topmost=bool(u.GetWindowLongPtrW(h,-20)&8)) for h in windows]))
    state('initial')
    for index in range(4):
        for target,after in [(0,-1),(1,-1),(0,-2),(1,-2)]:
            result=u.SetWindowPos(windows[target],after,0,0,0,0,0x13)
            state(f'{index}-{target}-{after}-immediate',result)
            time.sleep(.1);state(f'{index}-{target}-{after}-settled')
    for control in controls:write_snapshot(control,dict(stop=True))
    for process in processes:process.wait(timeout=10);assert process.returncode==0
    cleanup=job.finish();assert not cleanup['terminated_remaining']
(root/'research/topmost-probe.json').write_text(json.dumps(dict(records=records,cleanup=cleanup),indent=2))
for record in records: print(record['label'],record['result'],[w['topmost'] for w in record['windows']])
