import json,resource,subprocess,time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
here=Path(__file__).resolve().parent
build=Path('/tmp/nemoterm-sixel-palette-build-20261114-1453')
commands=[['cmake','--build',str(build),'--target','test_sixel','test_sixel_terminal','test_state_control','--parallel','4'],*[ [str(build/name)] for name in ['test_sixel','test_sixel_terminal','test_state_control']]]
results=[]
for i,cmd in enumerate(commands):
 start=time.monotonic();proc=subprocess.run(cmd,capture_output=True,text=True)
 name=f'fixed-second-{i}.log';(here/name).write_text(proc.stdout+proc.stderr)
 result={'argv':cmd,'returncode':proc.returncode,'seconds':time.monotonic()-start,'log':name};results.append(result)
 print(json.dumps(result),flush=True)
 if i==0 and proc.returncode:break
(here/'fixed-second.json').write_text(json.dumps(results,indent=2)+'\n')
