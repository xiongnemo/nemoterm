# Sixel palette redefinition reference investigation

Date: 2026-11-14. Task scope: palette redefinition within one DCS, across retained images, private/shared mode and narrow lifetime boundaries. No product source, tracked documentation or accepted Windows executable was changed.

## Evidence identity and isolation

These are local source observations and owned runtime observations, **not REA-server Evidence IDs**. Source was downloaded from the official ThomasDickey/xterm-snapshots repository at commit `5c75ead9a75d4b2e666ca06fa94503b5766ed93f`. Exact URLs and file SHA-256 values are in `source-manifest.json`. Downloaded source files retain their upstream notices.

Existing Debian runtime `/tmp/nemoterm-xterm-reference/xterm` reports `XTerm(412)`, executable SHA-256 `089de40f5a47b2ee07ddb778e7e031116673c7c20a55facbd9caf8d78978573c`. Its adjacent `graphics.c`, `graphics_sixel.c`, and `graphics.h` match the downloaded pinned source byte-for-byte. This investigation did not rebuild that existing executable or independently reconstruct its complete build provenance. `environment.json` records Xvfb, Xlib, compiler and kernel versions.

Each runtime invocation started its own Xvfb using `-displayfd` and `-nolisten tcp`, then started one owned XTerm on that explicitly selected display. Xlib captures and Expose requests targeted only that display. There was no interaction with the Windows desktop, clipboard, existing terminal sessions, or any existing X server. All owned XTerm and Xvfb processes exited; each observations JSON records its PIDs and cleanup result. No packages or tools were installed.

Runtime arguments use `-ti vt340`, fixed font, black background, transparent Sixel background (`DCS 0;1q`), explicit square pixels (`"1;1;16;6`), hidden cursor, and explicit DEC private mode 1070 selection. Results apply to this bounded fixture and XTerm build.

## Source observations

* `graphics.h:65-76` stores `RegisterNum *pixels`, per-graphic private palette, current palette pointer and the palette mode captured for that graphic.
* `graphics_sixel.c:156-187` writes the selected register number to each painted pixel, rather than RGB.
* `graphics_sixel.c:805-807` applies a parsed color definition through `update_color_register`.
* `graphics.c:445-462` changes the current image's private palette or the global shared palette. Existing private pixels therefore resolve through their changed register.
* `graphics.c:722-754` captures private/shared ownership at image creation. Private palettes initialize independently; shared images point to the same shared palette. `OPT_INHERIT_COLORS` is disabled at `graphics.c:46` in this source.
* `graphics.c:1003-1008` resolves stored register indices through the image palette at repaint.
* `graphics.c:399-421` writes the shared palette and attempts dirty marking of existing non-private graphics. The condition at line 418 indexes `color_registers_used[ii]` using the graphic-slot loop index, not the changed color number. The observed delayed shared repaint is consistent with incomplete dirty marking, but this experiment does not establish every case affected by that condition.

## Runtime observations

Every named case has exact sent bytes (`wire_hex`), reply bytes, direct XImage bytes, PPM images, image hashes, pixel counts and bounding boxes. A DSR completion reply precedes capture; each immediate capture waits 150 ms. "Forced expose" uses XClearArea with exposures on windows owned by this XTerm, followed by XSync and 150 ms. This forces normal redraw without changing the terminal content.

The primary image is 16 by 6 pixels (96 total), at captured coordinates x=3..18, y=3..8. A later image is at y=42..47. First-table records are in `observations.json`.

| Case | Immediately after complete DCS | After forced expose |
| --- | --- | --- |
| Private, within one DCS: register 1 red, draw 8 columns; redefine register 1 green, draw 8 columns | 96 green, 0 red | Same |
| Shared, same sequence | 96 green, 0 red | Same |
| Private, retained red image then later green image using register 1 | Old 96 red, new 96 green | Same |
| Shared, retained red image then later green image using register 1 | Old 96 red, new 96 green | Both images green: 192 green, 0 red |
| Retained private red image, toggle to shared, later green image | Old 96 red, new 96 green | Same |
| Retained shared red image, toggle to private, later private green image | Old 96 red, new 96 green | Same |
| Previous case, toggle back to shared and draw a blue third image | Old red, middle green, new blue, 96 each | Shared old and new blue: 192 blue; private middle remains 96 green |

For the same-DCS cases, the "before" capture is a separate clean red-only 16 by 6 fixture, not a mid-DCS streaming capture. The after capture is the final state of the red-then-green sequence. Incremental display timing while a DCS is open was not tested.

Narrow boundaries (`boundaries/observations.json`):

* Overwrite: draw register 1 red across 16 columns, overwrite the left 8 with register 2 blue, redefine register 1 green. Result: left 48 blue pixels and right 48 green pixels. Overwritten pixels no longer follow register 1.
* Shared cancellation: create a retained red image. Start a later DCS, define register 1 green, consume `?` to finish the numeric color definition, then send CAN before ST. Old image remains red immediately, becomes 96 green after expose. Thus a parsed shared palette mutation survives cancellation of the later DCS.
* Private cancellation: same procedure under mode 1070 set; retained old image remains 96 red even after expose.
* The initial soft-reset capture restored the visible cursor and obscured 36 pixels. Those raw observations are retained, but the corrected no-cursor run below is the appropriate color comparison.

Corrected reset boundaries (`reset-cursor-hidden/observations.json`):

* DECSTR (`CSI ! p`) followed by hiding the cursor retains all 96 red image pixels. Explicitly reselecting shared mode and drawing a later green image recolors both retained images after expose (192 green).
* RIS (`ESC c`) followed by hiding the cursor leaves none of the red/green/blue probe pixels visible, immediately or after expose. This establishes the visible graphics-reset boundary only, not every palette initialization value.

Register identity (`register-identity/observations.json`): register 1 and register 2 are both defined red and each paints 8 columns. Redefine only register 1 green. Left 48 pixels turn green while right 48 pixels stay red. Replacing pixels by matching their old RGB value would be incorrect.

## Current decoder comparison

`decoder-source-manifest.json` records copied product decoder source identities from fixture commit `1a38d46176114425a9db4c6beb41474594746891`. `decoder_probe.c` compiles those unmodified copies as an isolated Linux ELF using the existing GCC. Build command/result is in `decoder-compile.txt`; output in `decoder-observations.txt`; executable hash/status in `decoder-probe-identity.json`. This is a direct decoder probe, not a Windows UI/rendering observation.

* Same-DCS sequence returns eight `ffff0000` pixels followed by eight `ff00ff00` pixels on the first row. XTerm's equivalent row is all green.
* A separately retained decoder remains red after another decoder changes a copied palette.
* Even explicitly calling `nemo_sixel_set_palette` on the old decoder with the new green palette leaves old pixels red.

The current tile stores baked uint32 RGB values. The observed difference therefore exists before Windows rendering. `terminal-sixel-excerpt.txt` and `terminal-source-identity.json` preserve the inspected terminal integration: `terminal.c:2311-2312` copies the shared palette on begin; `2365-2367` copies it out only on successful image completion. Full shared semantics also require addressing the mutation-on-cancel boundary, not only decoder readback.

## Proposed minimal next change, not implemented

1. Preserve register identity in stored pixels and resolve RGB during `nemo_sixel_read_row`. Keep direct initial foreground/background pixels and transparency distinct. Existing uint32 storage could use an internal tagged register value, because the public output currently only uses alpha 0 or 255; a carefully defined internal tag can avoid increasing the tile allocation budget. Explicit index storage with dedicated sentinels is another option. Do not replace old pixels based on matching RGB values.
2. Capture private/shared ownership for each image/source. Private images use their own mutable palette; later private images do not recolor them. Shared retained images consult a shared palette owned by their terminal, even after mode 1070 toggles for future images.
3. Propagate a shared register definition when its parameters are parsed, including definitions in a DCS later canceled. Add a narrow palette-change callback or equivalent shared-palette binding; retaining only the existing successful-finish copy is insufficient.
4. Invalidate affected retained shared images when a register changes. Matching the observed final repaint semantics is the compatibility target; copying the reference's delayed-repaint defect is unnecessary. Preserve current hard-reset clearing and soft-reset retained-image behavior.
5. Add targeted decoder and terminal integration coverage for within-DCS redefinition, equal-RGB distinct registers, overwrite, retained shared/private images and mode toggles, CAN after a completed color definition, and DECSTR/RIS ownership boundaries. Recheck memory accounting because the user has explicit budgets.

This is a real, bounded compatibility gap. No decoder change or tracked compatibility claim has been made by this investigation.

## Remaining limits

No real VT340 hardware, other terminal implementation, other XTerm version, alternate-screen/scrollback image lifetime, image eviction, malformed definition, SUB cancellation, cancellation before the color parameters finish, HLS palette redefinition, non-default register count, multiple simultaneous XTerm instances, or GPU/window rendering was tested. Source evidence explains register lookup independent of RGB/HLS, but runtime HLS equivalence remains an inference. Reset testing does not establish all default palette colors. This result must not be described as broad Sixel compatibility.
