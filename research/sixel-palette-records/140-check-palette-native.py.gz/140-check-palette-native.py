import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];results=[]
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
base=root/'build/palette-native';base.mkdir(exist_ok=False)
before=root.parents[1]/'dist/nemoterm.exe'
after=root/'build/palette-single/nemoterm.exe'
assert hashlib.sha256(before.read_bytes()).hexdigest()=='ebd2d24edcf9ba10f0435597e15ad8aff44320fad1a707b6e4cbc10654345a63'
for label,exe,mode,expected in [('before-gdi',before,'gdi',1),('after-gdi',after,'gdi',0),
                                ('after-opengl',after,'opengl',0),('after-directx',after,'directx',0)]:
    dest=base/label
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),'sixel_palette',
            '--renderer',mode],cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
    record=dict(label=label,exit_code=code,expected_exit_code=expected)
    report=dest/'research'/f'sixel-palette-{mode}-observed.json'
    if report.exists():
        data=json.loads(report.read_text());record.update(completed=data['completed'],
            checks=len(data['checks']),matched=sum(c['matched'] for c in data['checks']))
        if expected:
            assert [r['name'] for r in data['checks']]==['private-same-dcs-before','private-same-dcs-after'],data.get('error')
            assert data['checks'][0]['matched'] and data['checks'][1]['observed_counts']==dict(red=48,green=48,blue=0)
            assert not data['cleanup']['terminated_remaining']
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(record,flush=True)
    if code!=expected:
        print((dest/'controller.log').read_text()[-3500:]);raise SystemExit(1)
