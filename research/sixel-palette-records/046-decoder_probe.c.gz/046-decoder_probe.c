#include "nemo_sixel.h"
#include <stdio.h>
#include <string.h>

static NemoSixel *make(const char *payload) {
    NemoSixel *s=nemo_sixel_init(0,0xffffffff,0xff000000,true);
    if (!s || !nemo_sixel_feed(s,payload,strlen(payload)) || !nemo_sixel_finish(s))
        return NULL;
    return s;
}
static void report(const char *name,NemoSixel *s) {
    uint32_t row[32];
    size_t n=nemo_sixel_read_row(s,0,0,row,32);
    printf("%s",name);
    for(size_t i=0;i<n;i++) printf(" %08x",row[i]);
    puts("");
}
int main(void) {
    NemoSixel *old=make("\"1;1;16;6#1;2;100;0;0!16~");
    NemoSixel *same=make("\"1;1;16;6#1;2;100;0;0!8~#1;2;0;100;0!8~");
    if(!old||!same)return 1;
    report("before",old);
    report("same-DCS-redefine",same);
    uint32_t palette[256];
    nemo_sixel_get_palette(old,palette);
    NemoSixel *next=nemo_sixel_init(0,0xffffffff,0xff000000,true);
    if(!next)return 2;
    nemo_sixel_set_palette(next,palette);
    const char *payload="\"1;1;16;6#1;2;0;100;0!16~";
    if(!nemo_sixel_feed(next,payload,strlen(payload))||!nemo_sixel_finish(next))return 3;
    nemo_sixel_get_palette(next,palette);
    report("separate-DCS-old",old);
    report("separate-DCS-new",next);
    nemo_sixel_set_palette(old,palette);
    report("old-after-explicit-palette-update",old);
    nemo_sixel_free(old);nemo_sixel_free(same);nemo_sixel_free(next);
    return 0;
}
