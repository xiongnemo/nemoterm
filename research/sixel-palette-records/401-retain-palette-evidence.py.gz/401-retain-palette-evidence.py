import gzip,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
reference=root.parents[1]/'build/sixel-palette-reference-20261114-142417'
for name,digest in json.loads((reference/'artifact-sha256.json').read_text()).items():
    assert hashlib.sha256((reference/name).read_bytes()).hexdigest()==digest,name
dest=root/'research/sixel-palette-records';dest.mkdir(exist_ok=False)
files=[p for p in reference.rglob('*') if p.is_file()]
for p in (root/'build/palette-evidence').rglob('*'):
    if p.is_file() and p.suffix in ['.c','.h','.py','.json','.md','.log','.patch']:files.append(p)
for name in ['palette-sixel','palette-renderer','palette-memory-gdi','palette-memory-directx','palette-native']:
    base=root/'build'/name
    for p in base.rglob('*'):
        if not p.is_file():continue
        parts=p.relative_to(base).parts
        if any(n in parts for n in ['tests','tools','dist','__pycache__']):continue
        if p.suffix in ['.json','.log','.png','.bmp']:files.append(p)
for name in ['link-palette-image.py','check-palette-existing.py','check-palette-memory.py',
             'check-palette-native.py','palette-existing-results.json','palette-memory-results.json']:
    files.append(root/'build'/name)
for name in ['image.json','link.rsp','link.log']:files.append(root/'build/palette-single'/name)
files.append(Path(__file__))
records=[]
for p in sorted(set(files)):
    data=p.read_bytes();archive=dest/f'{len(records):03d}-{p.name}.gz'
    archive.write_bytes(gzip.compress(data,mtime=0))
    original=('reference/'+str(p.relative_to(reference)) if p.is_relative_to(reference) else str(p.relative_to(root)))
    records.append(dict(path=original.replace('\\','/'),archive=str(archive.relative_to(root)).replace('\\','/'),
                        bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
manifest=dict(kind='Pinned source and local owned Xvfb/Win32 observations, not REA-server Evidence',
              product_change='8c3807280b8cd5fad0fd90765bc6f426175ccb11',
              native_fixture='5daf6e23fa2b1495b5619f5b74920dd0df17fe93',
              image_sha256='a991a5173ead454dfa0271b8684bce95a8c9553e8d847a32771c3bb797bde5b7',records=records)
(root/'research/sixel-palette-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
for r in records:
    data=gzip.decompress((root/r['archive']).read_bytes())
    assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
print('Verified',len(records),'records;',sum((root/r['archive']).stat().st_size for r in records),'compressed bytes')
