import json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];results=[]
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
for name in ['sixel','renderer']:
    dest=root/'build'/('palette-'+name);assert not dest.exists()
    for folder in ('dist','research','build','tools'):(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(root/'build/palette-single/nemoterm.exe',dest/'dist')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        code=subprocess.run([sys.executable,str(controller),str(dest),name],cwd=root,
                            stdout=log,stderr=subprocess.STDOUT).returncode
    results.append(dict(label=name,exit_code=code))
    (root/'build/palette-existing-results.json').write_text(json.dumps(results,indent=2)+'\n')
    print((dest/'controller.log').read_text()[-2300:],flush=True)
    if code:raise SystemExit(code)
