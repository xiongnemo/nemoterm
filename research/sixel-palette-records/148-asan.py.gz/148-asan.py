import json,os,resource,subprocess,time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
here=Path(__file__).resolve().parent;repo=here.parents[1]
build=Path('/tmp/nemoterm-sixel-palette-asan-20261114-1505')
assert not build.exists(),build
commands=[['cmake','-S',str(repo/'vendor/putty-0.85'),'-B',str(build),'-G','Ninja','-DPUTTY_GTK_VERSION=NONE','-DPUTTY_GSSAPI=OFF','-DCMAKE_C_FLAGS=-g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer','-DCMAKE_EXE_LINKER_FLAGS=-fsanitize=address,undefined'],['cmake','--build',str(build),'--target','test_sixel','test_sixel_terminal','test_state_control','--parallel','4'],*[[str(build/name)] for name in ['test_sixel','test_sixel_terminal','test_state_control']]]
results=[]
for i,cmd in enumerate(commands):
 start=time.monotonic();proc=subprocess.run(cmd,capture_output=True,text=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1',UBSAN_OPTIONS='halt_on_error=1'))
 name=f'asan-{i}.log';(here/name).write_text(proc.stdout+proc.stderr)
 result={'argv':cmd,'returncode':proc.returncode,'seconds':time.monotonic()-start,'log':name,'ASAN_OPTIONS':'detect_leaks=1','UBSAN_OPTIONS':'halt_on_error=1'};results.append(result)
 print(json.dumps(result),flush=True)
 if i<2 and proc.returncode:break
(here/'asan.json').write_text(json.dumps(results,indent=2)+'\n')
