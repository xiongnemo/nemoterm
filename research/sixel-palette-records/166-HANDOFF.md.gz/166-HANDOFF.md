# Sixel palette implementation handoff

Worktree: `C:/Users/nemo/Documents/Projects/nemoterm/build/sixel-palette-worktree`.
Branch: `fix/sixel-palette-20261114`; base `1a38d46176114425a9db4c6beb41474594746891`.
Only the six source/test files in `implementation.patch` changed. No tracked docs, Microsoft submodule, Windows executable or other worktree was changed. This branch has not been pushed.

## Behavior and source review

* Register-selected pixels use an internal `0x01000000 | register` tag inside the existing uint32 tile. Readback resolves the active palette. Alpha 0 and 255 remain the only public output alpha values; direct initial foreground, background and transparent pixels retain existing behavior.
* Each shared decoder borrows the owning Terminal's existing 256-entry palette and records a change callback at creation. Mode 1070 toggles only affect later decoders. No added palette or bitmap allocation is made.
* Parsed color definitions update the active array before their following drawing operator. The callback marks retained content invalid immediately. Canceling an in-flight DCS frees its decoder without rolling shared palette state back. Successful completion no longer copies an isolated palette over global state.
* Source review followed creation, callback, completion, cancellation, crop/refcount sharing, reset and destruction. `term_free` and hard reset clear retained and pending decoders before releasing/resetting Terminal-owned palette state. `nemo_sixel_reset` clears borrowed pointers/callbacks before restoring private defaults. The callback only invalidates the terminal; it cannot free the decoder. Existing rendering calls read rows at paint time, so no stale color cache was added.
* The callback invalidates the whole terminal when retained images exist. This favors correctness and existing repaint infrastructure. Many shared color definitions can cost extra invalidation work; native renderer performance has not been measured here.
* Linux x86-64 measured fixed decoder allocation changes from 3176 to 3200 bytes (+24 bytes for three pointers). A tile remains 4112 bytes. Existing 4 MiB accounting/admission, dense image bound and 8192-byte rejection tests pass unchanged. No complete bitmap or second pixel plane was introduced.

## Verification and preserved failures

`baseline.json` / `baseline-*.log`: new exact-color regressions ran against the old product implementation before source edits. Decoder aborts on the same-DCS green expectation; terminal suite fails retained/shared identity, cancellation and invalidation assertions. These failures are intentionally retained. The old red-before-redefinition assertion was replaced by the XTerm-derived exact green expectation, not relaxed.

`fixed-second.json`: all of `test_sixel`, `test_sixel_terminal`, `test_state_control` pass in the ordinary build. Decoder suite includes 20,000 existing deterministic fuzz cases. Terminal tests cover equal-RGB distinct registers, overwrite, private/shared mode toggles, parsed-definition invalidation before ST, CAN, soft/hard reset, split-source references and unchanged budget accounting.

`asan.json`: the same three suites pass with AddressSanitizer + UndefinedBehaviorSanitizer, `ASAN_OPTIONS=detect_leaks=1`, `UBSAN_OPTIONS=halt_on_error=1`. No sanitizer/leak diagnostics were emitted.

`review.json`: strict decoder compilation (`-std=c99 -Wall -Wextra -Werror -pedantic`) and execution pass. The two sizeof probes record allocation sizes. After the final test-helper guard was added (stop reading pixels after a failed length assertion), the terminal suite was rebuilt and rerun in both ordinary and sanitizer builds and passes.

One procedural build failure is retained in `fixed-first-0.log`: `test_modes` is not a target in the Linux CMake platform. It was removed from that invocation; the existing Linux state-control target, which tests reset and mode state, passed. No test assertions were disabled and no source workaround was needed.

## Reusable commands

Run these in Debian/WSL; no installation is needed. Source path:
`/mnt/c/Users/nemo/Documents/Projects/nemoterm/build/sixel-palette-worktree/vendor/putty-0.85`.

Ordinary build remains at `/tmp/nemoterm-sixel-palette-build-20261114-1453`:

```sh
cmake --build /tmp/nemoterm-sixel-palette-build-20261114-1453 --target test_sixel test_sixel_terminal test_state_control --parallel 4
/tmp/nemoterm-sixel-palette-build-20261114-1453/test_sixel
/tmp/nemoterm-sixel-palette-build-20261114-1453/test_sixel_terminal
/tmp/nemoterm-sixel-palette-build-20261114-1453/test_state_control
```

Sanitizer build remains at `/tmp/nemoterm-sixel-palette-asan-20261114-1505`:

```sh
cmake --build /tmp/nemoterm-sixel-palette-asan-20261114-1505 --target test_sixel test_sixel_terminal test_state_control --parallel 4
ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1 /tmp/nemoterm-sixel-palette-asan-20261114-1505/test_sixel
ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1 /tmp/nemoterm-sixel-palette-asan-20261114-1505/test_sixel_terminal
ASAN_OPTIONS=detect_leaks=1 UBSAN_OPTIONS=halt_on_error=1 /tmp/nemoterm-sixel-palette-asan-20261114-1505/test_state_control
```

All initial configure/compiler commands, return codes, timings and logs are in the JSON runner records. Both CMake builds explicitly use `PUTTY_GTK_VERSION=NONE`, `PUTTY_GSSAPI=OFF`; sanitizer flags are `-g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer` and linker `-fsanitize=address,undefined`.

## Reference and remaining limits

Reference investigation is preserved separately at `C:/Users/nemo/Documents/Projects/nemoterm/build/sixel-palette-reference-20261114-142417/REPORT.md`, with pinned official XTerm source identity, local owned Xvfb captures and exact sequences. This patch implements the bounded explicit-register behavior established there; it does not copy XTerm's delayed shared repaint defect.

No Windows compiler, native window, clipboard, GDI, OpenGL, DirectX or working-set validation was run by this worker. No broad Sixel compatibility claim is made. This patch deliberately preserves the existing direct initial foreground/background behavior; equivalence to all implicit opaque background palette rules remains outside this narrow reference test. Any Windows/UI acceptance is for the parent worker.
