import json,os,resource,subprocess,time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
here=Path(__file__).resolve().parent;repo=here.parents[1]
include=str(repo/'vendor/putty-0.85/terminal')
commands=[]
for name in ['before','after']:
 commands += [['gcc','-std=c99','-Wall','-Wextra','-Werror','-pedantic','-I',include,str(here/f'size-{name}.c'),'-o',str(here/f'size-{name}')],[str(here/f'size-{name}')]]
commands += [['gcc','-std=c99','-Wall','-Wextra','-Werror','-pedantic','-I',include,str(repo/'tests/test_sixel.c'),str(repo/'vendor/putty-0.85/terminal/nemo_sixel.c'),'-o',str(here/'strict-test-sixel')],[str(here/'strict-test-sixel')]]
for directory in ['/tmp/nemoterm-sixel-palette-build-20261114-1453','/tmp/nemoterm-sixel-palette-asan-20261114-1505']:
 commands += [['cmake','--build',directory,'--target','test_sixel_terminal','--parallel','4'],[directory+'/test_sixel_terminal']]
results=[]
for i,cmd in enumerate(commands):
 start=time.monotonic();proc=subprocess.run(cmd,capture_output=True,text=True,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1',UBSAN_OPTIONS='halt_on_error=1'))
 name=f'review-{i}.log';(here/name).write_text(proc.stdout+proc.stderr)
 result={'argv':cmd,'returncode':proc.returncode,'seconds':time.monotonic()-start,'log':name};results.append(result)
 print(json.dumps(result),flush=True)
 if proc.returncode:break
(here/'review.json').write_text(json.dumps(results,indent=2)+'\n')
