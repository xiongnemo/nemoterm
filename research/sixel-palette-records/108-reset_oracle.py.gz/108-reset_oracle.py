"""Owned XTerm/Xvfb Sixel palette probe. No desktop/clipboard interaction.

Local observations, not REA-server Evidence. Uses only existing stdlib/Xlib.
"""
import ctypes as C
import hashlib
import json
import os
from pathlib import Path
import select
import subprocess
import sys
import time

REPO = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent / 'reset-cursor-hidden'
HERE.mkdir(exist_ok=True)
sys.path.insert(0, str(REPO / 'tests'))
from xterm_state_oracle import child, read, write


class XImage(C.Structure):
    _fields_ = [('width', C.c_int), ('height', C.c_int),
                ('xoffset', C.c_int), ('format', C.c_int),
                ('data', C.c_void_p), ('byte_order', C.c_int),
                ('bitmap_unit', C.c_int), ('bitmap_bit_order', C.c_int),
                ('bitmap_pad', C.c_int), ('depth', C.c_int),
                ('bytes_per_line', C.c_int), ('bits_per_pixel', C.c_int),
                ('red_mask', C.c_ulong), ('green_mask', C.c_ulong),
                ('blue_mask', C.c_ulong)]


def main():
    if len(sys.argv) > 1 and sys.argv[1] == '--child':
        child(Path(sys.argv[2]), Path(sys.argv[3]))
        return
    binary = Path('/tmp/nemoterm-xterm-reference/xterm')
    lib = C.CDLL('libX11.so.6')
    signatures = {
        'XOpenDisplay': (C.c_void_p, [C.c_char_p]),
        'XDefaultRootWindow': (C.c_ulong, [C.c_void_p]),
        'XGetImage': (C.POINTER(XImage), [C.c_void_p, C.c_ulong, C.c_int,
            C.c_int, C.c_uint, C.c_uint, C.c_ulong, C.c_int]),
        'XDestroyImage': (C.c_int, [C.POINTER(XImage)]),
        'XSync': (C.c_int, [C.c_void_p, C.c_int]),
        'XQueryTree': (C.c_int, [C.c_void_p, C.c_ulong, C.POINTER(C.c_ulong),
            C.POINTER(C.c_ulong), C.POINTER(C.POINTER(C.c_ulong)), C.POINTER(C.c_uint)]),
        'XClearArea': (C.c_int, [C.c_void_p, C.c_ulong, C.c_int, C.c_int,
            C.c_uint, C.c_uint, C.c_int]),
        'XFree': (C.c_int, [C.c_void_p]),
        'XCloseDisplay': (C.c_int, [C.c_void_p]),
    }
    for name, (result, args) in signatures.items():
        getattr(lib, name).restype = result
        getattr(lib, name).argtypes = args
    log = {'observation_kind': 'local owned runtime; not REA-server Evidence',
           'version': subprocess.check_output([binary, '-version'], text=True).strip(),
           'executable': str(binary),
           'executable_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
           'source_sha256': {name: hashlib.sha256((binary.parent/name).read_bytes()).hexdigest()
               for name in ['graphics.c', 'graphics_sixel.c', 'graphics.h']},
           'cases': []}
    report, control = HERE/'child-report.json', HERE/'child-control.json'
    report.unlink(missing_ok=True)
    control.unlink(missing_ok=True)
    r, w = os.pipe()
    xvfb = subprocess.Popen(['Xvfb', '-displayfd', str(w), '-screen', '0',
         '640x480x24', '-nolisten', 'tcp'], pass_fds=[w],
         stdout=(HERE/'xvfb-stdout.txt').open('wb'), stderr=(HERE/'xvfb-stderr.txt').open('wb'))
    os.close(w)
    terminal, display = None, None
    try:
        assert select.select([r], [], [], 8)[0], 'Xvfb startup timeout'
        number = os.read(r, 100).decode().strip()
        os.close(r)
        assert number.isdigit(), number
        display = lib.XOpenDisplay((':'+number).encode())
        assert display, 'XOpenDisplay failed'
        root = lib.XDefaultRootWindow(display)
        args = [str(binary), '-geometry', '40x12+0+0', '-fn', 'fixed',
                '-bg', 'black', '-fg', 'white', '-ti', 'vt340',
                '-xrm', '*allowWindowOps: true', '-e', sys.executable,
                str(Path(__file__).resolve()), '--child', str(report), str(control)]
        log['argv'] = args
        log['display'] = ':'+number
        log['owned_pids'] = {'xvfb': xvfb.pid}
        terminal = subprocess.Popen(args, env=dict(os.environ, DISPLAY=':'+number),
            stdout=(HERE/'xterm-stdout.txt').open('wb'), stderr=(HERE/'xterm-stderr.txt').open('wb'))
        log['owned_pids']['xterm'] = terminal.pid
        deadline = time.monotonic()+8
        while not report.exists() and time.monotonic()<deadline:
            time.sleep(.01)
        assert report.exists(), 'child startup timeout'

        def capture(name):
            lib.XSync(display, False)
            width, height = 320, 240
            img = lib.XGetImage(display, root, 0, 0, width, height, C.c_ulong(-1).value, 2)
            assert img
            try:
                obj = img.contents
                assert (obj.bits_per_pixel, obj.byte_order, obj.red_mask,
                    obj.green_mask, obj.blue_mask) == (32, 0, 0xff0000, 0xff00, 0xff)
                raw = C.string_at(obj.data, obj.bytes_per_line * obj.height)
                (HERE/(name+'.ximage')).write_bytes(raw)
                rgb = bytearray()
                colors = {c: [] for c in ['ff0000', '00ff00', '0000ff']}
                for y in range(height):
                    for x in range(width):
                        off = y*obj.bytes_per_line+x*4
                        triplet = bytes([raw[off+2], raw[off+1], raw[off]])
                        rgb.extend(triplet)
                        value = triplet.hex()
                        if value in colors:
                            colors[value].append((x,y))
                ppm = f'P6\n{width} {height}\n255\n'.encode()+rgb
                (HERE/(name+'.ppm')).write_bytes(ppm)
                return {'ppm': name+'.ppm', 'ppm_sha256': hashlib.sha256(ppm).hexdigest(),
                        'raw': name+'.ximage', 'raw_sha256': hashlib.sha256(raw).hexdigest(),
                        'width': width, 'height': height, 'bytes_per_line': obj.bytes_per_line,
                        'bits_per_pixel': obj.bits_per_pixel, 'byte_order': obj.byte_order,
                        'masks': [obj.red_mask,obj.green_mask,obj.blue_mask],
                        'colors': {k: {'count': len(v), 'bounds':
                           [min(x for x,y in v), min(y for x,y in v),
                            max(x for x,y in v), max(y for x,y in v)] if v else None}
                           for k,v in colors.items()}}
            finally:
                lib.XDestroyImage(img)

        def expose(window):
            root_return, parent_return = C.c_ulong(), C.c_ulong()
            children, count = C.POINTER(C.c_ulong)(), C.c_uint()
            assert lib.XQueryTree(display, window, C.byref(root_return),
                C.byref(parent_return), C.byref(children), C.byref(count))
            found = [children[i] for i in range(count.value)]
            lib.XFree(children)
            for item in found:
                expose(item)
                lib.XClearArea(display, item, 0, 0, 0, 0, True)

        def phase(name, sequence, force_expose=False):
            wire = sequence+'\x1b[5n'
            write(control, {'phase': name, 'sequence': wire})
            deadline = time.monotonic()+8
            while time.monotonic()<deadline:
                data = read(report)
                reply = bytes.fromhex(data.get('hex',''))
                if data.get('phase') == name and reply.endswith(b'\x1b[0n'):
                    break
                time.sleep(.01)
            else:
                raise AssertionError((name,data))
            time.sleep(.15)
            result = {'name': name, 'sequence': sequence, 'wire_hex': wire.encode().hex(),
                      'reply_hex': reply.hex(), 'immediate': capture(name)}
            if force_expose:
                expose(root)
                lib.XSync(display, False)
                time.sleep(.15)
                result['after_forced_expose'] = capture(name+'-expose')
            log['cases'].append(result)
            print(name, json.dumps(result['immediate']['colors']),
                  json.dumps(result.get('after_forced_expose', {}).get('colors')), flush=True)

        esc='\x1b'
        def setup(private):
            return esc+'c'+esc+'[?25l'+esc+'[?1070'+('h' if private else 'l')
        def image(payload, row=1):
            return f'{esc}[{row};1H{esc}P0;1q"1;1;16;6'+payload+esc+'\\'
        red = '#1;2;100;0;0!16~'
        green = '#1;2;0;100;0!16~'
        blue = '#1;2;0;0;100!16~'
        phase('soft-reset-before', setup(False)+image(red))
        phase('soft-reset-after-hide-cursor', esc+'[!p'+esc+'[?25l', True)
        phase('soft-reset-shared-redefine', esc+'[?1070l'+image(green,4), True)
        phase('hard-reset-after-hide-cursor', esc+'c'+esc+'[?25l', True)
        write(control, {'stop': True})
    finally:
        if terminal:
            terminal.terminate()
            terminal.wait(timeout=5)
        if display:
            lib.XCloseDisplay(display)
        xvfb.terminate()
        xvfb.wait(timeout=5)
        log['cleanup'] = {'owned_xterm_exited': terminal.poll() is not None if terminal else None,
                          'owned_xvfb_exited': xvfb.poll() is not None}
        (HERE/'observations.json').write_text(json.dumps(log, indent=2)+'\n')


if __name__ == '__main__':
    main()
