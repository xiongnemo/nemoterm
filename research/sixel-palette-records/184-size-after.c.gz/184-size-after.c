#include <stdio.h>
#include "decoder-after.c"
int main(void) { printf("decoder=%zu tile=%zu\n",sizeof(NemoSixel),sizeof(SixelTile)); return 0; }
