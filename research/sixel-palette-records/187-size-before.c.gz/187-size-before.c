#include <stdio.h>
#include "decoder-before.c"
int main(void) { printf("decoder=%zu tile=%zu\n",sizeof(NemoSixel),sizeof(SixelTile)); return 0; }
