/* Diagnostic only: real offscreen rendering; not application acceptance. */
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include "nemo_cluster.h"
#include <cstdio>
#include <cwchar>
#include <cstring>
#include <chrono>
#include <cstdint>
#include <psapi.h>

int main() {
    HDC dc=CreateCompatibleDC(nullptr);
    BITMAPINFO bi{};bi.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth=1280;bi.bmiHeader.biHeight=-960;
    bi.bmiHeader.biPlanes=1;bi.bmiHeader.biBitCount=32;
    void *bits=nullptr;HBITMAP bitmap=CreateDIBSection(dc,&bi,DIB_RGB_COLORS,&bits,nullptr,0);
    HFONT font=CreateFontW(-16,0,0,0,FW_LIGHT,FALSE,FALSE,FALSE,DEFAULT_CHARSET,
        OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,FIXED_PITCH,L"SarasaTermSC Nerd Font Light");
    if (!dc || !bitmap || !font || !bits) return 1;
    HGDIOBJ old_bitmap=SelectObject(dc,bitmap),old_font=SelectObject(dc,font);
    NemoClusterRenderer *renderer=nullptr;
    const wchar_t *text[]={L"e\x301",L"\U0001f469\x200d\U0001f4bb",L"\U0001f44d\U0001f3fd",
        L"1\xfe0f\x20e3",L"\x1100\x1161\x11a8",L"\x5d0",L"\x5d1",L"\x5d2",L"\xfe8d",L"\xfe91",L"\xfe96"};
    unsigned cells[]={1,2,2,2,2,1,1,1,1,1,1};
    std::puts("{\"diagnostic_only\":true,\"frames\":[");
    uint64_t expected=0;
    for (unsigned frame=0;frame<12;frame++) {
        GdiFlush();std::memset(bits,0,1280*960*4);
        auto start=std::chrono::steady_clock::now();unsigned draws=0;
        for (unsigned row=0;row<47;row++) for (unsigned repeat=0;repeat<7;repeat++) {
            unsigned col=repeat*22;
            for (unsigned i=0;i<11;i++) {
                RECT box={LONG(col*8),LONG(row*20),LONG((col+cells[i])*8),LONG((row+1)*20)};
                if (!nemo_cluster_draw(&renderer,dc,&box,text[i],unsigned(std::wcslen(text[i])),0,
                    RGB(245,220,190),RGB(20,40,70),i>=1 && i<=3,1,false,false)) return 2;
                col+=cells[i]+(i<5?1:0);draws++;
            }
        }
        GdiFlush();auto end=std::chrono::steady_clock::now();
        uint64_t hash=14695981039346656037ULL;
        for (unsigned i=0;i<1280*960;i++) hash=(hash^(static_cast<uint32_t *>(bits)[i]&0xffffff))*1099511628211ULL;
        if (frame && expected!=hash) return 3;expected=hash;
        PROCESS_MEMORY_COUNTERS_EX memory{};memory.cb=sizeof(memory);
        if (!GetProcessMemoryInfo(GetCurrentProcess(),reinterpret_cast<PROCESS_MEMORY_COUNTERS *>(&memory),sizeof(memory))) return 4;
        std::printf("%s{\"index\":%u,\"draws\":%u,\"ms\":%.3f,\"pixel_hash\":\"%016llx\",\"private_commit\":%llu,\"total_ws\":%llu}",
            frame?",\n":"",frame,draws,std::chrono::duration<double,std::milli>(end-start).count(),
            static_cast<unsigned long long>(hash),static_cast<unsigned long long>(memory.PrivateUsage),
            static_cast<unsigned long long>(memory.WorkingSetSize));
    }
    std::puts("\n]}");nemo_cluster_free(&renderer);
    SelectObject(dc,old_font);SelectObject(dc,old_bitmap);DeleteObject(font);DeleteObject(bitmap);DeleteDC(dc);
}
