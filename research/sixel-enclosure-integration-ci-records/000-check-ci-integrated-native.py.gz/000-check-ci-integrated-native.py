import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/ci-integrated-local';base.mkdir(exist_ok=False)
exe=root/'build/ci-integrated-9e7549b/product/nemoterm.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='c239b4af83eb3ae341309c81f59afd7e7af8039f0c058a990eb7a9a5ac1cda84'
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
cases=[('renderer','renderer',[]),('wire','sgr_stack',[])]
cases += [(family+'-'+renderer,'sixel_'+family,['--renderer',renderer])
    for family in ['background','palette'] for renderer in ['gdi','opengl','directx']]
cases += [('sixel-resize','sixel',[])]
cases += [('memory-'+renderer,'tabs',['--renderer',renderer,'--side',side,'--cols','160','--rows','48','--workload-memory'])
    for renderer,side in [('gdi','top'),('directx','left')]]
results=[]
for label,test,arguments in cases:
    dest=base/label
    for folder in ['dist','research','build','tools']:(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        result=subprocess.run([sys.executable,str(controller),str(dest),test,*arguments],cwd=root,stdout=log,stderr=subprocess.STDOUT)
    record=dict(label=label,exit_code=result.returncode)
    for p in (dest/'research').glob('*-memory.json'):
        d=json.loads(p.read_text());record.update(samples=d['sample_count'],peaks=d['peaks']['frontend'])
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(record,flush=True)
    if result.returncode:
        print((dest/'controller.log').read_text()[-2800:],flush=True);raise SystemExit(result.returncode)
