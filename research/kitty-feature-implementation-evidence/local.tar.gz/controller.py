from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

repo = Path(__file__).resolve().parent.parent
work = repo / 'build/kitty-features-worktree'
stage = work / 'build/native-feature-stage'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
exe = stage / 'dist/nemoterm.exe'
digest = sha(exe.read_bytes())
suites = []
for name, actual in [('gdi', 0), ('opengl', 1), ('directx', 2), ('presented-gdi', 0)]:
    p = stage / 'research' / f'kitty-features-{name}-observed.json'
    d = json.loads(p.read_text())
    assert d['completed'] and d['executable_sha256'] == digest
    assert len(d['checks']) == 176 and d['actual_renderer'] == actual
    assert not d['cleanup']['terminated_remaining'] and d['cleanup']['after']['active'] == 0
    for check in d['checks']:
        assert check['matched'] and check['reply_hex'] == check['expected_reply_hex']
        assert sha((Path(d['folder']) / check['bmp']).read_bytes()) == check['bmp_sha256']
    suites.append(dict(name=name, stages=176, actual_renderer=actual, capture=d['capture'], cleanup=d['cleanup']))
raw_files = {}
for folder in ('research', 'logs'):
    for p in sorted((stage / folder).rglob('*')):
        if p.is_file(): raw_files['native/' + p.relative_to(stage).as_posix()] = p.read_bytes()
for name in ('baseline.log', 'build-feature.log', 'build-feature-2.log', 'build.log',
             'configure.log', 'feature-replay.log', 'feature-replay-2.log',
             'build/limits-build.log', 'build/limits-replay.log', 'build/frontend.log'):
    raw_files['core/' + name] = (work / name).read_bytes()
raw_files['controller.py'] = Path(__file__).read_bytes()
buf = io.BytesIO()
records = []
with tarfile.open(fileobj=buf, mode='w') as tar:
    for name, raw in sorted(raw_files.items()):
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        tar.addfile(info, io.BytesIO(raw))
        records.append(dict(path=name, raw_bytes=len(raw), raw_sha256=sha(raw)))
compressed = gzip.compress(buf.getvalue(), mtime=0)
path = 'research/kitty-feature-implementation-evidence/local.tar.gz'
(work / path).parent.mkdir(exist_ok=True)
(work / path).write_bytes(compressed)
with tarfile.open(fileobj=io.BytesIO(compressed), mode='r:gz') as tar:
    for row in records:
        assert sha(tar.extractfile(row['path']).read()) == row['raw_sha256']
sources = ['vendor/putty-0.85/terminal/nemo_kitty.c', 'vendor/putty-0.85/terminal/nemo_kitty_cache.c',
           'vendor/putty-0.85/terminal/nemo_kitty_terminal.inc', 'vendor/putty-0.85/test/test_kitty_terminal.inc',
           'vendor/putty-0.85/test/kitty_feature_reference.h', 'scripts/generate-kitty-feature-reference.py',
           'tests/kitty_feature_reference.json', 'tests/kitty_features_window_smoke.py',
           'tests/sixel_palette_window_smoke.py', 'tests/test_kitty_transport.c']
manifest = dict(scope='Development frontend with bundled sidecar host, not accepted single-executable product',
    accepted_product_unchanged='b3e03bb / 65145ffb30d8a75199161f526b690794b66f6d593deab6f88cfd078ce5a795a0',
    executable_sha256=digest, executable_bytes=exe.stat().st_size,
    runtime={p.name:sha(p.read_bytes()) for p in (stage/'dist').iterdir() if p.suffix.lower() in ('.dll','.exe')},
    core=dict(reference_cases=84, reference_states=176, capability_projection_cases=22,
        pending_internal_image_slots_excluded=8, repeated_queries_without_graphics_memory_growth=1000,
        original_terminal_states=101, compression_cases=26, compression_states=36,
        baseline='Exploratory fixture logs retained, including incomplete-slot comparison failures; not an independently pinned test snapshot'),
    native=suites, sources_sha256={name:sha((work/name).read_bytes()) for name in sources},
    fixture_snapshot_sha256={p.relative_to(stage).as_posix():sha(p.read_bytes())
        for base in ('tests','tools') for p in sorted((stage/base).rglob('*'))
        if p.is_file() and '__pycache__' not in p.parts},
    bundles=[dict(path=path, archive_bytes=len(compressed), archive_sha256=sha(compressed), records=records)])
(work / 'research/kitty-feature-implementation-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(records=len(records), archive_bytes=len(compressed), native_api_stages=528,
                      presented_gdi_stages=176, executable_sha256=digest)))
