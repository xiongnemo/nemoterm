"""Six targeted exact-product local checks after verified complete CI, without physical input."""
from pathlib import Path
import hashlib,io,json,os,shutil,subprocess,sys,tarfile,time
root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
base=root/'build/ci-d3d11-f3b5b65-full'
source='f3b5b6539fede4f13dfb2ef12c1ec9e1657a8fd8'
stage=root/'build/local-d3d11-product-f3b5b65-01'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
plan=load(base/'plan.json')
assert plan['source']==source and plan['single']==43796089119
def digest(p):
    with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

# Observe the existing collector. Do not dispatch or restart a workflow.
deadline=time.monotonic()+3600
last_notice=0
while True:
    done=True
    for kind,run_id,count in [('ordinary',plan['ordinary'],4),('single',43796089119,1)]:
        run=load(base/(kind+'-run.json'))
        assert run['headSha']==source and run['databaseId']==run_id
        if run['status']=='completed':
            assert run['conclusion']=='success' and len(run['jobs'])==count
            assert all(j['conclusion']=='success' for j in run['jobs'])
        else:done=False
    ready=all((base/p).exists() for p in ('product-download.json','single-evidence-download.json','core-evidence-download.json'))
    if done and ready:break
    assert time.monotonic()<deadline,'Existing CI/collector did not complete; no native checks started'
    if time.monotonic()-last_notice>60:
        print('Waiting for existing complete CI and artifact receipts; no local terminal launched',flush=True)
        last_notice=time.monotonic()
    time.sleep(10)

receipt=load(base/'product-download.json')
assert receipt['source']==source and receipt['run_id']==43796089119
image=base/'product/nemoterm.exe';image_sha=digest(image)
assert receipt['files']==[dict(path='nemoterm.exe',bytes=image.stat().st_size,sha256=image_sha)]
validation=load(base/'single-evidence/build/single-exe-check/research/single-exe-validation.json')
assert validation['executable_sha256']==image_sha and validation['executable_bytes']==image.stat().st_size
assert validation['executable_directory_files']==['nemoterm.exe']
assert len(validation['passed_checks'])==len(set(validation['passed_checks']))==167
assert {'special_keys','extended_keys','legacy_modifiers'}<=set(validation['passed_checks'])
assert not stage.exists()
stage.mkdir()
for folder in ('dist','logs','research','case-evidence','build'):(stage/folder).mkdir()
archive=subprocess.check_output(['git','archive',source,'tests','tools/nemoterm_debug.py'],cwd=work)
fixtures={}
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    for entry in tar:
        if entry.isdir():continue
        assert entry.isfile()
        target=(stage/entry.name).resolve();assert target.is_relative_to(stage)
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(tar.extractfile(entry).read());fixtures[entry.name]=digest(target)
shutil.copy2(image,stage/'dist/nemoterm.exe');shutil.copy2(__file__,stage/'controller.py')
font_script=root/'build/probe-d3d11-product-font-f3b5b65.py'
assert not font_script.exists()
font_script.write_text((root/'build/probe-answerback-product-font-map-253855b.py').read_text().replace(
    'build/answerback-product-font-map-253855b.json','build/d3d11-product-font-map-f3b5b65.json'))
subprocess.run([sys.executable,str(font_script)],check=True)
shutil.copy2(font_script,stage/'font-preflight.py')
shutil.copy2(root/'build/d3d11-product-font-map-f3b5b65.json',stage/'research/font-mapper-preflight.json')
import frida
assert frida.__version__=='17.24.3'
original=dict(load(root/'build/local-answerback-product-253855b-01/all-cases.json'))
cases=[(name,original[name]) for name in ('startup-size','command-line-profile','unicode-kitty-memory-gdi')]
cases += [(name,['tests/'+name.replace('-','_')+'_window_smoke.py'])
          for name in ('special-keys','extended-keys','legacy-modifiers')]
identity=dict(source_commit=source,fixture_commit=source,source_run=43796089119,
    artifact_id=receipt['artifact_id'],executable_sha256=image_sha,executable_bytes=image.stat().st_size,
    ci_groups=167,frida=frida.__version__,fixtures=fixtures,selected_groups=len(cases),
    scope='Six targeted local regressions on exact downloaded single EXE; no physical/global input or clipboard. GDI memory gate unchanged; no DX memory optimization or repeated DX gate. Remaining desktop, application and full-goal checks remain separate. No promotion.')
(stage/'IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n')
(stage/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
env=dict(os.environ,NEMOTERM_TEST_EXE=str(stage/'dist/nemoterm.exe'),
    NEMOTERM_TEST_FONT='SarasaTermSC Nerd Font Light',NEMOTERM_TEST_TRACEBACK_SECONDS='60')
env.pop('CI',None);env.pop('GITHUB_ACTIONS',None)
def observations():
    return {p.relative_to(stage):digest(p) for folder in ('research','build') for p in (stage/folder).rglob('*') if p.is_file()}
results=[]
for name,arguments in cases:
    print('Starting exact-product case:',name,flush=True)
    before=observations();started=time.monotonic()
    with (stage/'logs'/(name+'.log')).open('w',encoding='utf-8') as log:
        try:
            completed=subprocess.run([sys.executable,*arguments],cwd=stage,env=env,
                stdout=log,stderr=subprocess.STDOUT,timeout=1800 if '-memory-' in name else 1200)
            row=dict(name=name,exit_code=completed.returncode,seconds=time.monotonic()-started)
        except subprocess.TimeoutExpired:
            row=dict(name=name,controller_timeout=True,seconds=time.monotonic()-started)
    row['observations']=[]
    for relative,checksum in observations().items():
        if before.get(relative)==checksum:continue
        target=stage/'case-evidence'/name/relative
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(stage/relative,target)
        row['observations'].append(dict(path=target.relative_to(stage).as_posix(),bytes=target.stat().st_size,sha256=checksum))
    results.append(row);(stage/'logs/results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps({k:v for k,v in row.items() if k!='observations'}),flush=True)
    if row.get('exit_code')!=0:raise SystemExit(1)
assert digest(stage/'dist/nemoterm.exe')==image_sha and [p.name for p in (stage/'dist').iterdir()]==['nemoterm.exe']
print('Six targeted checks passed. Full local/physical acceptance remains separate; no promotion.',flush=True)
