"""Retain source-matched native interaction checks on the downloaded CI image."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time

root=Path(__file__).resolve().parents[1]
previous=root/'build/local-d3d11-product-f3b5b65-01'
stage=root/'build/local-d3d11-interaction-f3b5b65-01'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
identity=load(previous/'IDENTITY.json')
assert identity['source_commit']=='f3b5b6539fede4f13dfb2ef12c1ec9e1657a8fd8'
assert identity['executable_sha256']=='de2f9e105e9186cb99fd925f8824e0573ae144ff62954b63ab3cda7c15ff0d28'
results=load(previous/'logs/results.json')
assert len(results)==6 and all(v['exit_code']==0 for v in results)
assert not stage.exists()
stage.mkdir()
for folder in ('dist','logs','research','build','case-evidence'):(stage/folder).mkdir()
for name,expected in identity['fixtures'].items():
    source=previous/name
    assert digest(source)==expected,name
    target=stage/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
identity['fixture_overrides']={}
for name in ('selection_window_smoke.py','bindings_window_smoke.py','drop_window_smoke.py'):
    source=root/'build/gdi-dense-memory-worktree/tests'/name
    target=stage/'tests'/name;shutil.copy2(source,target)
    identity['fixture_overrides']['tests/'+name]=dict(sha256=digest(target),reason='Honor explicitly requested test font; no product or assertion changes')
shutil.copy2(previous/'dist/nemoterm.exe',stage/'dist/nemoterm.exe')
assert digest(stage/'dist/nemoterm.exe')==identity['executable_sha256']
shutil.copy2(__file__,stage/'controller.py')
original=load(root/'build/local-answerback-product-253855b-01/all-cases.json')
names={'input-byte','input-wide','bindings','drop-gdi','drop-directx','selection-gdi','selection-directx','unicode-presented-gdi'}
cases=[(name,args) for name,args in original if name in names]
assert len(cases)==8
clients={'codex':Path('C:/Users/nemo/AppData/Local/Programs/OpenAI/Codex/bin/codex.exe'),'opencode':Path('C:/Users/nemo/scoop/apps/opencode/current/opencode.exe')}
identity['clients']={name:dict(path=str(path.resolve()),sha256=digest(path),version=subprocess.check_output([str(path),'--version'],text=True).strip()) for name,path in clients.items()}
cases += [('agent-image-'+name,['tests/agent_clipboard_smoke.py','--client',name,'--client-exe',str(path)]) for name,path in clients.items()]
identity.update(selected_groups=len(cases),scope='Existing native input-thread/clipboard/IMM and window-capture fixtures, plus isolated real Codex and OpenCode image paste through a loopback text-only provider. Foreground preparation is allowed. Does not certify physical IME candidate selection, physical mouse/keyboard or cross-monitor DPI. Computer Use native pipe unavailable on this session. No promotion.')
(stage/'IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n')
(stage/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
env=dict(os.environ,NEMOTERM_TEST_EXE=str(stage/'dist/nemoterm.exe'),NEMOTERM_TEST_FONT='SarasaTermSC Nerd Font Light',NEMOTERM_REQUIRE_DIRECTX='1',NEMOTERM_TEST_TRACEBACK_SECONDS='60')
env.pop('CI',None);env.pop('GITHUB_ACTIONS',None)
def observations():
    return {p.relative_to(stage):digest(p) for folder in ('research','build') for p in (stage/folder).rglob('*') if p.is_file()}
results=[]
for name,args in cases:
    print('Starting interaction case:',name,flush=True)
    before=observations();started=time.monotonic()
    with (stage/'logs'/(name+'.log')).open('w',encoding='utf-8') as log:
        try:
            completed=subprocess.run([sys.executable,*args],cwd=stage,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
            row=dict(name=name,exit_code=completed.returncode,seconds=time.monotonic()-started)
        except subprocess.TimeoutExpired:
            row=dict(name=name,controller_timeout=True,seconds=time.monotonic()-started)
    row['observations']=[]
    for relative,checksum in observations().items():
        if before.get(relative)==checksum:continue
        target=stage/'case-evidence'/name/relative
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(stage/relative,target)
        row['observations'].append(dict(path=target.relative_to(stage).as_posix(),bytes=target.stat().st_size,sha256=checksum))
    results.append(row);(stage/'logs/results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps({k:v for k,v in row.items() if k!='observations'}),flush=True)
    if row.get('exit_code')!=0:raise SystemExit(1)
assert digest(stage/'dist/nemoterm.exe')==identity['executable_sha256']
print('Ten native interaction groups passed; physical input remains separate.',flush=True)
