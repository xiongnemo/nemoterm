"""Retain failed and successful CAN/SUB replay evidence without rewriting it."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

root = Path(__file__).resolve().parents[1]
work = root/'build/cancellation-worktree'
runs = [
    ('73ed664ceefaba24ff7900af9254fc25fa1d2f76', 43709232327, 'success'),
    ('069d220e0f53b732caab9748a66a5413c2a8c6fc', 43709798590, 'success'),
]
paths = [
    '.github/workflows/ansi-conformance.yml',
    'vendor/putty-0.85/test/test_selective_erase.c',
    'vendor/putty-0.85/test/test_sgr.c', 'vendor/putty-0.85/test/test_tcap.c',
    'scripts/generate-ansi-reference.py', 'scripts/generate-cancellation-reference.py',
    'tests/ansi_conformance_reference.h', 'tests/control_cancellation_reference.h',
    'tests/generate_presentation_state_oracle.py', 'tests/presentation_state_direct_cases.py',
    'tests/presentation_state_oracle_cases.h', 'tests/presentation_state_oracle_cases.py',
    'vendor/putty-0.85/terminal/terminal.c', 'vendor/putty-0.85/terminal/terminal.h',
    'vendor/putty-0.85/terminal/nemo_kitty_terminal.inc',
    'vendor/putty-0.85/test/test_ansi_terminal.c',
    'vendor/putty-0.85/test/test_cancellation_terminal.c',
    'vendor/putty-0.85/test/test_terminal.c', 'vendor/putty-0.85/test/test_queries.c',
    'vendor/putty-0.85/test/test_sixel_terminal.c',
    'vendor/putty-0.85/unix/CMakeLists.txt', 'vendor/putty-0.85/windows/CMakeLists.txt',
]
sha = lambda data: hashlib.sha256(data).hexdigest()
entries = {'controller.py': Path(__file__).read_bytes()}
summaries = []
for source, run_id, conclusion in runs:
    prefix = source[:7]
    base = root/('build/ci-cancellation-component-'+prefix)
    run = json.loads((base/'ansi-components-run.json').read_text(encoding='utf-8'))
    assert (run['headSha'], run['databaseId'], run['status'], run['conclusion']) == (
        source, run_id, 'completed', conclusion)
    assert len(run['jobs']) == 3
    artifacts = json.loads((base/'ansi-components-artifacts.json').read_text(encoding='utf-8'))['artifacts']
    blobs = {p: subprocess.check_output(['git', 'show', f'{source}:{p}'], cwd=work) for p in paths}
    verified, retained = [], []
    for compiler in ('gcc', 'clang', 'msvc'):
        receipt = json.loads((base/(compiler+'-download.json')).read_text(encoding='utf-8'))
        artifact = next(a for a in artifacts if a['id'] == receipt['artifact_id'])
        assert receipt['source'] == source and artifact['name'] == f'ansi-conformance-{compiler}-{source}'
        retained.append({'compiler': compiler, 'artifact_id': artifact['id']})
        if compiler == 'msvc':
            for item in json.loads((base/compiler/'sources.json').read_text(encoding='utf-8-sig')):
                path = item['Path'].replace('\\', '/')
                name = next(p for p in paths if path.endswith('/'+p))
                actual = item['Hash'].lower()
                assert actual in (sha(blobs[name]), sha(blobs[name].replace(b'\n', b'\r\n')))
                verified.append({'compiler': compiler, 'path': name,
                                 'encoding': 'Git LF' if actual == sha(blobs[name]) else 'CRLF'})
        else:
            for line in (base/compiler/'sources.sha256').read_text(encoding='utf-8').splitlines():
                digest, name = line.split(maxsplit=1)
                assert digest == sha(blobs[name])
                verified.append({'compiler': compiler, 'path': name, 'encoding': 'Git LF'})
        if conclusion == 'success':
            cancel = (base/compiler/'test_cancellation_terminal.log').read_text(encoding='utf-8-sig')
            ansi = (base/compiler/'test_ansi_terminal.log').read_text(encoding='utf-8-sig')
            for mode in ('whole', 'bytewise'):
                assert f'Cancellation {mode}: 254 streams, 0 failures' in cancel
                assert f'ANSI {mode}: 243 unchanged XTerm streams, 0 failures' in ansi
            assert 'Cancellation: 64 payload lifetime cycles, 0 failures' in cancel
            for suite in ('queries', 'state_control', 'keyboard', 'pointer_terminal', 'osc52', 'sixel_terminal') + (('selective_erase','sgr','tcap') if prefix == '069d220' else ()):
                assert 'passed' in (base/compiler/f'test_{suite}.log').read_text(encoding='utf-8-sig')
    for path in base.rglob('*'):
        if path.is_file():
            entries[prefix+'/'+path.relative_to(base).as_posix()] = path.read_bytes()
    for name, blob in blobs.items():
        entries[prefix+'/source/'+name] = blob
    summaries.append({'source': source, 'run': run_id, 'conclusion': conclusion,
                      'jobs': [{'name': j['name'], 'conclusion': j['conclusion']} for j in run['jobs']],
                      'artifacts': retained, 'source_matches': verified})

archive = work/'research/control-cancellation-regressions.tar.gz'
records = []
with archive.open('xb') as out, gzip.GzipFile(filename='', fileobj=out, mode='wb', mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w|') as tar:
        for name, raw in sorted(entries.items()):
            info = tarfile.TarInfo(name); info.size = len(raw)
            tar.addfile(info, io.BytesIO(raw))
            records.append({'path': name, 'raw_bytes': len(raw), 'raw_sha256': sha(raw)})
with tarfile.open(archive, 'r|gz') as tar:
    for member, record in zip(tar, records, strict=True):
        assert member.name == record['path']
        assert sha(tar.extractfile(member).read()) == record['raw_sha256']
manifest = {
    'runs': summaries,
    'reference_observations_sha256': 'd69f11e6a36383d0cd8e08c4555bc6decb67f063c751992cd640f77acc9c0fa1',
    'ansi_reference_observations_sha256': '098028b29c4cbfe4ea66a447e576ddd3750baa9acafe270697ab9194d4c23506',
    'cancellation_cases_per_mode': 254, 'ansi_cases_per_mode': 243,
    'fragmentation_modes': ['whole', 'bytewise'], 'lifetime_cycles_per_compiler': 64,
    'explicit_policy_exceptions': [],
    'scope': 'Follow-up component regressions, including selective erase, SGR and XTGETTCAP at 069d220; no production changes. Full product CI and native conformance remain separate.',
    'bundle': {'path': archive.relative_to(work).as_posix(), 'archive_bytes': archive.stat().st_size,
               'archive_sha256': sha(archive.read_bytes()), 'records': records},
}
(work/'research/control-cancellation-regression-validation.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'runs': len(runs), 'records': len(records), 'bytes': archive.stat().st_size,
                  'source_matches': sum(len(r['source_matches']) for r in summaries)}))
