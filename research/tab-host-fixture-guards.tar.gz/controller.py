"""Verify host guards using the known CLI regression and the corrected image."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time

root=Path(__file__).resolve().parents[1]
work=root/'build/gdi-dense-memory-worktree'
stage=root/'build/tab-host-fixture-guards-d914972-01'
assert not stage.exists(),'Keep original observations intact'
stage.mkdir()
for name in ('tests','tools'):shutil.copytree(work/name,stage/name,ignore=shutil.ignore_patterns('__pycache__'))
for name in ('research','build','case-evidence','logs'): (stage/name).mkdir()
shutil.copy2(__file__,stage/'controller.py')

def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
baseline=root/'build/ci-gdi-display-cache-12ee33b/product/nemoterm.exe'
candidate=root/'build/local-cli-profile-candidate-02/dist/nemoterm.exe'
assert digest(baseline)=='64195969a8f2e6653f854d598f169810107ee808d66eaa1088cf9e3ced6b259f'
assert digest(candidate)=='a6c4c3b2d31db884ca22636e4d05bfd055df0fa8d50d64a2e9cba7cf8485b292'
identity=dict(source_commit='d914972e781a6e1bb18711fb9b25b005e03e4560',
    fixture_scope='Working-tree host-class assertions added to geometry, resize and Codex; Codex replay awaits desktop availability.',
    fixtures={name:digest(stage/'tests'/name) for name in ('geometry_window_smoke.py','window_resize_window_smoke.py','codex_window_smoke.py')},
    images={str(p):digest(p) for p in (baseline,candidate)})
(stage/'IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n')
results=[]
for variant,image,tabs in [('negative',baseline,True),('hosted',candidate,True),('standalone',candidate,False)]:
    for family in ('geometry','window_resize'):
        name=variant+'-'+family
        env=dict(os.environ,NEMOTERM_TEST_EXE=str(image),NEMOTERM_TEST_FONT='SarasaTermSC Nerd Font Light',NEMOTERM_TEST_TRACEBACK_SECONDS='60')
        env.pop('CI',None);env.pop('GITHUB_ACTIONS',None)
        command=[sys.executable,str(stage/'tests'/f'{family}_window_smoke.py'),'--renderer','0']
        if tabs:command+=['--tabs','--tab-side','left']
        before={p.relative_to(stage):digest(p) for p in (stage/'research').rglob('*') if p.is_file()}
        print('Starting',name,flush=True);started=time.monotonic()
        with (stage/'logs'/f'{name}.log').open('w',encoding='utf-8') as log:
            completed=subprocess.run(command,cwd=stage,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300)
        observations=[]
        for p in (stage/'research').rglob('*'):
            if not p.is_file():continue
            relative=p.relative_to(stage);checksum=digest(p)
            if before.get(relative)==checksum:continue
            target=stage/'case-evidence'/name/relative
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
            observations.append(dict(path=target.relative_to(stage).as_posix(),sha256=checksum,bytes=target.stat().st_size))
        report_name=('tabs-' if tabs else '')+('geometry-window-observed.json' if family=='geometry' else 'window-resize-observed.json')
        report=json.loads((stage/'research'/report_name).read_text(encoding='utf-8-sig'))
        result=dict(name=name,exit_code=completed.returncode,seconds=time.monotonic()-started,observations=observations,
                    actual_tab_host=report['tab_host'],modes=[dict(host_class=m['host_class'],checks=len(m['checks']),cleanup=m.get('cleanup')) for m in report['modes']])
        results.append(result);(stage/'results.json').write_text(json.dumps(results,indent=2)+'\n')
        if variant=='negative':
            assert completed.returncode!=0 and report['tab_host'] is False
            assert report['modes'][0]['host_class']=='Nemoterm' and not report['modes'][0]['checks']
            assert 'AssertionError' in report['modes'][0]['error']
        else:
            assert completed.returncode==0 and report['tab_host']==tabs
            assert all(m['host_class']==('NemotermHost' if tabs else 'Nemoterm') for m in report['modes'])
            assert all(m.get('cleanup') and not m['cleanup']['terminated_remaining'] for m in report['modes'])
        print(json.dumps({k:v for k,v in result.items() if k not in ('observations','modes')}),flush=True)
print('Both old-image controls rejected before geometry checks; all four corrected-image invocations passed.',flush=True)
