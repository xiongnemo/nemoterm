"""Retain the complete successful single-image checkpoint, streaming large evidence."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[1];work=root/'build/locator-worktree'
base=root/'build/ci-cancellation-complete-73ed664';source='73ed664ceefaba24ff7900af9254fc25fa1d2f76'
component_source='069d220e0f53b732caab9748a66a5413c2a8c6fc'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
run=json.loads((base/'single-run.json').read_text())
assert (run['databaseId'],run['headSha'],run['status'],run['conclusion'])==(43709232409,source,'completed','success')
assert len(run['jobs'])==1 and run['jobs'][0]['conclusion']=='success'
research=base/'single-evidence/build/single-exe-check/research'
validation=json.loads((research/'single-exe-validation.json').read_text(encoding='utf-8-sig'))
image=base/'product/nemoterm.exe';image_sha=digest(image)
assert image_sha==validation['executable_sha256']=='c5a359282e012a5cbd3b27b74543a5c74e9e5e43687cd1cd8d0d01e687890a71'
assert image.stat().st_size==validation['executable_bytes']==4532224
assert len(validation['passed_checks'])==len(set(validation['passed_checks']))==155
assert validation['executable_directory_files']==['nemoterm.exe']
paths=['vendor/putty-0.85/terminal','vendor/putty-0.85/windows','vendor/putty-0.85/putty.h','native','scripts/build-single-exe.ps1','scripts/prepare-single-exe.py']
subprocess.run(['git','diff','--exit-code',component_source,source,'--',*paths],cwd=work,check=True)
native=json.loads((research/'control-cancellation-observed.json').read_text(encoding='utf-8'))
assert native['completed'] and native['executable_sha256']==image_sha and native['reference_case_count']==413
marker=b'\x1bP>|Nemoterm(PuTTY 0.85)\x1b\\'
for prefix,name,count in [('ansi','ansi_conformance_native_cases.py',177),('cancel','control_cancellation_native_cases.py',236)]:
    import ast
    tree=ast.parse(subprocess.check_output(['git','show',f'{source}:tests/{name}'],cwd=work).decode('utf-8'))
    values={node.targets[0].id:ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign)}
    assert len(values['CASES'])==count
    for case,sequence,expected in values['CASES']:
        assert bytes.fromhex(native['cases'][prefix+'-'+case])==expected+marker,case
assert len(native['exercise']['pixel_pairs'])==3
for pair in native['exercise']['pixel_pairs'].values():assert pair['literal_sha256']==pair['control_sha256']
assert not native['cleanup']['terminated_remaining'] and native['cleanup']['after']['active']==0
workloads=[]
for path in sorted(research.glob('*workload-tabs-*-observed.json')):
    data=json.loads(path.read_text())
    assert data['completed'] and data['memory_limit_passed'] and data['executable_sha256']==image_sha
    assert not data['memory_instrumented'] and not data['process_tree_memory']['injected']
    assert data['memory_limit_required'] and not data['process_tree_memory']['errors']
    dx=data['renderer']=='directx';limit=25000000 if dx else 20000000
    assert data['memory_limit_bytes']==limit and data['memory_limit_inclusive']==dx
    assert data['peak_private_ws']<=limit if dx else data['peak_private_ws']<limit
    cleanup=data['owned_job_cleanup']
    assert not cleanup['terminated_remaining'] and cleanup['after']['active']==0
    record=dict(path=path.relative_to(base).as_posix(),renderer=data['renderer'],actual_renderer=data['actual_renderer'],
        font=data['font'],grid=data['actual_grid'],frontend_peaks=data['process_tree_memory']['peaks']['frontend'],
        process_tree_peaks=data['process_tree_memory']['peaks'],private_limit_bytes=limit,passed=True,natural_cleanup=True)
    if path.name.startswith('unicode-'):
        samples=data['post_memory_kitty_unicode']
        assert len(samples)==4 and all(x['matched'] and x['after_memory_sampling'] and not x['injected'] for x in samples)
        record['post_memory_cells']=sum(x['cells_verified'] for x in samples)
    workloads.append(record)
assert len(workloads)==12 and sum(x.get('post_memory_cells',0) for x in workloads)==25048
drops=[]
for renderer in ('gdi','directx'):
    data=json.loads((research/f'drop-{renderer}-observed.json').read_text())
    assert data['completed'] and data['exe_sha256']==image_sha and len(data['checks'])==50
    assert all(not c['terminated_remaining'] and c['after']['active']==0 for c in data['cleanup'])
    parsers=data['shell_parser_processes']
    assert all(p['completed'] and p['timeout_seconds']==20 for p in parsers)
    drops.append(dict(renderer=renderer,checks=50,external_shell_seconds={p['shell']:p['elapsed_seconds'] for p in parsers}))
artifacts=json.loads((base/'single-artifacts.json').read_text())['artifacts']
product=next(a for a in artifacts if a['id']==14161561224)
assert product['name']=='nemoterm-single-exe-x64-'+source and not product['expired']
entries={'controller.py':Path(__file__)}
for name in ('single-run.json','single-run.log','single-artifacts.json','single-observed-at.txt','product-download.json','single-evidence-download.json','ordinary-run.json','ordinary-run.log'):
    entries[name]=base/name
for folder in ('product','single-evidence'):
    for path in (base/folder).rglob('*'):
        if path.is_file():entries[path.relative_to(base).as_posix()]=path
for name in ('.github/workflows/single-exe.yml','scripts/build-single-exe.ps1','scripts/test-single-exe.ps1',
             'scripts/prepare-single-exe.py','native/single_exe/entry.cpp','tests/drop_window_smoke.py',
             'tests/tabs_window_smoke.py','tests/tab_workload_memory.py','tests/memory_limits.py',
             'tests/native_test_utils.py','tests/owned_job.py','scripts/generate-ansi-reference.py','tests/ansi_conformance_reference.h','tests/ansi_conformance_native_cases.py','tests/control_cancellation_native_cases.py','tests/control_cancellation_window_smoke.py','tests/protocol_oracle_window.py','scripts/generate-cancellation-reference.py','vendor/putty-0.85/test/test_cancellation_terminal.c','vendor/putty-0.85/terminal/terminal.c','vendor/putty-0.85/terminal/terminal.h','vendor/putty-0.85/test/test_ansi_terminal.c'):
    entries['source/'+name]=subprocess.check_output(['git','show',f'{source}:{name}'],cwd=work)
archive=work/'research/control-cancellation-single.tar.gz';archive.parent.mkdir(exist_ok=True);records=[]
with archive.open('xb') as out,gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
    for name,value in sorted(entries.items()):
        info=tarfile.TarInfo(name)
        if isinstance(value,bytes):
            info.size=len(value);checksum=sha(value);tar.addfile(info,io.BytesIO(value))
        else:
            info.size=value.stat().st_size;checksum=digest(value)
            with value.open('rb') as stream:tar.addfile(info,stream)
        records.append(dict(path=name,raw_bytes=info.size,raw_sha256=checksum))
with tarfile.open(archive,'r|gz') as tar:
    for member,record in zip(tar,records,strict=True):
        assert member.name==record['path'] and hashlib.file_digest(tar.extractfile(member),'sha256').hexdigest()==record['raw_sha256']
ordinary=json.loads((base/'ordinary-run.json').read_text(encoding='utf-8'))
assert ordinary['databaseId']==43709232412 and ordinary['headSha']==source and ordinary['conclusion']=='failure'
assert 'selective_erase' in (base/'ordinary-run.log').read_text(encoding='utf-8')
manifest=dict(ordinary_failure=dict(run=43709232412,conclusion='failure',reason='Outdated no-glyph SUB assertions in selective-erase and SGR tests; corrected in source-equivalent 069d220'),source=source,run=43709232409,conclusion='success',validation=validation,
    production_equivalence=dict(source=component_source,paths=paths,git_diff_exit=0,
        scope='Same production and single-image build inputs as the corrected cancellation component checkpoint; test assertion sources are excluded and these were separately linked binaries.'),
    product_artifact=dict(id=product['id'],name=product['name'],expires_at=product['expires_at'],
        url=f"https://github.com/xiongnemo/nemoterm/actions/runs/43709232409/artifacts/{product['id']}"),
    workloads=workloads,drops=drops,native_comparison=dict(reference_streams=413,ansi=177,cancellation=236,binary_only_core=84,pixel_pairs=native['exercise']['pixel_pairs'],natural_cleanup=True),
    limits='Remote Consolas grids; not local 160x48 Sarasa acceptance. The GDI total target is approximately 50 MB. Current DX memory is accepted by the user; no further DX optimization is required. The contemporaneous ordinary workflow failed outdated SUB assertions; its source-equivalent replacement at 7c40765 is separately tracked. This image includes CAN/SUB parity and all 413 native reference streams.',
    bundle=dict(path=archive.relative_to(work).as_posix(),archive_bytes=archive.stat().st_size,
        archive_sha256=digest(archive),records=records))
(work/'research/control-cancellation-single-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(records=len(records),bytes=archive.stat().st_size,checks=len(validation['passed_checks']),
    artifact_id=product['id'],expires_at=product['expires_at'],drops=drops)))
