"""Three-cycle diagnostic plus a held-session negative control, never acceptance."""
import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
main=root.parents[1]
base=root/'build/resource-settle-passive-diagnostic';base.mkdir(exist_ok=False)
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
results=[]
for label,exe,negative in [
    ('accepted',main/'dist/nemoterm.exe',False),
    ('menu',root.parent/'tab-system-menu-worktree/build/menu-single/nemoterm.exe',False),
    ('held-session',main/'dist/nemoterm.exe',True)]:
    dest=base/label
    for folder in ['dist','research','build','tools']:(dest/folder).mkdir(parents=True,exist_ok=True)
    # Same main-420 fixture for both images; menu assertions are a separate check.
    shutil.copytree(main/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    shutil.copy2(main/'tools/nemoterm_debug.py',dest/'tools')
    shutil.copy2(root/'tests/resource_settle.py',dest/'tests')
    p=dest/'tests/tabs_window_smoke.py';code=p.read_text()
    code=code.replace('from collections import Counter', 'from collections import Counter\nfrom resource_settle import startup, after_close')
    anchor="            baseline=resources();evidence['initial']=initial;evidence['two_tabs']=baseline;evidence['cycles']=[]"
    replacement="""            evidence['startup_resources']=[]
            baseline=startup(resources,evidence['startup_resources'])
            evidence['initial']=initial;evidence['two_tabs']=baseline;evidence['cycles']=[]
            evidence['resource_return']=[]"""
    assert code.count(anchor)==1;code=code.replace(anchor,replacement)
    anchor="                sample=resources();evidence['cycles'].append(sample)"
    replacement="""                returned=[];evidence['resource_return'].append(returned)
                sample=after_close(resources,baseline,returned)
                evidence['cycles'].append(sample)"""
    assert code.count(anchor)==1;code=code.replace(anchor,replacement)
    assert code.count('for i in range(12):')==1;code=code.replace('for i in range(12):',f'for i in range({0 if negative else 3}):')
    if negative:
        anchor='            for i in range(0):'
        replacement="""            # Intentionally retain an entire extra native session. It must not
            # be accepted as a new baseline or discarded as a transient.
            held=duplicate(second,track_workers=True);output(held,scene('HELD SESSION','60;10;60'))
            observation=[];evidence['negative_control_resources']=observation
            try:
                after_close(resources,baseline,observation)
            except AssertionError as error:
                assert 'Closed-tab resources' in str(error),repr(error)
                evidence['persistent_session_rejected']=True
            else:
                raise AssertionError('Persistent native session escaped the resource gate')
            u.PostMessageW(held['hwnd'],0x10,0,0)
            wait_for(lambda:not u.IsWindow(held['hwnd']))
            select(second,1);wait_for(lambda:job.accounting()['active']==5)
            wait_for_tab_workers(held)
            evidence['negative_control_after_close']=[]
            after_close(resources,baseline,evidence['negative_control_after_close'])
            for i in range(0):"""
        code=code.replace(anchor,replacement)
    anchor="            evidence['checks'].append('12 create/close cycles retain one shared renderer without handle growth')"
    replacement="""            memory=memory_sampler.stop();memory_sampler=None
            memory['diagnostic_only']=True
            assert not memory['errors'],memory['errors']
            write_snapshot(root/'research/resource-diagnostic-memory.json',memory)
            evidence.update(diagnostic_completed=True,completed=False,memory_acceptance=False,
                            scope='Bounded resource timing diagnostic; not a full workload')
            u.PostMessageW(host,0x10,0,0);process.wait(timeout=15)
            assert process.returncode==0,process.returncode
            evidence['owned_job_cleanup']=job.finish(grace=5)
            assert not evidence['owned_job_cleanup']['terminated_remaining']
            raise SystemExit(2)"""
    assert code.count(anchor)==1;code=code.replace(anchor,replacement)
    # Preserve one original redraw per observation sequence. Polling itself
    # must not invalidate/repaint continuously and restart GUI timers.
    a="""            def resources():
                for visible_hwnd in windows(process.pid,'Nemoterm',host,True):
                    u.RedrawWindow(visible_hwnd,None,None,0x185)"""
    b="""            def resources(redraw=True):
                if redraw:
                    for visible_hwnd in windows(process.pid,'Nemoterm',host,True):
                        u.RedrawWindow(visible_hwnd,None,None,0x185)"""
    assert code.count(a)==1;code=code.replace(a,b)
    a='            first=new_child([])'
    b="""            def resource_observer():
                first=True
                def observe():
                    nonlocal first
                    value=resources(redraw=first);first=False
                    return value
                return observe
            first=new_child([])"""
    assert code.count(a)==1;code=code.replace(a,b)
    code=code.replace('startup(resources,','startup(resource_observer(),')
    code=code.replace('after_close(resources,','after_close(resource_observer(),')
    p.write_text(code)
    (dest/'diagnostic-fixture.json').write_text(json.dumps(dict(acceptance=False,negative_control=negative,
        executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),fixture_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
        helper_sha256=hashlib.sha256((dest/'tests/resource_settle.py').read_bytes()).hexdigest()),indent=2)+'\n')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        result=subprocess.run([sys.executable,str(controller),str(dest),'tabs','--renderer','directx','--side','left',
            '--cols','160','--rows','48','--workload-memory'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
    observed=json.loads((dest/'research/workload-tabs-directx-left-observed.json').read_text())
    record=dict(label=label,exit_code=result.returncode,diagnostic_completed=observed.get('diagnostic_completed',False),
        negative_control=observed.get('persistent_session_rejected'),baseline=observed.get('two_tabs'),
        cycles=observed.get('cycles'),cleanup=observed.get('owned_job_cleanup'))
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print({k:v for k,v in record.items() if k not in ['cycles','cleanup']},flush=True)
    if result.returncode!=2:print((dest/'controller.log').read_text()[-2600:],flush=True)
assert all(x['exit_code']==2 and x['diagnostic_completed'] for x in results),results
