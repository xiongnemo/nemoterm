import hashlib,json,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
base=root/'build/resource-settle-native';base.mkdir(exist_ok=False)
exe=root.parent/'tab-system-menu-worktree/build/menu-single/nemoterm.exe'
assert hashlib.sha256(exe.read_bytes()).hexdigest()=='18d20efbc85257fb8a04822debf2bc8a0a9a49d6a8e7c86a6871c10eb10eae6c'
controller=root.parent/'rtl-worktree/build/run-owned-check.py'
results=[]
for label,renderer,side,cols,rows,workload in [
    ('gdi-top','gdi','top',160,48,True),
    ('directx-left','directx','left',160,48,True),
    ('opengl-bottom','opengl','bottom',80,24,False),
    ('gdi-right','gdi','right',80,24,False)]:
    dest=base/label
    for folder in ['dist','research','build','tools']:(dest/folder).mkdir(parents=True,exist_ok=True)
    shutil.copytree(root/'tests',dest/'tests');shutil.copy2(exe,dest/'dist')
    shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools')
    arguments=['--renderer',renderer,'--side',side,'--cols',str(cols),'--rows',str(rows)]
    if workload:arguments.append('--workload-memory')
    with (dest/'controller.log').open('w',encoding='utf-8') as log:
        result=subprocess.run([sys.executable,str(controller),str(dest),'tabs',*arguments],cwd=root,stdout=log,stderr=subprocess.STDOUT)
    observed=next((dest/'research').glob('*-observed.json'));d=json.loads(observed.read_text())
    record=dict(label=label,exit_code=result.returncode,completed=d.get('completed'),
        peak_private_ws=d.get('peak_private_ws'),memory_limit_passed=d.get('memory_limit_passed'),
        startup_seconds=d.get('startup_resources',[{}])[-1].get('seconds'),
        resource_return_seconds=[r[-1]['seconds'] for r in d.get('resource_return',[])])
    results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(record,flush=True)
    if result.returncode:
        print((dest/'controller.log').read_text()[-2800:],flush=True)
        raise SystemExit(result.returncode)
