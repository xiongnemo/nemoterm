import gzip,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
files=[]
for name in ['resource-settle-diagnostic','resource-settle-passive-diagnostic','resource-settle-native']:
    folder=root/'build'/name
    for p in folder.rglob('*'):
        if not p.is_file() or any(n in p.relative_to(folder).parts for n in ['dist','tests','tools','__pycache__']):continue
        if p.suffix in ['.json','.log','.png','.bmp']:files.append(p)
    # The failed and corrected observation functions must remain reproducible.
    files += list(folder.glob('*/tests/tabs_window_smoke.py'))
    files += list(folder.glob('*/tests/resource_settle.py'))
files += list((root/'build').glob('check-resource-settle-*.py'))
files += [root/'build/resource-settle-unit.log',Path(__file__)]
files += [root/n for n in ['tests/resource_settle.py','tests/resource_settle_test.py','tests/tabs_window_smoke.py']]
dest=root/'research/resource-settle-records';dest.mkdir(exist_ok=True);records=[]
for p in sorted(set(files)):
    data=p.read_bytes();archive=dest/f'{len(records):03d}-{p.name}.gz'
    if archive.exists():assert gzip.decompress(archive.read_bytes())==data,archive
    else:archive.write_bytes(gzip.compress(data,mtime=0))
    records.append(dict(path=p.relative_to(root).as_posix(),archive=archive.relative_to(root).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
manifest=dict(base='c5535a69ab9ca95d9cfbccc7df5d057fd756faa7',
    kind='Local owned Win32 observations and deterministic unit tests, not REA-server Evidence',records=records)
(root/'research/resource-settle-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
for r in records:
    data=gzip.decompress((root/r['archive']).read_bytes());assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
print('Verified',len(records),'records;',sum((root/r['archive']).stat().st_size for r in records),'compressed bytes')
