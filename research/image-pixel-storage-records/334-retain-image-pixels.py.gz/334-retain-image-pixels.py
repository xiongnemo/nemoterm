from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path(__file__).resolve().parents[1];dest=root/'research/image-pixel-storage-records';dest.mkdir()
folders=[root/'build/staging-ci-local-01',root/'build/image-regions-01',root/'build/image-pixels-native-01',
         root/'build/image-pixels-linux-01',root/'build/image-pixel-unit']
paths=[p for folder in folders for p in folder.rglob('*') if p.is_file() and p.suffix in ('.json','.log','.png') and not any(s in p.parts for s in ('dist','tests','tools','normal','asan'))]
paths += [root/'build'/name for name in ('check-staging-ci.py','check-image-regions.py','check-image-pixels.py',
         'check-image-pixels-linux.py','link-image-pixels-01.py','build-image-pixels.log')]
paths += [Path(__file__),root/'build/image-pixels-single-01/link.rsp',root/'build/image-pixels-single-01/link.log',root/'build/image-pixels-single-01/image.json']
paths += [root/p for p in ('vendor/putty-0.85/terminal/nemo_raster.c','vendor/putty-0.85/terminal/nemo_raster.h',
          'vendor/putty-0.85/windows/nemo_wic.c','vendor/putty-0.85/test/test_iterm_terminal.inc','tests/test_raster.c',
          'tests/tab_workload_memory.py','tests/tabs_window_smoke.py','tests/working_set_regions.py')]
ci=root/'build/ci-staging-a3eb24e'
paths += [ci/(kind+'-'+suffix) for kind in ('core','single') for suffix in ('run.json','run.log','artifacts.json')]
paths += [ci/'single-evidence/build/single-exe-check/research/single-exe-validation.json',
          ci/'single-evidence/build/native-crashes/application-errors.json']
manifest=dict(scope='Failed exact-CI-artifact acceptance; read-only region comparisons; experimental independent large pixel reservations, not a demonstrated memory fix',
 parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 ci_acceptance=json.loads((folders[0]/'results.json').read_text()),regions=json.loads((folders[1]/'results.json').read_text()),
 experiment=json.loads((folders[2]/'results.json').read_text()),records=[])
for i,p in enumerate(sorted(set(paths))):
 data=p.read_bytes();archive=dest/f'{i:03d}-{p.name}.gz';archive.write_bytes(gzip.compress(data,mtime=0))
 assert gzip.decompress(archive.read_bytes())==data
 manifest['records'].append(dict(path=str(p),archive=archive.relative_to(root).as_posix(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(root/'research/image-pixel-storage-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(dict(records=len(manifest['records']),compressed_bytes=sum(p.stat().st_size for p in dest.iterdir())))
