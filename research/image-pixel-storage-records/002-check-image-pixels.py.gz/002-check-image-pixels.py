from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];base=root/'build/image-pixels-native-01';base.mkdir()
old=root/'build/staging-single-01/nemoterm.exe';new=root/'build/image-pixels-single-01/nemoterm.exe'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='9300a9cd87fc9f9fc4dff39408c07221addce0febc70e0b7b7fa2f7a3fee42c0'
assert hashlib.sha256(new.read_bytes()).hexdigest()=='52ae9cd898b61d43714706084b9fd764aa250b86e3f016953049903b185fa530'
memory=['--renderer','directx','--side','left','--cols','160','--rows','48','--workload-memory']
cases=[('before-directx-png','tabs',memory+['--inline-images'],old),
       ('after-directx-png','tabs',memory+['--inline-images'],new),
       ('after-directx-gif','tabs',memory+['--animated-images'],new)]
cases += [(f'after-{test}-{r}',test,['--renderer',r],new) for test in ('iterm_image','gif_animation') for r in ('gdi','opengl','directx')]
cases += [(f'after-gdi-{image}','tabs',['--renderer','gdi','--side','top','--cols','160','--rows','48','--workload-memory',flag],new) for image,flag in [('png','--inline-images'),('gif','--animated-images')]]
results=[]
for name,test,args,exe in cases:
 dest=base/name
 for directory in ('dist','research','build','tools'):(dest/directory).mkdir(parents=True)
 shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
 shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(exe,dest/'dist/nemoterm.exe')
for name,test,args,exe in cases:
 dest=base/name;print('Starting '+name,flush=True)
 with (dest/'controller.log').open('w') as log:
  run=subprocess.run([sys.executable,str(root.parent/'rtl-worktree/build/run-owned-check.py'),str(dest),test,*args],stdout=log,stderr=subprocess.STDOUT)
 record=dict(name=name,exit_code=run.returncode,executable_sha256=hashlib.sha256(exe.read_bytes()).hexdigest())
 for p in (dest/'research').glob('*-memory.json'):
  d=json.loads(p.read_text());record.update(samples=d['sample_count'],peaks=d['peaks']['frontend'],injected=d['injected'])
 results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps(record),flush=True)
 if run.returncode:
  print((dest/'controller.log').read_text()[-2500:],flush=True)
  if name.startswith('after-'):raise SystemExit(run.returncode)
print('All post-change native cases passed',flush=True)
