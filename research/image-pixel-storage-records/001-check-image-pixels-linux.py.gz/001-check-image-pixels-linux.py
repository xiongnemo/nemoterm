from pathlib import Path
import subprocess
root=Path.cwd();linux='/mnt/c/Users/nemo/Documents/Projects/nemoterm/build/dx-staging-worktree'
base=root/'build/image-pixels-linux-01';base.mkdir(exist_ok=True)
for name,flags in [('normal','-g -O1'),('asan','-g -O1 -fsanitize=address,undefined -fno-omit-frame-pointer')]:
    commands=[['cmake','-S',linux+'/vendor/putty-0.85','-B',linux+'/build/image-pixels-linux-01/'+name,'-G','Ninja','-DPUTTY_GTK_VERSION=NONE','-DPUTTY_GSSAPI=OFF','-DCMAKE_C_FLAGS='+flags],['cmake','--build',linux+'/build/image-pixels-linux-01/'+name,'--target','test_raster','test_iterm','test_sixel_terminal','test_osc52','test_sgr','--parallel','4']]
    commands += [['env','ASAN_OPTIONS=detect_leaks=1:halt_on_error=1','UBSAN_OPTIONS=halt_on_error=1',linux+'/build/image-pixels-linux-01/'+name+'/'+suite] for suite in ['test_raster','test_iterm','test_sixel_terminal','test_osc52','test_sgr']]
    for i,cmd in enumerate(commands):
        with (base/f'{name}-{i}.log').open('w') as log:subprocess.run(['wsl.exe','-d','Debian','--',*cmd],stdout=log,stderr=subprocess.STDOUT,check=True)
        print(name,i,'passed',flush=True)



