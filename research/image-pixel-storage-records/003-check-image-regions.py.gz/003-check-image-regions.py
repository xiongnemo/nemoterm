from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
root=Path(__file__).resolve().parents[1];base=root/'build/image-regions-01';base.mkdir()
cases=[('ci',root/'build/ci-staging-a3eb24e/product/nemoterm.exe','106439ed2b4f099091229e965c74cf55b32e6326432d47ee58f1c2972d113959'),
       ('local',root/'build/staging-single-01/nemoterm.exe','9300a9cd87fc9f9fc4dff39408c07221addce0febc70e0b7b7fa2f7a3fee42c0')]
for name,exe,digest in cases:
 assert hashlib.sha256(exe.read_bytes()).hexdigest()==digest
 dest=base/name
 for directory in ('dist','research','build','tools'):(dest/directory).mkdir(parents=True)
 shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
 shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(exe,dest/'dist/nemoterm.exe')
results=[]
for name,exe,digest in cases:
 dest=base/name
 with (dest/'controller.log').open('w') as log:
  run=subprocess.run([sys.executable,str(root.parent/'rtl-worktree/build/run-owned-check.py'),str(dest),'tabs',
       '--renderer','directx','--side','left','--cols','160','--rows','48','--workload-memory','--inline-images'],
       env=dict(os.environ,NEMOTERM_TEST_MEMORY_REGIONS='1'),stdout=log,stderr=subprocess.STDOUT)
 data=json.loads((dest/'research/inline-workload-tabs-directx-left-observed.json').read_text())
 record=dict(image=name,executable_sha256=digest,exit_code=run.returncode,error=data.get('error'),private_ws=data.get('peak_private_ws'),
             phases={k:dict(private_ws=v['private_ws'],by_kind=v['by_kind']) for k,v in data.get('memory_regions',{}).items()},
             diagnostic_only=True,acceptance=False)
 results.append(record);(base/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps(record),flush=True)
 if run.returncode:print((dest/'controller.log').read_text()[-1500:],flush=True)
print('Read-only region observation complete; earlier acceptance failure remains a failure',flush=True)
