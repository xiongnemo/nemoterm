from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time
root=Path(__file__).resolve().parents[1];ci=root/'build/ci-staging-a3eb24e'
source='a3eb24ea21ea767a2fd6269222bbe6441c279813'
base=root/'build/staging-ci-local-01';base.mkdir()
deadline=time.monotonic()+2100
print('Waiting for both exact-source CI results and the downloaded single image',flush=True)
while True:
 states=[json.loads((ci/f'{kind}-run.json').read_text()) for kind in ('core','single')]
 assert all(s['headSha']==source for s in states)
 if all(s['status']=='completed' for s in states):
  assert all(s['conclusion']=='success' for s in states),[(s['databaseId'],s['conclusion']) for s in states]
  if (ci/'product/nemoterm.exe').exists():break
 assert time.monotonic()<deadline,'CI observation deadline; no native acceptance started'
 time.sleep(20)
exe=ci/'product/nemoterm.exe';digest=hashlib.sha256(exe.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','diff',source,'HEAD','--','vendor','terminal','native','scripts/prepare-single-exe.py'],cwd=root)
memory=['--side','left','--cols','160','--rows','48','--workload-memory']
cases=[('renderer','renderer',[])]
cases += [(f'iterm-{r}','iterm_image',['--renderer',r]) for r in ('gdi','opengl','directx')]
cases += [(f'gif-{r}','gif_animation',['--renderer',r]) for r in ('gdi','opengl','directx')]
for renderer,side in [('directx','left'),('gdi','top')]:
 for image,flag in [('baseline',[]),('png',['--inline-images']),('gif',['--animated-images'])]:
  cases.append((f'{renderer}-{image}','tabs',['--renderer',renderer,'--side',side,'--cols','160','--rows','48','--workload-memory',*flag]))
summary=dict(source=source,fixture_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),executable_sha256=digest,bytes=exe.stat().st_size,
             planned=[name for name,_,_ in cases],results=[],completed=False)
(base/'results.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({k:v for k,v in summary.items() if k!='results'}),flush=True)
for name,test,args in cases:
 dest=base/name
 for directory in ('dist','research','build','tools'):(dest/directory).mkdir(parents=True)
 shutil.copytree(root/'tests',dest/'tests',ignore=shutil.ignore_patterns('*.exe','__pycache__'))
 shutil.copy2(root/'tools/nemoterm_debug.py',dest/'tools');shutil.copy2(exe,dest/'dist/nemoterm.exe')
for name,test,args in cases:
 dest=base/name
 print('Starting exact-artifact local test: '+name,flush=True)
 with (dest/'controller.log').open('w') as log:
  run=subprocess.run([sys.executable,str(root.parent/'rtl-worktree/build/run-owned-check.py'),str(dest),test,*args],stdout=log,stderr=subprocess.STDOUT)
 record=dict(name=name,exit_code=run.returncode)
 for p in (dest/'research').glob('*-memory.json'):
  d=json.loads(p.read_text());record.update(samples=d['sample_count'],peaks=d['peaks']['frontend'],injected=d['injected'])
 summary['results'].append(record);(base/'results.json').write_text(json.dumps(summary,indent=2));print(json.dumps(record),flush=True)
 if run.returncode:
  print((dest/'controller.log').read_text()[-3500:],flush=True)
  raise SystemExit(run.returncode)
summary['completed']=True;(base/'results.json').write_text(json.dumps(summary,indent=2));print('Exact CI image passed all planned local checks',flush=True)
