"""Read immutable remote artifacts only; never execute a binary or test."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[2]
base = root/'build/tcap-core/retained/44083541137'
record = dict(scope='File-only verification of completed hosted run 44083541137.')
with zipfile.ZipFile(base/'14333345297.zip') as bundle:
    name = next(n for n in bundle.namelist() if n.endswith('/single-exe-validation.json'))
    data = json.loads(bundle.read(name))
    print('single validation',json.dumps(data,indent=2)[:3500])
    record['single_validation'] = data
    for suffix in ('feature-policy-observed.json','tcap-keys-observed.json'):
        for name in bundle.namelist():
            if name.endswith('/'+suffix):
                data = json.loads(bundle.read(name))
                print(suffix,'keys',list(data.keys()))
                if suffix.startswith('tcap'):
                    record['tcap'] = dict(completed=data['completed'],cases=len(data['cases']),
                        mismatches=len(data['mismatches']),excluded=len(data['excluded']),
                        executable_sha256=data['executable_sha256'])
record['packages'] = {}
notice = (root/'vendor/terminfo/COPYING.ncurses').read_text().replace('\n','\r\n').encode()
for artifact in ('14332971661','14332545690'):
    with zipfile.ZipFile(base/(artifact+'.zip')) as bundle:
        files = {}
        for name in bundle.namelist():
            data = bundle.read(name)
            files[name] = dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
            if name.endswith('.exe'):
                files[name]['embedded_ncurses_notice_offset'] = data.find(notice)
        record['packages'][artifact] = files
print('package identities',json.dumps(record['packages'],indent=2))
(base/'final-file-verification.json').write_text(json.dumps(record,indent=2)+'\n')
