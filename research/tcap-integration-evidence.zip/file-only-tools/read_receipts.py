"""Summarize downloaded JSON only; never launch the tested executable."""
from pathlib import Path
import json
import sys
import zipfile

base = Path(__file__).resolve().parent/'retained'
for run in sys.argv[1:]:
    for archive in (base/run).glob('*.zip'):
        with zipfile.ZipFile(archive) as bundle:
            names = bundle.namelist()
            for name in names:
                if name.endswith(('SOURCE-HOST.json', 'identity.json', 'tcap-keys-observed.json',
                                  'dpi-real-gdi-en.json', 'dpi-real-gdi-zh-CN.json')):
                    data = json.loads(bundle.read(name).decode('utf-8-sig'))
                    result = {key:data[key] for key in ('completed','executable_sha256','executable_bytes',
                        'Executable','SourceCommit','source_commit','fixture_commit','scope') if key in data}
                    if 'cases' in data:
                        result['cases'] = len(data['cases'])
                    if 'mismatches' in data:
                        result['mismatches'] = len(data['mismatches'])
                        result['excluded'] = len(data['excluded'])
                    print(run, name, json.dumps(result))
            pages = controls = 0
            for name in names:
                if name.endswith('-settings.json'):
                    data = json.loads(bundle.read(name))
                    pages += len(data.get('pages', []))
                    controls += sum(len(p.get('controls', [])) for p in data.get('pages', []))
            if pages:
                print(run, archive.name, 'pages', pages, 'controls', controls)
