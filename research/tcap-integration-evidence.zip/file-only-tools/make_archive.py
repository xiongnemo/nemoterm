"""Package downloaded records only; no build, test or product execution."""
from pathlib import Path
import hashlib
import io
import json
import zipfile

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
entries = {}
for run in sorted((base/'retained').iterdir()):
    for source in sorted(run.iterdir()):
        if source.suffix in ('.json','.log'):
            entries[f'{run.name}/{source.name}'] = source.read_bytes()
    for source in sorted(run.glob('*.zip')):
        receipt = json.loads(source.with_suffix('.receipt.json').read_text())
        if receipt['name'].startswith('source-console-host'):
            with zipfile.ZipFile(source) as bundle:
                identity = json.loads(bundle.read('SOURCE-HOST.json'))
                product = bundle.read('nemoterm.exe')
                actual = dict(bytes=len(product), sha256=hashlib.sha256(product).hexdigest())
                if actual['bytes'] != identity['Executable']['Bytes'] or actual['sha256'] != identity['Executable']['SHA256']:
                    raise ValueError('Product receipt mismatch')
                entries[f'{run.name}/SOURCE-HOST.json'] = bundle.read('SOURCE-HOST.json')
                entries[f'{run.name}/downloaded-image-verification.json'] = json.dumps(actual, indent=2).encode()
        elif receipt['name'].startswith(('nemoterm-single-exe-x64-', 'nemoterm-windows-x64-', 'nemoterm-portable-notices-')):
            with zipfile.ZipFile(source) as bundle:
                identities = {}
                for name in bundle.namelist():
                    data = bundle.read(name)
                    identities[name] = dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
                    if not name.endswith(('.exe','.dll')):
                        entries[f'{run.name}/{source.stem}.package-files/{name}'] = data
                if 'PACKAGING-REPLAY.json' in bundle.namelist():
                    verification = json.loads(bundle.read('PACKAGING-REPLAY.json'))
                    for name, expected in verification['original_files'].items():
                        if identities[name] != expected:
                            raise ValueError('Repacked original changed: '+name)
                elif 'SOURCE-HOST.json' in bundle.namelist():
                    host = json.loads(bundle.read('SOURCE-HOST.json'))['Executable']
                    if identities['OpenConsole.exe'] != dict(bytes=host['Bytes'],sha256=host['SHA256']):
                        raise ValueError('Portable host identity mismatch')
                else:
                    evidence = json.loads((run/'final-file-verification.json').read_text())
                    expected = evidence['single_validation']
                    if identities != {'nemoterm.exe':dict(bytes=expected['executable_bytes'],sha256=expected['executable_sha256'])}:
                        raise ValueError('Single image identity mismatch')
                entries[f'{run.name}/{source.stem}.package-verification.json'] = json.dumps(identities,indent=2).encode()
        elif receipt['name'].startswith('dpi-evidence') and source.stat().st_size > 3000000:
            selected = io.BytesIO()
            with zipfile.ZipFile(source) as original, zipfile.ZipFile(selected, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
                for name in original.namelist():
                    representative = ('tabs-cold-200-0-' in name and
                        name.endswith(('-keyboard.png','-terminfo.png','-extended.png')))
                    if name.endswith(('.json','.log','.md')) or representative:
                        item = zipfile.ZipInfo(name, (2026,11,17,0,0,0))
                        item.compress_type = zipfile.ZIP_DEFLATED
                        output.writestr(item, original.read(name))
            entries[f'{run.name}/{source.stem}.selected.zip'] = selected.getvalue()
        else:
            entries[f'{run.name}/{source.name}'] = source.read_bytes()
for name in ('retain_remote.py', 'make_archive.py', 'read_receipts.py', 'final_receipt.py'):
    entries['file-only-tools/'+name] = (base/name).read_bytes()
manifest = dict(scope='Selected immutable remote evidence. Source-host and package binaries are omitted after file-only identity verification; package metadata and per-file hashes remain. Large DPI artifacts retain all JSON/logs and representative 200 percent screenshots in explicitly named selected ZIPs. Original download receipts remain unchanged.',
                files={name:dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest()) for name,data in entries.items()})
entries['MANIFEST.json'] = (json.dumps(manifest, indent=2)+'\n').encode()
target = root/'research/tcap-integration-evidence.zip'
with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name,data in sorted(entries.items()):
        item = zipfile.ZipInfo(name, (2026,11,17,0,0,0))
        item.compress_type = zipfile.ZIP_DEFLATED
        bundle.writestr(item,data)
print(target.name, 'entries',len(entries),'bytes',target.stat().st_size,'sha256',hashlib.sha256(target.read_bytes()).hexdigest())
