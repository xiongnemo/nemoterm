"""Download immutable remote run evidence; do not execute downloaded programs."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess
import sys
import zipfile

base = Path(__file__).resolve().parent / 'retained'
base.mkdir(exist_ok=True)
repository = 'repos/xiongnemo/nemoterm'

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--artifact-regex', default='.')
parser.add_argument('runs', nargs='+')
args = parser.parse_args()
for run_id in args.runs:
    destination = base/run_id
    destination.mkdir(exist_ok=True)
    run = json.loads(subprocess.check_output(['gh', 'api', f'{repository}/actions/runs/{run_id}']))
    if run['status'] != 'completed':
        raise RuntimeError('Refusing incomplete metadata: '+run_id)
    for name, endpoint in [('run', f'runs/{run_id}'), ('jobs', f'runs/{run_id}/jobs?per_page=100'),
                           ('artifacts', f'runs/{run_id}/artifacts?per_page=100')]:
        content = subprocess.check_output(['gh', 'api', f'{repository}/actions/{endpoint}'])
        (destination/(name+'.json')).write_bytes(content)
    artifacts = json.loads((destination/'artifacts.json').read_bytes())
    for artifact in artifacts['artifacts']:
        if not re.search(args.artifact_regex, artifact['name']):
            continue
        target = destination/(str(artifact['id'])+'.zip')
        if not target.exists():
            with target.open('wb') as output:
                subprocess.run(['gh', 'api', f"{repository}/actions/artifacts/{artifact['id']}/zip"],
                               stdout=output, check=True)
        with zipfile.ZipFile(target) as archive:
            if archive.testzip() is not None:
                raise RuntimeError('Corrupt download')
        receipt = dict(id=artifact['id'], name=artifact['name'], bytes=target.stat().st_size,
                       sha256=hashlib.sha256(target.read_bytes()).hexdigest())
        (destination/(str(artifact['id'])+'.receipt.json')).write_text(json.dumps(receipt, indent=2)+'\n')
    print(run_id, run['head_sha'], run['conclusion'], 'retained', len(list(destination.glob('*.zip'))), 'original ZIPs', flush=True)
